#!/bin/sh

cd /apps/resources
jar vfu $1 *.*

