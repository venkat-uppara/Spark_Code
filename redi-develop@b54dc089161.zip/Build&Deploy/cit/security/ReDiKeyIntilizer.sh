#!/bin/sh
#Create a Shell script to check the validity of the keytab and initialize
kinit -kt /home/srvredi/srvredi.service.keytab srvredi@IPA.AM.TSACORP.COM
klist >> /home/srvredi/output.txt # Capture the status of the keytab initialization status