#!/bin/sh

/usr/hdp/2.6.5.0-292/spark2/bin/spark-submit --master yarn --driver-memory 12G --executor-memory 8G --executor-cores 4  \
--jars $(echo /apps/ReDi/ReDi/RS_Trans_Dataflow/target/lib/*.jar | tr ' ' ',') \
--class com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess /apps/ReDi/ReDi/RS_Trans_Dataflow/target/RS_Trans_Dataflow-1.0-SNAPSHOT.jar \
-Djava.security.krb5.conf="/etc/krb5.conf" \
-Djava.security.auth.login.config="/apps/ReDiKeyTabs/jaas.conf"

