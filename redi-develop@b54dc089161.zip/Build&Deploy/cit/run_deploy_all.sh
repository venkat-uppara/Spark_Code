#!/bin/sh

echo -n Password:
read -s password

extra_var1="ansible_ssh_pass=$password"


echo "Deploying ReDi HDP code into edge node" 
ansible-playbook ../scripts/deploy-ReDi.yml --inventory-file=ReDiInventory-CIT.yml --user=buildtest  --extra-vars=$extra_var1

