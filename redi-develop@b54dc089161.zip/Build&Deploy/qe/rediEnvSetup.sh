echo "###############################################################################"
echo "START- setting up total environment variable for session"
echo "###############################################################################"

export ORACLE_URL="jdbc:oracle:thin:@10.13.21.110:1521:RSCIT01"
export MODS_USER_NAME="MODS"
export MODS_PASSWORD="aci110MODS"
export SYBASE_DRIVER="com.sybase.jdbc3.jdbc.SybDriver"
export SYBASE_USERNAME="MODS"
export SYBASE_PASSWORD="R3D1#mods"
export SYBASEIQ_DRIVER="jdbc:sybase:Tds:10.13.33.210:10000/DATABASE=REDIDEVIQ"
export HDFS_LOCATION="/user/srvredi/redi"
export SCRIPT_PATH="/home/srvredi/ReDi"
export HIVE_BEELINE_PATH="jdbc:hive2://cov3lhdpmst01.am.tsacorp.com:2181,cov3lhdpmst02.am.tsacorp.com:2181,cov3lhdpmst03.am.tsacorp.com:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2-hive2"

echo "###############################################################################"
echo "END- setting up total environment variable for session"
echo "###############################################################################"

