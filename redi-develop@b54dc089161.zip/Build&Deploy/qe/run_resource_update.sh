#!/bin/sh

cd resources
jar vfu $1 *.*

