#!/bin/bash
########################################################################################################
# Created / Version : 05-Aug-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	kcs
# Description : Adhoc clienttimezone update for Client
########################################################################################################
Update_ClientTimeZone()
{
TODAY=`date +%Y-%m-%d:%H:%M:%S` 
echo ""Executed on date: $TODAY""
echo "Enter the Clientid for which update needs to be done." 
read clientid 
echo "Entered Clientid is:"${clientid} 
export whrvalue=${clientid}
echo "ENTER THE TIMEZONE VALUE TO BE UPDATED"
read newtzone
echo "Entered Timezonevalue is:"${newtzone}
export tzvalue=${newtzone}
if [  -z "$whrvalue" ] || [  -z "$tzvalue" ];then
echo "You did not enter proper values.Please enter proper values"
 exit 1
fi
echo "Executing the hive query - starts"
hive -e "update redi.rbi_ref_client set tzclient='${tzvalue}' where clientid=${clientid}"
echo "Executing the hive query - ends"
}
Update_ClientTimeZone | tee -a tzlog.txt
