#!/bin/bash
########################################################################################################
# Created / Version : 05-Aug-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	kcs
# Description : Adhoc Subclienttimezone update for SUbclient
########################################################################################################
Update_SubClientTimeZone()
{
TODAY=`date +%Y-%m-%d:%H:%M:%S` 
echo ""Executed on date: $TODAY""
echo "Enter the clientid for which you want to update timezone"
read clientid
echo "Entered Clientid is:"${clientid}
export whrvalue=${clientid}
echo "Enter the Subclientid for which you want to update timezone"
read subclientid
echo "Entered Subclientid is:"${subclientid}
export whrvalue1=${subclientid}
echo "ENTER THE TIMEZONE VALUE TO BE UPDATED"
read newtzone
echo "Entered TimeZonevalue is:"${newtzone}
export tzvalue=${newtzone}

if [  -z "$whrvalue" ] || [  -z "$tzvalue" ];then
echo "You did not enter proper values.Please enter proper values"
 exit 1
fi
echo "Executing the hive query - starts"
hive  -e "update redi.rbi_ref_client set tzsubclient='${tzvalue}' where clientid=${clientid} and subclientid=${subclientid}"
echo "Executing the hive query - ends"
}
Update_SubClientTimeZone | tee -a tzsublog.txt
