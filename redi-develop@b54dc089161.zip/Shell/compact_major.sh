#!/bin/bash
########################################################################################################
# Created / Version :21-Jun-2019 / Initial Draft
#  Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	Venkat 
# Description : Manual Comapaction Scripts
########################################################################################################

DATE=`date +%Y%m%d`
Hive_URL="jdbc:hive2://nxu22hdpmst001.ise.pos.net:2181,nxu22hdpmst002.ise.pos.net:2181,nxu22hdpmst003.ise.pos.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2"

########################################################################################################
# Major_Compaction started for redi.trans_master_core
########################################################################################################

echo `date` + " : Major Compaction started for redi.trans_master_core " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

count="$(hdfs dfs -ls /warehouse/tablespace/managed/hive/redi.db/trans_master_core|grep -c `date +%Y%m%d`)"

echo `date` + " : Current day partition available check (1-Yes, 0-No) :  " $count >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

if [ $count -gt 0 ]

then

beeline -u ${Hive_URL} -e "alter table redi.trans_master_core partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a /apps/ReDi/compaction/trans_master_core.txt

Error=`cat /apps/ReDi/compaction/trans_master_core.txt | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for redi.trans_master_core : "  >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
	
else

    echo `date` + " : Major Compaction not Successfully for redi.trans_master_core : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
	
    mailx -s  `date` + " : Major Compaction not Successfully for redi.trans_master_core :" grp-aci-fp-app-support@aciworldwide.com
fi

else

    echo `date` + " : no partition folders found today for compaction on redi.trans_master_core table : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
   mailx -s  `date` + " :no partition folders found today for compaction on redi.trans_master_core table: " grp-aci-fp-app-support@aciworldwide.com
fi

########################################################################################################
# Major_Compaction Completed for redi.trans_master_core
########################################################################################################


########################################################################################################
# Major_Compaction Started for redi.bi_trans_master_core
########################################################################################################

echo `date` + " : Major Compaction started for redi.bi_trans_master_core " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

count="$(hdfs dfs -ls /warehouse/tablespace/managed/hive/redi.db/bi_trans_master_core|grep -c `date +%Y%m%d`)"

echo `date` + " : Current day partition available check (1-Yes, 0-No) :  " $count >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

if [ $count -gt 0 ]

then

beeline -u ${Hive_URL} -e "alter table redi.bi_trans_master_core partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a /apps/ReDi/compaction/bi_trans_master_core.txt

Error=`cat /apps/ReDi/compaction/bi_trans_master_core.txt | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for redi.bi_trans_master_core : "  >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
		
else

    echo `date` + " : Major Compaction not Successfully for redi.bi_trans_master_core : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
	
    mailx -s  `date` + " : Major Compaction not Successfully for redi.bi_trans_master_core : " grp-aci-fp-app-support@aciworldwide.com

fi

else

    echo `date` + " : no partition folders found today for compaction on  bi_trans_master_core table : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
  mailx -s  `date` + " :no partition folders found today for compaction on  bi_trans_master_core table: " grp-aci-fp-app-support@aciworldwide.com
fi

########################################################################################################
# Major_Compaction Completed for redi.bi_trans_master_core
########################################################################################################


########################################################################################################
# Major_Compaction Started for redi.bi_trans_detail
########################################################################################################

echo `date` + " : Major_Compaction started for redi.bi_trans_detail " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

count="$(hdfs dfs -ls /warehouse/tablespace/managed/hive/redi.db/bi_trans_detail | grep -c `date +%Y%m%d`)"

echo `date` + " : Current day partition available check (1-Yes, 0-No) :  " $count >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

if [ $count -gt 0 ]

then

beeline -u ${Hive_URL} -e "alter table redi.bi_trans_detail partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a /apps/ReDi/compaction/bi_trans_detail.txt

Error=`cat /apps/ReDi/compaction/bi_trans_detail.txt | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for redi.bi_trans_detail : "  >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
else
    echo `date` + " : Major Compaction not Successfully for redi.bi_trans_detail : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
	
   mailx -s  `date` + " : Major Compaction not Successfully for redi.bi_trans_detail : " grp-aci-fp-app-support@aciworldwide.com
	
fi

else

    echo `date` + " : no partition folders found today for compaction on  bi_trans_detail table : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
  mailx -s  `date` + " :no partition folders found today for compaction on  bi_trans_detail table : " grp-aci-fp-app-support@aciworldwide.com
fi

########################################################################################################
# Major_Compaction Completed for redi.bi_trans_detail
########################################################################################################


########################################################################################################
# Major_Compaction Started for redi.bi_trans_rule_hits
########################################################################################################

echo `date` + " : Major Compaction started for redi.bi_trans_rule_hits " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

count="$(hdfs dfs -ls /warehouse/tablespace/managed/hive/redi.db/bi_trans_rule_hits | grep -c `date +%Y%m%d`)"

echo `date` + " : Current day partition available check (1-Yes, 0-No) :  " $count >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

if [ $count -gt 0 ]

then

beeline -u ${Hive_URL} -e "alter table redi.bi_trans_rule_hits partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a /apps/ReDi/compaction/bi_trans_rule_hits.txt

Error=`cat /apps/ReDi/compaction/bi_trans_rule_hits.txt | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for redi.bi_trans_rule_hits : "  >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log	
else
    echo `date` + " : Major Compaction not Successfully for redi.bi_trans_rule_hits : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log

	mailx -s  `date` + " : Major Compaction not Successfully for redi.bi_trans_rule_hits  : " grp-aci-fp-app-support@aciworldwide.com
	
fi

else

    echo `date` + " : no partition folders found today for compaction on  bi_trans_rule_hits table : " >> /apps/ReDi/compaction/logs/compaction_major_`date +"%d-%m-%Y"`.log
  
  mailx -s  `date` + " :no partition folders found today for compaction on  bi_trans_rule_hits table: " grp-aci-fp-app-support@aciworldwide.com
fi

########################################################################################################
# Major_Compaction Completed for redi.bi_trans_rule_hits
########################################################################################################

########################################################################################################
# Removing the Temp file  Started 
########################################################################################################
rm  /apps/ReDi/compaction/trans_master_core.txt
rm  /apps/ReDi/compaction/bi_trans_master_core.txt
rm  /apps/ReDi/compaction/bi_trans_detail.txt
rm  /apps/ReDi/compaction/bi_trans_rule_hits.txt
########################################################################################################
# Removing the Temp file  Completed 
########################################################################################################
 

