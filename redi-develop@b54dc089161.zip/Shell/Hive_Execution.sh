#!/bin/sh

source /home/srvredi/ReDi/ReDiEnv/rediEnvSetup.sh

echo "Hive Table Schema  creation started "

beeline -u ${HIVE_BEELINE_PATH} -f ${SCRIPT_PATH}/hive/schema/createschema.hql

echo "Hive Table Schema  creation completed "
  
echo "Hive Table Creation is Started "

for entry in ${SCRIPT_PATH}/hive/Tables/*
 do
  echo "Hive Table creation : file name is :"  $entry
  beeline -u ${HIVE_BEELINE_PATH} -f  $entry
  echo "Hive Table is created :"  $entry
 done

 echo "Hive Table Creation is Completed "
 
 echo "Hive View Creation is Started "

for entry in ${SCRIPT_PATH}/hive/views/*
 do
  echo "Hive View creation : file name is :"  $entry
  beeline -u ${HIVE_BEELINE_PATH} -f  $entry
  echo "Hive View is created :"  $entry
 done

 echo "Hive View Creation is Completed "

echo "Hive DML execution started "

beeline -u ${HIVE_BEELINE_PATH} -f ${SCRIPT_PATH}/hive/dml/createHighWaterMarks.hql

echo "Hive DML execution completed "




