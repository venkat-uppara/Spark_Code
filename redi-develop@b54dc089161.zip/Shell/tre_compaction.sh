#!/bin/bash
########################################################################################################
# Created / Version :30-Jul-2019 / Initial Draft
# Created By		 : 	Babu 
# Description : Manual Comapaction Scripts
# Modified Version / Modified By / Date
#
########################################################################################################

if [ "$#" -ne 1 ]; then
        echo "Please refer the below usage example...
        Ex: sh $0 path
        Usage: sh $0 /home/srvredi/apps/ReDi/conf"
        exit 1
fi

source $1/rediEnvSetup.sh

DATE=`date +%Y%m%d`

Database="redi"

TreRuleHitsTable="rule_hits_ingestion"
TreFeaturesTable="dynamic_feature_data"
HDFS_WAREHOUSE_LOCATION="/warehouse/tablespace/managed/hive"

BaseDirectory="/home/srvredi/compaction"

if [ -d ${BaseDirectory}/logs ];then
        echo "$BaseDirectory directory exists..."
else
        mkdir -p ${BaseDirectory}/logs
fi

LogFile="${BaseDirectory}/logs/compaction_major_`date +'%d-%m-%Y'`.log"
RuleHitsTextFile="${BaseDirectory}/${TreRuleHitsTable}.txt"
FeaturesTextFile="${BaseDirectory}/${TreFeaturesTable}.txt"

########################################################################################################
# Major_Compaction started for ${Database}.${TreRuleHitsTable}
########################################################################################################

echo `date` + " : Major Compaction started for ${Database}.${TreRuleHitsTable} " >> ${LogFile}

count="$(hdfs dfs -ls ${HDFS_WAREHOUSE_LOCATION}/${Database}.db/${TreRuleHitsTable}|grep -c ${DATE})"

echo `date` + " : Current day partition available check (1-Yes, 0-No) : " $count >> ${LogFile}

if [ $count -gt 0 ]

then

	echo "Compaction started for: ${DATE} " >> ${LogFile}
	beeline -u ${HIVE_BEELINE_PATH} -e "alter table ${Database}.${TreRuleHitsTable} partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a ${RuleHitsTextFile}

Error=`cat ${RuleHitsTextFile} | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for ${Database}.${TreRuleHitsTable} : "  >> ${LogFile}
	
else

    echo `date` + " : Major Compaction not Successfully for ${Database}.${TreRuleHitsTable} : " >> ${LogFile}
	
    mailx -s  `date` + " Major Compaction not Successfully for ${Database}.${TreRuleHitsTable} " grp-aci-fp-app-support@aciworldwide.com
fi

else

    echo `date` + " : no partition folders found today for compaction on ${Database}.${TreRuleHitsTable} table : " >> ${LogFile}
   echo " no partition folders found today for compaction on ${Database}.${TreRuleHitsTable} table " | mailx -s  `date` + " no partition folders found today for compaction on ${Database}.${CoreTable} table " grp-aci-fp-app-support@aciworldwide.com
   
fi

########################################################################################################
# Major_Compaction Completed ${Database}.${TreRuleHitsTable}
########################################################################################################

########################################################################################################
# Major_Compaction started for ${Database}.${TreFeaturesTable}
########################################################################################################

echo `date` + " : Major Compaction started for ${Database}.${TreFeaturesTable} " >> ${LogFile}

count="$(hdfs dfs -ls ${HDFS_WAREHOUSE_LOCATION}/${Database}.db/${TreFeaturesTable}|grep -c ${DATE})"

echo `date` + " : Current day partition available check (1-Yes, 0-No) : " $count >> ${LogFile}

if [ $count -gt 0 ]

then

	echo "Compaction started for: ${DATE} " >> ${LogFile}
	beeline -u ${HIVE_BEELINE_PATH} -e "alter table ${Database}.${TreFeaturesTable} partition(oiddateyyyymmdd=${DATE}) compact 'major';" 2>&1 | tee -a ${FeaturesTextFile}

Error=`cat ${FeaturesTextFile} | grep -i "ERROR"`

RES=`echo $ERROR|awk '{print match($0,"ERROR")}'`

if [ $RES -eq 0 ]; then 

	echo `date` + " : Major compaction successfully triggered for ${Database}.${TreFeaturesTable} : "  >> ${LogFile}
	
else

    echo `date` + " : Major Compaction not Successfully for ${Database}.${TreFeaturesTable} : " >> ${LogFile}
	
    mailx -s  `date` + " Major Compaction not Successfully for ${Database}.${TreFeaturesTable} " grp-aci-fp-app-support@aciworldwide.com
fi

else

    echo `date` + " : no partition folders found today for compaction on ${Database}.${TreFeaturesTable} table : " >> ${LogFile}
   echo " no partition folders found today for compaction on ${Database}.${TreFeaturesTable} table " | mailx -s  `date` + " no partition folders found today for compaction on ${Database}.${CoreTable} table " grp-aci-fp-app-support@aciworldwide.com
   
fi

cat ${LogFile}
cat ${RuleHitsTextFile}
cat ${FeaturesTextFile}
########################################################################################################
# Major_Compaction Completed ${Database}.${TreFeaturesTable}
########################################################################################################

########################################################################################################
# Removing the Temp file  Started 
########################################################################################################
#rm  ${RuleHitsTextFile}
#rm  ${FeaturesTextFile}
########################################################################################################
# Removing the Temp file  Completed 
########################################################################################################
 

