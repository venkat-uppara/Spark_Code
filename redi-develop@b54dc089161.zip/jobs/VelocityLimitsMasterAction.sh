#!/bin/sh

########################################################################################################
# Created / Version : 27-Mar-2019 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	Venkat
# Description : Spark submit script for VelocityLimitsMasterAction
########################################################################################################
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --driver-memory 4G --executor-memory 2G --num-executors 8 --executor-cores 2 --queue ReDi-Batch --deploy-mode cluster --conf spark.memory.fraction=0.8 --conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s --conf spark.driver.extraClassPath="/usr/hdp/current/spark2-client/jars/ojdbc6-11.2.0.3.jar" --keytab /etc/security/keytabs/srvredi.keytab --principal srvredi@AOD.LOCAL --conf spark.security.credentials.hiveserver2.enabled=false --jars $(echo /apps/ReDi/ReDi_ext_jars/core*.jar,/apps/ReDi/ReDi_ext_jars/encryptor-1.0.jar,/apps/ReDi/lib/config-1.3.2.jar,/apps/ReDi/lib/log4j*.jar,/apps/ReDi/lib/ojdbc6-11.2.0.3.jar,/usr/share/java/kafka-rest/*.jar,/usr/share/java/confluent-common/*.jar,/apps/ReDi/lib/avro-1.8.2.jar,/apps/ReDi/lib/ReDi_common-1.0-SNAPSHOT.jar,/usr/hdp/current/hive_warehouse_connector/*.jar | tr ' ' ',' ) --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf" --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" --files "/etc/security/keytabs/jaas.conf,/etc/security/certs/schema_keystore.jks" --class com.aciworldwide.ra.redi.tre.ruledetails.actions.VelocityLimitsMasterAction /apps/ReDi/lib/TRE_Rule_Details-1.0-SNAPSHOT.jar

return_code=$?

if [[ ${return_code} -ne 0 ]]; then

    echo "VelocityLimitsMasterAction job has failed" 
   exit ${return_code}
fi

echo " VelocityLimitsMasterAction Job succeeded" 
 
exit 0
