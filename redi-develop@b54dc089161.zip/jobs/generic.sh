#!/bin/sh

SPARK_OPTS="-Djava.security.krb5.conf=krb5.conf \
    -Dlog4j.configurationFile=log4j2.xml \
    -Djava.security.auth.login.config=jaas.conf \
    -Dconfig.file=application.conf \
    -Dsun.security.krb5.debug=true \
    -Dcom.ibm.security.krb5.Krb5Debug=all \
	-Djavax.net.ssl.trustStore=keytore \
    -Dcom.ibm.security.jgss.debug=all"
	
 
SPARK_DEBUG=0
if [[ $# != 12 ]]; then
    echo "Usage: $0 {driver_memory} {executor_memory} {num_executors}{executor_cores} {queue} {keytab} {principal} {files} {parallelism} {jars} {class} {jar}"
    exit 1
else
    DRIVER_MEMORY=${1}
    EXECUTOR_MEMORY=${2}
	NUM_EXECUTORS=${3}
    EXECUTOR_CORES=${4}
    SPARK_QUEUE=${5}
    SPARK_KEYTAB=${6}
    SPARK_PRINCIPAL=${7}
    SPARK_FILES=${8}
    SPARK_PARALLELISM=${9}
    SPARK_JARS=${10}
    SPARK_ACTION=${11}
    SPARK_JAR=${12}
fi

if [[ ${SPARK_DEBUG} == 1 ]]; then
    echo "driver_memory: ${DRIVER_MEMORY}"
	echo "executor_memory: ${EXECUTOR_MEMORY}"
	echo "num_executors: ${NUM_EXECUTORS}"
    echo "executor_cores: ${EXECUTOR_CORES}"
    echo "Queue: ${SPARK_QUEUE}"
    echo "Parallelism: ${SPARK_PARALLELISM}"
    echo "Action: ${SPARK_ACTION}"
    echo "Jar: ${SPARK_JAR}"
fi

/usr/hdp/current/spark2-client/bin/spark-submit \
        --master yarn \
        --driver-memory "${DRIVER_MEMORY}"  \
        --executor-memory "${EXECUTOR_MEMORY}" \
        --num-executors "${NUM_EXECUTORS}" \
        --executor-cores "${EXECUTOR_CORES}" \
        --queue "${SPARK_QUEUE}" \
        --deploy-mode cluster \
        --keytab "${SPARK_KEYTAB}" \
        --principal "${SPARK_PRINCIPAL}" \
        --files "${SPARK_FILES}" \
		--conf spark.security.credentials.hiveserver2.enabled="false" \
        --conf spark.sql.shuffle.partitions="${SPARK_PARALLELISM}" \
        --conf spark.default.parallelism="${SPARK_PARALLELISM}" \
        --conf spark.driver.extraClassPath="ojdbc6-11.2.0.3.jar" \
        --conf spark.executor.extraClassPath="ojdbc6-11.2.0.3.jar" \
        --conf spark.driver.extraJavaOptions="${SPARK_OPTS}" \
        --conf spark.executor.extraJavaOptions="${SPARK_OPTS}" \
        --conf spark.memory.fraction=0.8 \
		--conf spark.tez.cancel.delegation.tokens.on.completion="false" \
        --conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
        --jars "${SPARK_JARS}" \
        --class "${SPARK_ACTION}" "${SPARK_JAR}"

# EOF

