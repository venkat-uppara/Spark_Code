#!/bin/bash
########################################################################################################
# Created / Version : 05-Aug-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	kcs
# Description : For running BedCBDataProcess job and handling its restart mechanism (retry for 5 times and write the log)
########################################################################################################
 n=0
   until [ $n -ge 5 ]
   do
      sh /apps/ReDi/scripts/BedCBDataProcess.sh && break
    n=$[$n+1]
	sleep 30
	  echo "BedCBDataProcess job has failed" | mailx -s "BedCBDataProcess job has failed" grp-aci-fp-app-support@aciworldwide.com
	  done
