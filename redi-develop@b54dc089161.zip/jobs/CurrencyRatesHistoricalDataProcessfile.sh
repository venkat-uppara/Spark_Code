#!/bin/sh

########################################################################################################
# Created / Version : 27-Mar-2019 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	Venkat
# Description : Spark submit script for CurrencyRatesHistoricalDataProcessFile
########################################################################################################
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --driver-memory 4G --executor-memory 2G --num-executors 8 --executor-cores 2 --queue ReDi-Batch --deploy-mode cluster \
--conf spark.memory.fraction=0.8 \
--conf spark.scheduler.maxRegisteredResourcesWaitingTime=60s \
--conf spark.driver.extraClassPath="/usr/hdp/current/spark2-client/jars/ojdbc6-11.2.0.3.jar" \
--conf spark.security.credentials.hiveserver2.enabled=false \
--keytab /etc/security/keytabs/srvredi.keytab --principal srvredi@AOD.LOCAL \
--jars $(echo /apps/ReDi/lib/config-1.3.2.jar,/apps/ReDi/ReDi_ext_jars/core*.jar,/apps/ReDi/ReDi_ext_jars/encryptor-1.0.jar,/apps/ReDi/lib/log4j*.jar,/apps/ReDi/lib/ojdbc6-11.2.0.3.jar,/usr/hdp/current/hive_warehouse_connector/*.jar | tr ' ' ',' ) \
--class com.aciworldwide.ra.redi.common.actions.CurrencyRatesHistoricalDataProcessFile /apps/ReDi/lib/ReDi_common-1.0-SNAPSHOT.jar

return_code=$?

if [[ ${return_code} -ne 0 ]]; then

    echo "Job failed" 
   exit ${return_code}
fi

echo " CurrencyRatesHistoricalDataProcessFile Job succeeded" 
 
exit 0

