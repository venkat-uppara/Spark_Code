#!/bin/sh

########################################################################################################
# Created / Version : 05-Aug-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	kcs
# Description : Spark submit script for TREFeaturesKafkaConsumer
########################################################################################################
/usr/hdp/current/spark2-client/bin/spark-submit --master yarn --driver-memory 8G --executor-memory 12G --num-executors 2 --executor-cores 5 --queue ReDi-Stream --deploy-mode cluster --keytab /etc/security/keytabs/srvredi.keytab --principal srvredi@AOD.LOCAL --jars $(echo /apps/ReDi/lib/ReDi_common-1.0-SNAPSHOT.jar,/apps/ReDi/ReDi_ext_jars/spark-sql-kafka-0-10_2.11-2.3.2.3.1.0.10-1.jar,/apps/ReDi/ReDi_ext_jars/kafka-avro-serializer-5.1.0.jar,/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-5.1.0.jar,/apps/ReDi/ReDi_ext_jars/kafka-schema-registry-client-5.1.0.jar,/apps/ReDi/ReDi_ext_jars/kafka-streams-avro-serde-5.1.0.jar,/apps/ReDi/ReDi_ext_jars/common*.jar,/apps/ReDi/ReDi_ext_jars/abris_2.11-2.2.2.jar,/apps/ReDi/lib/spark-avro_2.11-4.0.0.jar,/apps/ReDi/ReDi_ext_jars/encryptor*.jar,/apps/ReDi/ReDi_ext_jars/core*.jar,/apps/ReDi/lib/config-1.3.2.jar,/usr/hdp/current/hive_warehouse_connector/*.jar,/apps/ReDi/ReDi_ext_jars/kafka-clients-2.1.0-cp2.jar,/apps/ReDi/ReDi_ext_jars/avro-1.8.2.jar,/apps/ReDi/lib/log4j* | tr ' ' ',' ) --conf spark.security.credentials.hiveserver2.enabled=false --conf "spark.driver.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" --conf "spark.executor.extraJavaOptions=-Djava.security.auth.login.config=jaas.conf -Djavax.net.ssl.trustStore=schema_keystore.jks" --conf spark.datasource.hive.warehouse.disable.pruning.and.pushdowns=true --conf "spark.yarn.am.nodeLabelExpression=spark_nodes" --conf "spark.yarn.executor.nodeLabelExpression=spark_nodes" --files "/etc/security/keytabs/jaas.conf,/etc/security/certs/schema_keystore.jks" --class com.aciworldwide.ra.redi.tre.features.actions.TREFeaturesKafkaConsumer /apps/ReDi/lib/TRE_Features-1.0-SNAPSHOT.jar


return_code=$?

if [[ ${return_code} -ne 0 ]]; then

    echo "Job failed" 
   exit ${return_code}
fi

echo " TREFeaturesKafkaConsumer Job succeeded" 
 
exit 0

