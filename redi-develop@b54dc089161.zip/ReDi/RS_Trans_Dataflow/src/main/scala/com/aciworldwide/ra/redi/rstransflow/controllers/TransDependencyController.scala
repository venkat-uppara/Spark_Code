package com.aciworldwide.ra.redi.rstransflow.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.dao.TransFlowDao
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{Column, DataFrame, SaveMode, SparkSession}

class TransDependencyController(spark: SparkSession) extends Loggers with ReDiSerializers
  with Serializable with DatabaseServices with ReDiTableSchemas with RSTransFlowCommonUtils with CommonUtils with ReDiConstants {


  @transient lazy val transDependencyLogger = LogManager.getLogger(getClass.getName)

  import spark.implicits._

  //var rbiDf: DataFrame = _

  val ref_bin_data = gettheDataFromHive(spark, RBI_REF_BIN_DATA_TABLE)
  // val rbiDf = gettheDataFromHive(spark, "redi_qe.ext_rbi_client_prod")
  val rsTransFlowDao = new TransFlowDao(spark)
  val CusClientId = ConfigFactory.load().getString("local.common.Custom_Client.Macys")

  val TempStreamTable = ConfigFactory.load().getString("local.common.Custom_Client.TempStreamTable")
  val TempHistoryTable = ConfigFactory.load().getString("local.common.Custom_Client.TempHistoryTable")
  val HistoryRun = ConfigFactory.load().getString("local.common.Custom_Client.HistoryRun").toBoolean
  //val rbiRefClient = gettheDataFromHiveForRef(spark, REDI_RBI_REF_CLIENT).select($"ClientID", $"SubClientID", $"clientset")
  //rbiDf = rbiRefClient.select($"ClientSet").where($"ClientSet".contains("CREDECLINE"))


  /** Author :Yeswanth.S
    * Date:21/09/2018
    * Integration of Dataframes from TransCoreMaster,TransDetail and TransRuleHits based on the dependencies.
    *
    * */

  /*def c(tablename: String, format: String, inputdataset: DataFrame): Unit = {
    inputdataset.write.mode(format).insertInto(tablename)
  }*/

  /**
    * @author :Krushna 04/09/2018
    *         Transformation for country matching
    */

  /* Assigning the default value to the country matching variables */

  def matchCountryTransformation(inputdataframe: DataFrame, transDetailDf: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Country Transformation Starts")
    val countryPhase1 = CountrymatchingPhase1(inputdataframe)
    val countryPhase2 = CountrymatchingPhase2(countryPhase1, transDetailDf)
    joindf1countrymatchingdf(countryPhase2)

  }

  def CountrymatchingPhase1(CountrymatchingdfInit: DataFrame): DataFrame = {
    val countrymatchingdf = CountrymatchingdfInit
      .withColumn("MatchCountryBillShip", when(col("BillCountry").isNotNull && col("ShipCountry").isNotNull && col("BillCountry") === col("ShipCountry"), "Y").otherwise("N"))
      .withColumn("MatchCountryBillIP", when(col("BillCountry").isNotNull && col("VirtIPIDCountryEBG").isNotNull && col("BillCountry") === col("VirtIPIDCountryEBG"), "Y").otherwise("N"))
      .withColumn("MatchCountryBillBin", when(col("BillCountry").isNotNull && col("VirtBin").isNotNull && col("BillCountry") === col("VirtBin"), "Y").otherwise("N"))
      .withColumn("MatchCountryShipIP", when(col("ShipCountry").isNotNull && col("VirtIPIDCountryEBG").isNotNull && col("ShipCountry") === col("VirtIPIDCountryEBG"), "Y").otherwise("N"))
      .withColumn("MatchCountryShipBin", when(col("ShipCountry").isNotNull && col("VirtBin").isNotNull && col("ShipCountry") === col("VirtBin"), "Y").otherwise("N"))
      .withColumn("MatchCountryIPBin", when(col("VirtIPIDCountryEBG").isNotNull && col("VirtBin").isNotNull && col("VirtIPIDCountryEBG") === col("VirtBin"), "Y").otherwise("N"))
      .withColumn("MatchCountryAnyMismatch", when(col("MatchCountryBillShip") === "N", "Y")
        .when(col("MatchCountryBillIP") === "N", "Y")
        .when(col("MatchCountryBillBin") === "N", "Y")
        .when(col("MatchCountryShipIP") === "N", "Y")
        .when(col("MatchCountryShipBin") === "N", "Y")
        .when(col("MatchCountryIPBin") === "N", "Y")
        .when(concat(col("MatchCountryBillShip"), col("MatchCountryBillIP"), col("MatchCountryBillBin"), col("MatchCountryShipIP"), col("MatchCountryShipBin"), col("MatchCountryIPBin")) === "YYYYYY", "N")
        .otherwise("X"))
      .withColumn("MatchZipBillShip", when(col("BillZipcd").isNotNull && col("ShipZipcd").isNotNull && col("BillZipcd") === col("ShipZipcd"), "Y").otherwise("N"))

    countrymatchingdf

  }


  def CountrymatchingPhase2(CountrymatchingPhase1: DataFrame, transDetailDf: DataFrame): DataFrame = {

//    val cntrydf1 = transDetailDf
//      .select($"oid", $"RecipientState".alias("xState"), $"RecipientCity".alias("xCity"), $"RecipientZipCd".alias("xZipCd"))
//      .groupBy(col("Oid"))
//      .agg(max("xState").as("RecipientState"), max("xCity").as("RecipientCity"), max("xZipCd").as("RecipientZipCd"))
//
//    CountrymatchingPhase1.join(cntrydf1, Seq("oid"))


    CountrymatchingPhase1
      .withColumn("RecipientState",$"RecipientColumns.RecipientState")
      .withColumn("RecipientCity",$"RecipientColumns.RecipientCity")
      .withColumn("RecipientZipCd",$"RecipientColumns.RecipientZipCd")
      .drop("RecipientColumns")
  }

  def joindf1countrymatchingdf(Phase2DF: DataFrame): DataFrame = {
    //val countrymatchingdf4 = Phase1DF.join(Phase2F, Seq("OID"), "left_outer")
    Phase2DF
      .withColumn("MatchStateBillShip", when(col("BillState").isNotNull && col("ShipState").isNotNull
        && col("BillState") === col("ShipState"), "Y").otherwise("N"))
      .withColumn("VirtIpidCity", when(col("VirtIpidCity").isNull, lit(null))
        .otherwise(upper(col("VirtIpidCity"))))
      .withColumn("MatchCityBillIP", when(col("BillCity").isNotNull && col("VirtIpidCity").isNotNull
        && col("BillCity") === col("VirtIpidCity"), "Y").otherwise("N"))
      .withColumn("VirtIpidUsState", when(col("VirtIpidUsState").isNull, lit(null))
        .otherwise(upper(col("VirtIpidUsState"))))
      .withColumn("MatchStateBillIP", when(col("BillState").isNotNull && col("VirtIpidUsState").isNotNull
        && col("BillState") === col("VirtIpidUsState"), "Y").otherwise("N"))
      .withColumn("MatchStateShipIP", when(col("ShipState").isNotNull && col("VirtIpidUsState").isNotNull
        && col("ShipState") === col("VirtIpidUsState"), "Y").otherwise("N"))
      .withColumn("MatchZipBillRecip", when(col("BillZipcd").isNotNull && col("RecipientZipCd").isNotNull
        && col("BillZipcd") === col("RecipientZipCd"), "Y").otherwise("N"))
      .withColumn("MatchStateRecipIP", when(col("BillState").isNotNull && col("RecipientState").isNotNull
        && col("BillState") === col("RecipientState"), "Y").otherwise("N"))

    //countrymatchingdf4
  }

  /** End of MERF-9241 */


  def StoreDateToHive(database: String, tablename: String, format: String, inputdataset: DataFrame): Unit = {
    inputdataset.write.format(HIVE_WAREHOUSE_CONNECTOR)
      .option("database", database)
      .mode(format)
      .option("table", tablename)
      .save()
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Successfully stored data into Hive")
  }

  /*
    def StoreMainTransdataFromTempTableintoHive(tablename: String, format: String, partitionColumn: String, inputdataset: DataFrame): Unit = {
      inputdataset.createOrReplaceTempView("tableDataframe")
      spark.sql(s"insert into $tablename PARTITION ($partitionColumn) select * from tableDataframe")
    }*/


  /** ***********************CORE->DETAIL->RULE HITS ************************************/
  /*These are the transformation on Core which having dependency on Details Dataframe:Result will stored to Core*/
  def coreDependenciesOnDetailsDF(transCoreDF: DataFrame, transDetailsDF: DataFrame,hiveSession: HiveWarehouseSession): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Master Core dependency on Trans Details Starts")
    val countrymatchingdf = matchCountryTransformation(transCoreDF, transDetailsDF)
    val transformBinDataDF = transformBinData(countrymatchingdf, ref_bin_data, transDetailsDF)
    val getShipMethodDF = getShipMethodFromItemSummaryAndRegion(transformBinDataDF, transDetailsDF)
    val MacyTransformationDF = MacyTransformation(getShipMethodDF, transDetailsDF,hiveSession)
    MacyTransformationDF

    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Master Core dependency on Trans Details Finished")
  }

  /*These are the transformation on Core which having dependency on ruleHits Dataframe:Result will stored to Core*/
  def coreDependenciesOnRuleHitsDF(transCoreDF: DataFrame, ruleHitsDF: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Master Core dependency on Trans Rule Hits Starts")
    var coreOnruleHitsDF: DataFrame = null
    // if (!transCoreDF.head(1).isEmpty || !ruleHitsDF.head(1).isEmpty) {

    //val initialRecommedStatusDetaildf = initialRecommedStatusDetail(transCoreDF, ruleHitsDF)
    //val fraudYnDF = UpdateFraudYN(transCoreDF, ruleHitsDF)
    val initialReconnTransDF = InitialReconnTrans(transCoreDF)
    val updateRecReasonDF = updateRecReason(initialReconnTransDF)
    val updateRecReasonWithNineDF = updateRecReasonWithNine(updateRecReasonDF, ruleHitsDF)
    val updateRecReasonThreeDF = updateRecReasonThree(updateRecReasonWithNineDF)
    val updateRecReasonwithTSWDF = updateRecReasonwithTSW(updateRecReasonThreeDF, ruleHitsDF)
    coreOnruleHitsDF = updateRecReasonwithTSWDF.withColumn("Whenloaded", current_time_utc())
    /* }
    else {
      coreOnruleHitsDF = transCoreDF
    }*/
    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Master Core dependency on Trans Rule Hits Finished")
    coreOnruleHitsDF
  }

  /** ***********************END ***************************************************/


  /** ***********************DETAIL->CORE->RULE HITS ************************************/
  /*These are the transformation on Details which having dependency on Core Dataframe:Result will stored to Detail*/
  //need to handle nulls here

  def detailDependenciesOnCoreDF(transDetailsDF: DataFrame, transCoreDF: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Details dependency on Trans Master Core Starts")
    var detailOnCoreDF: DataFrame = null
    /*    if (!transDetailsDF.head(1).isEmpty || !transCoreDF.head(1).isEmpty)
          detailOnCoreDF = transDetailsDF
        else*/
    detailOnCoreDF = transDetailsDF

    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Details dependency on Trans Master Core Finished")
    detailOnCoreDF
  }

  def detailDependenciesOnRuleHitsDF(transDetailsDF: DataFrame, ruleHitsDF: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Details dependency on Trans Rule Hits Starts")
    var detailOnRuleHitsDF: DataFrame = null

    detailOnRuleHitsDF = transDetailsDF.withColumn("Whenloaded", current_time_utc())


    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Details dependency on Trans Rule Hits  Finished")
//    detailOnRuleHitsDF.dropDuplicates(Seq("oid", "LINENUMBER"))
    detailOnRuleHitsDF
  }

  /** ***********************END ***************************************************/

  /** ***********************RULE HITS->CORE->DETAIL ************************************/
  /*These are the transformation on RuleHits which having dependency on Core Dataframe:Result will stored to RuleHits*/
  def ruleHitsDependenciesOnCoreDF(ruleHitsDF: DataFrame, transCoreDF: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Rule Hits dependency on Trans Core Starts")
    var ruleHitsOnCoreDF: DataFrame = null
    ruleHitsOnCoreDF = ruleHitsDF
    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Rule Hits dependency on Trans Details  Finished")
    ruleHitsOnCoreDF
  }

  /*These are the transformation on RuleHits which having dependency on Details Dataframe:Result will stored to RuleHits*/
  def ruleHitsDependenciesOnDetailsDF(ruleHitsDF: DataFrame, transDetailsDF: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Rule Hits dependency on Trans Details Starts")
    var ruleHitsOnDetailsDF: DataFrame = null
    ruleHitsOnDetailsDF = ruleHitsDF.withColumn("Whenloaded", current_time_utc())
    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation for applying Trans Rule Hits dependency on Trans Details  Finished")
    ruleHitsOnDetailsDF
  }

  /** ***********************END ************************************/

  def reorderTransSourceTableSchema(columnString: String, inputdateFrame: DataFrame): DataFrame = {

    val columns: Array[String] = columnString.split(",")
    val outputDataFrame = inputdateFrame.select(columns.head, columns.tail: _*)

    outputDataFrame
  }


  def processDependencies(coreDF: DataFrame, detailsDF: DataFrame, ruleHitsDF: DataFrame,hiveSession: HiveWarehouseSession): Map[String, DataFrame] = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": ProcessDependencies Starts..")

    val finalCoreDF = reorderTransSourceTableSchema(REDI_TRANS_MASTER_COL_ORDER, coreDependenciesOnRuleHitsDF(coreDependenciesOnDetailsDF(coreDF, detailsDF,hiveSession), ruleHitsDF))
    val finalDetailDF = reorderTransSourceTableSchema(REDI_TRANS_DETAIL_COL_ORDER, detailDependenciesOnRuleHitsDF(detailDependenciesOnCoreDF(detailsDF, coreDF), ruleHitsDF))
    val finalRuleHitsDF = reorderTransSourceTableSchema(TRANS_RULE_HITS_COL_ORDER, ruleHitsDependenciesOnDetailsDF(ruleHitsDependenciesOnCoreDF(ruleHitsDF, coreDF), detailsDF))

    //transDependencyLogger.info(TRANSFLOWPROCESS_INFO + " Saving data using INSERT")

    //finalCoreDF.printSchema()

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Sending data to main flow controller.")
    Map("Trans_master" -> finalCoreDF, "Trans_detail" -> finalDetailDF, "Rule_hits" -> finalRuleHitsDF)

  }


  /** MERF-9244 */
  //Got wrong, look into it again
  /*  def prodDetailsTotal(coredf: DataFrame, detaildf: DataFrame): DataFrame = {
      transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Inside prod details method")
      val detailExplodedf = detaildf.select($"ProdQuantity", $"ProdUnitPrice", $"Oid", $"LINENUMBER")
      val coreExplodedf = coredf.select($"Oid", $"Total", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"recommend", $"report", $"authresp")
      val combinedDF = coreExplodedf.join(detailExplodedf, Seq("Oid"))
        .select($"Oid", $"Total", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"ProdQuantity", $"ProdUnitPrice", $"LINENUMBER", $"recommend", $"report", $"authresp")
      val prodfDf = combinedDF.withColumn("ProdTotal", prodTotal(col("ProdUnitPrice"), col("ProdQuantity")).cast("decimal(14,2)"))
        .withColumn("ProdTotalUSD", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalUSD", $"Total").cast("decimal(14,2)")))
        .withColumn("ProdTotalGBP", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalGBP", $"Total").cast("decimal(14,2)")))
        .withColumn("ProdTotalEUR", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalEUR", $"Total").cast("decimal(14,2)")))
        .withColumn("ProdTotalEUR", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalEUR", $"Total").cast("decimal(14,2)")))
        .withColumn("ProdTotalClientCurr", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalClient", $"Total").cast("decimal(14,2)")))
        .withColumn("ProdTotalSubClientCurr", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
          otherwise(prodTotalCurrency($"ProdTotal", $"TotalSubClient", $"Total").cast("decimal(14,2)")))
        .drop($"TotalGBP").drop($"TotalUSD").drop($"TotalEUR").drop($"TotalClient").drop($"TotalSubClient").drop($"Total")
        .drop($"ProdQuantity").drop($"ProdUnitPrice")

    val df = detaildf.join(prodfDf, Seq("Oid", "LINENUMBER")).dropDuplicates()
    df

  }*/


  def prodTotal: UserDefinedFunction = udf((prodUnitPrice: String, prodQuantity: String) => {
    //        transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Inside Product total UDF")
    var total: Double = 0.0
    if (prodUnitPrice != null && prodQuantity != null) {
      total = prodUnitPrice.toDouble * 1.0 * prodQuantity.toDouble
    }
    //        transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": END of Product total UDF")
    total
  })

  /*
    def prodTotalCurrency: UserDefinedFunction = udf((prodTotal: String, totalAllCurr: String, total: String) => {
      //        transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Inside prodTotalCurrency UDF")
      var totalForAllCurrencies: BigDecimal = 0.0
      if (prodTotal != null && total != null && totalAllCurr != null) {
        totalForAllCurrencies = prodTotal.toDouble * 1.0 * totalAllCurr.toDouble / total.toDouble
      }
      //        transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": END of prodTotalCurrency UDF")
      totalForAllCurrencies
    })
  */

  /** END MERF-9244 */


  /** MERF-9144 */

  /*  def setBinRefData = udf((bingDataFrmBinTable: String) => {
      var updBinVal = bingDataFrmBinTable
      updBinVal
    })*/

  def setCardTypeFull = udf((binCrdr: String, binType: String, cardType: String) => {
    var crdrTypeFull = ""
    if (binCrdr != null && !binCrdr.trim.isEmpty) {
      crdrTypeFull = binType + " " + binCrdr
    } else if (binType != null && !binType.trim.isEmpty) {
      crdrTypeFull = binType + " (Unknown Type)"
    }
    if (cardType == "U") {
      crdrTypeFull = null
    } else if (cardType == "P") {
      crdrTypeFull = "Private Label"
    }
    if (crdrTypeFull != null && !crdrTypeFull.trim.isEmpty) {
      crdrTypeFull = crdrTypeFull.toLowerCase.split(' ').map(_.capitalize).mkString(" ")
    }

    crdrTypeFull
  })

  def transformBinData(transCoreDF: DataFrame, ref_bin_data: DataFrame, transDtlDf: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Start of transformBinData Transformation")

//    val prodDtlDf = transDtlDf.select($"ProdDesc", $"Oid").cache()

    val transcoretempDf = transCoreDF.withColumn("cardbin", when($"CardNoMask".isNotNull && length($"CardNoMask").geq(lit("6")),
      substring(col("CardNoMask"),0,6)))

    val subSetBinData = ref_bin_data.select($"bin", $"bintype", $"bincrdr".as("refbincrdr"), $"bingroup".as("refbingroup"))
    val finalBinDf = subSetBinData.join(transcoretempDf, transcoretempDf.col("cardbin") === subSetBinData.col("bin"), "right_outer")

    val df4 = finalBinDf
      .withColumn("bingroup",when($"CardNoMask".isNotNull && length($"CardNoMask").leq(lit("14")) && $"cardtype" === lit("P"),null)
        .when($"cardtype" === lit("U"),null).otherwise(col("refbingroup")))
      .withColumn("bincrdr",when($"CardNoMask".isNotNull && length($"CardNoMask").leq(lit("14")) && $"cardtype" === lit("P"),null)
        .when($"cardtype" === lit("U"),null).otherwise(col("refbincrdr")))
      .withColumn("bindetail",when($"CardNoMask".isNotNull && length($"CardNoMask").leq(lit("14")) && $"cardtype" === lit("P"),null)
        .when($"cardtype" === lit("U"),null)
        .otherwise(when($"bintype".isNotNull && $"refbincrdr".isNotNull && length(concat(concat(col("bintype"),lit(":")),col("refbincrdr")))
          .gt(lit("40")),substring(concat(concat(col("bintype"),lit(":")),col("refbincrdr")),0,40)).
          when($"bintype".isNotNull && $"refbincrdr".isNotNull && length(concat(concat(col("bintype"),lit(":")),col("refbincrdr")))
            .leq(lit("40")),concat(concat(col("bintype"),lit(":")),col("refbincrdr")))
          .when($"bintype".isNull && $"refbincrdr".isNotNull,concat(lit(":"),col("refbincrdr")))
          .when($"bintype".isNotNull && $"refbincrdr".isNull,concat(col("bintype"),lit(":")))))
      .withColumn("cardbin",when($"CardNoMask".isNotNull && length($"CardNoMask").leq(lit("14")) && $"cardtype" === lit("P"),null)
        .when($"cardtype" === lit("U"),null).otherwise(col("cardbin")))
      .withColumn("cardtypefull", setCardTypeFull($"bincrdr", $"bintype", $"CardType"))
      /*.drop($"ProdDesc")*/.drop($"refbincrdr").drop($"refbingroup")

    /*val flag20DF1 = prodDtlDf.filter(col("ProdDesc").like("%VIRT%GIFT%CARD%")).groupBy($"OID").agg($"OID").select($"OID".as("rOid"))
    val flag20DF2 = prodDtlDf.filter(col("ProdDesc").like("%EGIFT%CARD%")).groupBy($"OID").agg($"OID").select($"OID".as("rOid"))
    val flag20DF3 = prodDtlDf.filter(col("ProdDesc").like("%ELECTRONIC%GIFT%CARD%")).groupBy($"OID").agg($"OID").select($"OID".as("rOid"))
    val flag20DF4 = prodDtlDf.filter(col("ProdDesc").like("%ONLINE%GIFT%CARD%")).groupBy($"OID").agg($"OID").select($"OID".as("rOid"))*/
//    val flag20DF5 = prodDtlDf.filter(col("ProdDesc").like("%GIFT%CARD%")).select($"OID".as("rOid")).distinct()
//
//    val flag20dfv = prodDtlDf.where($"ProdDesc".like("%VIRT%GIFT%CARD%") || $"ProdDesc".like("%EGIFT%CARD%") ||
//    $"ProdDesc".like("%ELECTRONIC%GIFT%CARD%") || $"ProdDesc".like("%ONLINE%GIFT%CARD%")).select($"oid".as("rOid")).distinct()
//
//    val finaltemp = updateFlag20V(df4,flag20dfv)
//    val finalDf = updateFlag20G(finaltemp,flag20DF5)

//    finalDf
    df4
  }
//  def updateFlag20V(coreDf: DataFrame, detailDf: DataFrame): DataFrame = {
//    val subDetailDf = detailDf.join(coreDf, coreDf("OID") === detailDf("rOid"), "right_outer")
//    val finalDetailDf = subDetailDf.withColumn("flag20", when($"flag20" =!= lit("V") && $"oid" === $"rOid", lit("V")))
//      .drop("rOid")
//
//    finalDetailDf
//  }
//
//
//  def updateFlag20G(coreDf: DataFrame, detailDf: DataFrame): DataFrame = {
//    val subDetailDf = detailDf.join(coreDf, coreDf("OID") === detailDf("rOid"), "right_outer")
//    val finalDetailDf = subDetailDf.withColumn("flag20", when($"flag20" === lit("N") && $"oid" === $"rOid", lit("G")).otherwise(col("flag20")))
//      .drop("rOid")
//
//    finalDetailDf
//
//  }




  def UpdateFraudYN(coreDf: DataFrame, ruleHits: DataFrame): DataFrame = {
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation Started for RealFraudYN")
    val subRuleHits = ruleHits.select($"OID", $"RuleSource").filter((col("RuleId").like("9%") || col("RuleId").like("B%")) && col("rulesource").isin("DVE","TSW")).select($"OID".as("rOid")).distinct()
      subRuleHits.join(coreDf,coreDf("OID")===subRuleHits("rOid"),"right_outer")
      .withColumn("RealFraudYN", when($"Recommendation" === lit("Deny") && $"oid" === $"rOid", lit("Y")).otherwise(lit("N")))
        .drop("rOid")
  }


  def checkRuleID(ruleId: String): String = {

    val ruleIDPattern1 = """^B.*$""".r
    val ruleIDPattern2 = """^9.*$""".r
    val ruleIDPattern3 = """^t_.*$""".r

    val matchCase = ruleId match {

      case ruleIDPattern1() => "INIT_B"
      case ruleIDPattern2() => "INIT_9"
      case ruleIDPattern3() => "INIT_T"
      case _ => "INIT_NONE"
    }
    matchCase
  }


  /** End of MERF-9144 */
  /** MERF-9080 & 10431 */
/*
  def setIgnoreRules = udf((recomendation: String) => {
    val ignoreRules = recomendation match {
      case "Test" | "AuthDec" | "NoScore" => {
        "Y"
      }
      case _ => {
        "N"
      }
    }
    ignoreRules
  })*/

  def setReconStatAndReason1 = udf((clientSet: String, AuthCode: String, recomend: String, flag: String, report: String) => {
    var outputRecomendStatus = ""
    var reason = ""
    var output: String = null
    var reasonCode: String = null
    var reasondf: DataFrame = null

    val clientdata: Boolean = clientSet.contains("CREDECLINE")

    if (clientSet != null && clientdata) {
      if ((AuthCode == "05") && (recomend.toUpperCase == "DENY")) {
        if (flag == "outComeReasonStatus") {
          output = "Decline"
        } else if (flag == "reason") {
          output = "Auth Decline"
        }
      }

      if (report == "0150" && recomend.toUpperCase == "ACCEPT") {
        if ((flag == "outComeReasonStatus") && output == null) {
          output = getCamelCasedStr(recomend.toUpperCase, "Recommendation")
        } else if (flag == "reason" && output == null) {
          output = "Always"
        }
      }
    }
    output
  })

  def setReconStatAndReason3 = udf((clientSet: String, AuthCode: String, recomend_in: String, flag: String, report_in: String) => {

    var outputRecomendStatus = ""
    var reason = ""
    var output: String = null
    var reasonCode: String = null
    var reasondf: DataFrame = null
    val clientdata: Boolean = clientSet.contains("CREDECLINE")
    var report: String = " "
    var recomend: String = " "

    if (report_in != null) report = report_in
    if (recomend_in != null) recomend = recomend_in

    if (clientSet != null && clientdata) {
      if (report == "1300" || report == "2000") {
        if ((flag == "outComeReasonStatus") && (output == null)) {
          output = getCamelCasedStr(recomend.toUpperCase, "Recommendation")
        } else if ((flag == "reason") && (output == null)) {
          output = "SDS"
        }
      }
      /*/****************MERF10431**************/

      if (ruleSource == "DVE" || ruleSource == "TSW") {

        if (checkRuleID(ruleId) == "INIT_B") {
          if (flag == "outComeReasonStatus") {
            output = getCamelCasedStr(recomend, "Recommend")
          } else if (flag == "reason") {
            output = "ReD Manual"
          }
        } else if (checkRuleID(ruleId) == "INIT_9") {
          if (flag == "outComeReasonStatus") {
            output = getCamelCasedStr(recomend, "Recommend")
          } else if (flag == "reason") {
            output = "Click/Block"
          }
        }
      }

      /***************END MERF 10431***********/*/


      if (report == "0250" && recomend.toUpperCase == "DENY") {
        if ((flag == "outComeReasonStatus") && (output == null)) {
          output = getCamelCasedStr(recomend.toUpperCase, "Recommendation")
        } else if ((flag == "reason") && (output == null)) {
          output = "Always"
        }

      }
      if (recomend.toUpperCase == "DENY" || recomend.toUpperCase == "CHALLENGE") {
        if ((flag == "outComeReasonStatus") && (output == null)) {
          output = getCamelCasedStr(recomend.toUpperCase, "Recommendation")
        } else if ((flag == "reason") && (output == null)) {
          output = "Rule"
        }
      }
      if (recomend.toUpperCase == "ACCEPT") {
        if ((flag == "outComeReasonStatus") && (output == null)) {
          output = getCamelCasedStr(recomend.toUpperCase, "Recommendation")
        } else if ((flag == "reason") && (output == null)) {
          output = "NoRule"
        }
      }
    }

    //val clientID:String = null
    if (clientSet != null && !clientdata) {
      if (flag == "outComeReasonStatus") {
        output = getCamelCasedStr(recomend, "Recommendation")
      } else if (flag == "reason") {
        //output = getCamelCasedReason(report, "OutcomeReason")
        output = getCamelCasedReason(report)
      }
    }

    /*/****************MERF10431**************/
    if (checkRuleID(ruleId) == "INIT_T"){

      if (flag == "outComeReasonStatus") {
        output = getCamelCasedStr(recomend, "Recommend")
      } else if (flag == "reason") {
        output = "TSW"
      }
    }
    /***************END MERF 10431***********/*/

    output
  })

/*  def checkClientSet = udf((clientSet: String) => {

    var output: String = null

    val clientdata: Boolean = clientSet.contains("CREDECLINE")

    if (clientSet != null && clientdata) {
      output = "1"
    }
    else {
      output = "0"
    }
    output
  })*/

  def getCamelCasedReason(sourceKey: String): String = {
    val x = ""
    if (sourceKey != null || !sourceKey.isEmpty) {
      sourceKey.toUpperCase match {
        case "0000" => "NoRule"
        case "0100" => "NoRule"
        case "0150" => "Always"
        case "0200" => "Auth Decline"
        case "0250" => "Always"
        case "0330" => "Rule"
        case "0700" => "Rule"
        case "0800" => "TSW"
        case "1300" => "SDS"
        case "2000" => "SDS"
        case _ => ""
      }
    } else {
      x
    }
  }

  //  def InitialReconnTrans(inputDf1: DataFrame): DataFrame = {
  //
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for challstatus,OutComeRecomStat,Reason,IgnoreRules,Recommendation")
  //    val initialReconnDf = inputDf1
  //      .withColumn("challstatus", when($"Recommendation".isNotNull, challangeStatus($"Recommendation")).otherwise(lit(null)))
  //      .withColumn("Recommendation", when($"Recommendation".isNotNull, updateRecomendations($"Recommendation")).otherwise(lit(null)))
  //      .withColumn("ignoreRules", when($"Recommendation".isNotNull, setIgnoreRules($"Recommendation")).otherwise(lit(null))).drop($"clientset")
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation finished for challstatus,OutComeRecomStat,Reason,IgnoreRules,Recommendation")
  //    initialReconnDf
  //  }

  def InitialReconnTrans(inputDf1: DataFrame): DataFrame ={

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for challstatus,OutComeRecomStat,Reason,IgnoreRules,Recommendation")
    val initialReconnDf = inputDf1
      .withColumn("challstatus", when(upper($"Recommendation").equalTo("CHALLENGE"),lit("NoAction")).otherwise(lit(null)))
      .withColumn("Recommendation", when($"Recommendation".isNotNull, updateRecomendations($"Recommendation")).otherwise(lit(null)))
      .withColumn("ignoreRules", when($"Recommendation".equalTo("Test") || $"Recommendation".equalTo("AuthDec") || $"Recommendation".equalTo("NoScore"), lit("Y"))
      .otherwise(lit("N"))
    )
    initialReconnDf
  }

  def updateRecReason(coreDF: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReason")

    val recReasonDF1 = coreDF.withColumn("outcomeRec", when($"authresp".isNull, lit(null)).when($"Recommendation".isNull, lit(null))
      .when($"report".isNull, lit(null)).otherwise(setReconStatAndReason1(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")), $"authresp", $"Recommendation", lit("outComeReasonStatus"), $"report")))
      .withColumn("outcomeReason", when($"authresp".isNull, lit(null)).when($"Recommendation".isNull, lit(null))
        .when($"report".isNull, lit(null)).otherwise(setReconStatAndReason1(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")), $"authresp", $"Recommendation", lit("reason"), $"report")))

    recReasonDF1
  }

/*  def updateRecReasonWithNine(coreDF: DataFrame, ruleHits: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReasonWithNine")

    val subRuleHitsNine = ruleHits.where("(ruleId like '9%' or ruleId like 'B%') and  rulesource in ('DVE','TSW')")
    .withColumn("ruleidstart", substring(col("ruleId"),0,1)).select($"OID".as("rOid"), $"ruleidstart").distinct()

    val subCoreHits = subRuleHitsNine.join(coreDF, coreDF("OID") === subRuleHitsNine("rOid"), "right_outer")

    coreDF.withColumn("challstatus",when(upper($"Recommendation").equalTo("CHALLENGE"),lit("NoAction")).otherwise(lit(null)))
      .withColumn("outcomeRec",when(($"outcomeRec".isNull||$"outcomeRec"==="")&& $"Oid"===$"rOid" && $"clientset".contains("CREDECLINE"),$"Recommendation").otherwise($"outcomeRec"))
      .withColumn("outcomeReason",when(($"outcomeReason".isNull||$"outcomeReason"==="")&& $"Oid"===$"rOid" && $"clientset".contains("CREDECLINE"),when($"rulestart" === "9", lit("Click/Block")).otherwise(lit("Red Manual"))).otherwise($"outcomeReason"))
      .drop("rOid")
      .drop("ruleidstart")
  }*/


  def updateRecReasonWithNine(coreDF: DataFrame, ruleHits: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReasonWithNine")

   /* val subRuleHitsNine = ruleHits.where("ruleId like '9%' and  rulesource in ('DVE','TSW')").select($"OID".as("rOid")).distinct()
    val subRuleHitsB = ruleHits.where("ruleId like 'B%' and rulesource in ('DVE','TSW')").select($"OID".as("rOid")).distinct()*/

//    val subRuleHitsNine = ruleHits.where("ruleId like '9%' and  rulesource in ('DVE','TSW')").select($"OID".as("rOid")).dropDuplicates()
//    val subRuleHitsB = ruleHits.where("ruleId like 'B%' and rulesource in ('DVE','TSW')").select($"OID".as("rOid")).dropDuplicates()

//    updateRecReasonWithB(updateRecReasonWithB(coreDF, subRuleHitsNine, "Click/Block"), subRuleHitsB, "Red Manual")
    coreDF.withColumn("challstatus",when(upper($"Recommendation").equalTo("CHALLENGE"),lit("NoAction")).otherwise(lit(null)))
      //      .withColumn("outcomeRec",when(($"outcomeRec".isNull||$"outcomeRec"==="")&& $"Oid"===$"rOid" && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")))==="1",$"Recommendation").otherwise($"outcomeRec"))
      .withColumn("outcomeRec",when(($"outcomeRec".isNull||$"outcomeRec"==="")&& ($"updateRecReasonWithNineFlag".contains("B") || $"updateRecReasonWithNineFlag".contains("9") || $"updateRecReasonWithNineFlag".contains("9B")) && $"clientset".contains("CREDECLINE"),$"Recommendation").otherwise($"outcomeRec"))
      //      .withColumn("outcomeReason",when(($"outcomeReason".isNull||$"outcomeReason"==="")&& $"Oid"===$"rOid" && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")))==="1",outcomeReason).otherwise($"outcomeReason"))
      .withColumn("outcomeReason",when(($"outcomeReason".isNull||$"outcomeReason"==="")&& ($"updateRecReasonWithNineFlag".contains("9") || $"updateRecReasonWithNineFlag".contains("9B")) && $"clientset".contains("CREDECLINE"),lit( "Click/Block"))
      .when(($"outcomeReason".isNull||$"outcomeReason"==="")&& $"updateRecReasonWithNineFlag".contains("B") && $"clientset".contains("CREDECLINE"),lit( "Red Manual")).otherwise($"outcomeReason"))
      .drop("updateRecReasonWithNineFlag")

  }

  //  def updateRecReasonWithB(coreDF: DataFrame, subRuleHits: DataFrame, outcomeReason: String): DataFrame = {
  //
  //    val subCoreHits = subRuleHits.join(coreDF, coreDF("OID") === subRuleHits("rOid"), "right_outer")
  //    val recReasonDF3 = subCoreHits.withColumn("challstatus", when($"Recommendation".isNotNull, challangeStatus($"Recommendation")).otherwise(lit(null)))
  //      .withColumn("outcomeRec", when(($"outcomeRec".isNull || $"outcomeRec" === "") && $"Oid" === $"rOid" && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue"))) === "1", $"Recommendation").otherwise($"outcomeRec"))
  //      .withColumn("outcomeReason", when(($"outcomeReason".isNull || $"outcomeReason" === "") && $"Oid" === $"rOid" && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue"))) === "1", outcomeReason).otherwise($"outcomeReason"))
  //      .drop("rOid")
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation finished for updateRecReasonWithB")
  //    recReasonDF3
  //  }

  def updateRecReasonThree(coreDF: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReason3")

    val recReasonDF4 = coreDF.withColumn("outcomeRec", when($"outcomeRec".isNull || $"outcomeRec" === "", setReconStatAndReason3(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")), when($"authresp".isNotNull, $"authresp").otherwise(lit("")), when($"Recommendation".isNotNull, $"Recommendation").otherwise(lit(" ")), lit("outComeReasonStatus"), when($"report".isNotNull, $"report").otherwise(lit("")))).when($"authresp".isNull, lit(null)).when($"Recommendation".isNull, lit(null))
      .when($"report".isNull, lit(null)).otherwise($"outcomerec"))
      .withColumn("outcomeReason", when($"outcomeReason".isNull || $"outcomeReason" === "", setReconStatAndReason3(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue")), when($"authresp".isNotNull, $"authresp").otherwise(lit("")), when($"Recommendation".isNotNull, $"Recommendation").otherwise(lit(" ")), lit("reason"), when($"report".isNotNull, $"report").otherwise(lit("")))).when($"authresp".isNull, lit(null)).when($"Recommendation".isNull, lit(null))
        .when($"report".isNull, lit(null)).otherwise($"outcomeReason"))

    recReasonDF4
  }

  //  def updateRecReasonwithTSW(coreDF: DataFrame, ruleHits: DataFrame): DataFrame = {
  //
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReasonwithTSW")
  //    val subRuleHits = ruleHits.where("rulesource='TSW'").groupBy($"OID").agg($"OID").select($"OID".as("rOid"))
  //    val subCoreHits = subRuleHits.join(coreDF, coreDF("OID") === subRuleHits("rOID"), "right_outer")
  //
  //    val recReasonDF5 = subCoreHits.withColumn("challstatus", when($"Recommendation".isNotNull, challangeStatus($"Recommendation")).otherwise(lit(null)))
  //      .withColumn("outcomeRec", when(($"outcomeRec".isNull || $"outcomeRec" === "") && ($"Oid" === $"rOid") && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue"))) === "1", $"Recommendation").otherwise($"outcomeRec"))
  //      .withColumn("outcomeReason", when(($"outcomeReason".isNull || $"outcomeReason" === "") && ($"Oid" === $"rOid") && checkClientSet(when($"clientset".isNotNull, $"clientset").otherwise(lit("novalue"))) === "1", lit("TSW")).otherwise($"outcomeReason"))
  //      .drop($"rOid")
  //      .drop($"clientset")
  //
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation finished for updateRecReasonwithTSW")
  //    recReasonDF5
  //  }


  def updateRecReasonwithTSW(coreDF:DataFrame,ruleHits:DataFrame):DataFrame={

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation started for updateRecReasonwithTSW")
//    val subRuleHits = ruleHits.where("rulesource='TSW'").select($"OID".as("rOid")).distinct()
//    val subCoreHits = subRuleHits.join(coreDF, coreDF("OID") === subRuleHits("rOID"), "right_outer")

    val recReasonDF5 = coreDF.withColumn("outcomeRec",when(($"outcomeRec".isNull||$"outcomeRec"==="")&& $"updateRecReasonwithTSWFlag".contains("TSW") && $"clientset".contains("CREDECLINE"),$"Recommendation").otherwise($"outcomeRec"))
      .withColumn("outcomeReason",when(($"outcomeReason".isNull||$"outcomeReason"==="")&& $"updateRecReasonwithTSWFlag".contains("TSW") && $"clientset".contains("CREDECLINE"),lit("TSW")).otherwise($"outcomeReason"))
      .drop($"updateRecReasonwithTSWFlag")
      .drop($"clientset")

    recReasonDF5
  }


  def getCamelCasedStr(sourceKey: String, sourceColumn: String): String = {
    if (sourceKey != null || !sourceKey.isEmpty) {
      sourceKey.toUpperCase match {
        case "ALLOW" => "Allow"
        case "ALWAYS ACCEPT" => "Always Accept"
        case "ALWAYS ALLOW" => "Always Allow"
        case "ALWAYS DENY" => "Always Deny"
        case "CHALLENGE" => "Challenge"
        case "CHALLANGE" => "Challenge"
        case "DENY" => "Deny"
        case "HARD ACCEPT" => "Hard Accept"
        case "ACCEPT(HARD)" => "Hard Accept"
        case "HARD CHALLENGE" => "Hard Challenge"
        case "SOFT DENY" => "Soft Deny"
        case "SOFT ACCEPT" => "Soft Accept"
        case "SOFT CHALLENGE" => "Soft Challenge"
        case "CHALLENGE(SOFT)" => "Soft Challenge"
        case "NO RECOMMENDATION" => "Silent"
        case "RECORD RULE ID" => "Silent"
        case "OBSERVE" => "Silent"
        case "UNKNOWN" => "Unknown"
        case "NOSCORE" => "NoScore"
        case "ACCEPT" => "Accept"
        case "AUTHDEC" => "AuthDec"
        case "Accept" => "Accept"
        case "NoScore" => "NoScore"
        case "PREAUTH" => "PreAuth"
        case _ => "Unknown Recommendation"
      }
    } else {
      null
    }
  }

  /** END OF 9080 & 10431 */
  def challangeStatus = udf((recomendation: String) => {

    var challangeStatus = ""
    if (recomendation.toUpperCase == "CHALLENGE") {
      challangeStatus = "NoAction"
    }
    challangeStatus
  })

  def updateRecomendations = udf((recomendations: String) => {
    val sourceColumn = "Recommendation"
    val updRecomendations = getCamelCasedStr(recomendations, sourceColumn)

    updRecomendations

  })

  /** MERF-10761 and MERF-11224 Starts */
  //  def MacyTransformation(detailDF: DataFrame, coreDF: DataFrame): DataFrame = {
  //
  //
  //    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Macy Transformation on product Starts")
  //
  //    val MacydetailDF50 = detailDF.select($"OID", $"ProdCd", $"ProdDesc", $"LINENUMBER")
  //      .where(col("ClientId") === CusClientId)
  //
  //    val MacydetailDFNOT50 = detailDF.select($"OID", $"ProdCd", $"ProdDesc", $"LINENUMBER")
  //      .where(col("ClientId") =!= CusClientId)
  //      .dropDuplicates("OID")
  //
  //    val Macydtlnewnot50 = MacydetailDFNOT50.withColumn("Flag01", lit(" ")).withColumn("Flag02", lit(" "))
  //      .withColumn("Flag03", lit(" "))
  //      .withColumn("Flag04", lit(" ")).withColumn("Flag05", lit(" ")).withColumn("Flag06", lit(" "))
  //      .withColumn("Flag07", lit(" "))
  //      .withColumn("Flag01Ct", lit(" ")).withColumn("Flag02Ct", lit(" ")).withColumn("Flag03Ct", lit(" "))
  //      .withColumn("Flag04Ct", lit(" "))
  //      .withColumn("Flag05Ct", lit(" ")).withColumn("Flag06Ct", lit(" ")).withColumn("Flag07Ct", lit(" "))
  //
  //
  //    val macytransformationDF = MacydetailDF50
  //      .groupBy("OID")
  //      .agg(sum(when(col("ProdCd") === "1700", 1).otherwise(0)).as("Flag01Ct"),
  //        sum(when(col("ProdCd") === lit("7000"), 1).otherwise(0)).as("Flag02Ct"),
  //        sum(when(col("ProdCd") === lit("7000") && col("ProdDesc").like("VIRTUAL%"), 1).
  //          otherwise(0)).as("Flag03Ct"),
  //        sum(when(col("ProdCd") === "1830" or col("ProdCd") === "2020", 1).otherwise(0)).as("Flag04Ct"),
  //        sum(when(col("ProdCd") === "2110", 1).otherwise(0)).as("Flag05Ct"),
  //        sum(when(col("ProdCd") === "2330", 1).otherwise(0)).as("Flag06Ct"),
  //        sum(when(col("ProdCd").isin("2330", "2320", "2340"), 1).otherwise(0)).as("Flag07Ct"),
  //        max("LINENUMBER").as("NumberofLines"))
  //      .withColumn("Flag01", when(col("Flag01Ct").equalTo(0), "N")
  //        .when(col("Flag01Ct") === col("NumberofLines"), "A").otherwise("S"))
  //      .withColumn("Flag02", when(col("Flag02Ct").equalTo(0), "N")
  //        .when($"Flag02Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("Flag03", when(col("Flag03Ct").equalTo(0), "N")
  //        .when($"Flag03Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("Flag04", when(col("Flag04Ct").equalTo(0), "N")
  //        .when($"Flag04Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("Flag05", when(col("Flag05Ct").equalTo(0), "N")
  //        .when($"Flag05Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("Flag06", when(col("Flag06Ct").equalTo(0), "N")
  //        .when($"Flag06Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("Flag07", when(col("Flag07Ct").equalTo(0), "N")
  //        .when($"Flag07Ct" === $"NumberofLines", "A").otherwise("S"))
  //      .withColumn("FlagsUsed", lit("Y"))
  //      .withColumn("Flag20", flag20update(col("Flag02"), col("Flag03")))
  //
  //
  //    val finalcore = macytransformationDF.union(Macydtlnewnot50)
  //
  //      .drop($"ProdCd").drop($"ProdDesc")
  //      .drop($"Flag01Ct").drop($"Flag02Ct").drop($"Flag03Ct")
  //      .drop($"Flag04Ct").drop($"Flag05Ct").drop($"Flag06Ct")
  //      .drop($"Flag07Ct")
  //      .drop($"LINENUMBER")
  //    val MacycoreDF50 = coreDF.filter($"ClientId" === CusClientId).
  //      withColumn("Recommendation", when(col("authresp").isNotNull && col("authresp") =!= "00"
  //        && col("authresp") =!= "01", lit("AuthDec")).otherwise(col("Recommendation")))
  //      .withColumn("Flag10", when(col("Userdata01").isNull or col("Userdata02").isNull, "X")
  //        .otherwise(propcard(col("Userdata01"), col("Userdata02"))))
  //
  //    val MacycoreDFNOT50 = coreDF.filter($"ClientId" =!= CusClientId)
  //
  //    val coreDFedit = MacycoreDF50.union(MacycoreDFNOT50)
  //      .drop("Flag01").drop("Flag02").drop("Flag03").drop("Flag04")
  //      .drop("Flag05").drop("Flag06").drop("Flag07").drop("Flag20")
  //      .drop("FlagsUsed")
  //
  //    val macyfinaldf: DataFrame = coreDFedit.join(finalcore, Seq("Oid"))
  //
  //    macyfinaldf
  //  }


  def MacyTransformation(coreDF: DataFrame, detailDF: DataFrame,hiveSession: HiveWarehouseSession): DataFrame = {

    var tempTable:String=" "
    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Macy Transformation on product Starts")

    val MacydetailDF50 = detailDF.select($"OID", $"ProdCd", $"ProdDesc", $"LINENUMBER")
      .where(col("ClientId") === CusClientId)


    if ( HistoryRun ){
      tempTable = TempHistoryTable
      MacydetailDF50.write.mode(SaveMode.Overwrite).format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector") .option("table",TempHistoryTable) .save
    }
    else {
      tempTable = TempStreamTable
      MacydetailDF50.write.mode(SaveMode.Overwrite).format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector") .option("table",TempStreamTable) .save
    }

    //MacydetailDF50.write.mode(SaveMode.Overwrite).format("com.hortonworks.spark.sql.hive.llap.HiveWarehouseConnector") .option("table",tempTable) .save
    val macytransformationDF =  hiveSession.executeQuery(s"""
     select oid,MFlag01,MFlag02,MFlag03,MFlag04,MFlag05,MFlag06,MFlag07,
     "Y" as MFlagsUsed,
     case
     when temp.MFlag03 != "N" THEN "V"
     when temp.MFlag02 != "N" and temp.MFlag03 != "N" THEN "G"
     END as MFlag20
     from (
     select oid,
     case
     when t.Flag01Ct = 0 THEN "N"
     when t.Flag01Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag01,
     case
     when t.Flag02Ct = 0 THEN "N"
     when t.Flag02Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag02,
     case
     when t.Flag03Ct = 0 THEN "N"
     when t.Flag03Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag03,
     case
     when t.Flag04Ct = 0 THEN "N"
     when t.Flag04Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag04,
     case
     when t.Flag05Ct = 0 THEN "N"
     when t.Flag05Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag05,
     case
     when t.Flag06Ct = 0 THEN "N"
     when t.Flag06Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag06,
     case
     when t.Flag07Ct = 0 THEN "N"
     when t.Flag07Ct = t.NumberofLines THEN "A"
     ELSE "S"
     END as MFlag07


     from (
     select oid,

     sum(case when ProdCd = "1700" THEN 1 ELSE 0 END) as Flag01Ct,
     sum(case when ProdCd = "7000" THEN 1 ELSE 0 END) as Flag02Ct,
     sum(case when ProdCd = "7000" and ProdDesc like "VIRTUAL%" THEN 1  ELSE 0 END) as Flag03Ct,

     sum(case when ProdCd = "1830" or ProdCd = "2020" THEN 1 ELSE 0 END)as Flag04Ct,
     sum(case when ProdCd = "2110" THEN 1 ELSE 0 END)as Flag05Ct,
     sum(case when ProdCd = "2330" THEN 1 ELSE 0 END)as Flag06Ct,
     sum(case when ProdCd in ("2330", "2320", "2340") THEN 1 ELSE 0 END)as Flag07Ct,
     max( LINENUMBER) as NumberofLines

     from

     $tempTable

     group By oid) t ) temp """)
   /* val macytransformationDF = MacydetailDF50
      .groupBy("OID")
      .agg(sum(when(col("ProdCd") === "1700", 1).otherwise(0)).as("Flag01Ct"),
        sum(when(col("ProdCd") === lit("7000"), 1).otherwise(0)).as("Flag02Ct"),
        sum(when(col("ProdCd") === lit("7000") && col("ProdDesc").like("VIRTUAL%"), 1).
          otherwise(0)).as("Flag03Ct"),
        sum(when(col("ProdCd") === "1830" or col("ProdCd") === "2020", 1).otherwise(0)).as("Flag04Ct"),
        sum(when(col("ProdCd") === "2110", 1).otherwise(0)).as("Flag05Ct"),
        sum(when(col("ProdCd") === "2330", 1).otherwise(0)).as("Flag06Ct"),
        sum(when(col("ProdCd").isin("2330", "2320", "2340"), 1).otherwise(0)).as("Flag07Ct"),
        max("LINENUMBER").as("NumberofLines"))
      .withColumn("MFlag01", when(col("Flag01Ct").equalTo(0), "N")
        .when(col("Flag01Ct") === col("NumberofLines"), "A").otherwise("S"))
      .withColumn("MFlag02", when(col("Flag02Ct").equalTo(0), "N")
        .when($"Flag02Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlag03", when(col("Flag03Ct").equalTo(0), "N")
        .when($"Flag03Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlag04", when(col("Flag04Ct").equalTo(0), "N")
        .when($"Flag04Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlag05", when(col("Flag05Ct").equalTo(0), "N")
        .when($"Flag05Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlag06", when(col("Flag06Ct").equalTo(0), "N")
        .when($"Flag06Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlag07", when(col("Flag07Ct").equalTo(0), "N")
        .when($"Flag07Ct" === $"NumberofLines", "A").otherwise("S"))
      .withColumn("MFlagsUsed", lit("Y"))
      .withColumn("MFlag20", flag20update(col("MFlag02"), col("MFlag03")))
      .drop($"ProdCd").drop($"ProdDesc")
      .drop($"Flag01Ct").drop($"Flag02Ct").drop($"Flag03Ct")
      .drop($"Flag04Ct").drop($"Flag05Ct").drop($"Flag06Ct")
      .drop($"Flag07Ct")
      .drop($"LINENUMBER")*/



    val MacycoreDF50 = coreDF//.filter($"ClientId" === CusClientId).
      .withColumn("Recommendation", when(col("ClientId") === CusClientId, when(col("authresp").isNotNull && col("authresp") =!= "00"
      && col("authresp") =!= "01", lit("AuthDec")).otherwise(col("Recommendation"))).otherwise(col("Recommendation")))
      .withColumn("Flag10", when(col("ClientId") === CusClientId, when(col("Userdata01").isNull or col("Userdata02").isNull, "X")
        .otherwise(propcard(col("Userdata01"), col("Userdata02")))).otherwise(col("Flag10")))

    val macyfinaldf: DataFrame = MacycoreDF50.join(macytransformationDF, Seq("Oid"), "left_outer")

    macyfinaldf
      .withColumn("Flag01", when(col("ClientId") === CusClientId,col("MFlag01")).otherwise(col("Flag01"))).drop(col("MFlag01"))
      .withColumn("Flag02", when(col("ClientId") === CusClientId,col("MFlag02")).otherwise(col("Flag02"))).drop(col("MFlag02"))
      .withColumn("Flag03", when(col("ClientId") === CusClientId,col("MFlag03")).otherwise(col("Flag03"))).drop(col("MFlag03"))
      .withColumn("Flag04", when(col("ClientId") === CusClientId,col("MFlag04")).otherwise(col("Flag04"))).drop(col("MFlag04"))
      .withColumn("Flag05", when(col("ClientId") === CusClientId,col("MFlag05")).otherwise(col("Flag05"))).drop(col("MFlag05"))
      .withColumn("Flag06", when(col("ClientId") === CusClientId,col("MFlag06")).otherwise(col("Flag06"))).drop(col("MFlag06"))
      .withColumn("Flag07", when(col("ClientId") === CusClientId,col("MFlag07")).otherwise(col("Flag07"))).drop(col("MFlag07"))
      .withColumn("FlagsUsed", when(col("ClientId") === CusClientId,col("MFlagsUsed")).otherwise(col("FlagsUsed"))).drop(col("MFlagsUsed"))
      .withColumn("Flag20", when(col("ClientId") === CusClientId,col("MFlag20")).otherwise(col("Flag20"))).drop(col("MFlag20"))
  }

  def flag20update: UserDefinedFunction = udf((flag02: String, flag03: String) => {

    var flag20: String = null

    if (flag03 != "N") {

      flag20 = "V"

    }

    if (flag02 != "N" && flag20 != "V") {
      flag20 = "G"
    }
    flag20

  })

  def propcard: UserDefinedFunction = udf((Userdata01: String, Userdata02: String) => {

    var Flag10: String = null
    var str1: String = null


    if (Userdata01 != null && Userdata02 != null) {

      val usrdata1len = Userdata01.length()
      val usrdata2len = Userdata02.length()
      val usrdat3 = substring(col("Userdata01"), 0, usrdata2len)

      val usrdata1 = Userdata01.split(',')
      if (usrdata1.take(0).isEmpty)
        str1 = usrdata1(0)
      var str2: String = null
      val usrdata2 = Userdata02.split(',')
      if (usrdata2.take(0).isEmpty)
        str2 = usrdata2(0)

      if ((str1 == str2) || (!Userdata01.contains(',') && !Userdata02.contains(',') && Userdata01 == Userdata02)) {
        Flag10 = "Y"
      }

      else if ((usrdata1len > usrdata2len) && col("Userdata02") == usrdat3) {
        Flag10 = "Z"
      }

      else if (usrdata1len > usrdata2len) {
        Flag10 = "Z"
      }
      else {
        Flag10 = "N"
      }
    }
    Flag10
  })

  def getShipMethodFromItemSummaryAndRegion(rawTransMsterDF: DataFrame, detailDF: DataFrame): DataFrame = {

    transDependencyLogger.info(TRANSFLOWPROCESS_INFO + ": Start of getShipMethodFromItemSummaryAndRegion Transformation")

    val maxItemShipMethod = detailDF.select($"Oid", $"ItemShipMethod")
      .groupBy($"Oid", $"ItemShipMethod".as("ShipMethod"))
      .agg(count($"ItemShipMethod").as("ItemShipMethodCount"))
      .withColumn("ItemShipMethodPriority", when($"ShipMethod".isin("N", "O", "T"), lit(0)).otherwise(lit(1)))
      .orderBy($"ItemShipMethodPriority".asc, $"ItemShipMethodCount".desc)
      .dropDuplicates("Oid")

    rawTransMsterDF.join(maxItemShipMethod, Seq("Oid"), "left_outer")
      .drop(col("ItemShipMethodPriority"))
      .drop(col("ItemShipMethodCount"))
  }
}

