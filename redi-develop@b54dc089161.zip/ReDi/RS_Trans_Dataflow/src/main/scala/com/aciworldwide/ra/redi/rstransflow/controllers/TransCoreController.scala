/**
  * @author :
  * @version : 1.0 Initial Draft
  * @usecase :
  * @note :
  */

package com.aciworldwide.ra.redi.rstransflow.controllers

/** Dependencies
  * Importing the dependent classes, objects or traits as required in the below processes
  */

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.dao.ClientMasterDataDao
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.dao.TransFlowDao
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.logging.log4j.LogManager
//import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TransCoreController extends Serializable with ReDiConstants {
  val simpleformat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
  simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

  val targetformat1 = new SimpleDateFormat(TARGDATEFORMAT)
  val targetformat2 = new SimpleDateFormat(DATEFORMATYYYYMMDD)

  def removeBlanks: UserDefinedFunction = udf((inputColumn: String) => {
    if (inputColumn != null || !inputColumn.isEmpty) {
      inputColumn.replace(" ", "")
    } else ""
  })

  /*  def ConvertTimeZoneO(inputdate: String, targetTimeZone: String): Timestamp = {
      targetformat1.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
      java.sql.Timestamp.valueOf(targetformat1.format(simpleformat.parse(inputdate)))
    }

    def ConvertTimeZoneYYYYMMDDO(inputdate: String, targetTimeZone: String): String = {
      targetformat2.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
      String.valueOf(targetformat2.format(simpleformat.parse(inputdate)))
    }*/

  def getCamelCasedStr(sourceKey: String, sourceColumn: String): String = {
    if (sourceKey != null || !sourceKey.isEmpty) {
      sourceKey.toUpperCase match {
        case "ALLOW" => "Allow"
        case "ALWAYS ACCEPT" => "Always Accept"
        case "ALWAYS ALLOW" => "Always Allow"
        case "ALWAYS DENY" => "Always Deny"
        case "CHALLENGE" => "Challenge"
        case "CHALLANGE" => "Challenge"
        case "DENY" => "Deny"
        case "HARD ACCEPT" => "Hard Accept"
        case "ACCEPT(HARD)" => "Hard Accept"
        case "HARD CHALLENGE" => "Hard Challenge"
        case "SOFT DENY" => "Soft Deny"
        case "SOFT ACCEPT" => "Soft Accept"
        case "SOFT CHALLENGE" => "Soft Challenge"
        case "CHALLENGE(SOFT)" => "Soft Challenge"
        case "NO RECOMMENDATION" => "Silent"
        case "RECORD RULE ID" => "Silent"
        case "OBSERVE" => "Silent"
        case "UNKNOWN" => "Unknown"
        case "NOSCORE" => "NoScore"
        case "ACCEPT" => "Accept"
        case "AUTHDEC" => "AuthDec"
        case "Accept" => "Accept"
        case "NoScore" => "NoScore"
        case "PREAUTH" => "PreAuth"
        case _ => "Unknown Recommendation"
      }
    } else {
      null
    }
  }

  def getHourPart(oidDate: String): String = {
    if (oidDate != null && !oidDate.isEmpty) {
      val hourPart = oidDate.substring(11, 13)
      hourPart
    } else {
      null
    }
  }

  /*  def getHourPart(OidDate: String, TimeZone: String): String = {
      var inputTimeZone = TimeZone
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }

      if (OidDate != null || !OidDate.isEmpty) {
        val ClientDate = ConvertTimeZoneO(OidDate, inputTimeZone)
        var clientHourPart = ClientDate.toString.substring(11, 13)
        clientHourPart
      } else {
        null
      }
    }*/

  def funcUkPostCodeFull: UserDefinedFunction = udf((billZipCdNorm: String) => {
    var outputStringPostCode: String = null
    if (((billZipCdNorm.length < 5) || billZipCdNorm.length > 7 || billZipCdNorm.substring(0, 1).matches(".*[^A-Z]+.*")
      || billZipCdNorm.toString.toUpperCase == "NOCODE"))
      outputStringPostCode = ""
    else
      outputStringPostCode = (billZipCdNorm.substring(0, billZipCdNorm.length - 3) + " " + billZipCdNorm.substring(billZipCdNorm.length - 3, billZipCdNorm.length)).toUpperCase

    outputStringPostCode
  })

  def funcUkPostCodeArea: UserDefinedFunction = udf((inputName: String) => {
    var outputStringPostCodeArea: String = null
    if (UKPOSTCODE.contains(inputName.substring(1, 2)))
      outputStringPostCodeArea = inputName.substring(0, 1)
    else
      outputStringPostCodeArea = inputName.substring(0, 2)
    outputStringPostCodeArea
  })
}

/** */
class TransCoreController(spark: SparkSession) extends Loggers with ReDiConstants with ReDiSerializers
  with Serializable with DatabaseServices with ReDiTableSchemas with RSTransFlowCommonUtils with CommonUtils {

  @transient lazy val transCoreLogger = LogManager.getLogger(getClass.getName)

  val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(spark).build()

  import spark.implicits._

  //  val NumRuleInfoSchema = new ArrayType(new StructType()
  //    .add("ServiceName", StringType, true)
  //    .add("NumRuleHits", StringType, true)
  //    .add("ErrorCount", StringType, true)
  //    .add("Answer", StringType, true)
  //    , true)

  // var currencyrates1: Broadcast[DataFrame] = _
  /* var valueBandsDf: Broadcast[DataFrame] = _
   var valueTransMetadataDf: Broadcast[DataFrame] = _*/

  val rsTransFlowDao = new TransFlowDao(spark)

  val countryDimensionbc = rsTransFlowDao.getCountryDimension(REDI_RBI_REF_COUNTRY_TABLE) //.cache()

  /* MERF-9082 Needed while merging */
  val clientMasterDataDao = new ClientMasterDataDao(spark)
  /*var dfRbiRefClientData: DataFrame = _
  var dfDistinctClientName: DataFrame = _
  var rbiDf: DataFrame = _*/
  val rbiRefDate = gettheDataFromHive(spark, REDI_RBI_REF_DATES_TABLE).select(col("DateTextShort"), col("WeekTextShort"), col("WeekYYMMDD"), col("MonthTextMed"), col("MonthYYYYMM"), col("DateYYMMDD"), col("WeekBTextShort"), col("WeekBYYMMDD"))

  /* @author KP - MERF-9082 REQUIRED for the transformation */
  //dfRbiRefClientData = gettheDataFromHiveForRef(spark, REDI_RBI_REF_CLIENT)
  //dfDistinctClientName = dfRbiRefClientData.select($"ClientID", $"ClientName").groupBy($"ClientID").agg(max($"ClientName").alias("ClientName"))
  //rbiDf = dfRbiRefClientData.select($"ClientId", $"SubclientId", $"ClientSet").where($"ClientSet".contains("AUTHDECLNE") && $"ClientId" != "000050")

  /** The processTransMasterCore is the main transformation process that initiates the transformations in the core controller.
    * The transformation starts with data type conversion of the initial data from executor and then the transformations that are
    * specific to the transaction core table. */

  def processTransMasterCore(rows: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Initial Transformation started for Transaction Master Core")
    val dataTypeDF = fntrRemovingUnusedCols(rows)
    val ruleHitsDetailsDF = fntrAddRuleHitsDetails(dataTypeDF)
    val finalTransMasterData = fntrCoreSpecificTransformation(ruleHitsDetailsDF)
    finalTransMasterData
  }


  /** The DataTypeConversion function is used to drop all unused columns in transaction core table from executor data.
    * Columns that needs to be converted are selected and the conversion is performed. */

  def fntrRemovingUnusedCols(indfExecutorData: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:fntrRemovingUnusedCols")

    val updateRecReasonWithNineAndTSW = indfExecutorData.withColumn("updateRecReasonWithNineFlag", returnFlagForupdateRecReasonWithNine(indfExecutorData("RuleMaster.RuleId")))
      .withColumn("updateRecReasonwithTSWFlag", updateRecReasonwithTSW(indfExecutorData("RuleMaster.RuleSource")))
      .withColumn("RecipientColumns", CountrymatchingPhase2(indfExecutorData("ProductDetail.RecipientState"), indfExecutorData("ProductDetail.RecipientCity"), indfExecutorData("ProductDetail.RecipientZipcd")))
      //                                                .withColumn("flag20", when(indfExecutorData("ProductDetail.ProdDesc").isNotNull, transformBinData(indfExecutorData("ProductDetail.ProdDesc"))).otherwise(lit("")))
      .withColumn("flag20", transformBinData(indfExecutorData("ProductDetail.ProdDesc")))


    val retdfCoreSpecificData = updateRecReasonWithNineAndTSW.drop($"ProductDetail").drop($"RuleMaster").drop($"ServiceProcess").drop($"RuleCategoryFlag")

    /** Returning Core Specific DataFrame that contains all the columns that are needed for the transaction core table. */
    retdfCoreSpecificData
  }

  /** To derive the DURATION fileds from ServiceProcess array as part of MERF-16429 user story */

  def fntrDeriveDurationFields(inputDF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:fntrDeriveDurationFields")

    val durationDF = inputDF.select($"oid", $"STARTTIME", $"oiddate", $"serviceprocess".as("DurationArray"))
      .select($"oid", $"STARTTIME", $"oiddate", explode_outer($"DurationArray").alias("DurationCols"))
	
    val durationColumnsTemp = durationDF.select($"oid", $"STARTTIME", $"DurationCols.servicename".as("ServiceName"), $"DurationCols.servicetype".as("ServiceType"), $"DurationCols.svcstarttime".as("SvcStartTime"), $"DurationCols.svcendtime".as("SvcEndTime"))
	
	//Here /1000 is nothing but converting the difference time in milliseconds to seconds
    val durationColumns = durationColumnsTemp.groupBy("oid").agg(
      first(when(($"ServiceName" === "CLI" && $"ServiceType" === "1"), $"SvcStartTime"), ignoreNulls = true).alias("RECEIVE_TIME"),
      first(when(($"ServiceName" === "CLI" && $"ServiceType" === "2"), ($"SvcEndTime".cast("long") - ($"STARTTIME".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION"),
      first(when(($"ServiceName" === "CLI" && $"ServiceType" === "1"), ($"SvcStartTime".cast("long") - ($"STARTTIME".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_VALID"),
      first(when($"ServiceName" === "COP", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_COP"),
      first(when($"ServiceName" === "DVE", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_DVE"),
      first(when($"ServiceName" === "EWB", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_EWB"),
      first(when($"ServiceName" === "IOV", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_IOV"),
      first(when($"ServiceName" === "IPID", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_IPID"),
      first(when($"ServiceName" === "PPI", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_PPI"),
      first(when($"ServiceName" === "PRISM", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_PRISM"),
      first(when($"ServiceName" === "PWS", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_PWS"),
      first(when($"ServiceName" === "RPS", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_RPS"),
      first(when($"ServiceName" === "SDS", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_SDS"),
      first(when($"ServiceName" === "TMX", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_TMX"),
      first(when($"ServiceName" === "TSW", (($"SvcEndTime".cast("long") - $"SvcStartTime".cast("long")))/1000).cast("double"), ignoreNulls = true).alias("DURATION_TSW"))
      .select($"oid", from_unixtime(unix_timestamp($"RECEIVE_TIME","yyyyMMddHHmmssSSS"),"yyyy-MM-dd HH:mm:ss").cast("timestamp").alias("RECEIVE_TIME"), $"DURATION", $"DURATION_VALID", $"DURATION_COP", $"DURATION_DVE", $"DURATION_EWB", $"DURATION_IOV", $"DURATION_IPID", $"DURATION_PPI", $"DURATION_PRISM", $"DURATION_PWS", $"DURATION_RPS", $"DURATION_SDS", $"DURATION_TMX", $"DURATION_TSW")
	//filetring Gathering and Recommend services to get the specific time difference in Seconds
    val durationColumnsGather = durationColumnsTemp.filter($"ServiceName" === "COP" || $"ServiceName" === "IPID" || $"ServiceName" === "IOV" || $"ServiceName" === "PWS" || $"ServiceName" === "PRISM" || $"ServiceName" === "PPI" ||$"ServiceName" === "RPS" || $"ServiceName" === "TMX" || $"ServiceName" === "FUZ" || $"ServiceName" === "SAE").groupBy($"oid").agg(((max($"SvcEndTime".cast("long"))-min($"SvcStartTime".cast("long")))/1000).cast("double").alias("DURATION_GATHER")).select($"oid", $"DURATION_GATHER")
    val durationColumnsRecomended = durationColumnsTemp.filter($"ServiceName" === "DVE" || $"ServiceName" === "SDS" || $"ServiceName" === "TSW" || $"ServiceName" === "EWB" || $"ServiceName" === "CEA" || $"ServiceName" === "TRE").groupBy($"oid").agg(((max($"SvcEndTime".cast("long"))-min($"SvcStartTime".cast("long")))/1000).cast("double").alias("DURATION_RECOMMEND")).select($"oid", $"DURATION_RECOMMEND")
    val durationColumnsJoin = durationColumns.join(durationColumnsGather,Seq("oid"),"left_outer").join(durationColumnsRecomended,Seq("oid"),"left_outer")

    val res = inputDF.join(durationColumnsJoin, Seq("oid"))
    res
  }

  /** Deriving the Number of Rules that were hit in each of the services (DVE, TSW, TRE) */

  def fntrAddRuleHitsDetails(indfCoreData: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:fntrAddRuleHitsDetails")

    /** The Rule Hits are stored in an array called NumRuleInfo as part of the Executor Message.
      * We are creating a temporary view on the NumRuleInfo along with oid and oiddate
      * We use explode_outer to handle NULL values */

    //    val temp = indfCoreData.select($"oid", $"oiddate", from_json($"numruleinfo", NumRuleInfoSchema).as("NumRuleInfoArray"))
    val temp = indfCoreData.select($"oid", $"oiddate", $"numruleinfo".as("NumRuleInfoArray"))
      .select($"oid", $"oiddate", explode_outer($"NumRuleInfoArray").alias("RuleInfo"))

    /** Select the required set of columns from temporary view, group it based on the oid and oidate and aggregate the rulehits based on the service name
      * Derive the column level rule hits based on the aggregation on service name. */

    val dfNumRuleHits = temp.select($"oid", $"RuleInfo.ServiceName".as("ServiceName"), $"RuleInfo.NumRuleHits".as("NumRuleHits"), $"RuleInfo.answer".as("answer"))
      .groupBy("oid").agg(
      first(when($"ServiceName" === "DVE", $"NumRuleHits"), ignoreNulls = true).alias("DVERuleHits"),
      first(when($"ServiceName" === "TSW", $"NumRuleHits"), ignoreNulls = true).alias("TSWRuleHits"),
      first(when($"ServiceName" === "TRE", $"NumRuleHits"), ignoreNulls = true).alias("TRERuleHits"),
      first(when($"ServiceName" === "SDS", $"answer"), ignoreNulls = true).alias("sdsanswer"),
      first(when($"ServiceName" === "DVE", $"answer"), ignoreNulls = true).alias("DVE_ANSWER"),
      first(when($"ServiceName" === "TSW", $"answer"), ignoreNulls = true).alias("TSW_ANSWER"),
      first(when($"ServiceName" === "EWB", $"answer"), ignoreNulls = true).alias("EWB_ANSWER"),
      first(when($"ServiceName" === "TRE", $"answer"), ignoreNulls = true).alias("TRE_ANSWER"))
      .select($"oid", $"DVERuleHits", $"TSWRuleHits", $"TRERuleHits", $"sdsanswer",$"DVE_ANSWER",$"TSW_ANSWER",$"EWB_ANSWER",$"TRE_ANSWER")

    /** The column NumRuleInfo contains array of details of the rule hits based on the service side.
      */

    val dfCoreData = indfCoreData.drop($"NumRuleInfo")

    val retdfCoreDatawithRuleHits = dfCoreData.join(dfNumRuleHits, Seq("oid"))

    val durationMapWithruleHits = fntrDeriveDurationFields(retdfCoreDatawithRuleHits)

    val retDFCoreDataWithDurationCols = durationMapWithruleHits.select($"OID", $"OIDDATE", $"ABA", $"ACCEPT".cast("integer").alias("ACCEPT"), $"ACCTTYPE", $"ACHRESPONSE", $"ADMINUSERCODE", $"AGENTBRAND", $"AGENTDEVICEID", $"AGENTTYPE", $"AMOUNT1".cast("DECIMAL(14,2)").alias("AMOUNT1"), $"AMOUNT2".cast("DECIMAL(14,2)").alias("AMOUNT2"), $"ANCHORF".cast("integer").alias("ANCHORF"), $"AOL", $"APACS", $"APPREPINSTALLMAL", $"APPREPINSTALLSUS", $"APPREPRUNMAL", $"APPREPRUNSUS", $"APPREPSELFHASHCAT", $"ASN", $"AUTH3DSRESULT", $"AUTH3DSXID", $"AUTHAMT".cast("DECIMAL(14,2)").alias("AUTHAMT"), $"AUTHCODE", to_date($"AUTHDT", "yyyyMMdd").alias("AUTHDT"), $"AUTHRESP", $"AUTHTM", $"AUTHTZ".cast("integer").alias("AUTHTZ"), $"AVSRESPONSE", $"BADSCORE", $"BCISCORE", $"BCOSCORE", upper($"BILLADDRESS2").alias("BILLADDRESS2"), upper($"BILLAPT").alias("BILLAPT"), upper($"BILLCITY").alias("BILLCITY"), $"BILLCOUNTRY", $"BILLSCORE".cast("integer").alias("BILLSCORE"), $"BILLSTATE", $"BILLSTATUS", upper($"BILLSTREET").alias("BILLSTREET"), $"BILLZIPCD", $"BPNSCORE".cast("integer").alias("BPNSCORE"), $"BROWSERCONFIGUREDLANG", $"BROWSERLANG", $"BROWSERTYPE", $"BROWSERVERSION", $"BZISCORE".cast("integer").alias("BZISCORE"), $"CALCAUTHCODE", $"CARDDETAILS", $"CARDEXPDT", $"CARDGLTOF".cast("integer").alias("CARDGLTOF"), $"CARDNO", $"CARDNODES3", $"CARDSEQNUM", $"CARDTYPE", $"CARRIER", $"CAVVAAV", $"CINPRESENT", $"CINRESPONSE", $"CLIENTID", $"CLIPCNT1".cast("integer").alias("CLIPCNT1"), $"CLTOF".cast("integer").alias("CLTOF"), $"CLTOFMIN".cast("integer").alias("CLTOFMIN"), $"CMPLTRCK2DATA", $"CONFIRMATION", $"COOKIEENABLED", $"COP2NOSCORE", $"COP2REPORT", $"CORPADDRESS2", $"CORPCITY", $"CORPCOUNTRY", $"CORPFAX", $"CORPNAME", $"CORPPHONE", $"CORPPONBR", $"CORPPURCHASE", $"CORPPURCHDESC", $"CORPSTATE", $"CORPSTREET", $"CORPSUITE", $"CORPZIPCD", $"CREDDEBIND", $"CURRCD", $"CUSTAGE".cast("integer").alias("CUSTAGE"), to_date($"CUSTBDATE", "yyyyMMdd").alias("CUSTBDATE"), $"CUSTCOOKIES", $"CUSTEMAIL", $"CUSTFAX", $"CUSTFIRSTNAME", $"CUSTGENDER", $"CUSTHOMEPHONE", $"CUSTID", $"CUSTIDCLTOF".cast("integer").alias("CUSTIDCLTOF"), $"CUSTIDCLTOFMIN".cast("integer").alias("CUSTIDCLTOFMIN"), $"CUSTIP", $"CUSTLASTNAME", $"CUSTMAXAGE".cast("integer").alias("CUSTMAXAGE"), $"CUSTMIDNAME", $"CUSTMINAGE".cast("integer").alias("CUSTMINAGE"), $"CUSTSALUTATION", $"CUSTSSN", $"CUSTTM", $"CUSTTRANDT", $"CUSTWORKPHONE", $"CVV2DATA", $"CVV2DATAOLD".cast("integer").alias("CVV2DATAOLD"), $"DECISION", $"DEFFORMFILL", $"DENY".cast("integer").alias("DENY"), $"DEVICEalias", $"DEVICECONFIDENCE", $"DEVICEFIRSTSEEN", $"DEVICEID", $"DEVICENEW", $"DEVICEPROFILECOMPOSITE", $"DEVICETOF".cast("integer").alias("DEVICETOF"), $"DEVICETYPE", $"DEVICETZ".cast("integer").alias("DEVICETZ"), $"DEVMATCHRES", $"DIALINDICATOR1", $"DIALINDICATOR2", $"DLHID", $"DRIVERLICENSE", $"ECOMMFLAG", $"EMAILCLTOF".cast("integer").alias("EMAILCLTOF"), $"EMAILCLTOFMIN".cast("integer").alias("EMAILCLTOFMIN"), $"EMAILGLTOF".cast("integer").alias("EMAILGLTOF"), $"EMAILGLTOFMIN".cast("integer").alias("EMAILGLTOFMIN"), $"EMLSCORE".cast("integer").alias("EMLSCORE"),
      $"EMVCARDVRFYRSLTS", $"EMVTERMTYPE", $"EMVTRMNLVRFYRSLT", $"EMVUSRFLR", $"ENABLEDCK", $"ENABLEDFL", $"ENABLEDIM", $"ENABLEDJS", $"ERR", $"ERRORCOUNT".cast("integer").alias("ERRORCOUNT"), $"ERRORMESSAGE", $"ERRORMSG", to_date($"EXPDATE", "yyyyMMdd").alias("EXPDATE"), $"FIID", $"FLASHENABLED", $"FLASHINSTALLED", $"FLASHVERSION", $"FORGOTPWD", $"FUZZYDEVICECONF".cast("integer").alias("FUZZYDEVICECONF"), $"FUZZYDEVICEID", $"FUZZYDEVICEMTCHRES", $"GEOPOINTERROR", $"GEOPOINTRESULT", $"GIFTCARDTYPE", $"GIFTMSG", $"HANDLING".cast("integer").alias("HANDLING"), $"HPFINGERPRINT", $"HPFINGERPRINTDIFF", $"HPFINGERPRINTMATCH", $"HPUNKNOWNDIFF", $"HWGPSACCURACY".cast("integer").alias("HWGPSACCURACY"), $"HWLATITUDE".cast("FLOAT").alias("HWLATITUDE"), $"HWLONGITUDE".cast("FLOAT").alias("HWLONGITUDE"), $"IOVADMINCD", $"IOVATIONERROR", $"IOVFLD", $"IOVSUBID", $"IPADDRCITY", $"IPADDRLOCCOUNTRYCD", $"IPADDRPROXY", $"IPADDRREGION", $"IPASCORE".cast("integer").alias("IPASCORE"), $"IPIDFLD", $"ISSUEDIG", $"JBROOT".cast("integer").alias("JBROOT"), $"JBROOTREASON", $"JSENABLED", $"LOADDATE", $"LOADHOST", $"LOADPROCESSORID", $"LOADPROCESSORTYPE", $"LOCALATTRIB1", $"LOCALATTRIB2", $"LOCALATTRIB3", $"LOCALATTRIB4", $"LOCALATTRIB5", $"LOCALATTRIB6", $"LOCALATTRIB7", $"LOCALATTRIB8", $"LOCALATTRIB9", $"MERCHANTCOUNTRY", $"MERCHANTID", $"MERCHANTINT".cast("integer").alias("MERCHANTINT"), $"MERCHANTNM", $"MERCHANTSIC", $"MERCHANTZIPCD", $"MERCHSTR", $"MESSAGE", $"MESSAGEINT1", $"MESSAGEINT2", $"MESSAGETYPE1", $"MESSAGETYPE2", $"MODEL", $"NEURAL", $"NEURALFLAG", $"NOSCORE".cast("integer").alias("NOSCORE"), $"ORDERBIN", to_date($"ORDERDT", "yyyyMMdd").alias("ORDERDT"), $"ORDERID", $"ORDERSTATUS", $"ORDERTM", $"ORDERTZ".cast("integer").alias("ORDERTZ"), $"ORDSCORE", $"OS", to_date($"PASSEXPDT", "yyyyMMdd").alias("PASSEXPDT"), $"PASSISSUECOUNTRY", $"PASSMRZ1", $"PASSMRZ2", $"PASSNATIONALITYCD", $"PASSPERSONALNO", $"PASSPORTNO", $"PASSWORD", $"PAYMETHOD", $"PFNSCORE", $"PHONECLTOF".cast("integer").alias("PHONECLTOF"), $"PHONECLTOFMIN".cast("integer").alias("PHONECLTOFMIN"), $"PHONEGLTOF".cast("integer").alias("PHONEGLTOF"), $"PHONEGLTOFMIN".cast("integer").alias("PHONEGLTOFMIN"), $"PININDX", $"PLNSCORE".cast("integer").alias("PLNSCORE"), $"PN2SCORE".cast("integer").alias("PN2SCORE"), $"POLICYSCORE".cast("integer").alias("POLICYSCORE"), $"POSCONDCODE", $"POSENTRYMOD", $"PRENOTE", $"PREVIOUSCUST", $"PRODIND", $"PROXYIP", $"PROXYTYPE", $"PWSFIRSTNAME", $"PWSID", $"PWSLASTNAME", $"PWSPASSWORD", $"PWSSCORE".cast("integer").alias("PWSSCORE"), $"PWSUSERNAME", $"QUOVAFIELDAOL", $"QUOVAFIELDMETROCITY", $"QUOVAFIELDMETRODISTANCE", $"QUOVAFIELDMETROSTATE", $"QUOVAFIELDRETURNCODE", $"RCF", $"RCFFLAG", $"REALIPADDR", $"REALIPISP", $"REALIPSOURCE", $"REASON", $"REASON1", $"REASON2", $"REASON3", $"REASONCODE", $"RECOMMENDATION", $"REDFUZRSP", $"REDIOVRSP", $"REDPWSRSP", $"REDRPSRSP", $"REDSAERSP",
      $"REDTMXRSP", $"REGLOYALTY", $"REGPROMOS", $"REJECTLOGIN", $"REPORT", $"REQUESTDURATION".cast("integer").alias("REQUESTDURATION"), $"REQUESTID", $"RERSPCD", $"RERULEID", $"RESPONSE", $"RESPONSECODE", $"RESPONSETYPE", $"RESTATCD", $"RESULT", $"RETURNALLOWED", $"RISKRATING", $"RPSAUTHID", $"RPSID", $"RPSKEY", $"RPSSTATUS", $"RTLRSICCODE", $"RULESMATCHED".cast("integer").alias("RULESMATCHED"), $"RULESSCORE".cast("integer").alias("RULESSCORE"), $"VIRTSAEMETADATAVERSION".cast("BIGINT").alias("VIRTSAEMETADATAVERSION"), $"SCORE", $"SDSFLDSTR", $"SERVER", $"SERVERID", $"SERVICE", $"SERVICES", $"SERVTO", $"SESSIONID", $"SETTLEMENTCURRCD", upper($"SHIPADDRESS2").alias("SHIPADDRESS2"), upper($"SHIPAPT").alias("SHIPAPT"), upper($"SHIPCITY").alias("SHIPCITY"), $"SHIPCOMMENTS", $"SHIPCOUNTRY", $"SHIPEMAIL", $"SHIPFAX", $"SHIPFIRSTNAME", $"SHIPINSTRUCTION", $"SHIPLASTNAME", $"SHIPMENTNO", $"SHIPMIDNAME", $"SHIPPHONE", $"SHIPSALUTATION", $"SHIPSCORE".cast("integer").alias("SHIPSCORE"), $"SHIPSTATE", upper($"SHIPSTREET").alias("SHIPSTREET"), $"SHIPZIPCD", $"SOURCE", $"STARTTIME", $"STATUS", $"SUBCLIENTID", $"SUBSCRIBERID", $"SUBSCRIBERPASSCD", $"SUBTOTAL".cast("DECIMAL(14,2)").alias("SUBTOTAL"), $"TAX".cast("DECIMAL(14,2)").alias("TAX"), $"TERMCITY", $"TERMCNTR".cast("integer").alias("TERMCNTR"), $"TERMID", $"TERMINALID1", $"TERMINALID2", $"TERMINALTYPE", $"TERMNAMELOC", $"TERMPSTLCODE", $"TERMST", $"TERMSTR", $"TIMESTAMPA", $"TMXAPIKEY", $"TMXEVENTTYPE", $"TMXORGID", $"TMXPOLICY", $"TMXSERVICETYPE", $"TOF".cast("integer").alias("TOF"), $"TOKENID", $"TOTAL".cast("DECIMAL(14,2)").alias("TOTAL"), $"TRACKINGINT", $"TRACKINGNUM", $"TRACKINGNUMBER", $"TRANAMT1".cast("DECIMAL(14,2)").alias("TRANAMT1"), $"TRANAMT4".cast("DECIMAL(14,2)").alias("TRANAMT4"), $"TRANAMT5".cast("DECIMAL(14,2)").alias("TRANAMT5"), $"TRANAUTHSRC", $"TRANCATEGORY", $"TRANCODE", $"TRANRSNCODE", $"TRANSACTIONID", $"TRANTYPE", $"TRUEIP", $"TXDATETIME", $"USERCODE", upper($"USERDATA01").alias("USERDATA01"), upper($"USERDATA02").alias("USERDATA02"), upper($"USERDATA03").alias("USERDATA03"), upper($"USERDATA04").alias("USERDATA04"), upper($"USERDATA05").alias("USERDATA05"), upper($"USERDATA06").alias("USERDATA06"), upper($"USERDATA07").alias("USERDATA07"), upper($"USERDATA08").alias("USERDATA08"), upper($"USERDATA09").alias("USERDATA09"), upper($"USERDATA10").alias("USERDATA10"), upper($"USERDATA11").alias("USERDATA11"), upper($"USERDATA12").alias("USERDATA12"), upper($"USERDATA13").alias("USERDATA13"), upper($"USERDATA14").alias("USERDATA14"), upper($"USERDATA15").alias("USERDATA15"), upper($"USERDATA16").alias("USERDATA16"), upper($"USERDATA17").alias("USERDATA17"), upper($"USERDATA18").alias("USERDATA18"), upper($"USERDATA19").alias("USERDATA19"), upper($"USERDATA20").alias("USERDATA20"), upper($"USERDATA21").alias("USERDATA21"), upper($"USERDATA22").alias("USERDATA22"), upper($"USERDATA23").alias("USERDATA23"), upper($"USERDATA24").alias("USERDATA24"), upper($"USERDATA25").alias("USERDATA25"), $"VERSION", $"VIRTBILLSHIP".cast("integer").alias("VIRTBILLSHIP"), $"VIRTBILLZIPMATCH".cast("integer").alias("VIRTBILLZIPMATCH"), $"VIRTBIN", $"VIRTCARDBIN", $"VIRTCARDCLASS", $"VIRTCUSTEMAILDOMAIN", $"VIRTCUSTEMAILMATCH".cast("integer").alias("VIRTCUSTEMAILMATCH"), $"VIRTEXPIRED".cast("integer").alias("VIRTEXPIRED"), $"VIRTFUZBILLSCORE".cast("integer").alias("VIRTFUZBILLSCORE"), $"VIRTFUZRSP", $"VIRTFUZSHIPSCORE".cast("integer").alias("VIRTFUZSHIPSCORE"), $"VIRTIOVBLNG", $"VIRTIOVCK", $"VIRTIOVCNTRYCD", $"VIRTIOVDEVICEID", $"VIRTIOVDTYPE", $"VIRTIOVFLSH", $"VIRTIOVJS", $"VIRTIOVPROF", $"VIRTIOVPROXY", $"VIRTIOVRCNT".cast("integer").alias("VIRTIOVRCNT"),
      $"VIRTIOVREALIP", $"VIRTIOVREJECT", $"VIRTIOVRSLT", $"VIRTIOVRSN", $"VIRTIOVRSP", $"VIRTIOVTOF", $"VIRTIPIDADDRTYPE", $"VIRTIPIDANONYMIZER", $"VIRTIPIDAOL", $"VIRTIPIDAREACODE".cast("integer").alias("VIRTIPIDAREACODE"), $"VIRTIPIDASN".cast("integer").alias("VIRTIPIDASN"), $"VIRTIPIDCARRIER", $"VIRTIPIDCFCOUNTRY", $"VIRTIPIDCITY", $"VIRTIPIDCONNSPEED", $"VIRTIPIDCONNTYPE", $"VIRTIPIDCONTINENT", $"VIRTIPIDCOUNTRY", $"VIRTIPIDCOUNTRYEBG", $"VIRTIPIDDMA".cast("integer").alias("VIRTIPIDDMA"), $"VIRTIPIDIPADDR", $"VIRTIPIDLAT".cast("integer").alias("VIRTIPIDLAT"), $"VIRTIPIDLONG".cast("integer").alias("VIRTIPIDLONG"), $"VIRTIPIDMSA".cast("integer").alias("VIRTIPIDMSA"), $"VIRTIPIDPMSA".cast("integer").alias("VIRTIPIDPMSA"), $"VIRTIPIDPOSTAL", $"VIRTIPIDRTMETHOD", $"VIRTIPIDSLD", $"VIRTIPIDTLD", $"VIRTIPIDTZ", $"VIRTIPIDUSMETRO", $"VIRTIPIDUSREGION", $"VIRTIPIDUSSTATE", $"VIRTMOD10FAIL".cast("integer").alias("VIRTMOD10FAIL"), $"VIRTPPANCHORF".cast("integer").alias("VIRTPPANCHORF"), $"VIRTPPANCHORR".cast("integer").alias("VIRTPPANCHORR"), $"VIRTPPFMOVERLAP".cast("integer").alias("VIRTPPFMOVERLAP"), $"VIRTPPFMSCORE".cast("integer").alias("VIRTPPFMSCORE"), to_date($"VIRTPPLASTSEEN", "yyyyMMdd").alias("VIRTPPLASTSEEN"), $"VIRTPPTOF".cast("integer").alias("VIRTPPTOF"), $"VIRTPPTOFMIN".cast("integer").alias("VIRTPPTOFMIN"), $"VIRTPPTRANS".cast("integer").alias("VIRTPPTRANS"), $"VIRTPRISMRSN1", $"VIRTPRISMRSN2", $"VIRTPRISMRSN3", $"VIRTPRISMSCORE".cast("integer").alias("VIRTPRISMSCORE"), $"VIRTPWSEML", $"VIRTPWSIPA", $"VIRTPWSPFN", $"VIRTPWSPLN", $"VIRTPWSRSP", $"VIRTPWSSCORE".cast("integer").alias("VIRTPWSSCORE"), $"VIRTRECIPEMAILMATCH".cast("integer").alias("VIRTRECIPEMAILMATCH"), $"VIRTRECIPZIPMATCH".cast("integer").alias("VIRTRECIPZIPMATCH"), $"VIRTRPSRSP", $"VIRTRPSSTATUS", $"VIRTSAEANCHORF".cast("integer").alias("VIRTSAEANCHORF"), $"VIRTSAECARDCLTOF".cast("integer").alias("VIRTSAECARDCLTOF"), $"VIRTSAECARDCLTOFMIN".cast("integer").alias("VIRTSAECARDCLTOFMIN"), $"VIRTSAECARDGLTOF".cast("integer").alias("VIRTSAECARDGLTOF"), $"VIRTSAECARDGLTOFMIN".cast("integer").alias("VIRTSAECARDGLTOFMIN"), $"VIRTSAECLCARDCNT1".cast("integer").alias("VIRTSAECLCARDCNT1"), $"VIRTSAECLCARDCNT7".cast("integer").alias("VIRTSAECLCARDCNT7"), $"VIRTSAECLCARDSUM1".cast("integer").alias("VIRTSAECLCARDSUM1"), $"VIRTSAECLCARDSUM7".cast("integer").alias("VIRTSAECLCARDSUM7"), $"VIRTSAECLCUSTIDCNT1".cast("integer").alias("VIRTSAECLCUSTIDCNT1"), $"VIRTSAECLCUSTIDSUM1".cast("integer").alias("VIRTSAECLCUSTIDSUM1"), $"VIRTSAECLCUSTIPSUM1".cast("integer").alias("VIRTSAECLCUSTIPSUM1"), $"VIRTSAECLDEVBIN1".cast("integer").alias("VIRTSAECLDEVBIN1"), $"VIRTSAECLDEVCARD1".cast("integer").alias("VIRTSAECLDEVCARD1"), $"VIRTSAECLDEVCARD7".cast("integer").alias("VIRTSAECLDEVCARD7"), $"VIRTSAECLDEVEMAIL1".cast("integer").alias("VIRTSAECLDEVEMAIL1"), $"VIRTSAECLDEVEMLDOM1".cast("integer").alias("VIRTSAECLDEVEMLDOM1"),
      $"VIRTSAECLDEVIP1".cast("integer").alias("VIRTSAECLDEVIP1"), $"VIRTSAECLEMAILCNT1".cast("integer").alias("VIRTSAECLEMAILCNT1"), $"VIRTSAECLEMAILSUM1".cast("integer").alias("VIRTSAECLEMAILSUM1"), $"VIRTSAECLIPCNT1".cast("integer").alias("VIRTSAECLIPCNT1"), $"VIRTSAECLTOF".cast("integer").alias("VIRTSAECLTOF"), $"VIRTSAECLTOFMIN".cast("integer").alias("VIRTSAECLTOFMIN"), $"VIRTSAECUSTIDCLTOF".cast("integer").alias("VIRTSAECUSTIDCLTOF"), $"VIRTSAECUSTIDCLTOFMIN".cast("integer").alias("VIRTSAECUSTIDCLTOFMIN"), $"VIRTSAEEMAILCLTOF".cast("integer").alias("VIRTSAEEMAILCLTOF"), $"VIRTSAEEMAILCLTOFMIN".cast("integer").alias("VIRTSAEEMAILCLTOFMIN"), $"VIRTSAEEMAILGLTOF".cast("integer").alias("VIRTSAEEMAILGLTOF"), $"VIRTSAEEMAILGLTOFMIN".cast("integer").alias("VIRTSAEEMAILGLTOFMIN"), $"VIRTSAEGLCARDCNT1".cast("integer").alias("VIRTSAEGLCARDCNT1"), $"VIRTSAEGLCARDCNT7".cast("integer").alias("VIRTSAEGLCARDCNT7"), $"VIRTSAEGLCARDSUM1".cast("integer").alias("VIRTSAEGLCARDSUM1"), $"VIRTSAEGLCARDSUM7".cast("integer").alias("VIRTSAEGLCARDSUM7"), $"VIRTSAEGLCUSTIPSUM1".cast("integer").alias("VIRTSAEGLCUSTIPSUM1"), $"VIRTSAEGLDEVBIN1".cast("integer").alias("VIRTSAEGLDEVBIN1"), $"VIRTSAEGLDEVCARD1".cast("integer").alias("VIRTSAEGLDEVCARD1"), $"VIRTSAEGLDEVCARD7".cast("integer").alias("VIRTSAEGLDEVCARD7"), $"VIRTSAEGLDEVEMAIL1".cast("integer").alias("VIRTSAEGLDEVEMAIL1"), $"VIRTSAEGLDEVEMLDOM1".cast("integer").alias("VIRTSAEGLDEVEMLDOM1"), $"VIRTSAEGLDEVIP1".cast("integer").alias("VIRTSAEGLDEVIP1"), $"VIRTSAEGLEMAILCNT1".cast("integer").alias("VIRTSAEGLEMAILCNT1"), $"VIRTSAEGLEMAILSUM1".cast("integer").alias("VIRTSAEGLEMAILSUM1"), $"VIRTSAEGLIPCNT1".cast("integer").alias("VIRTSAEGLIPCNT1"), $"VIRTSAEGLTOF".cast("integer").alias("VIRTSAEGLTOF"), $"VIRTSAEGLTOFMIN".cast("integer").alias("VIRTSAEGLTOFMIN"), $"VIRTSAEPHONECLTOF".cast("integer").alias("VIRTSAEPHONECLTOF"), $"VIRTSAEPHONECLTOFMIN".cast("integer").alias("VIRTSAEPHONECLTOFMIN"), $"VIRTSAEPHONEGLTOF".cast("integer").alias("VIRTSAEPHONEGLTOF"), $"VIRTSAEPHONEGLTOFMIN".cast("integer").alias("VIRTSAEPHONEGLTOFMIN"), $"VIRTSAERSP", $"VIRTSAEUSRDEF1".cast("integer").alias("VIRTSAEUSRDEF1"), $"VIRTSAEUSRDEF10".cast("integer").alias("VIRTSAEUSRDEF10"), $"VIRTSAEUSRDEF11".cast("integer").alias("VIRTSAEUSRDEF11"), $"VIRTSAEUSRDEF12".cast("integer").alias("VIRTSAEUSRDEF12"), $"VIRTSAEUSRDEF13".cast("integer").alias("VIRTSAEUSRDEF13"), $"VIRTSAEUSRDEF14".cast("integer").alias("VIRTSAEUSRDEF14"), $"VIRTSAEUSRDEF15".cast("integer").alias("VIRTSAEUSRDEF15"), $"VIRTSAEUSRDEF16".cast("integer").alias("VIRTSAEUSRDEF16"), $"VIRTSAEUSRDEF17".cast("integer").alias("VIRTSAEUSRDEF17"), $"VIRTSAEUSRDEF18".cast("integer").alias("VIRTSAEUSRDEF18"), $"VIRTSAEUSRDEF19".cast("integer").alias("VIRTSAEUSRDEF19"), $"VIRTSAEUSRDEF2".cast("integer").alias("VIRTSAEUSRDEF2"), $"VIRTSAEUSRDEF20".cast("integer").alias("VIRTSAEUSRDEF20"), $"VIRTSAEUSRDEF21".cast("integer").alias("VIRTSAEUSRDEF21"),
      $"VIRTSAEUSRDEF22".cast("integer").alias("VIRTSAEUSRDEF22"), $"VIRTSAEUSRDEF23".cast("integer").alias("VIRTSAEUSRDEF23"), $"VIRTSAEUSRDEF24".cast("integer").alias("VIRTSAEUSRDEF24"), $"VIRTSAEUSRDEF25".cast("integer").alias("VIRTSAEUSRDEF25"), $"VIRTSAEUSRDEF26".cast("integer").alias("VIRTSAEUSRDEF26"), $"VIRTSAEUSRDEF27".cast("integer").alias("VIRTSAEUSRDEF27"), $"VIRTSAEUSRDEF28".cast("integer").alias("VIRTSAEUSRDEF28"), $"VIRTSAEUSRDEF29".cast("integer").alias("VIRTSAEUSRDEF29"), $"VIRTSAEUSRDEF3".cast("integer").alias("VIRTSAEUSRDEF3"), $"VIRTSAEUSRDEF30".cast("integer").alias("VIRTSAEUSRDEF30"), $"VIRTSAEUSRDEF31".cast("integer").alias("VIRTSAEUSRDEF31"), $"VIRTSAEUSRDEF32".cast("integer").alias("VIRTSAEUSRDEF32"), $"VIRTSAEUSRDEF33".cast("integer").alias("VIRTSAEUSRDEF33"), $"VIRTSAEUSRDEF34".cast("integer").alias("VIRTSAEUSRDEF34"), $"VIRTSAEUSRDEF35".cast("integer").alias("VIRTSAEUSRDEF35"), $"VIRTSAEUSRDEF36".cast("integer").alias("VIRTSAEUSRDEF36"), $"VIRTSAEUSRDEF37".cast("integer").alias("VIRTSAEUSRDEF37"), $"VIRTSAEUSRDEF38".cast("integer").alias("VIRTSAEUSRDEF38"), $"VIRTSAEUSRDEF39".cast("integer").alias("VIRTSAEUSRDEF39"), $"VIRTSAEUSRDEF4".cast("integer").alias("VIRTSAEUSRDEF4"), $"VIRTSAEUSRDEF40".cast("integer").alias("VIRTSAEUSRDEF40"), $"VIRTSAEUSRDEF41".cast("integer").alias("VIRTSAEUSRDEF41"), $"VIRTSAEUSRDEF42".cast("integer").alias("VIRTSAEUSRDEF42"), $"VIRTSAEUSRDEF43".cast("integer").alias("VIRTSAEUSRDEF43"), $"VIRTSAEUSRDEF44".cast("integer").alias("VIRTSAEUSRDEF44"), $"VIRTSAEUSRDEF45".cast("integer").alias("VIRTSAEUSRDEF45"), $"VIRTSAEUSRDEF46".cast("integer").alias("VIRTSAEUSRDEF46"), $"VIRTSAEUSRDEF47".cast("integer").alias("VIRTSAEUSRDEF47"), $"VIRTSAEUSRDEF48".cast("integer").alias("VIRTSAEUSRDEF48"), $"VIRTSAEUSRDEF49".cast("integer").alias("VIRTSAEUSRDEF49"), $"VIRTSAEUSRDEF5".cast("integer").alias("VIRTSAEUSRDEF5"), $"VIRTSAEUSRDEF50".cast("integer").alias("VIRTSAEUSRDEF50"), $"VIRTSAEUSRDEF6".cast("integer").alias("VIRTSAEUSRDEF6"), $"VIRTSAEUSRDEF7".cast("integer").alias("VIRTSAEUSRDEF7"), $"VIRTSAEUSRDEF8".cast("integer").alias("VIRTSAEUSRDEF8"), $"VIRTSAEUSRDEF9".cast("integer").alias("VIRTSAEUSRDEF9"), $"VIRTSHIPEMAILMATCH".cast("integer").alias("VIRTSHIPEMAILMATCH"), $"VIRTSHIPZIPMATCH".cast("integer").alias("VIRTSHIPZIPMATCH"), $"VIRTTMXAGENTBRAND", $"VIRTTMXAGENTTYPE", $"VIRTTMXBROWSERLANG", $"VIRTTMXDEVICEID", $"VIRTTMXENABLEDCK", $"VIRTTMXENABLEDFL", $"VIRTTMXENABLEDIM", $"VIRTTMXENABLEDJS", $"VIRTTMXFUZZYDEVICEID", $"VIRTTMXOS", $"VIRTTMXPOLICYSCORE".cast("integer").alias("VIRTTMXPOLICYSCORE"), $"VIRTTMXPROXYIP", $"VIRTTMXPROXYTYPE", $"VIRTTMXREASONCODE", $"VIRTTMXRISKRATING", $"VIRTTMXRSP", $"VIRTTMXTRUEIP", $"VIRTTRERSP", $"VIRTUSDTOTAL".cast("DECIMAL(14,2)").alias("VIRTUSDTOTAL"), $"VIRTUTF8", $"WEBSITE", $"WRAPPED", $"XBILLSTATE", $"XBILLSTREET", $"XBILLZIPCD", $"REDI_XCUSTEMAIL".as("XCUSTEMAIL"), $"XCUSTFIRSTNAME",
      $"XCUSTLASTNAME", $"XSHIPEMAIL", $"XSHIPFIRSTNAME", $"XSHIPLASTNAME", $"XSHIPSTATE", $"XSHIPSTREET", $"XSHIPZIPCD", $"XTRANSACTIONID", $"XUSERDATA09", $"NUMRULEINFO", $"RULECATEGORYFLAG", $"SERVICEPROCESS", $"DETAILLINES", $"DETAILLINESBAND", $"DETAILLINESBANDDESC", $"CURRCLIENT", $"CURRSUBCLIENT", $"TOTALCLIENT", $"TOTALEUR", $"TOTALGBP", $"TOTALSUBCLIENT", $"TOTALUSD", $"CARDNOMASK", $"DVERULEHITS", $"TRERULEHITS", $"TSWRULEHITS", $"DVE_ANSWER", $"TSW_ANSWER", $"EWB_ANSWER", $"TRE_ANSWER", $"WHENUPDATED", $"WHOLOADED", $"WHOUPDATED", $"OIDDATEYYYYMMDD", $"RealFraudYN", $"hashcardno", $"XCUSTEMAILDOMAIN", $"REALFRAUDTYPE", $"REALFRAUDDATE", $"REALFRAUDDATEBAE", $"CLIENTDATE", $"SubClientDate", $"ClientDateYYYYMMDD", initcap($"SDSANSWER").alias("sdsanswer"), $"SubClientDateYYYYMMDD", $"Region", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"Client12", $"ClientSet", $"updateRecReasonWithNineFlag", $"updateRecReasonwithTSWFlag", $"flag20", $"RecipientColumns", $"RECEIVE_TIME", $"DURATION", $"DURATION_VALID", $"DURATION_COP", $"DURATION_DVE", $"DURATION_EWB", $"DURATION_IOV", $"DURATION_IPID", $"DURATION_PPI", $"DURATION_PRISM", $"DURATION_PWS", $"DURATION_RPS", $"DURATION_SDS", $"DURATION_TMX", $"DURATION_TSW", $"DURATION_GATHER", $"DURATION_RECOMMEND").withColumn("WHENLOADED", current_timestamp())
    // KP Perf changes - added subclientyyyymmdd, region to select, removed $"SHIPMETHOD"
    
	retDFCoreDataWithDurationCols

  }

  def fntrCoreSpecificTransformation(inputDataFrame: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:fntrCoreSpecificTransformation")
    //    val tdf = inputDataFrame.createOrReplaceTempView("inputcore")
    //    val df1 = hiveSession.session().sql("select oid, '' as ACCEPTCOUNT,'' as ACCEPTVALUE,'' as ACCEPTVALUECLIENT,'' as ACCEPTVALUEEUR,'' as ACCEPTVALUEGBP,'' as ACCEPTVALUESUBCLIENT,'' as ACCEPTVALUEUSD,'' as AUTH_DATE_TIME,'' as AUTH_DATE_TIME_GMT,'' as AUTHDATETIME,'' as AUTHDECCT,'' as BEDCBAMOUNT,'' as BEDCBBANKREASON,'' as BEDCBCLIENTDESC,'' as BEDCBCLIENTREASON,'' as BEDCBDATAPROCYYYYMMDD,'' as BEDCBFRAUDYN,'' as BEDCBPROCESSDATE,'' as BEDCBPROCESSYYYYMMDD,'' as BEDCBRECEIPTDATE,'' as BEDCBRECEIPTYYYYMMDD,'' as BEDCBWHENLOADED,'' as BEDCBWHENUPDATED,'' as BEDCBWHOLOADED,'' as BEDCBWHOUPDATED,'' as BEDCLIENTDESC,'' as BEDCLIENTID,'' as BEDCLIENTREASONCODE,'' as BEDDATAFILENAME,'' as BEDDATAPROCDATE,'' as BEDDATAPROCYYYYMMDD," +
    //      "'' as BEDDISPOSITION,'' as BEDDISPOSTIONREDI,'' as BEDFRAUDYN,'' as BEDLINENUMBER,'' as BEDMASTAMOUNT,'' as BEDMASTPROCDATE,'' as BEDMASTREASONCODE,'' as BEDMASTRECEIPTDATE,'' as BEDMASTRECEIPTYYYYMMDD,'' as BEDMASTSTATUSDATE,'' as BEDMASTSTATUSIND,'' as BEDMASTSTATUSYYYYMMDD,'' as BEDMASTTRANSACTION,'' as BEDMASTUPDATETYPE,'' as BEDMASTWHENLOADED,'' as BEDMASTWHENUPDATED,'' as BEDMASTWHOLOADED,'' as BEDMASTWHOUPDATED,'' as BEDOTHERCOUNT1,'' as BEDOTHERCOUNT2,'' as BEDOTHERINFO1,'' as BEDOTHERINFO2,'' as BEDPROCESSDATE,'' as BEDPROCESSYYYYMMDD,'' as BEDREFERENCEID,'' as BEDREMARKS,'' as BEDSOURCE,'' as BEDSUBCLIENTID,'' as BEDTRANSACTIONID,'' as BEDWHENLOADED,'' as BEDWHENUPDATED,'' as BEDWHOLOADED,'' as BEDWHOUPDATED,'' as BILLUKPOSTCODEAREA," +
    //      "'' as BILLUKPOSTCODEDISTRICT,'' as BILLUKPOSTCODEFULL,'' as BILLUKPOSTCODERISK,'' as BILLUKPOSTCODESECTOR,'' as BILLZIPCDNORM,'' as BINCRDR,'' as BINDETAIL,'' as BINGROUP,'' as BINRFX, '' as CARDBIN,'' as CARDNOLAST4,'' as CARDTYPEFULL,'' as CBDATEACTUAL,'' as CBDATEYYYYMMDD,'' as CBFRAUDYN,'' as CBVALUECLIENT,'' as CBVALUEEUR,'' as CBVALUEGBP,'' as CBVALUESUBCLIENT,'' as CBVALUEUSD,'' as CBWHENLOADED,'' as CBWHENUPDATED,'' as CBWHOLOADED,'' as CBWHOUPDATED,'' as CEA_RESPONSE_CODE,'' as CEXRESPONSETEXT,'' as CHALLENGECOUNT,'' as CHALLENGEVALUE,'' as CHALLENGEVALUECLIENT,'' as CHALLENGEVALUEEUR,'' as CHALLENGEVALUEGBP,'' as CHALLENGEVALUESUBCLIENT,'' as CHALLENGEVALUEUSD,'' as CHALLSOURCE,'' as CHARGEBACKDATE,'' as CHARGEBACKFRAUDYN," +
    //      "'' as CHARGEBACKID,'' as CHARGEBACKITEMS,'' as CHARGEBACKPROCYYYYMMDD,'' as CHARGEBACKREASON,'' as CHARGEBACKVALUE,'N' as CHARGEBACKYN,'' as CHARGEBACKYYYYMMDD,'' as CLIENTTXNTIME,'' as CLUBRFXALERTYN,'' as CMCANCELREASON,'' as CMCLIENTUPDATETIME,'' as CMFRAUD,'' as CMQID,'' as CMQUEUENAME,'' as CMSTATUS,'' as CMUPDATE,'' as CMUSERFULLNAME,'' as CMUSERID,'' as CMUSERNAME,'' as CREATE_TIMESTAMP,'' as CSICASECANCELCODE,'' as CSICASECANCELDESC,'' as CSICASECANCELFRAUDYN,'' as CSICASECANCELREASON,'' as CSICASECBFRAUDTEXT,'' as CSICASECHARGEBACKDATE,'' as CSICASECHARGEBACKFRAUD,'' as CSICASECHARGEBACKYN,'' as CSICASECMSOURCE,'' as CSICASECMTYPE,'' as CSICASECOMPLETECLIENTWEEK,'' as CSICASECOMPLETECLIENTYYYYMMDD,'' as CSICASECOMPLETEDATETIME," +
    //      "'' as CSICASECOMPLETEDATETIMECLIENT,'' as CSICASEDAYSTORELEASE,'' as CSICASEDAYSTORELEASESORT, '' as CSICASEDAYSTORELEASETEXT,'' as CSICASEEBCARDTYPEC1,'' as CSICASEEBSHIPMETHODC1,'' as CSICASEEFALCONSCOREC1,'' as CSICASEFLAG1,'' as CSICASEFLAG2,'' as CSICASEFLAG3,'' as CSICASEFLAG4,'' as CSICASEFLAG5,'' as CSICASEFLAG6,'' as CSICASEFRAUDDATE,'' as CSICASEFRAUDTYPE,'' as CSICASEFRAUDYN,'' as CSICASEGRAPHLABELDAY,'' as CSICASEGRAPHLABELHOUR,'' as CSICASEGRAPHLABELMONTH,'' as CSICASEGRAPHLABELWEEK,'' as CSICASEHOURSBAND,'' as CSICASEHOURSBANDCODE,'' as CSICASEHOURSTOQUEUE,'' as CSICASEHOURSTORELEASE,'' as CSICASEHOWMANYPENDS,'' as CSICASEINTERNALID,'' as CSICASELASTPEND,'' as CSICASELASTPENDCLIENT,'' as CSICASELOADDATETIMEC1,'' as CSICASEMINUTESQUEUEBAND," +
    //      "'' as CSICASEMINUTESQUEUEBANDSORT,'' as CSICASEMINUTESTOQUEUE,'' as CSICASEMINUTESTORELEASE,'' as CSICASEMODIFIEDBYC2,'' as CSICASEMODIFIEDDATEC2,'' as CSICASEOIDCLIENTYYYYMMDD,'' as CSICASEOIDDATETIMECLIENT,'' as CSICASEOUTCOME,'' as CSICASEOVERALLHOURS,'' as CSICASEPRISMSCOREC1,'' as CSICASEPROCESSBYAAIDC2,'' as CSICASEPROCESSBYUSERC2,'' as CSICASEPROCESSBYUSERIDC2,'' as CSICASEPROCESSEDDATETIMEC2,'' as CSICASEPROCESSTYPE,'' as CSICASEQUEUECLIENTYYYYMMDD,'' as CSICASEQUEUEDATETIME,'' as CSICASEQUEUEDATETIMECLIENT,'' as CSICASEQUEUEIDREDI,'' as CSICASEQUEUENAME,'' as CSICASEQUEUENUMBER,'' as CSICASERESPONSESTATUSC1,'' as CSICASEUSERFULLNAME,'' as CSICASEUSERID,'' as CSICASEUSERIDREDI,'' as CSICASEUSERNAME,'' as CSICASEVIRTBILLSHIPC1,'' as CSICASEWHENLOADED," +
    //      "'' as CSICASEWHENUPDATED,'' as CSICASEWHOLOADED,'' as CSICASEWHOUPDATED,'' as CSICASEXNOTE,'' as CSICASEXNUM1,'' as CSICASEXNUM2,'' as CSICASEXTEXT1,'' as CSICASEXTEXT2,'' as CSIFRAUDYN,'' as CSILASTUPDATED,'' as CSILASTUPDATEDYYYYMMDD,'' as CSIORDERSTATUS,'' as CSIUPDATEUSER,'' as CSIUSER,'' as CSIWHENUPDATED,'' as CSIWHOLOADED,'' as CSIWHOUPDATED,'' as CURRENCYCODE,'' as CURRENCYDESC,'' as CUSTEMAILPART1,'' as CUSTHOMEPHONETYPE,'' as CUSTHOMEPHONETYPEORDER,'' as CUSTHOMEPHONETYPESHORT,'' as CUSTWORKPHONETYPE,'' as CUSTWORKPHONETYPEORDER,'' as CUSTWORKPHONETYPESHORT,'' as CBDATETEXT,'' as DECISIONREDI,'' as DELTAMINUTES,'' as DELTAMINUTESSUB,'' as DENYCOUNT,'' as DENYVALUE,'' as DENYVALUECLIENT,'' as DENYVALUEEUR," +
    //      "'' as DENYVALUEGBP,'' as DENYVALUESUBCLIENT,'' as DENYVALUEUSD,'' as DURATION,'' as DURATION_192,'' as DURATION_BTI,'' as DURATION_COP,'' as DURATION_CX,'' as DURATION_DVE,'' as DURATION_EWB,'' as DURATION_GATHER,'' as DURATION_IOV,'' as DURATION_IPID,'' as DURATION_PPI,'' as DURATION_PRISM,'' as DURATION_PWS,'' as DURATION_RECOMMEND,'' as DURATION_RPS,'' as DURATION_SDS,'' as DURATION_TMX,'' as DURATION_TMX_SVC,'' as DURATION_TSW,'' as DURATION_VALID,'' as DVE_ANSWER,'' as END_TIME,'' as END_TIME_CHAR,'' as FLAG01,'' as FLAG02,'' as FLAG03,'' as FLAG04,'' as FLAG05,'' as FLAG06,'' as FLAG07,'' as FLAG08,'' as FLAG09,'' as FLAG10,'' as FLAG11,'' as FLAG12,'' as FLAG13,'' as FLAG14,'' as FLAG15,'' as FLAG16,'' as FLAG17,'' as FLAG18," +
    //      "'' as FLAG19,'' as FLAG20,'N' as FLAGSUSED,'' as GENNOTE,'' as GRAPHLABELDATE,'' as GRAPHLABELMONTH,'' as GRAPHLABELMONTHSORT,'' as GRAPHLABELWEEK,'' as MASKEDCARDNO, '' as GRAPHLABELWEEKSORT,'' as IGNORERULES,'' as ISSUERALERT,'' as ISSUERALERTDATE,'' as ISSUERALERTKEY,'' as ISSUERALERTYYYYMMDD,'' as LIVERECORD,'' as MATCHCITYBILLIP,'' as MATCHCOUNTRYANYMISMATCH,'' as MATCHCOUNTRYBILLBIN,'' as MATCHCOUNTRYBILLIP,'' as MATCHCOUNTRYBILLSHIP,'' as MATCHCOUNTRYIPBIN,'' as MATCHCOUNTRYSHIPBIN,'' as MATCHCOUNTRYSHIPIP,'' as MATCHEDOID,'' as MATCHSTATEBILLIP,'' as MATCHSTATEBILLSHIP,'' as MATCHSTATERECIPIP,'' as MATCHSTATESHIPIP,'' as MATCHTYPE,'' as MATCHZIPBILLRECIP,'' as MATCHZIPBILLSHIP,'' as MODIFY_TIMESTAMP,'' as CBMONTHTEXT," +
    //      "'' as CBMONTHYYYYMM,'' as MULTIPLERECIP,'' as NOSCORECT,'' as ORDER_DATE_TIME_GMT,'' as ORDERDATETIME,'' as ORIGRECOMM,'' as ORIGRECOMMSORT,'' as OTHERCOUNT,'' as OTHERVALUE,'' as OTHERVALUECLIENT,'' as OTHERVALUEEUR,'' as OTHERVALUEGBP,'' as OTHERVALUESUBCLIENT,'' as OTHERVALUEUSD,'' as OUTCOMEREASON,'' as OUTCOMEREC,'' as OVERRIDE,'' as OVERRIDEFRAUDYN,'' as OVERRIDETYPE,'' as OVERRIDEUPDATEDYYYYMMDD,'' as OVERRIDEYYYYMMDD,'' as PAYMETHODSHORT,'' as PROCDATETIME,'' as CBPROCESSOR,'' as PSPMERCHANTID,'' as RAWCBDATE,'' as RAWDATAFILEDATE,'' as RAWTXNDATE,'' as REALFRAUDYYYYMMDD,'' as CBREASONTEXT,'' as RECEIVE_TIME,'' as REDTOF,'' as REDTOF1,'' as REDTOF2,'' as REDTOF3," +
    //      "'' as REDTOF4,'' as REDTOF5,'' as RELFRAUDOID,'' as RELFRAUDTYPE,'N' as RELFRAUDYN,'' as RELFRAUDYYYYMMDD,'' as REPEATDENY,'' as REPORTSORT, '' as REPORTTEXT,'' as REPORTTEXT2,'' as REPORTTEXTSHORT,'' as SDSCOUNT,'' as CBSDSYN,'' as SHIPCOMMENTS12,'' as SHIPCOMMENTSITEM12,'' as SHIPDEST12,'' as SHIPFROMRECIP,'' as SHIPPHONETYPE,'' as SHIPPHONETYPEORDER,'' as SHIPPHONETYPESHORT,'' as SHIPUKPOSTCODEAREA,'' as SHIPUKPOSTCODEDISTRICT,'' as SHIPUKPOSTCODEFULL,'' as SHIPUKPOSTCODERISK,'' as SHIPUKPOSTCODESECTOR,'' as SHIPZIPCDNORM,'' as SOURCEFILE,'' as SOURCERAWCBDATE,'' as SOURCERAWTXNDATE,'' as SUBGRAPHLABELDATE,'' as SUBGRAPHLABELMONTH,'' as SUBGRAPHLABELMONTHSORT,'' as SUBGRAPHLABELWEEK,'' as SUBGRAPHLABELWEEKSORT,'' as TCHARGEBACKID," +
    //      "'' as TEMPCARDNO,'' as TESTCT,'' as TESTTXN,'' as CBTXNDATEACTUAL,'' as CBTXNDATETEXT,'' as CBTXNDATEYYYYMMDD,'' as TXNTIME,'' as VALUEBAND,'' as VALUEBANDCODE,'' as CBWEEKSTART,'' as CBWEEKTEXT,'' as CBWEEKYYYYMMDD,'' as XGENDT1,'' as XGENDT2,'' as XGENNUM1,'' as XGENNUM2,'' as XGENNUM3,'' as XGENNUM4,'' as XGENTEXT1,'' as XGENTEXT2, '' as XGENTEXT3,'' as XGENTEXT4,'' as XGENTEXT5,'' as XGENTYPE,'' as XGENYN1,'' as XGENYN2,'' as XGENYN3,'' as XMERCHANTID,'' as XMERCHANTNAME,'' as XMERCHANTYN,'' as NUMRULEINFO,'' as SERVICEPROCESS,''as RULECATEGORYFLAG from inputcore")
    //    val retFinalDFTransMaster = inputDataFrame.join(df1, Seq("oid"), "left_outer")


    val retFinalDFTransMasterWithColumn = inputDataFrame.select($"*" +: WITHCOLUMNNAMES.map(c =>
      lit("").alias(s"$c")
    ): _*)

    val retFinalDFTransMaster = retFinalDFTransMasterWithColumn
      .withColumn("CHARGEBACKYN", lit("N"))
      .withColumn("FLAGSUSED", lit("N"))
      .withColumn("RELFRAUDYN", lit("N"))
      .withColumn("DECISIONREDI", lit("A"))
      .withColumn("DELTAMINUTES", lit(0))
      .withColumn("ACCEPTVALUE", lit(0))
      .withColumn("CHALLENGEVALUE", lit(0))
      .withColumn("DENYVALUE", lit(0))
      .withColumn("OTHERVALUE", lit(0))
      .withColumn("SDSCOUNT", lit(0))
      .withColumn("MATCHCITYBILLIP", lit("X"))
      .withColumn("MATCHCOUNTRYBILLSHIP", lit("X"))
      .withColumn("MATCHCOUNTRYBILLIP", lit("X"))
      .withColumn("MATCHCOUNTRYBILLBIN", lit("X"))
      .withColumn("MATCHCOUNTRYSHIPIP", lit("X"))
      .withColumn("MATCHCOUNTRYSHIPBIN", lit("X"))
      .withColumn("MATCHCOUNTRYIPBIN", lit("X"))
      .withColumn("MATCHCOUNTRYANYMISMATCH", lit("X"))
      .withColumn("MATCHSTATEBILLIP", lit("X"))
      .withColumn("MATCHSTATEBILLSHIP", lit("X"))
      .withColumn("MATCHSTATERECIPIP", lit("X"))
      .withColumn("MATCHSTATESHIPIP", lit("X"))
      .withColumn("MATCHZIPBILLRECIP", lit("X"))
      .withColumn("MATCHZIPBILLSHIP", lit("X"))
      .withColumn("AUTHDECCT", lit(0))
      .withColumn("TESTCT", lit(0))
      .withColumn("NOSCORECT", lit(0))

    val currencyConversion = currencyConversionAndValueBands(retFinalDFTransMaster)
    val countryName = CountryNameDf(currencyConversion)
    val billCountry = countryNameBillCountry(countryName, countryDimensionbc)
    val virtIovCntryCd = countryNameVirtIovCntryCd(billCountry, countryDimensionbc)
    val shipCountry = countryNameShipCountry(virtIovCntryCd, countryDimensionbc)
    val virtBin = countryNameVirtBin(shipCountry, countryDimensionbc)
    val virtIpidCountryEbg = countryNameVirtIpidCountryEbg(virtBin, countryDimensionbc)
    //val region = getRegion(virtIpidCountryEbg)
    val rs001TidyLoaded = rs001TidyLoadedData(virtIpidCountryEbg)
    val custName = addCustName(rs001TidyLoaded)
    val descTransformation = addDescTransformation(custName)
    //val transfmClientDetailsDf = transfmClientDetails(descTransformation)
    val transformDateBanddf = transformDateBand(descTransformation)
    val initialRecommedStatusDetaildf = initialRecommedStatusDetail(transformDateBanddf)
    val transfmRuleBandAndDescDF = transfmRuleBandAndDesc(initialRecommedStatusDetaildf)
    val maskedcardnotransformationdf = maskedcardnotransformation(transfmRuleBandAndDescDF)
    val graphLabelfieldsDf = graphLabelfields(maskedcardnotransformationdf)
    val rsShipBillPhoneUpdateDF = rsShipBillPhoneUpdate(graphLabelfieldsDf)
    val addReportTextDF = addReportText(rsShipBillPhoneUpdateDF)
    addReportTextDF
    //graphLabelfieldsDf
  }

  /** MERF-9134 */

  def currencyConversionAndValueBands(df: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:currencyConversionAndValueBands")

    val allCurrencyTotal = df.withColumn("USDValueBand", getvalueBand(col("TotalUSD"), lit("USDValueBand")))
      .withColumn("GBPValueBand", getvalueBand(col("TotalGBP"), lit("GBPValueBand")))
      .withColumn("EURValueBand", concat(lit("EUR"), lit(" "), getvalueBand(col("TotalEUR"), lit("EURValueBand"))))
      .withColumn("ClientValueBand",
        when(col("currclient") === lit("USD"), getvalueBand(col("TotalClient"), lit("USDValueBand")))
          .when(col("currclient") === lit("GBP"), getvalueBand(col("TotalClient"), lit("GBPValueBand")))
          .when(col("currclient") === lit("EUR"), concat(lit("EUR"), getvalueBand(col("TotalClient"), lit("EURValueBand"))))
          .otherwise(concat(col("currclient"), lit(" "), getvalueBand(col("TotalClient"), lit("ClientValueBand"))))
      )
      .withColumn("SubClientValueBand",
        when(col("currsubclient") === lit("USD"), getvalueBand(col("TotalSubClient"), lit("USDValueBand")))
          .when(col("currsubclient") === lit("GBP"), getvalueBand(col("TotalSubClient"), lit("GBPValueBand")))
          .when(col("currsubclient") === lit("EUR"), concat(lit("EUR"), getvalueBand(col("TotalSubClient"), lit("EURValueBand"))))
          .otherwise(concat(col("currsubclient"), lit(" "), getvalueBand(col("TotalSubClient"), lit("SubClientValueBand")))))
      .withColumn("GBPValueBandCode",
        getvalueBandCode(col("TotalGBP"), lit("GBPValueBandCode")))
      .withColumn("USDValueBandCode", getvalueBandCode(col("TotalUSD"), lit("USDValueBandCode")))
      .withColumn("EURValueBandCode", getvalueBandCode(col("TotalEUR"), lit("EURValueBandCode")))
      .withColumn("ClientValueBandCode",
        when(col("currclient") === lit("USD"), getvalueBandCode(col("TotalClient"), lit("USDValueBandCode")))
          .when(col("currclient") === lit("GBP"), getvalueBandCode(col("TotalClient"), lit("GBPValueBandCode")))
          .when(col("currclient") === lit("EUR"), getvalueBandCode(col("TotalClient"), lit("EURValueBandCode")))
          .otherwise(getvalueBandCode(col("TotalClient"), lit("ClientValueBandCode"))))
      .withColumn("SubClientValueBandCode",
        when(col("currsubclient") === lit("USD"), getvalueBandCode(col("TotalSubClient"), lit("USDValueBandCode")))
          .when(col("currsubclient") === lit("GBP"), getvalueBandCode(col("TotalSubClient"), lit("GBPValueBandCode")))
          .when(col("currsubclient") === lit("EUR"), getvalueBandCode(col("TotalSubClient"), lit("EURValueBandCode")))
          .otherwise(getvalueBandCode(col("TotalSubClient"), lit("SubClientValueBandCode"))))
    allCurrencyTotal
  }


  def getvalueBandCode: UserDefinedFunction = udf((bandvaluep: String, bandcode: String) => {
    var bandvalue: Double = 0.0
    //        transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": getvalueBandCode Started")

    if (bandvaluep != null && !bandvaluep.equalsIgnoreCase("null") && !bandvaluep.isEmpty) {
      bandvalue = bandvaluep.toDouble
    }
    bandcode.trim match {
      case "GBPValueBandCode" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "VA5000"
          case bandvalue2000 if bandvalue2000 > 2000 => "VA2000"
          case bandvalue1000 if bandvalue1000 > 1000 => "VA1000"
          case bandvalue500 if bandvalue500 > 500 => "VA0500"
          case bandvalue400 if bandvalue400 > 400 => "VA0400"
          case bandvalue300 if bandvalue300 > 300 => "VA0300"
          case bandvalue200 if bandvalue200 > 200 => "VA0200"
          case bandvalue100 if bandvalue100 > 100 => "VA0100"
          case bandvalue75 if bandvalue75 > 75 => "VA075"
          case bandvalue50 if bandvalue50 > 50 => "VA050"
          case bandvalue25 if bandvalue25 > 25 => "VA025"
          case bandvalue10 if bandvalue10 > 10 => "VA010"
          case _ => "VA0000"
        }
      case "USDValueBandCode" =>
        bandvalue match {
          case bandvalue10000 if bandvalue10000 > 10000 => "VA9999"
          case bandvalue5000 if bandvalue5000 > 5000 => "VA5000"
          case bandvalue2000 if bandvalue2000 > 2000 => "VA2000"
          case bandvalue1000 if bandvalue1000 > 1000 => "VA1000"
          case bandvalue500 if bandvalue500 > 500 => "VA0500"
          case bandvalue400 if bandvalue400 > 400 => "VA0400"
          case bandvalue300 if bandvalue300 > 300 => "VA0300"
          case bandvalue200 if bandvalue200 > 200 => "VA0200"
          case bandvalue100 if bandvalue100 > 100 => "VA0100"
          case bandvalue75 if bandvalue75 > 75 => "VA0075"
          case bandvalue50 if bandvalue50 > 50 => "VA0050"
          case bandvalue25 if bandvalue25 > 25 => "VA0025"
          case bandvalue10 if bandvalue10 > 10 => "VA0010"
          case _ => "VA0000"
        }
      case "EURValueBandCode" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "VA5000"
          case bandvalue2000 if bandvalue2000 > 2000 => "VA2000"
          case bandvalue1000 if bandvalue1000 > 1000 => "VA1000"
          case bandvalue500 if bandvalue500 > 500 => "VA0500"
          case bandvalue400 if bandvalue400 > 400 => "VA0400"
          case bandvalue300 if bandvalue300 > 300 => "VA0300"
          case bandvalue200 if bandvalue200 > 200 => "VA0200"
          case bandvalue100 if bandvalue100 > 100 => "VA0100"
          case bandvalue75 if bandvalue75 > 75 => "VA0075"
          case bandvalue50 if bandvalue50 > 50 => "VA0050"
          case bandvalue25 if bandvalue25 > 25 => "VA0025"
          case bandvalue10 if bandvalue10 > 10 => "VA0010"
          case _ => "VA0000"
        }

      case "ClientValueBandCode" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "VA5000"
          case bandvalue2000 if bandvalue2000 > 2000 => "VA2000"
          case bandvalue1000 if bandvalue1000 > 1000 => "VA1000"
          case bandvalue500 if bandvalue500 > 500 => "VA0500"
          case bandvalue400 if bandvalue400 > 400 => "VA0400"
          case bandvalue300 if bandvalue300 > 300 => "VA0300"
          case bandvalue200 if bandvalue200 > 200 => "VA0200"
          case bandvalue100 if bandvalue100 > 100 => "VA0100"
          case bandvalue75 if bandvalue75 > 75 => "VA0075"
          case bandvalue50 if bandvalue50 > 50 => "VA0050"
          case bandvalue25 if bandvalue25 > 25 => "VA0025"
          case bandvalue10 if bandvalue10 > 10 => "VA0010"
          case _ => "VA0000"
        }

      case "SubClientValueBandCode" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "VA5000"
          case bandvalue2000 if bandvalue2000 > 2000 => "VA2000"
          case bandvalue1000 if bandvalue1000 > 1000 => "VA1000"
          case bandvalue500 if bandvalue500 > 500 => "VA0500"
          case bandvalue400 if bandvalue400 > 400 => "VA0400"
          case bandvalue300 if bandvalue300 > 300 => "VA0300"
          case bandvalue200 if bandvalue200 > 200 => "VA0200"
          case bandvalue100 if bandvalue100 > 100 => "VA0100"
          case bandvalue75 if bandvalue75 > 75 => "VA0075"
          case bandvalue50 if bandvalue50 > 50 => "VA0050"
          case bandvalue25 if bandvalue25 > 25 => "VA0025"
          case bandvalue10 if bandvalue10 > 10 => "VA0010"
          case _ => "VA0000"
        }

    }
  }
  )


  def getvalueBand: UserDefinedFunction = udf((bandvaluep: String, bandcode: String) => {
    var bandvalue: Double = 0
    if (bandvaluep != null && !bandvaluep.isEmpty) {
      bandvalue = bandvaluep.toDouble
    }
    bandcode match {
      case "GBPValueBand" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "Over £5,000"
          case bandvalue2000 if bandvalue2000 > 2000 => "£2,000-£5,000"
          case bandvalue1000 if bandvalue1000 > 1000 => "£1,000-£2,000"
          case bandvalue500 if bandvalue500 > 500 => "£500-£1,000"
          case bandvalue400 if bandvalue400 > 400 => "£400-£500"
          case bandvalue300 if bandvalue300 > 300 => "£300-£400"
          case bandvalue200 if bandvalue200 > 200 => "£200-£300"
          case bandvalue100 if bandvalue100 > 100 => "£100-£200"
          case bandvalue75 if bandvalue75 > 75 => "£75-£100"
          case bandvalue50 if bandvalue50 > 50 => "£50-£75"
          case bandvalue25 if bandvalue25 > 25 => "£25-£50"
          case bandvalue10 if bandvalue10 > 10 => "£10-£25"
          case _ => "£10/Under"
        }
      case "USDValueBand" =>
        bandvalue match {
          case bandvalue10000 if bandvalue10000 > 10000 => "Over $10,000"
          case bandvalue5000 if bandvalue5000 > 5000 => "$5,000-$10,000"
          case bandvalue2000 if bandvalue2000 > 2000 => "$2,000-$5,000"
          case bandvalue1000 if bandvalue1000 > 1000 => "$1,000-$2,000"
          case bandvalue500 if bandvalue500 > 500 => "$500-$1,000"
          case bandvalue400 if bandvalue400 > 400 => "$400-$500"
          case bandvalue300 if bandvalue300 > 300 => "$300-$400"
          case bandvalue200 if bandvalue200 > 200 => "$200-$300"
          case bandvalue100 if bandvalue100 > 100 => "$100-$200"
          case bandvalue75 if bandvalue75 > 75 => "$75-$100"
          case bandvalue50 if bandvalue50 > 50 => "$50-$75"
          case bandvalue25 if bandvalue25 > 25 => "$25-$50"
          case bandvalue10 if bandvalue10 > 10 => "$10-$25"
          case _ => "$10/Under"
        }
      case "EURValueBand" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "Over 5,000"
          case bandvalue2000 if bandvalue2000 > 2000 => "2,000-5,000"
          case bandvalue1000 if bandvalue1000 > 1000 => "1,000-2,000"
          case bandvalue500 if bandvalue500 > 500 => "500-1,000"
          case bandvalue400 if bandvalue400 > 400 => "400-500"
          case bandvalue300 if bandvalue300 > 300 => "300-400"
          case bandvalue200 if bandvalue200 > 200 => "200-300"
          case bandvalue100 if bandvalue100 > 100 => "100-200"
          case bandvalue75 if bandvalue75 > 75 => "75-100"
          case bandvalue50 if bandvalue50 > 50 => "50-75"
          case bandvalue25 if bandvalue25 > 25 => "25-50"
          case bandvalue10 if bandvalue10 > 10 => "10-25"
          case _ => "10/Under"
        }
      case "ClientValueBand" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "Over 5,000"
          case bandvalue2000 if bandvalue2000 > 2000 => "2,000-5,000"
          case bandvalue1000 if bandvalue1000 > 1000 => "1,000-2,000"
          case bandvalue500 if bandvalue500 > 500 => "500-1,000"
          case bandvalue400 if bandvalue400 > 400 => "400-500"
          case bandvalue300 if bandvalue300 > 300 => "300-400"
          case bandvalue200 if bandvalue200 > 200 => "200-300"
          case bandvalue100 if bandvalue100 > 100 => "100-200"
          case bandvalue75 if bandvalue75 > 75 => "75-100"
          case bandvalue50 if bandvalue50 > 50 => "50-75"
          case bandvalue25 if bandvalue25 > 25 => "25-50"
          case bandvalue10 if bandvalue10 > 10 => "10-25"
          case _ => "10/Under"
        }

      case "SubClientValueBand" =>
        bandvalue match {
          case bandvalue5000 if bandvalue5000 > 5000 => "Over 5,000"
          case bandvalue2000 if bandvalue2000 > 2000 => "2,000-5,000"
          case bandvalue1000 if bandvalue1000 > 1000 => "1,000-2,000"
          case bandvalue500 if bandvalue500 > 500 => "500-1,000"
          case bandvalue400 if bandvalue400 > 400 => "400-500"
          case bandvalue300 if bandvalue300 > 300 => "300-400"
          case bandvalue200 if bandvalue200 > 200 => "200-300"
          case bandvalue100 if bandvalue100 > 100 => "100-200"
          case bandvalue75 if bandvalue75 > 75 => "75-100"
          case bandvalue50 if bandvalue50 > 50 => "50-75"
          case bandvalue25 if bandvalue25 > 25 => "25-50"
          case bandvalue10 if bandvalue10 > 10 => "10-25"
          case _ => "10/Under"
        }
    }
  })

  //    def valueBands: UserDefinedFunction = udf((totalValue: String, band: String) => {
  //
  //        var valueBand: DataFrame = null
  //        var value: String = null
  //        if (totalValue != null && !totalValue.isEmpty) {
  //            valueBand = spark.sql(s"select bandvalue  from bandmetadatasource where ${totalValue.toDouble} > lowerband and ${totalValue.toDouble} <= upperband  and bandcategory=\'$band\'")
  //        }
  //        if (valueBand != null && valueBand.count() > 0) {
  //            value = valueBand.head().getString(0)
  //        }
  //        value
  //    })

  /** End of MERF-9134 */

  /** MERF-9239 */

  //  var countryDimensionbc: Broadcast[DataFrame] = _
  //val countryDimensionbc = rsTransFlowDao.getCountryDimension(REDI_RBI_REF_COUNTRY_TABLE).cache()

  /**
    * Method to fetch country dimension data from Hive -- MERF-9239 -- Prabhu
    */

  /*  def getCountryDimensionData(): DataFrame = {
        rsTransFlowDao.getCountryDimension(REDI_RBI_REF_COUNTRY_TABLE)
    }*/


  /** Country Risk Function -- MERF-9239 -- Prabhu **/

  //def countryName(sc: SparkSession, countrydimension: DataFrame, countrycode: String): String = {
  //    def countryName(countrydimension: DataFrame, countrycode: String): String = {
  //        var countryName: String = null
  //        var fetchcountryName = countrydimension.filter(col("countrycode") === countrycode or col("countrycode2") === countrycode).select("countrydesc")
  //        //var fetchcountryName = spark.sql(s"select countrydesc from countrydimensionview where (countrycode=\'$countrycode\' or countrycode2=\'$countrycode\')")
  //
  //        if (fetchcountryName.count() > 0) {
  //            countryName = fetchcountryName.select("countrydesc").head().getString(0)
  //        }
  //        countryName
  //    }

  def UdffuncCountryRisk = udf((cntryCode: String) => {
    /* -- Risk countries are Russian Federation (643), Panama (591), Mexico (484), Thailand (764) */
    val riskCntryCodeList: List[String] = List("643", "591", "484", "764")
    var CntryRisk: String = null

    if (cntryCode != null && !riskCntryCodeList.isEmpty && riskCntryCodeList.contains(cntryCode)) {
      CntryRisk = "H"
    } else if (cntryCode != null && !riskCntryCodeList.isEmpty && !riskCntryCodeList.contains(cntryCode)) {
      CntryRisk = "L"
    } else {
      CntryRisk = "X"
    }
    CntryRisk
  }
  )

  def CountryNameDf(execDF: DataFrame): DataFrame = {

    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:CountryNameDf")

    execDF.withColumn("BillCountry", when(col("BillCountry") === lit("826") && (col("BillZipcd").isNull || col("BillZipcd") === "") && (col("BillZipcd").isNull || col("BillZipcd") === "") && (col("BillCity").isNull || col("BillCity") === "") && (col("BillAddress2").isNull || col("BillAddress2") === "") && (col("BillStreet").isNull || col("BillStreet") === "") && (col("BillState").isNull || col("BillState") === ""), lit("X26")).otherwise(col("BillCountry")))
      .withColumn("BillCountryRisk", when((col("BillCountry").isNull || col("BillCountry") === ""), lit("X")).otherwise(UdffuncCountryRisk(col("BillCountry"))))
      .withColumn("ShipCountryRisk", when((col("ShipCountry").isNull || col("ShipCountry") === ""), lit("X")).otherwise(UdffuncCountryRisk(col("ShipCountry"))))
      .withColumn("VirtIPIDCountryEBGRisk", when((col("VirtIpidCountryEbg").isNull || col("VirtIpidCountryEbg") === ""), lit("X")).otherwise(UdffuncCountryRisk(col("VirtIpidCountryEbg"))))
      .withColumn("VirtBinCountryRisk", when((col("VirtBin").isNull || col("VirtBin") === ""), lit("X")).otherwise(UdffuncCountryRisk(col("VirtBin"))))
      .withColumn("RouteOneUK", when(col("VirtBin") === lit("826") && col("VirtIpidCountryEbg") =!= lit("840") && col("BillCountry") =!= lit("840") && col("ShipCountry") =!= lit("840"), lit("Y")).otherwise(lit(null)))
  }


  def countryNameBillCountry(execDF: DataFrame, countrydimension1: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:countryNameBillCountry")
    val countrydimension2 = countrydimension1.select($"countrycode", $"countrycode2", $"countrydesc")
    val joinDF = execDF.join(countrydimension2, execDF("BillCountry") === countrydimension2("countrycode") || execDF("BillCountry") === countrydimension2("countrycode2"), "left_outer").drop($"countrycode").drop($"countrycode2")
      .withColumnRenamed("countrydesc", "BillCountryName")
    joinDF
  }

  def countryNameVirtIovCntryCd(execDF: DataFrame, countrydimension1: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:countryNameVirtIovCntryCd")
    val countrydimension2 = countrydimension1.select($"countrycode", $"countrycode2", $"countrydesc")
    val joinDF = execDF.join(countrydimension2, execDF("VirtIovCntryCd") === countrydimension2("countrycode") || execDF("VirtIovCntryCd") === countrydimension2("countrycode2"), "left_outer").drop($"countrycode").drop($"countrycode2").withColumnRenamed("countrydesc", "VirtIOVCountryName")
    joinDF
  }

  def countryNameShipCountry(execDF: DataFrame, countrydimension1: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:countryNameShipCountry")
    val countrydimension2 = countrydimension1.select($"countrycode", $"countrycode2", $"countrydesc")
    val joinDF = execDF.join(countrydimension2, execDF("ShipCountry") === countrydimension2("countrycode") || execDF("ShipCountry") === countrydimension2("countrycode2"), "left_outer").drop($"countrycode").drop($"countrycode2").withColumnRenamed("countrydesc", "ShipCountryName")
    joinDF
  }

  def countryNameVirtBin(execDF: DataFrame, countrydimension1: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:countryNameVirtBin")
    val countrydimension2 = countrydimension1.select($"countrycode", $"countrycode2", $"countrydesc")
    val joinDF = execDF.join(countrydimension2, execDF("VirtBin") === countrydimension2("countrycode") || execDF("VirtBin") === countrydimension2("countrycode2"), "left_outer").drop($"countrycode").drop($"countrycode2").withColumnRenamed("countrydesc", "VirtBinCountryName")
    joinDF
  }

  def countryNameVirtIpidCountryEbg(execDF: DataFrame, countrydimension1: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:countryNameVirtIpidCountryEbg")
    val countrydimension2 = countrydimension1.select($"countrycode", $"countrycode2", $"countrydesc")
    val joinDF = execDF.join(countrydimension2, execDF("VirtIpidCountryEbg") === countrydimension2("countrycode") || execDF("VirtIpidCountryEbg") === countrydimension2("countrycode2"), "left_outer").drop($"countrycode").drop($"countrycode2").withColumnRenamed("countrydesc", "VirtIPIDCountryEBGName")
    joinDF
  }

  /** End of MERF-9239 */

  /** MERF-9243 */
  // KP Perf changes
  /*def getRegion(df: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:getRegion")
    val rbiRefClient = dfRbiRefClientData.select($"ClientID", $"SubClientID", $"Region")
    //df.join(rbiRefClient, Seq("ClientID", "SubClientID"), "left_outer")
    rbiRefClient.join(df, Seq("ClientID", "SubClientID"), "right_outer")
    //.withColumn("Region", col("Region"))
  }*/

  /*val rbiMap = dfRbiRefClientData.select($"ClientID", $"SubClientID", $"Region").collect().map(row => (row.getString(0)+""+row.getString(1), row.getString(2))).toMap

  def getRegion(df: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:getRegion")
    df.withColumn("Region", regionFromRbiRefClient($"ClientID", $"SubClientID"))
  }

  def regionFromRbiRefClient = udf((ClientID: String, SubClientID: String) => {
    var clientSubClient: String = ""
    var region:String=""
    if (ClientID != null) {
      clientSubClient = ClientID
    }
    if (SubClientID != null) {
      clientSubClient= clientSubClient.concat(SubClientID)
    }
    if (rbiMap.isDefinedAt(clientSubClient)) {
      var res = rbiMap.get(clientSubClient)
      region =res.get
    }
    region
  })*/


  /** End of MERF-9243 */

  /** MERF-9137 */

  //  def oIdDateWithoutTimePart = udf((oidDate: String) => {
  //    val inputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
  //    val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
  //    val date = outputFormat.format(inputFormat.parse(oidDate))
  //    date
  //  })


  def getHourBand = udf((oidDate: String) => {
    val hourpart = TransCoreController.getHourPart(oidDate)
    if (hourpart != null && !hourpart.isEmpty) {
      val oidhourband = "HR".concat(hourpart).concat("00")
      oidhourband
    } else {
      null
    }
  })

  def getHourBandDesc = udf((oidDate: String) => {
    val hourpart = TransCoreController.getHourPart(oidDate)
    if (hourpart != null && !hourpart.isEmpty) {
      var hourbanddesc = hourpart.concat("00-").concat(hourpart).concat("59")
      hourbanddesc
    } else {
      null
    }
  })

  // KP Perf changes
  /*  def getClientOrSubClientHourBand = udf((oidDate: String, tzClient: String) => {
      var inputTimeZone = tzClient
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }
      val clientHourPart = TransCoreController.getHourPart(oidDate, inputTimeZone)
      if (clientHourPart != null && !clientHourPart.isEmpty) {
        var clientHourBand = "HR".concat(clientHourPart).concat("00")
        clientHourBand
      } else {
        null
      }
    })

    def getClientOrSubClientDesc = udf((oidDate: String, tzClient: String) => {
      var inputTimeZone = tzClient
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }
      val clientHourPart = TransCoreController.getHourPart(oidDate, inputTimeZone)
      if (clientHourPart != null && !clientHourPart.isEmpty) {
        var clientHourbanddesc = clientHourPart.concat("00-").concat(clientHourPart).concat("59")
        clientHourbanddesc
      } else {
        null
      }
    })*/

  def transformDateBand(df: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:transformDateBand")
    df
      .withColumn("oidhourband", getHourBand($"OidDate".cast("string")))
      .withColumn("oidhourbanddesc", getHourBandDesc($"OidDate".cast("string")))
      .withColumn("clienthourband", when($"clientdate".isNotNull, getHourBand($"clientdate".cast("string"))).otherwise(lit(null)))
      .withColumn("clienthourbanddesc", when($"clientdate".isNotNull, getHourBandDesc($"clientdate".cast("string"))).otherwise(lit(null)))
      .withColumn("subclienthourband", when($"subclientdate".isNotNull, getHourBand($"subclientdate".cast("string"))).otherwise(lit(null)))
      .withColumn("subclienthourbanddesc", when($"subclientdate".isNotNull, getHourBandDesc($"subclientdate".cast("string"))).otherwise(lit(null)))
      .withColumn("durationband", getDurationBandandDesc($"duration", lit("DurationBand")))
      .withColumn("durationbanddesc", getDurationBandandDesc($"duration", lit("DurationBandDesc")))
  }

  def getDurationBandandDesc: UserDefinedFunction = udf((durationbandvaluep: String, durationband: String) => {
    var durationbandvalue: Double = 0
    if (durationbandvaluep != null && !durationbandvaluep.equalsIgnoreCase("null") && !durationbandvaluep.isEmpty) {
      durationbandvalue = durationbandvaluep.toDouble
    }
    durationband match {
      case "DurationBand" =>
        durationbandvalue match {
          case durationbandvalue30 if durationbandvalue30 > 30.0 => "DU9999"
          case durationbandvalue20 if durationbandvalue20 > 20.0 => "DU3000"
          case durationbandvalue10 if durationbandvalue10 > 10.0 => "DU2000"
          case durationbandvalue5 if durationbandvalue5 > 5.0 => "DU1000"
          case durationbandvalue4 if durationbandvalue4 > 4.0 => "DU0500"
          case durationbandvalue3 if durationbandvalue3 > 3.0 => "DU0400"
          case durationbandvalue2 if durationbandvalue2 > 2.0 => "DU0300"
          case durationbandvalue1 if durationbandvalue1 > 1.0 => "DU0200"
          case durationbandvalue05 if durationbandvalue05 > 0.5 => "DU0100"
          case durationbandvalue025 if durationbandvalue025 > 0.25 => "DU0050"
          case _ => "DU0025"
        }
      case "DurationBandDesc" =>
        durationbandvalue match {
          case durationbandvalue30 if durationbandvalue30 > 30.0 => "Over 30 sec"
          case durationbandvalue20 if durationbandvalue20 > 20.0 => "20-30 sec"
          case durationbandvalue10 if durationbandvalue10 > 10.0 => "10-20 sec"
          case durationbandvalue5 if durationbandvalue5 > 5.0 => "5-10 sec"
          case durationbandvalue4 if durationbandvalue4 > 4.0 => "4-5 sec"
          case durationbandvalue3 if durationbandvalue3 > 3.0 => "3-4 sec"
          case durationbandvalue2 if durationbandvalue2 > 2.0 => "2-3 sec"
          case durationbandvalue1 if durationbandvalue1 > 1.0 => "1-2 sec"
          case durationbandvalue05 if durationbandvalue05 > 0.5 => "0.5-1 sec"
          case durationbandvalue025 if durationbandvalue025 > 0.25 => "0.25-0.5 sec"
          case _ => "under 0.25 sec"
        }
    }
  })

  /** End of MERF-9137 */

  /** MERF-9499 */

  def rs001TidyLoadedData(rs001DF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:rs001TidyLoadedData")
    val RS100DFACT = rs001DF
      .withColumn("Reason", when(upper(trim(col("Reason"))) === "NULL", lit(null)).otherwise(col("Reason")))
      .withColumn("TempEmail", when(col("xCustEmail").isNull or col("xCustEmail") === ""
        or col("xCustEmail") === " ", lit(null)).otherwise(split(col("xCustEmail"), "@")(0)))
      .withColumn("CustEMailPart1", when(col("TempEmail").isNull, lit(null)).otherwise(expr("substring(TempEmail,1,60)")))
      .drop("TempEmail")
      .withColumn("CustEMailRisk", when(col("xCustEmailDomain").isNull
        or col("xCustEmailDomain") === ""
        or col("xCustEmailDomain") === " ", "X")
        .when(upper(col("xCustEmailDomain")) === "YAHOO.COM"
          or upper(col("xCustEmailDomain")) === "YAHOO.CO.UK"
          or upper(col("xCustEmailDomain")) === "GMAIL"
          or upper(col("xCustEmailDomain")) === "HOTMAIL.COM", "H")
        .otherwise("L"))
    //      .withColumn("UserData01", when(col("UserData01").isNull, lit(null)).otherwise(upper(col("UserData01"))))
    //      .withColumn("UserData02", when(col("UserData02").isNull, lit(null)).otherwise(upper(col("UserData02"))))
    //      .withColumn("UserData03", when(col("UserData03").isNull, lit(null)).otherwise(upper(col("UserData03"))))
    //      .withColumn("UserData04", when(col("UserData04").isNull, lit(null)).otherwise(upper(col("UserData04"))))
    //      .withColumn("UserData05", when(col("UserData05").isNull, lit(null)).otherwise(upper(col("UserData05"))))
    //      .withColumn("UserData06", when(col("UserData06").isNull, lit(null)).otherwise(upper(col("UserData06"))))
    //      .withColumn("UserData07", when(col("UserData07").isNull, lit(null)).otherwise(upper(col("UserData07"))))
    //      .withColumn("UserData08", when(col("UserData08").isNull, lit(null)).otherwise(upper(col("UserData08"))))
    //      .withColumn("UserData09", when(col("UserData09").isNull, lit(null)).otherwise(upper(col("UserData09"))))
    //      .withColumn("UserData10", when(col("UserData10").isNull, lit(null)).otherwise(upper(col("UserData10"))))
    //      .withColumn("UserData11", when(col("UserData11").isNull, lit(null)).otherwise(upper(col("UserData11"))))
    //      .withColumn("UserData12", when(col("UserData12").isNull, lit(null)).otherwise(upper(col("UserData12"))))
    //      .withColumn("UserData13", when(col("UserData13").isNull, lit(null)).otherwise(upper(col("UserData13"))))
    //      .withColumn("UserData14", when(col("UserData14").isNull, lit(null)).otherwise(upper(col("UserData14"))))
    //      .withColumn("UserData15", when(col("UserData15").isNull, lit(null)).otherwise(upper(col("UserData15"))))
    //      .withColumn("UserData16", when(col("UserData16").isNull, lit(null)).otherwise(upper(col("UserData16"))))
    //      .withColumn("UserData17", when(col("UserData17").isNull, lit(null)).otherwise(upper(col("UserData17"))))
    //      .withColumn("UserData18", when(col("UserData18").isNull, lit(null)).otherwise(upper(col("UserData18"))))
    //      .withColumn("UserData19", when(col("UserData19").isNull, lit(null)).otherwise(upper(col("UserData19"))))
    //      .withColumn("UserData20", when(col("UserData20").isNull, lit(null)).otherwise(upper(col("UserData20"))))
    //      .withColumn("UserData21", when(col("UserData21").isNull, lit(null)).otherwise(upper(col("UserData21"))))
    //      .withColumn("UserData22", when(col("UserData22").isNull, lit(null)).otherwise(upper(col("UserData22"))))
    //      .withColumn("UserData23", when(col("UserData23").isNull, lit(null)).otherwise(upper(col("UserData23"))))
    //      .withColumn("UserData24", when(col("UserData24").isNull, lit(null)).otherwise(upper(col("UserData24"))))
    //      .withColumn("UserData25", when(col("UserData25").isNull, lit(null)).otherwise(upper(col("UserData25"))))

    RS100DFACT
  }

  /** End of MERF-9499 */

  /** MERF-9082 */

  /* @author KP MERF-9082 30/08/2018 Function for cleaning up client name column
   */
  /*  def trnsfmClientName = udf((clientid: String, clientname: String) => {
      var outputString: String = ""
      var df: DataFrame = null

      if (clientid != null || !clientid.isEmpty) {
        if (clientname == null || clientname.isEmpty) {
          df = dfDistinctClientName.select(max("ClientName")).where($"ClientId" === clientid)
          if (df != null && df.count() > 0) {
            //     val tmpdf = df.select(when($"ClientName" =!= null, $"ClientName").otherwise("Client " + clientid + " ???"))
            val tmpdf = df.select(coalesce($"ClientName", lit("Client " + clientid + " ???")).as("ClientName"))
            outputString = tmpdf.take(1).head(0).toString
          } else {
            outputString = "Client " + clientid + " ???"
          }
        } else {
          outputString = clientname
        }
        if (outputString == null || outputString.isEmpty) {
          outputString = "Client " + clientid + " ???"
        }
        outputString
      } else {
        if (clientname == null) {
          ""
        } else {
          clientname
        }
      }
    })*/


  /* @author KP MERF-9082 30/08/2018 Function for cleaning up subclient name column
   */
  /*
    def trnsfmSubClientName = udf((subclientid: String, clientname: String, clientnamenew: String, subclientname: String) => {
      var outputString: String = ""
      var df: DataFrame = null

      if (subclientid != null || !subclientid.isEmpty) {
        if (clientname == null || clientname.isEmpty) {
          if (clientnamenew.startsWith("Client") && clientnamenew.endsWith("???") == true) {
            outputString = "SubClient " + subclientid + " ???"
          } else {
            outputString = "Client " + subclientid + " ???"
          }
        } else {
          if (subclientname == null || subclientname.isEmpty) {
            outputString = "SubClient " + subclientid + " ???"
          } else {
            outputString = subclientname
          }
        }
        outputString
      } else {
        if (subclientname == null) {
          ""
        } else {
          subclientname
        }
      }
    })
  */


  /* @author KP MERF-9082 30/08/2018 Function used for ClientDate calculation
   */
  /*  def fntrgetTZConvertedDate = udf((OIDDate: String, TZValue: String) => {
      var inputTimeZone = TZValue
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }

      val returnTZ = TransCoreController.ConvertTimeZoneO(OIDDate, inputTimeZone)
      returnTZ

    })*/

  /* @author KP MERF-9082 30/08/2018 Function used for ClientDateYYYYMMDD calculation
   */
  /*  def fntrgetTZConvertedDateYYYYMMDD = udf((OIDDate: String, TZValue: String) => {
      var inputTimeZone = TZValue
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }
      val returnTZString = TransCoreController.ConvertTimeZoneYYYYMMDDO(OIDDate, inputTimeZone)
      returnTZString

    })*/

  /* @author KP MERF-9082 30/08/2018 Function used for Customer Names Transformation
   */
  def functTrnsfmCustName = udf((custfirstname: String, custlastname: String) => {
    var returnCustName: String = null
    if (custfirstname != null && !custfirstname.isEmpty && custlastname != null && !custlastname.isEmpty) {
      returnCustName = custfirstname + ", " + custlastname
    } else if ((custfirstname != null && !custfirstname.isEmpty) && (custlastname == null || custlastname.isEmpty)) {
      returnCustName = custfirstname
    } else if ((custlastname != null && !custlastname.isEmpty) && (custfirstname == null || custfirstname.isEmpty)) {
      returnCustName = custlastname
    }
    returnCustName
  })

  /*
     * Author : KP 28/08/2018 MERF-9240 function to add transformations description based on codes.
     */
  def addDescTransformation(inputDF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:addDescTransformation")
    inputDF.withColumn("CardTypeDesc", funcAddTransformedColumn(col("CardType"), lit("CardType")))
      .withColumn("PayMethodDesc", funcAddTransformedColumn(col("PayMethod"), lit("PayMethod")))
      .withColumn("PayMethodShort", funcAddTransformedColumn(col("PayMethod"), lit("PayMethodShort")))
      .withColumn("TranTypeDesc", funcAddTransformedColumn(col("TranType"), lit("TranType")))
      .withColumn("AuthRespDesc", funcAddTransformedColumn(col("AuthResp"), lit("AuthResp")))
      .withColumn("AVSResponseDesc", funcAddTransformedColumn(col("AVSResponse"), lit("AVSResponse")))
      .withColumn("CarrierDesc", funcAddTransformedColumn(col("Carrier"), lit("Carrier")))
      .withColumn("CINPresentDesc", funcAddTransformedColumn(col("CINPresent"), lit("CINPresent")))
      .withColumn("CINResponseDesc", funcAddTransformedColumn(col("CINResponse"), lit("CINResponse")))
      .withColumn("TranCategoryDesc", funcAddTransformedColumn(col("TranCategory"), lit("TranCategory")))
  }

  /*
* Author : KP 28/08/2018 MERF-9240 Generic utility to transform description based on codes.
*/

  def funcAddTransformedColumn: UserDefinedFunction = udf((inputValue: String, inputColumn: String) => {

    if (inputValue != null && !inputValue.isEmpty) {
      inputColumn match {
        case "CardType" => inputValue match {
          case "A" => "Amex"
          case "C" => "Card Blanche"
          case "D" => "Discover"
          case "E" => "Diners"
          case "J" => "JCB"
          case "M" => "Mastercard"
          case "V" => "Visa"
          case "P" => "Private Label"
          case "U" => "Alternative"
          case _ => "Unknown CardType " + inputValue
        }
        case "PayMethod" => inputValue match {
          case "O" => "Card Not Present - Online"
          case "P" => "Card Present"
          case "V" => "Card Not Present - Phone"
          case "A" => "ACH"
          case "C" => "Check"
          case "G" => "Gift Certificate"
          case "M" => "Money Order"
          case "W" => "Wire Transfer"
          case _ => "Unknown PayMethod " + inputValue
        }
        case "PayMethodShort" => inputValue match {
          case "O" => "CNP - Online"
          case "P" => "CP"
          case "V" => "CNP - Phone"
          case "A" => "ACH"
          case "C" => "Check"
          case "G" => "Gift Cert"
          case "M" => "Money Ord"
          case "W" => "Wire Tfr"
          case _ => "Unknown PayMethod " + inputValue
        }
        case "TranType" => inputValue match {
          case "P" => "Purchase"
          case _ => "Unknown TranType " + inputValue
        }
        case "AuthResp" => inputValue match {
          case "00" => "Auth OK"
          case "01" => "Referral"
          case "03" => "Invalid Merchant"
          case "04" => "Pickup"
          case "05" => "Decline"
          case "08" => "Honor with ID"
          case "12" => "Invalid Transaction"
          case "13" => "Invalid Amount"
          case "14" => "Invalid Card Number"
          case "15" => "Invalid Issuer"
          case "30" => "Format Error"
          case "41" => "Lost Card"
          case "43" => "Stolen Card"
          case "51" => "NSF Credit"
          case "54" => "Expired Card"
          case "55" => "Invalid PIN"
          case "57" => "ISSCH not permitted"
          case "58" => "ACQMER not permitted"
          case "61" => "Exceeds Withdrawal limit"
          case "62" => "Restricted Card"
          case "63" => "Security Violation"
          case "65" => "Exceeds Count"
          case "75" => "Exceeds PIN retries"
          case "76" => "Invalid to account"
          case "77" => "Invalid from account"
          case "78" => "RESERVED"
          case "80" => "CVC Decline"
          case "84" => "Invalid Life Cycle"
          case "85" => "Not declined"
          case "91" => "System Unavailable"
          case "92" => "Unable to Route"
          case "94" => "Duplicate"
          case "96" => "System Error"
          case _ => "Unknown AuthResp " + inputValue
        }
        case "AVSResponse" => inputValue match {
          case "X" => "AVS Exact"
          case "Y" => "AVS Zip Five Add"
          case "A" => "AVS Add Only"
          case "W" => "AVS Zip Nine"
          case "Z" => "AVS Zip Five Only"
          case "N" => "AVS No Match"
          case "U" => "AVS No Data"
          case "R" => "AVS Sys Unavail"
          case "G" => "Global"
          case "S" => "AVS Not Supported"
          case _ => "Unknown AVSResponse " + inputValue
        }
        case "Carrier" => inputValue match {
          case "F" => "Fedex"
          case "P" => "USPS"
          case "U" => "USP"
          case "L" => "Purolater"
          case "G" => "Greyhound"
          case "D" => "DHL"
          case "O" => "Other"
          case _ => "Unknown Carrier " + inputValue
        }
        case "CINPresent" => inputValue match {
          case "0" => "CV2 Not Provided"
          case "1" => "CV2 Present"
          case "2" => "CV2 Present Not Legible"
          case "8" => "CV2 Not Requested"
          case "9" => "CV2 Not Present"
          case _ => "Unknown CINPresent " + inputValue
        }
        case "CINResponse" => inputValue match {
          case "M" => "Match"
          case "N" => "No Match"
          case "P" => "Not Processed"
          case "S" => "Missing on Card"
          case "U" => "Issuer not Certified"
          case _ => "Unknown CINResponse " + inputValue
        }
        case "TranCategory" => inputValue match {
          case "P" => "Card Present"
          case "T" => "MOTO"
          case "I" => "Internet"
          case _ => "Unknown TranCategory " + inputValue
        }
        case "CustomerHomePhoneTypeOrder" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile Phone"
          case "1" => "Zone 1 - North America & Caribbean"
          case "2" => "Zone 2 - Africa"
          case "3" => "Zone 3/4 - Europe & International"
          case "5" => "Zone 5 - Latin America"
          case "6" => "Zone 6 - Southeast Asia & Oceania"
          case "7" => "Zone 7 - Euroasia (Former Soviet Union)"
          case "8" => "Zone 8 - East Asia & Special Services"
          case "9" => "Zone 9 - Central, South and Western Asia"
          case "21" => "Toll-Free"
          case _ => "Unknown CustomerHomePhoneTypeOrder " + inputValue
        }
        case "CustomerHomePhoneTypeOrderShort" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile"
          case "1" => "Z1 NA/Carib"
          case "2" => "Z2 Africa"
          case "3" => "Z3 Eur/Int"
          case "5" => "Z5 LatAm"
          case "6" => "Z6 SEAsia/Oc"
          case "7" => "Z7 Eurasia"
          case "8" => "Z8 EAsia/Spc"
          case "9" => "Z9 CSW Asia"
          case "21" => "TollFree"
          case _ => "Unknown CustomerHomePhoneTypeOrderShort " + inputValue
        }
        case "CustWorkPhoneTypeOrder" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile Phone"
          case "1" => "Zone 1 - North America & Caribbean"
          case "2" => "Zone 2 - Africa"
          case "3" => "Zone 3/4 - Europe & International"
          case "5" => "Zone 5 - Latin America"
          case "6" => "Zone 6 - Southeast Asia & Oceania"
          case "7" => "Zone 7 - Euroasia (Former Soviet Union)"
          case "8" => "Zone 8 - East Asia & Special Services"
          case "9" => "Zone 9 - Central, South and Western Asia"
          case "21" => "Toll-Free"
          case _ => "Unknown CustWorkPhoneTypeOrder " + inputValue
        }
        case "CustWorkPhoneTypeOrderShort" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile"
          case "1" => "Z1 NA/Carib"
          case "2" => "Z2 Africa"
          case "3" => "Z3 Eur/Int"
          case "5" => "Z5 LatAm"
          case "6" => "Z6 SEAsia/Oc"
          case "7" => "Z7 Eurasia"
          case "8" => "Z8 EAsia/Spc"
          case "9" => "Z9 CSW Asia"
          case "21" => "TollFree"
          case _ => "Unknown CustWorkPhoneTypeOrderShort " + inputValue
        }
        case "ShipPhoneTypeOrder" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile Phone"
          case "1" => "Zone 1 - North America & Caribbean"
          case "2" => "Zone 2 - Africa"
          case "3" => "Zone 3/4 - Europe & International"
          case "5" => "Zone 5 - Latin America"
          case "6" => "Zone 6 - Southeast Asia & Oceania"
          case "7" => "Zone 7 - Euroasia (Former Soviet Union)"
          case "8" => "Zone 8 - East Asia & Special Services"
          case "9" => "Zone 9 - Central, South and Western Asia"
          case "21" => "Toll-Free"
          case _ => "Unknown ShipPhoneTypeOrder " + inputValue
        }
        case "ShipPhoneTypeOrderShort" => inputValue match {
          case "9999" => "No Number"
          case "9998" => "Too Short"
          case "31" => "Mobile"
          case "1" => "Z1 NA/Carib"
          case "2" => "Z2 Africa"
          case "3" => "Z3 Eur/Int"
          case "5" => "Z5 LatAm"
          case "6" => "Z6 SEAsia/Oc"
          case "7" => "Z7 Eurasia"
          case "8" => "Z8 EAsia/Spc"
          case "9" => "Z9 CSW Asia"
          case "21" => "TollFree"
          case _ => "Unknown ShipPhoneTypeOrderShort " + inputValue
        }
      }
    } else {
      inputValue

    }
  })

  /** End of MERF-9240 */

  /* @author KP MERF-9082 30/08/2018 ClientInfo, Timezone and Client Dates updates - 4 columns
   * To be merged with TRANS_MASTER_CORE dataframe
   */
  /*def transfmClientDetails(MasterDF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:transfmClientDetails")
    val RefClientdf = dfRbiRefClientData.select($"ClientID", $"SubClientID", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"TZClient", $"TZSubClient",
      concat($"ClientID", $"SubClientID").alias("Client12"))
    MasterDF.join(RefClientdf, Seq("ClientId", "SubclientId"), "left_outer")
      //.withColumn("ClientDate", when($"OIDDate".isNotNull && $"TZClient".isNotNull, fntrgetTZConvertedDate($"OIDDate".cast("string"), $"TZClient")).otherwise(lit(null)))
      //.withColumn("SubClientDate", when($"OIDDate".isNotNull && $"TZSubClient".isNotNull, fntrgetTZConvertedDate($"OIDDate".cast("string"), $"TZSubClient")).otherwise(lit(null)))
      //.withColumn("ClientDateYYYYMMDD", when($"OIDDate".isNotNull && $"TZClient".isNotNull, fntrgetTZConvertedDateYYYYMMDD($"OIDDate".cast("string"), $"TZClient")).otherwise(lit(null)))
      .withColumn("SubClientDateYYYYMMDD", when($"OIDDate".isNotNull && $"TZSubClient".isNotNull, fntrgetTZConvertedDateYYYYMMDD($"OIDDate".cast("string"), $"TZSubClient")).otherwise(lit(null)))
      .drop($"TZClient")
      .drop($"TZSubClient")
  }*/

  /* @author KP MERF-9082 30/08/2018 ClientName and SubClientName cleanup
   * To be merged with TRANS_MASTER_CORE dataframe
   */
  /*  def cleanupClientNames(MasterDF: DataFrame): DataFrame = {
      MasterDF.withColumn("ClientNameNew", trnsfmClientName($"ClientID", $"ClientName"))
        .withColumn("SubClientNameNew", trnsfmSubClientName($"SubClientID", $"ClientName", $"ClientNameNew", $"SubClientName"))
        .drop($"ClientName").drop($"SubClientName")
        .withColumnRenamed("ClientNameNew", "ClientName")
        .withColumnRenamed("SubClientNameNew", "SubClientName")
    }*/

  /* @author KP MERF-9082 30/08/2018 Customer Names Transformation - 1 column
   * To be merged with TRANS_MASTER_CORE dataframe
   * WHILE MERGING WE CAN DIRECTLY ADD BELOW COLUMN INSTEAD OF HAVING THIS METHOD
   */
  def addCustName(MasterDF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:addCustName")
    MasterDF.withColumn("cust_name", functTrnsfmCustName($"CUSTFIRSTNAME", $"CUSTLASTNAME"))
  }

  def initialRecommedStatusDetail(inputDataFrame: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Transformation Started for RECOMMEND,CurrentStatus,Decision,FraudYN")
    // val joinedDf = inputDataFrame.join(refClientProd, Seq("clientid", "subclientid"), "left_outer")
    //val joinedDf = refClientProd.join(inputDataFrame, Seq("clientid", "subclientid"), "right_outer")

    inputDataFrame
        .withColumn("Actual_Recommendation",$"Recommendation")
      .withColumn("Recommendation",
        when($"authresp".isNotNull && $"ClientSet".isNotNull && !$"authresp".isin("00", "56") && $"ClientSet".contains("AUTHDECLNE") && $"clientid" =!= lit("000050"),
          lit("AuthDec"))
          .when($"authresp".isNotNull && !$"authresp".isin("00", "01") && $"clientid" === lit("000050"), lit("AuthDec"))
          .when($"clientid" === lit("000383") && $"userdata11" === lit("PREAUTH"), lit("PreAuth"))
          .otherwise(when($"Recommendation".isNotNull,updateRecomendations($"Recommendation")).otherwise(lit(null))))
      .withColumn("challstatus", when($"Recommendation".isNotNull, challangeStatus($"Recommendation")).otherwise(lit(null)))
      .withColumn("CurrentStatus", when($"Recommendation".isNull, lit(null)).otherwise(updateCurrentStatus($"Recommendation", $"authresp", when(($"ClientSet".isNotNull && $"ClientSet".contains("AUTHDECLNE") && $"ClientId" != "000050"), $"ClientSet").otherwise(lit("ClientSetIsNull")), $"clientid")))
      .withColumn("Decisionredi", when($"Recommendation".isNotNull, updateDecision($"Recommendation")).otherwise(lit(null)))
    //.drop($"ClientSetAuthDec")
  }

  def updateRecomendations = udf((recomendations: String) => {
    val sourceColumn = "Recommendation"
    val updRecomendations = TransCoreController.getCamelCasedStr(recomendations, sourceColumn)

    updRecomendations

  })

  def updateCurrentStatus = udf((recomendation: String, responseCode: String, clientSet: String, clientID: String) => {

    val currentStatus = if (responseCode != "00" && recomendation.toUpperCase == "NOSCORE") {
      "NoScore->CreditDec"
    } else {
      TransCoreController.getCamelCasedStr(recomendation, "Recommendation")

    }
    currentStatus
  })

  def updateDecision = udf((recomendation: String) => {
    val decision = if (recomendation.toUpperCase == "DENY") {
      "R"
    } else if (recomendation.toUpperCase == "CHALLENGE") {
      "?"
    } else {
      "A"
    }
    decision
  })

  def challangeStatus = udf((recomendation: String) => {

    var challangeStatus = ""
    if (recomendation.toUpperCase == "CHALLENGE") {
      challangeStatus = "NoAction"
    }
    challangeStatus
  })

  /* Start - MERF-10749 / 9138 */

  def transfmRuleBandAndDesc(MasterDf: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Started transformation for TRE and DVE Rule Bands and Description")
    MasterDf.withColumn("dverulehitsband", updateRuleHitsBandAndDesc(col("dverulehits"), lit("rulehitsband")))
      .withColumn("dverulehitsbanddesc", updateRuleHitsBandAndDesc(col("dverulehits"), lit("rulehitsbanddesc")))
      .withColumn("trerulehitsband", updateRuleHitsBandAndDesc(col("trerulehits"), lit("rulehitsband")))
      .withColumn("trerulehitsbanddesc", updateRuleHitsBandAndDesc(col("trerulehits"), lit("rulehitsbanddesc")))
  }

  def updateRuleHitsBandAndDesc = udf((ruleHitsp: String, ruleBand: String) => {
    var bandvalue: Int = 0

    if (ruleHitsp != null && !ruleHitsp.equalsIgnoreCase("null") && !ruleHitsp.isEmpty) {
      bandvalue = ruleHitsp.toInt
    }

    ruleBand match {

      case "rulehitsband" => {
        bandvalue match {
          case rule101 if rule101 >= 101 => "RH9999"
          case rule51 if rule51 >= 51 => "RH0051"
          case rule21 if rule21 >= 21 => "RH0021"
          case rule11 if rule11 >= 11 => "RH0011"
          case rule6 if rule6 >= 6 => "RH0006"
          case rule5 if rule5 == 5 => "RH0005"
          case rule4 if rule4 == 4 => "RH0004"
          case rule3 if rule3 == 3 => "RH0003"
          case rule2 if rule2 == 2 => "RH0002"
          case rule1 if rule1 == 1 => "RH0001"
          case _ => "RH0000"
        }
      }

      case "rulehitsbanddesc" =>
        bandvalue match {
          case rule101 if rule101 >= 101 => "More than 100"
          case rule51 if rule51 >= 51 => "51-100"
          case rule21 if rule21 >= 21 => "21-50"
          case rule11 if rule11 >= 11 => "11-20"
          case rule6 if rule6 >= 6 => "6-10"
          case rule5 if rule5 == 5 => "5"
          case rule4 if rule4 == 4 => "4"
          case rule3 if rule3 == 3 => "3"
          case rule2 if rule2 == 2 => "2"
          case rule1 if rule1 == 1 => "1"
          case _ => "0"
        }
    }
  })

  /* End - MERF-10749 / 9138 */
  def maskedcardnotransformation(inputDataFrame: DataFrame): DataFrame = {
    //val dF1 = inputDataFrame.withColumn("CardNoMask", setMskdCardNo($"CardNoM", $"CoreCardType"))
    val dF1 = inputDataFrame.withColumn("CardNoMask", setMskdCardNo($"CardNoMask", $"CardType"))
    dF1
  }

  def setMskdCardNo = udf((mskCrdr: String, crdrType: String) => {
    var updCrdrNo = ""
    //updCrdrNo = mskCrdr
    if (crdrType == "P") {
      if (mskCrdr.length <= 14 && mskCrdr.length >= 8) {
        updCrdrNo = mskCrdr.take(mskCrdr.length - 8) + "****" + mskCrdr.takeRight(4)
      } else {
        updCrdrNo = mskCrdr
      }
    } else {
      updCrdrNo = mskCrdr
    }
    updCrdrNo
  })

  /*
  MERF-10766  : Prabhu
  Transformation of Graph Label Dates - Week
  */
  def graphLabelfields(execDF: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Graph Label fields Transformation")

    val execDFtemp = execDF.withColumn("clientdateyyyymmdd1", date_format(to_date(col("clientdateyyyymmdd"), "yyyyMMdd"), "yyMMdd"))
      .withColumn("subclientdateyyyymmdd1", date_format(to_date(col("subclientdateyyyymmdd"), "yyyyMMdd"), "yyMMdd")).drop("monthyyyymm")

    val graphlabelclient = rbiRefDate
      .join(execDFtemp, execDFtemp.col("clientdateyyyymmdd1") === rbiRefDate.col("DateYYMMDD"), "right_outer")
      .withColumnRenamed("monthyyyymm", "rdmonthyyyymm")
      .withColumn("graphlabeldate", col("datetextshort"))
      .withColumn("graphlabelweek",
        when(($"ClientSet".isNotNull && $"ClientSet".contains("WKSUNSAT")), substring(col("weekBtextshort"), 1, 5))
          .otherwise(substring(col("weektextshort"), 1, 5)))
      .withColumn("graphlabelweeksort",
        when(($"ClientSet".isNotNull && $"ClientSet".contains("WKSUNSAT")), col("weekByymmdd"))
          .otherwise(col("weekyymmdd")))
      .withColumn("graphlabelmonth", col("monthtextmed"))
      .withColumn("graphlabelmonthsort", substring(col("rdmonthyyyymm"), 3, 4))
      .drop("clientdateyyyymmdd1")
      .drop("datetextshort")
      .drop("weektextshort")
      .drop("weekyymmdd")
      .drop("monthtextmed")
      .drop("rdmonthyyyymm")
      .drop("dateyymmdd")
      .drop("weekbtextshort")
      .drop("weekbyymmdd")
    //.drop("ClientSet")

    val graphlabelsubclient = rbiRefDate.join(graphlabelclient,
      graphlabelclient.col("subclientdateyyyymmdd1") === rbiRefDate.col("DateYYMMDD"), "right_outer")
      //.withColumnRenamed("monthyyyymm", "rdmonthyyyymm")
      .withColumn("subgraphlabeldate", col("datetextshort"))
      .withColumn("subgraphlabelweek", substring(col("weektextshort"), 1, 5))
      .withColumn("subgraphlabelweeksort", col("weekyymmdd"))
      .withColumn("subgraphlabelmonth", col("monthtextmed"))
      .withColumn("subgraphlabelmonthsort", substring(col("monthyyyymm"), 3, 4))
      .drop("subclientdateyyyymmdd1")
      .drop("datetextshort")
      .drop("weektextshort")
      .drop("weekyymmdd")
      .drop("monthtextmed")
      .drop("dateyymmdd")
      .drop("weekbtextshort")
      .drop("weekbyymmdd")
    graphlabelsubclient //.withColumn("monthyyyymm", lit(""))

  }

  /*
  MERF-9081  : Yeswanth
  Transformation of Ship Bill phones
  */

  def rsShipBillPhoneUpdate(items: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Start of rsShipBillPhoneUpdate Transformation")
    val itemsReturn = items
      /*      .withColumn("billaddress2", upper(col("billaddress2")))
            .withColumn("billapt", upper(col("billapt")))
            .withColumn("billcity", upper(col("billcity")))
            .withColumn("billstreet", upper(col("billstreet")))
            .withColumn("shipaddress2", upper(col("shipaddress2")))
            .withColumn("shipapt", upper(col("shipapt")))
            .withColumn("shipcity", upper(col("shipcity")))
            .withColumn("shipstreet", upper(col("shipstreet")))*/
      .withColumn("custhomephonetypeorder", when((col("custhomephone").isNull or col("custhomephone") === " " or col("custhomephone") === ""), 9999)
      .when(length(col("custhomephone")) < 9, 9998)
      .when(col("custhomephone") like "07%", 31)
      .when(((col("custhomephone") like "+1%") or (col("custhomephone") like "001%") or (col("custhomephone") like "1%") and (col("custhomephone").substr(0, 4) =!= "1800")), 1)
      .when(((col("custhomephone") like "+2%") or (col("custhomephone") like "002%") or (col("custhomephone") like "2%")), 2)
      .when(((col("custhomephone") like "+3%") or (col("custhomephone") like "003%") or (col("custhomephone") like "3%")), 3)
      .when(((col("custhomephone") like "+4%") or (col("custhomephone") like "004%") or (col("custhomephone") like "4%")), 4)
      .when(((col("custhomephone") like "+5%") or (col("custhomephone") like "005%") or (col("custhomephone") like "5%")), 5)
      .when(((col("custhomephone") like "+6%") or (col("custhomephone") like "006%") or (col("custhomephone") like "6%")), 6)
      .when(((col("custhomephone") like "+7%") or (col("custhomephone") like "007%") or (col("custhomephone") like "7%")), 7)
      .when(((col("custhomephone") like "+8%") or (col("custhomephone") like "008%") or (col("custhomephone") like "8%")), 8)
      .when(((col("custhomephone") like "+9%") or (col("custhomephone") like "009%") or (col("custhomephone") like "9%")), 9)
      .when(((col("custhomephone") like "0800%") or (col("custhomephone") like "1800%")), 21)
      .otherwise(lit(99)))

      .withColumn("custworkphonetypeorder", when((col("custworkphone").isNull or col("custworkphone") === " " or col("custworkphone") === ""), 9999)
        .when(length(col("custworkphone")) < 9, 9998)
        .when(col("custworkphone") like "07%", 31)
        .when(((col("custworkphone") like "+1%") or (col("custworkphone") like "001%") or (col("custworkphone") like "1%") and (col("custworkphone").substr(0, 4) =!= "1800")), 1)
        .when(((col("custworkphone") like "+2%") or (col("custworkphone") like "002%") or (col("custworkphone") like "2%")), 2)
        .when(((col("custworkphone") like "+3%") or (col("custworkphone") like "003%") or (col("custworkphone") like "3%")), 3)
        .when(((col("custworkphone") like "+4%") or (col("custworkphone") like "004%") or (col("custworkphone") like "4%")), 4)
        .when(((col("custworkphone") like "+5%") or (col("custworkphone") like "005%") or (col("custworkphone") like "5%")), 5)
        .when(((col("custworkphone") like "+6%") or (col("custworkphone") like "006%") or (col("custworkphone") like "6%")), 6)
        .when(((col("custworkphone") like "+7%") or (col("custworkphone") like "007%") or (col("custworkphone") like "7%")), 7)
        .when(((col("custworkphone") like "+8%") or (col("custworkphone") like "008%") or (col("custworkphone") like "8%")), 8)
        .when(((col("custworkphone") like "+9%") or (col("custworkphone") like "009%") or (col("custworkphone") like "9%")), 9)
        .when(((col("custworkphone") like "0800%") or (col("custworkphone") like "1800%")), 21)
        .otherwise(lit(99)))

      .withColumn("shipphonetypeorder", when((col("shipphone").isNull or col("shipphone") === " " or col("shipphone") === ""), 9999)
        .when(length(col("shipphone")) < 9, 9998)
        .when(col("shipphone") like "07%", 31)
        .when(((col("shipphone") like "+1%") or (col("shipphone") like "001%") or (col("shipphone") like "1%") and (col("shipphone").substr(0, 4) =!= "1800")), 1)
        .when(((col("shipphone") like "+2%") or (col("shipphone") like "002%") or (col("shipphone") like "2%")), 2)
        .when(((col("shipphone") like "+3%") or (col("shipphone") like "003%") or (col("shipphone") like "3%")), 3)
        .when(((col("shipphone") like "+4%") or (col("shipphone") like "004%") or (col("shipphone") like "4%")), 4)
        .when(((col("shipphone") like "+5%") or (col("shipphone") like "005%") or (col("shipphone") like "5%")), 5)
        .when(((col("shipphone") like "+6%") or (col("shipphone") like "006%") or (col("shipphone") like "6%")), 6)
        .when(((col("shipphone") like "+7%") or (col("shipphone") like "007%") or (col("shipphone") like "7%")), 7)
        .when(((col("shipphone") like "+8%") or (col("shipphone") like "008%") or (col("shipphone") like "8%")), 8)
        .when(((col("shipphone") like "+9%") or (col("shipphone") like "009%") or (col("shipphone") like "9%")), 9)
        .when(((col("shipphone") like "0800%") or (col("shipphone") like "1800%")), 21)
        .otherwise(lit(99)))

      .withColumn("custhomephonetype", funcAddTransformedColumn(col("custhomephonetypeorder"), lit("CustomerHomePhoneTypeOrder")))
      .withColumn("custworkphonetype", funcAddTransformedColumn(col("custworkphonetypeorder"), lit("CustWorkPhoneTypeOrder")))
      .withColumn("shipphonetype", funcAddTransformedColumn(col("shipphonetypeorder"), lit("ShipPhoneTypeOrder")))
      .withColumn("custhomephonetypeshort", funcAddTransformedColumn(col("custhomephonetypeorder"), lit("CustomerHomePhoneTypeOrderShort")))
      .withColumn("custworkphonetypeshort", funcAddTransformedColumn(col("custworkphonetypeorder"), lit("CustWorkPhoneTypeOrderShort")))
      .withColumn("shipphonetypeshort", funcAddTransformedColumn(col("shipphonetypeorder"), lit("ShipPhoneTypeOrderShort")))
      /*.withColumn("billzipcdnorm",TransCoreController.removeBlanks(col("billzipcd")))
      .withColumn("shipzipcdnorm",TransCoreController.removeBlanks(col("shipzipcd")))*/
      .withColumn("billzipcdnorm", regexp_replace(col("billzipcd"), " ", ""))
      .withColumn("shipzipcdnorm", regexp_replace(col("shipzipcd"), " ", ""))

      /*.withColumn("billukpostcodefull",when(col("billcountry")==="826",when((col("billzipcdnorm").isNull or col("billzipcdnorm") === " "), null).otherwise(TransCoreController.funcUkPostCodeFull(col("billzipcdnorm")))))
      .withColumn("shipukpostcodefull",when(col("shipcountry")==="826",when((col("shipzipcdnorm").isNull or col("shipzipcdnorm") === " "), null).otherwise(TransCoreController.funcUkPostCodeFull(col("shipzipcdnorm")))))
      .withColumn("billukpostcodearea",when((col("billcountry")==="826" and length(col("billukpostcodefull"))>=6),when((col("billukpostcodefull").isNull or col("billukpostcodefull") === " "), null).otherwise(TransCoreController.funcUkPostCodeArea(col("billukpostcodefull")))))
      .withColumn("shipukpostcodearea",when((col("shipcountry")==="826" and length(col("shipukpostcodefull"))>=6),when((col("shipukpostcodefull").isNull or col("shipukpostcodefull") === " "), null).otherwise(TransCoreController.funcUkPostCodeArea(col("shipukpostcodefull")))))*/
      .withColumn("billukpostcodefull", when(col("billcountry") === "826" && $"billzipcdnorm".isNotNull, TransCoreController.funcUkPostCodeFull(col("billzipcdnorm"))).otherwise(lit("")))
      .withColumn("shipukpostcodefull", when(col("shipcountry") === "826" && $"shipzipcdnorm".isNotNull, TransCoreController.funcUkPostCodeFull(col("shipzipcdnorm"))).otherwise(lit("")))
      .withColumn("billukpostcodearea", when((col("billcountry") === "826" and length(col("billukpostcodefull")) >= 6), TransCoreController.funcUkPostCodeArea(col("billukpostcodefull"))))
      .withColumn("shipukpostcodearea", when((col("shipcountry") === "826" and length(col("shipukpostcodefull")) >= 6), TransCoreController.funcUkPostCodeArea(col("shipukpostcodefull"))))
      .withColumn("billukpostcodedistrict", when((col("billcountry") === "826" and length(col("billukpostcodefull")) >= 6), expr("substring(billukpostcodefull,1,(locate(' ',billukpostcodefull)-1))")))
      .withColumn("billukpostcodesector", when((col("billcountry") === "826" and length(col("billukpostcodefull")) >= 6), expr("substring(billukpostcodefull,1,(locate(' ',billukpostcodefull)-2))")))
      .withColumn("shipukpostcodedistrict", when((col("shipcountry") === "826" and length(col("shipukpostcodefull")) >= 6), expr("substring(shipukpostcodefull,1,(locate(' ',shipukpostcodefull)-1))")))
      .withColumn("shipukpostcodesector", when((col("shipcountry") === "826" and length(col("shipukpostcodefull")) >= 6), expr("substring(shipukpostcodefull,1,(locate(' ',shipukpostcodefull)-2))")))
      .withColumn("billukpostcoderisk", when(col("billcountry") === "826",
        (when(col("billukpostcodefull").isNull or col("billukpostcodefull") === "", lit("X")).when(col("billukpostcodedistrict").isin(UKPOSTCODEDISTRICT: _*), lit("H")).otherwise(lit("L")))))
      .withColumn("shipukpostcoderisk", when(col("shipcountry") === "826",
        (when(col("shipukpostcodefull").isNull or col("shipukpostcodefull") === "", lit("X")).when(col("shipukpostcodedistrict").isin(UKPOSTCODEDISTRICT: _*), lit("H")).otherwise(lit("L")))))

    itemsReturn
  }

  def addReportText(df: DataFrame): DataFrame = {
    transCoreLogger.info(TRANSFLOWPROCESS_INFO + ": Start of addReportText Transformation")
    df.withColumn("ReportText", funcReport(col("Report"), lit("ReportText")))
      .withColumn("ReportTextShort", funcReport(col("Report"), lit("ReportTextShort")))
      .withColumn("ReportText2", funcReport(col("Report"), lit("ReportText2")))
      .withColumn("ReportSort", funcReport(col("Report"), lit("ReportSort")))
      .withColumn("CEXResponseText", when(col("ResponseCode").equalTo("00"),
        lit("Approved")).when(col("ResponseCode").equalTo("04"), lit("Hot or Stolen")))
      .withColumn("SDSCount", when(col("Report").equalTo("1300") || col("Report").equalTo("2000"), lit("1")).otherwise(lit("0")))
  }

  def funcReport: UserDefinedFunction = udf((inputValue: String, inputColumn: String) => {
    var value: String = ""

    /*if (inputValue != null && !inputValue.equalsIgnoreCase("null")) {
      value = inputValue
    }*/

    if (inputValue != null) {
      value = inputValue
      inputColumn match {
        case "ReportText" => value match {
          case "0000" => "No Score (0000)"
          case "0100" => "Accept (0100)"
          case "0150" => "Always Accept (0150)"
          case "0200" => "Auth Decline (0200)"
          case "0250" => "Always Deny (0250)"
          case "0330" => "Rule Challenge (0330)"
          case "0700" => "Velocity/Threshold (0700)"
          case "0800" => "Tumbling/Swapping (0800)"
          case "1300" => "Screening Challenge (1300)"
          case "2000" => "Screening Deny (2000)"
          case "" => "No Code"
          case _ => "??? (|| " + inputValue + " ||)"
        }
        case "ReportTextShort" => value match {
          case "0000" => "No Score"
          case "0100" => "Accept"
          case "0150" => "Always Accept"
          case "0200" => "Auth Decline"
          case "0250" => "Always Deny"
          case "0330" => "Rule Challenge"
          case "0700" => "Velocity Deny"
          case "0800" => "Tumb/Swap Deny"
          case "1300" => "SDS Challenge"
          case "2000" => "SDS Deny"
          case "" => "No Code"
          case _ => "???"
        }
        case "ReportText2" => value match {
          case "0000" => "No Score"
          case "0100" => "No Rules"
          case "0150" => "Rule"
          case "0200" => "Auth/HCF"
          case "0250" => "Deny"
          case "0330" => "Rule"
          case "0700" => "Velocity"
          case "0800" => "Tumb/Swap"
          case "1300" => "SDS"
          case "2000" => "SDS"
          case "" => "No Code"
          case _ => "??? (" + inputValue + ")"
        }
        case "ReportSort" => value match {
          case "0100" => "1"
          case "0150" => "2"
          case "0330" => "11"
          case "1300" => "12"
          case "0700" => "21"
          case "0250" => "22"
          case "0200" => "23"
          case "0800" => "24"
          case "2000" => "25"
          case "0000" => "41"
          case "" => "81"
          case _ => "99"
        }
      }
    } else {
      value
    }
  })

}