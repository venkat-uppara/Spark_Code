package com.aciworldwide.ra.redi.rstransflow.dao

import com.aciworldwide.ra.redi.common.dao.CBReasonCodesDao
import com.aciworldwide.ra.redi.common.services.EstablishConnections
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql._
import java.text.SimpleDateFormat
import java.util.{Calendar, Date}


object getTransmasterData extends EstablishConnections with App {

  val sparkmaster = ConfigFactory.load().getString("local.common.spark.master")
  val sparkappname = ConfigFactory.load().getString("local.common.spark.app.name")

  val sc = sparkSessionBuilder(sparkmaster,sparkappname)

  val dateformat = "YYYYMMdd"
  val calendar = Calendar.getInstance()
  calendar.roll(Calendar.DAY_OF_YEAR, -2 )
  val currentdate = calendar.getTime()
  val format = new SimpleDateFormat(dateformat)
  val inputdate = format.format(currentdate)

  sc.sql("set spark.sql.hive.convertMetastoreOrc=true")
  val df = sc.sql("select clientId, SubClientId, currcd, max(OIDDateYYYYMMDD)from " +
    s"redi.trans_master_core1 where OIDDateYYYYMMDD >=$inputdate  group by  clientId, SubClientId, currcd")


}

