package com.aciworldwide.ra.redi.rstransflow.actions

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.rstransflow.controllers.RSExecIngestionController
import org.apache.log4j.LogManager
import org.apache.spark.sql.SparkSession


object RSExecIngestProcess extends BaseController with Loggers with Serializable with ReDiConstants {

  @transient lazy val mainIngestionDatalogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    mainIngestionDatalogger.error(MAINFLOWINGESTIONPROCESS_INFO +":Start of Incremental Transaction flow from RS EXEC")
    try {
      val sparkSession: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
      val RSExecIngestionController = new RSExecIngestionController(sparkSession)
      RSExecIngestionController.RSTranflowPipeline()
    } catch {
      case e: Exception => mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO +":We have an error in the Incremental Transaction flow from RS EXEC " + e)
    } finally {
      mainIngestionDatalogger.error(MAINFLOWINGESTIONPROCESS_INFO +":End of Incremental Transaction flow from RS EXEC")
    }
  }
}