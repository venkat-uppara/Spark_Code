/**
  * @author : JS
  * @version : 1.0 Initial Draft
  * @usecase : This controller is created to handle all the common transformations in transaction flow.
  * @note : This will add the new columns into the executor data.
  */
package com.aciworldwide.ra.redi.rstransflow.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{ArrayType, StringType, StructType}
import org.apache.spark.sql.{DataFrame, SparkSession}


/** This TransCommonController is used to create */

class TransCommonController(spark: SparkSession) extends Loggers with ReDiSerializers
  with Serializable with DatabaseServices with ReDiTableSchemas with RSTransFlowCommonUtils with CommonUtils with ReDiConstants {

  @transient lazy val transCommonLogger = LogManager.getLogger(getClass.getName)

  import spark.implicits._

  var dfRbiRefClientData: DataFrame = _
  dfRbiRefClientData = gettheDataFromHiveForRef(spark, REDI_RBI_REF_CLIENT)


  var currencyrates: DataFrame = gettheDataFromHive(spark, CURR_CONV_TABLE_VIEW).filter($"DestCurrencyCode".isNotNull && $"ConversionRate".isNotNull)
  var destmap = currencyrates.select($"DestCurrencyCode", $"ConversionRate").collect()
    .map(row => (if (row.isNullAt(0)) "" else row.getString(0), if (row.isNullAt(1)) 0 else row.getDouble(1))).toMap
  var currMap: Map[String, String] = _

  def convertedCurrency: UserDefinedFunction = udf((sourceCurrency: String, destcurrency: String, noOfUnits: String) => {
    var convertedCurrency: Double = 0.0
    var sourceconvrate: Double = 0.0
    var destconvrate: Double = 0.0

    if (destmap.isDefinedAt(sourceCurrency)) {
      var currrate = destmap.get(sourceCurrency)
      sourceconvrate = currrate.get
    }
    if (destmap.contains(destcurrency)) {
      var currrate = destmap.get(destcurrency)
      destconvrate = currrate.get
    }
    if (destmap.contains(sourceCurrency) && destmap.contains(destcurrency) && sourceconvrate > 0 &&  noOfUnits!=null && noOfUnits.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)")) {
      convertedCurrency = ((1 / sourceconvrate) * destconvrate) * noOfUnits.toDouble
      convertedCurrency = BigDecimal(convertedCurrency).setScale(2, BigDecimal.RoundingMode.HALF_UP).toDouble
    }
    convertedCurrency
  })

  def ConvertToTimestamp: UserDefinedFunction = udf((inputdate: String, sourceformat: String, targetformat: String) => {
    val sourceformatObj = new SimpleDateFormat(sourceformat)
    val targetformatObj = new SimpleDateFormat(targetformat)
    java.sql.Timestamp.valueOf(targetformatObj.format(sourceformatObj.parse(inputdate)))
  })

  /** */
  def processCommonTransformation(rows: DataFrame): DataFrame = {
    val detaillinesDF = transfmDetailLines(rows)
    val currconvDF = currencyConversion(detaillinesDF)
    val dfExecutorData = addtransflowAuditColumns(fntrCommonTransformation(currconvDF))
    dfExecutorData
  }

  //  def fntrCommonTransformation(indfExecutorData: DataFrame): DataFrame = {
  //    val retdfExecutorData = indfExecutorData
  //      .withColumn("cardnomask", funcMaskCardNo($"CardNo"))
  ////      .withColumn("RuleMasterArray", from_json($"RuleMaster", ruleMasterSchema))
  //      .withColumn("RuleMasterArray", $"RuleMaster")
  //      .withColumn("ClientDateYYYYMMDD", udfDeriveClientdateYYYYMMDD($"clientdate"))
  //      .withColumn("clientdate", to_timestamp($"clientdate", CLIENTDATEFORMAT))
  //    retdfExecutorData
  //  }

  def fntrCommonTransformation(indfExecutorData: DataFrame): DataFrame = {
    val retdfExecutorData = indfExecutorData
      .withColumn("cardnomask", funcMaskCardNo($"CardNo"))
      //      .withColumn("RuleMasterArray", from_json($"RuleMaster", ruleMasterSchema))
      //.withColumn("RuleMasterArray", $"RuleMaster")
      .withColumn("ClientDateYYYYMMDD", udfDeriveClientdateYYYYMMDD($"clientdate"))
      .withColumn("SubClientDateYYYYMMDD", udfDeriveClientdateYYYYMMDD($"subclientdate"))
      .withColumn("clientdate", ConvertToTimestamp($"clientdate", lit(CLIENTDATEFORMAT), lit(CLIENTDATEFORMAT)))
      .withColumn("subclientdate", ConvertToTimestamp($"subclientdate", lit(CLIENTDATEFORMAT), lit(CLIENTDATEFORMAT)))
      .withColumn("oiddate", ConvertToTimestamp($"oiddate", lit(DATEFORMATYYYYMMDDHHMMSSSSS), lit(CLIENTDATEFORMAT)))
    retdfExecutorData
  }

  def udfDeriveClientdateYYYYMMDD: UserDefinedFunction = udf((clientdate: String) => {
    val inputFormat = new SimpleDateFormat(CLIENTDATEFORMAT)
    val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
    val date = outputFormat.format(inputFormat.parse(clientdate))
    date
  })

  /* @author KP MERF-9082 30/08/2018 Order DetailLines and Band updates - 3 columns
 */
  def transfmDetailLines(inputDF: DataFrame): DataFrame = {

    inputDF
      //      .withColumn("ProdDetailsArray", from_json(col("ProductDetail"), productDetailSchema))
      //.withColumn("ProdDetailsArray", $"ProductDetail")
      //.withColumn("DetailLines", size($"ProdDetailsArray"))
      .withColumn("DetailLines", size($"ProductDetail"))
      .withColumn("DetailLinesBand", getDetailLines(col("DetailLines"), lit("DetailLines")))
      .withColumn("DetailLinesBandDesc", getDetailLines(col("DetailLines"), lit("DetailLinesDesc")))
  }



  /** End of MERF-9082 */
  def getDetailLines: UserDefinedFunction = udf((detailLinesp: String, detaillinesp: String) => {
    var detailLines: Int = 0
    if (detailLinesp != null && !detailLinesp.equalsIgnoreCase("null") && !detailLinesp.isEmpty) {
      detailLines = detailLinesp.toInt
    }
    detaillinesp match {
      case "DetailLines" =>
        detailLines match {
          case detailLines101 if detailLines101 >= 101 => "DL9999"
          case detailLines51 if detailLines51 >= 51 => "DL0051"
          case detailLines26 if detailLines26 >= 26 => "DL0026"
          case detailLines11 if detailLines11 >= 11 => "DL0011"
          case detailLines6 if detailLines6 >= 6 => "DL0006"
          case detailLines5 if detailLines5 == 5 => "DL0005"
          case detailLines4 if detailLines4 == 4 => "DL0004"
          case detailLines3 if detailLines3 == 3 => "DL0003"
          case detailLines2 if detailLines2 == 2 => "DL0002"
          case detailLines1 if detailLines1 == 1 => "DL0001"
          case _ => "DL0000"
        }
      case "DetailLinesDesc" =>
        detailLines match {
          case detailLines101 if detailLines101 >= 101 => "More than 100"
          case detailLines51 if detailLines51 >= 51 => "51-100"
          case detailLines26 if detailLines26 >= 26 => "26-50"
          case detailLines11 if detailLines11 >= 11 => "11-25"
          case detailLines6 if detailLines6 >= 6 => "6-10"
          case detailLines5 if detailLines5 == 5 => "5"
          case detailLines4 if detailLines4 == 4 => "4"
          case detailLines3 if detailLines3 == 3 => "3"
          case detailLines2 if detailLines2 == 2 => "2"
          case detailLines1 if detailLines1 == 1 => "1"
          case _ => "0"
        }
    }
  })

  def currencyConversion(df: DataFrame): DataFrame = {
    transCommonLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:currencyConversion")

    val rbirefClientDF = dfRbiRefClientData.select($"ClientID", $"SubClientID", $"clientcurr", $"subclientcurr", $"Region", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"ClientSet",
      concat($"ClientID", $"SubClientID").alias("Client12"))

    val window = Window.partitionBy("clientid").orderBy($"curroccurance".desc, $"clientcurr".asc)

    currMap= dfRbiRefClientData.select("clientid","clientcurr").filter($"clientcurr".isNotNull && trim($"clientcurr")=!=lit("")).
      groupBy("clientid","clientcurr").agg(count($"clientcurr").as("curroccurance")).withColumn("row_number_curr",row_number().over(window)).
      filter($"row_number_curr" === 1).collect().map(row => (if (row.isNullAt(0)) "" else row.getString(0), if (row.isNullAt(1)) "" else row.getString(1))).toMap

    var allCurrencyTotal = df.join(rbirefClientDF, Seq("clientId", "subClientId"), "left_outer")
    allCurrencyTotal = allCurrencyTotal
      .withColumn("CURRCLIENTTEMP", currClientSubclient($"ClientID", $"clientcurr", $"currCd"))
      .withColumn("CURRCLIENT", when(!$"CURRCLIENTTEMP".equalTo("novalue"),col("CURRCLIENTTEMP")).otherwise($"currcd"))
      .withColumn("CURRSUBCLIENT", when(!currSubclient($"subclientcurr").equalTo("novalue"), col("subclientcurr")).otherwise(col("CURRCLIENT")))
      .withColumn("total", col("total").cast("decimal(14,2)"))
      .withColumn("TotalGBP", when(col("currCd") === lit("GBP"), col("total"))
        .otherwise(when(col("currCd") =!= lit("GBP"), convertedCurrency(col("currCd"), lit("GBP"), col("total")))))
      .withColumn("TotalUSD", col("VirtUsdTotal"))
      .withColumn("TotalEUR", when(col("currCd") === lit("EUR"), col("total"))
        .otherwise(when(col("currCd") =!= lit("EUR"), convertedCurrency(col("currCd"), lit("EUR"), col("total")))))
      .withColumn("TotalClient", when(col("currCd") === col("CURRCLIENT"), col("total"))
        .otherwise(convertedCurrency(col("currCd"), when(col("CURRCLIENT").isNotNull, col("CURRCLIENT")).otherwise(col("currCd")), col("total"))))
      .withColumn("TotalSubClient", when(col("currCd") === col("CURRSUBCLIENT"), col("total"))
        .otherwise(convertedCurrency(col("currCd"), when(col("CURRSUBCLIENT").isNotNull, col("CURRSUBCLIENT")).when(col("CURRCLIENT").isNotNull, col("CURRCLIENT")).otherwise(col("currCd")), col("total"))))
      .drop($"clientcurr")
      .drop($"subclientcurr")
      .drop($"CURRCLIENTTEMP")
    allCurrencyTotal
  }

  def currClientSubclient: UserDefinedFunction = udf((clientID: String, clientcurr: String, currcd: String) => {
    var curr: String = "novalue"
    if (clientcurr == null || (clientcurr != null && clientcurr.trim.isEmpty)) {
      if (currMap!=null && currMap.isDefinedAt(clientID)) {
        var clientcurr = currMap.get(clientID)
        if(!clientcurr.get.trim.isEmpty) {
          curr = clientcurr.get
        }else
        {
          curr
        }
      }
    }
    else if (clientcurr != null && !clientcurr.trim.isEmpty) {
      curr = clientcurr
    }
    curr
  })

  def currSubclient: UserDefinedFunction = udf((subclientcurr: String) => {
    var curr: String = "novalue"

    if (subclientcurr != null && !subclientcurr.trim.isEmpty) {
      curr = subclientcurr
    }
    curr

  })

}