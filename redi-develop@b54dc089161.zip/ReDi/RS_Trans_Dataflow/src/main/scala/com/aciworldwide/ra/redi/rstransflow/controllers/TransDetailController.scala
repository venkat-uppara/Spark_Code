package com.aciworldwide.ra.redi.rstransflow.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.DatabaseServices
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.dao.TransFlowDao
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


class TransDetailController(spark: SparkSession) extends BaseController with ReDiConstants
  with Serializable with DatabaseServices with ReDiTableSchemas with RSTransFlowCommonUtils with CommonUtils {

  @transient lazy val transDetailLogger = LogManager.getLogger(getClass.getName)

  import spark.implicits._

  val rsTransFlowDao = new TransFlowDao(spark)

  def processTransDetail(rows: DataFrame): DataFrame = {
    transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Initial Transformation started for Transaction Detail")
    val detailDf = finalTransDetailDF(streamingTransDetailDF(rows))

    detailDf
  }

  def streamingTransDetailDF(execDF: DataFrame): DataFrame = {
    /** Adding MERF-9134 Columns */
    transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:streamingTransDetailDF")

    val windowSpec = Window.partitionBy('Oid).orderBy('ProdSku)
    execDF.select(explode_outer($"ProductDetail").as("product_detail"), $"Oid", $"oiddate", $"clientdate", $"ClientDateYYYYMMDD", $"oiddateyyyymmdd", $"ClientId", $"SubclientId", $"Whenloaded", $"Wholoaded", $"Whenupdated", $"Whoupdated", $"Total", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient")
      .select($"Oid", $"oiddate", $"clientdate", $"ClientDateYYYYMMDD", $"oiddateyyyymmdd", $"ClientId", $"SubclientId", $"product_detail.ProdQuantity",
        $"product_detail.ProdUnitPrice", $"product_detail.ProdCategory", $"product_detail.ProdSku", $"product_detail.ProdCd",
        $"product_detail.Upc", $"product_detail.Manufacturer", $"product_detail.ManPartno", $"product_detail.ProdDesc",
        $"product_detail.ProdType", $"product_detail.RecipientFirstName", $"product_detail.RecipientLastName",
        $"product_detail.RecipientMidName", $"product_detail.RecipientSalutation", $"product_detail.RecipientEmail",
        $"product_detail.RecipientStreet", $"product_detail.RecipientAddress2", $"product_detail.RecipientApt",
        $"product_detail.RecipientCity", $"product_detail.RecipientState", $"product_detail.RecipientCountry",
        $"product_detail.RecipientZipcd", $"product_detail.RecipientPhone", $"product_detail.ItemShipMethod",
        $"product_detail.ItemCarrier", $"product_detail.ItemShipmentNo", $"product_detail.ItemshipInstruction",
        $"product_detail.ItemShipComments", $"product_detail.ItemWrapped", $"product_detail.ItemCardAttach",
        $"product_detail.ItemGiftMessage", $"Whenloaded", $"Wholoaded", $"Whenupdated", $"Whoupdated", $"Total", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"OIDDATEYYYYMMDD")
      .withColumn("LINENUMBER", row_number() over windowSpec).dropDuplicates()

  }

  def finalTransDetailDF(transDetailDF: DataFrame): DataFrame = {
    transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:finalTransDetailDF")
    val transDetailDF1 = transDetailDF.withColumn("Client12", lit("")).withColumn("ItemGiftCardType", lit(""))
      .withColumn("ItemShipComments12", lit("")).withColumn("ProdCode", lit("")).withColumn("ProdMarker1", lit(""))
      .withColumn("ProdNote", lit("")).withColumn("xProdNote", lit(""))


    /** @author: KP : 28/08/2018 : MERF-9240 Adding Code based Description columns transformation */

    val prodCategoryDF = addProdCategandType(transDetailDF1)
    val finalDetailDF = prodDetailsTotal(prodCategoryDF)
    finalDetailDF
  }

  /** MERF-9082 */

  /* @author KP MERF-9082 30/08/2018 Prod Category and Type description updates - 2 columns
   * KP 18Mar2019 : Merged code from Yeswanth for MERF-9081 ItemCarrierDesc and ItemShipMethodDesc
   */

  def addProdCategandType(DetailDF: DataFrame): DataFrame = {
    transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:addProdCategandType")
    DetailDF.withColumn("ProductCategoryDesc", funcAddTransformedColumn(col("ProdCategory"), lit("ProdCategory")))
      .withColumn("ProdTypeDesc", funcAddTransformedColumn(col("ProdType"), lit("ProdType")))
      .withColumn("ItemCarrierDesc", funcAddTransformedColumn(col("ItemCarrier"), lit("ItemCarrier")))
      .withColumn("ItemShipMethodDesc", funcAddTransformedColumn(col("ItemShipMethod"), lit("ItemShipMethod")))
  }

  def funcAddTransformedColumn: UserDefinedFunction = udf((inputValue: String, inputColumn: String) => {
    if (inputValue != null && !inputValue.isEmpty) {
      inputColumn match {
        case "ProdCategory" => inputValue match {
          case "S" => "Standard"
          case "P" => "Promotion"
          case _ => "Unknown ProdCategory " + inputValue
        }
        case "ProdType" => inputValue match {
          case "P" => "Physical Goods"
          case "D" => "Digital Goods"
          case "C" => "Digital Content"
          case "S" => "Shareware"
          case "M" => "Digital->Physical"
          case _ => "Unknown ProdType " + inputValue
        }
        case "ItemCarrier" => inputValue match {
          case "F" => "Fedex"
          case "P" => "USPS"
          case "U" => "USP"
          case "L" => "Purolater"
          case "G" => "Grayhound"
          case "D" => "DHL"
          case "O" => "Other"
          case _ => "Unknown ItemCarrier " + inputValue
        }
        case "ItemShipMethod" => inputValue match {
          case "N" => "Next Day/Overnight"
          case "T" => "Two Day Service"
          case "W" => "Three Day Service"
          case "C" => "Lowest Cost"
          case "I" => "International"
          case "D" => "Customer Design Carrier"
          case "M" => "Military"
          case "P" => "Store Pickup"
          case "O" => "Other"
          case _ => "Unknown ItemShipMethod " + inputValue
        }
      }
    } else {
      inputValue
    }
  })

  def prodDetailsTotal(inputdf: DataFrame): DataFrame = {
    transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Inside prod details method")

    val inputdatadf = inputdf.select($"Oid", $"Total", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"ProdQuantity", $"ProdUnitPrice", $"LINENUMBER")
    val prodfDf = inputdatadf

      /** .withColumn("ProdTotal",lit(""))
        * .withColumn("ProdTotalUSD",lit(""))
        * .withColumn("ProdTotalGBP",lit(""))
        * .withColumn("ProdTotalEUR",lit(""))
        * .withColumn("ProdTotalClientCurr",lit(""))
        * .withColumn("ProdTotalSubClientCurr",lit("")) */

      .withColumn("ProdTotal", prodTotal(col("ProdUnitPrice"), col("ProdQuantity")).cast("decimal(14,2)"))
      .withColumn("ProdTotalUSD", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
        otherwise(prodTotalCurrency($"ProdTotal", $"TotalUSD", $"Total").cast("decimal(14,2)")))
      .withColumn("ProdTotalGBP", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
        otherwise(prodTotalCurrency($"ProdTotal", $"TotalGBP", $"Total").cast("decimal(14,2)")))
      .withColumn("ProdTotalEUR", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
        otherwise(prodTotalCurrency($"ProdTotal", $"TotalEUR", $"Total").cast("decimal(14,2)")))
      .withColumn("ProdTotalClientCurr", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
        otherwise(prodTotalCurrency($"ProdTotal", $"TotalClient", $"Total").cast("decimal(14,2)")))
      .withColumn("ProdTotalSubClientCurr", when(col("Total").equalTo(0) || col("Total").lt(0), lit(0)).
        otherwise(prodTotalCurrency($"ProdTotal", $"TotalSubClient", $"Total").cast("decimal(14,2)")))
      /*     .withColumn("clientcurr",lit(""))
           .withColumn("subclientcurr",lit(""))*/

      .drop($"TotalGBP").drop($"TotalUSD").drop($"TotalEUR").drop($"TotalClient").drop($"TotalSubClient").drop($"Total")
      .drop($"ProdQuantity").drop($"ProdUnitPrice")

    val df = inputdf.join(prodfDf, Seq("Oid", "LINENUMBER")).dropDuplicates()
    df
  }

  def prodTotal: UserDefinedFunction = udf((prodUnitPrice: String, prodQuantity: String) => {
    //        transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Inside Product total UDF")
    var total: Double = 0.0
    if (prodUnitPrice != null && prodQuantity != null && !prodUnitPrice.isEmpty && !prodQuantity.isEmpty &&
      prodUnitPrice.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)") && prodQuantity.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)")) {
      total = prodUnitPrice.toDouble * 1.0 * prodQuantity.toDouble
      total
    } else {
      total
    }
    //        transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": END of Product total UDF")
  })


  def prodTotalCurrency: UserDefinedFunction = udf((prodTotal: String, totalAllCurr: String, total: String) => {
    //        transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": Inside prodTotalCurrency UDF")
    var totalForAllCurrencies: BigDecimal = 0.0
    if (prodTotal != null && total != null && totalAllCurr != null && !prodTotal.isEmpty && !total.isEmpty && totalAllCurr!=null &&
      !totalAllCurr.isEmpty && prodTotal.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)") && total.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)") &&
      totalAllCurr.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)")) {
      totalForAllCurrencies = prodTotal.toDouble * 1.0 * totalAllCurr.toDouble / total.toDouble
      totalForAllCurrencies
    } else {
      totalForAllCurrencies
    }
    //        transDetailLogger.info(TRANSFLOWPROCESS_INFO + ": END of prodTotalCurrency UDF")
  })

}
