package com.aciworldwide.ra.redi.rstransflow.schemas

import java.util.Date

case class CurrencyRates(currencydate:Date,DestCurrencyCode:String,ConversionRate:Double)
