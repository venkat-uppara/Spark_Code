package com.aciworldwide.ra.redi.rstransflow.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class TransRuleHitsController(spark: SparkSession) extends Loggers with ReDiConstants with RSTransFlowCommonUtils
  with ReDiTableSchemas with DatabaseServices {

  @transient lazy val transRuleHitsLogger = LogManager.getLogger(getClass.getName)

  import spark.implicits._

  val ruleDetailsDf = gettheDataFromHive(spark, RULE_DETAILS_VIEW)
  .select($"ruleid",
  $"descriptionredi".as("RuleDescription"),
  $"fraudyn".as("RuleFraudYN"),
  $"recommendredi".as("RuleRecommend"),
  $"RuleGroupShort"
  )

  def processRuleHits(rows: DataFrame): DataFrame = {

    transRuleHitsLogger.info(TRANSFLOWPROCESS_INFO + ": Initial Transformation started for Transaction Rule Hits")

    val ruleDf = funcAddRuleHits(rows)
    ruleDf
  }

  def funcAddRuleHits(inputDF: DataFrame): DataFrame = {

    transRuleHitsLogger.info(TRANSFLOWPROCESS_INFO + ": Started Transformation of fntr:funcAddRuleHits")

    //val ruleHitsDF =
    inputDF.select($"OID", $"oiddate", $"clientdate", $"ClientId", $"ClientDateYYYYMMDD", explode_outer($"RuleMaster").as("RuleHits"), $"Whenloaded", $"WhenUpdated", $"WhoUpdated", $"WhoLoaded", $"OIDDATEYYYYMMDD")
      .select($"OID", $"oiddate", $"RuleHits.RuleSource".as("RuleSource"), $"RuleHits.RuleId".as("RuleId"),
        $"RuleHits.RuleName".as("RuleName"), $"RuleHits.sdsanswer".as("RuleSDSAnswer"), $"Whenloaded", $"WhenUpdated", $"WhoUpdated", $"WhoLoaded", $"clientdate", $"OIDDateYYYYMMDD", $"ClientDateYYYYMMDD", $"ClientId")
      .join(ruleDetailsDf, Seq("ruleid"), "left_outer")
  }
}
