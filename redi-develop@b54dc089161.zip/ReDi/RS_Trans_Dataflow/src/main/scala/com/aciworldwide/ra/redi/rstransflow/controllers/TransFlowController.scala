package com.aciworldwide.ra.redi.rstransflow.controllers

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.concurrent.TimeUnit

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.format.DateTimeFormat
import org.joda.time.{DateTime, DateTimeZone}

/* POC cluster related imports */


import scala.util.control.Breaks._

class TransFlowController extends BaseController with ReDiConstants with Loggers with ReDiSerializers {

  @transient lazy val transDataFlowLogger = LogManager.getLogger(getClass.getName)

  val sparkSession: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)


  val transMasterCore = new TransCoreController(sparkSession)
  val detail = new TransDetailController(sparkSession)
  val common = new TransCommonController(sparkSession)
  val ruleHits = new TransRuleHitsController(sparkSession)
  val dependent = new TransDependencyController(sparkSession)
  var flags = new Array[Boolean](3)
  val dateUtil = new DateUtils

  val localtimezone: String = ConfigFactory.load().getString("local.common.serverConfig.localtimezone")
  val jobidFilter: String = ConfigFactory.load().getString("local.common.realtime_transflow.jobidFilter")
  var clientFilter: String = ConfigFactory.load().getString("local.common.realtime_transflow.clientFilter")
  val sourceFilter: String = ConfigFactory.load().getString("local.common.realtime_transflow.sourceFilter")
  val minTime: Int = ConfigFactory.load().getString("local.common.realtime_transflow.minTime").toInt
  val maxTime: Int = ConfigFactory.load().getString("local.common.realtime_transflow.maxTime").toInt
  val simpleformat = new SimpleDateFormat(TARGDATEFORMAT)


  if (clientFilter != null && !clientFilter.trim.isEmpty) {
    clientFilter = " and " + clientFilter + " "
  }
  else {
    clientFilter = ""
  }

  import sparkSession.implicits._

  def convertToTimeStamp(strDataTime: String): Timestamp = {
    val dateFormat = new SimpleDateFormat(TARGDATEFORMAT)
    val dt = dateFormat.parse(strDataTime)
    val timStampFormat = new java.sql.Timestamp(dt.getTime)
    timStampFormat
  }

  def transFlowProcesTransformations(): Unit = {

    def fn_currenttime_utc(): String = {
      val dates = DateTime.now(DateTimeZone.UTC)
      val dateOut = DateTimeFormat.forPattern(TARGDATEFORMAT)
      dateOut.print(dates)
    }

    def fn_diff_millisec(currTime: String, endTime: String): Long = {
      val ct = java.sql.Timestamp.valueOf(simpleformat.format(simpleformat.parse(currTime)))
      val et = java.sql.Timestamp.valueOf(simpleformat.format(simpleformat.parse(endTime)))
      et.getTime - ct.getTime
    }

    var nextRunWithoutError = true

    /*    def partitionColumn(startTime: String) = {
          val inputFormat = new SimpleDateFormat(CLIENTDATEFORMAT)
          val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
          val date = outputFormat.format(inputFormat.parse(startTime))
          date.toInt
        }*/

    while (nextRunWithoutError) {
      val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sparkSession).build()
      breakable {
        var startTimeFrom = hiveSession.executeQuery(s"select max(lastusedtime) as lastusedtime, $jobidFilter as jobid from "
          + REDI_CONTROL_FOR_EXTERNAL_TABLE + s" where jobid = $jobidFilter")

        startTimeFrom = startTimeFrom.withColumn("oiddateyyyymmdd", date_format($"lastusedtime", "yyyyMMdd"))
        val StartTime1 = startTimeFrom.select($"lastusedtime").first()(0)
        var StartTime: String = null
        var EndTime: String = null

        if (StartTime1 == null) {
          transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": No records inserted in controlfortransflow table : Please insert the records in controlfortransflow")
          throw new Exception("No records inserted in controlfortransflow: Please insert the records in controlfortransflow")
        }

        StartTime = StartTime1.toString.trim
        val partColStart = startTimeFrom.select($"oiddateyyyymmdd").first()(0).toString.trim.toInt
        val currentTime = fn_currenttime_utc()

        val timeDiff = fn_diff_millisec(StartTime, currentTime)
        val timeDiffInMinutes = TimeUnit.MILLISECONDS.toMinutes(timeDiff)
        transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "StarTime : " + StartTime + " CurrentTime : " + currentTime)
        transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + "Time difference in minutes : " + timeDiffInMinutes)

        if (StartTime != null && currentTime != null && convertToTimeStamp(StartTime).getTime >= convertToTimeStamp(currentTime).getTime) {
          val diff = fn_diff_millisec(currentTime, StartTime) + 600000 // 1 min seconds buffer
          Thread.sleep(diff)
          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + "Start time is greater than current Time so waiting till current time is greater.." + "currentTime " + currentTime + " StartTime " + StartTime)
          break
        }

        if (timeDiffInMinutes >= minTime && timeDiffInMinutes <= maxTime) {
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Inside min and max if condition" + timeDiffInMinutes)
          EndTime = currentTime
        }
        else if (timeDiffInMinutes >= 0 && timeDiffInMinutes < minTime) {
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Inside less than minTime if condition block. timeDiffInMinutes : " + timeDiffInMinutes)
          val endtimetemp = new java.sql.Timestamp(convertToTimeStamp(StartTime).getTime + minTime * 60 * 1000)
          val timeDiffWait = fn_diff_millisec(currentTime, endtimetemp.toString)
          Thread.sleep(timeDiffWait)
          EndTime = endtimetemp.toString
        }
        else if (timeDiffInMinutes > maxTime) {
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Inside maxTime if condition " + timeDiffInMinutes)
          EndTime = new java.sql.Timestamp(convertToTimeStamp(StartTime).getTime + maxTime * 60 * 1000).toString
        }

        if (EndTime == null) {
          transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": End time could not be calculated based on start time retrieved")
          throw new Exception("End time could not be calculated based on start time retrieved")
        }

        val partColEnd = dateUtil.convertDateFormat(EndTime, TARGDATEFORMAT, "yyyyMMdd")

        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": JobID : " + jobidFilter + " From time: " + StartTime + " to time: " + EndTime)
        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Start of Micro batch : " + Calendar.getInstance.getTime)

        val rows: DataFrame = hiveSession.executeQuery(s"select oid, oiddate, oiddateyyyymmdd, whenloaded, ProductDetail, " +
          s"clientId, subClientId, currCd, total, VirtUsdTotal, CardNo, RuleMaster, clientdate, subclientdate " +
          s"from " + TRANS_MASTER_CORE_BASE + s" where oiddateyyyymmdd between '$partColStart' and '$partColEnd' and" +
          s" whenloaded > '$StartTime' and whenloaded <= '$EndTime' " +
          clientFilter + s" and datasource = '$sourceFilter'")


        val rows_count = rows.count

        transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Number of input rows from source : " + rows_count)

        if (rows_count > 0) {

          val FailedBatchDF: DataFrame = Seq(StartTime).toDF()
            .withColumn("endtime", lit(EndTime))
            .withColumn("jobid", lit(jobidFilter))
            .withColumn("datasource", lit(sourceFilter))

          /* Step-01: Transformation of Exec Data - Deriving common transformations required for all other controllers*/
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Common Transformations")
          val commondf = common.processCommonTransformation(rows)
          commondf.persist()
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Common Transformations")

          /* Step-03: Transaction Details data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Details Transformations")
          val detaildf = detail.processTransDetail(commondf)
          detaildf.persist() // Persisting the data from transaction details for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Details Transformations")

          /* Step-04: Transaction Rule Hits data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Rule Hits Transformations")
          val ruleHitsdf = ruleHits.processRuleHits(commondf)
          ruleHitsdf.persist() // Persisting the data from transaction rule hits for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Rule Hits Transformations")

          val commondf1 = commondf.select($"oid", $"oiddate".as("oiddateintimestamp"), $"clientdate".as("clientdateintimestamp"), $"DetailLines", $"DetailLinesBand", $"DetailLinesBandDesc", $"Region", $"ClientName", $"SubClientName", $"ClientGroup", $"PSP_GROUP", $"ClientSet", $"Client12", $"CURRCLIENT", $"CURRSUBCLIENT", $"TotalGBP", $"TotalUSD", $"TotalEUR", $"TotalClient", $"TotalSubClient", $"cardnomask", $"ClientDateYYYYMMDD", $"SubClientDateYYYYMMDD", $"WhoLoaded", $"WhenUpdated", $"WhoUpdated")



          //val hiveSessionCore: HiveWarehouseSession = HiveWarehouseSession.session(sparkSession).build()
          val rows1: DataFrame = hiveSession.executeQuery(s"select * from " + TRANS_MASTER_CORE_BASE + s" where oiddateyyyymmdd between '$partColStart' and '$partColEnd' and whenloaded > '$StartTime' and whenloaded <= '$EndTime' " +
            clientFilter + s" and datasource = '$sourceFilter'")
            .withColumnRenamed("wholoaded", "wholoaded_source")
            .withColumnRenamed("whenupdated", "whenupdated_source")
            .withColumnRenamed("whoupdated", "whoupdated_source")


          val rows2 = rows1.join(commondf1, Seq("oid")).drop("wholoaded_source").drop("whenupdated_source").drop("whoupdated_source")
              .drop($"oiddate").withColumnRenamed("oiddateintimestamp","oiddate")
          	.drop($"clientdate").withColumnRenamed("clientdateintimestamp","clientdate")


          /* Step-02: Transaction Master Core data transformations */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Transaction Master Core Transformations")
          val coredf = transMasterCore.processTransMasterCore(rows2)
          coredf.persist() // Persisting the data from transaction master for using it in dependency transformations
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Transaction Master Core Transformations")
          /* Step-05: Dependent data transformations  -- Dependent transformations are those that requires data from other tables in order to do a transformation */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Start of Dependent Transformations")
          val finaldataFrame = dependent.processDependencies(coredf, detaildf, ruleHitsdf, hiveSession)
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": End of Dependent Transformations")


          /* Step-05(a): Storing data into Transaction Master Hive table (BI_TRANS_MASTER_CORE) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Master Core data into Hive")
          try {
           dependent.StoreDateToHive(DBNAME, BI_TRANS_MASTER_CORE, APPEND_MODE, finaldataFrame("Trans_master"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Master core dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(EndTime).toDF().withColumn("jobid", lit(jobidFilter)))
              break
          }

          /* Step-05(b): Storing data into Transaction Details Hive table (BI_TRANS_DETAIL) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Detail data into Hive")
          try {
            dependent.StoreDateToHive(DBNAME, BI_TRANS_DETAILS, APPEND_MODE, finaldataFrame("Trans_detail"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Details dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(EndTime).toDF().withColumn("jobid", lit(jobidFilter)))
              break
          }

          /* Step-05(c): Storing data into Transaction Rule Hits Hive table (BI_TRANS_RULE_HITS) */
          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Storing Transaction Rule Hits data into Hive")
          try {
            dependent.StoreDateToHive(DBNAME, BI_TRANS_RULE_HITS, APPEND_MODE, finaldataFrame("Rule_hits"))
          } catch {
            case e: Exception =>
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Issue while storing Trans Rule Hits dataframe. Refer Controlfortransflow_fail table. " + e.printStackTrace)
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_MAINFLOW_FAILOVER, APPEND_MODE, FailedBatchDF)
              transDataFlowLogger.error(TRANSFLOWPROCESS_ERROR + ": Batch unprocessed info saved in control_fail table, let's go to next batch ")
              dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, Seq(EndTime).toDF().withColumn("jobid", lit(jobidFilter)))
              break
          }

          val EndTimeFromNew: DataFrame = Seq(EndTime).toDF().withColumn("jobid", lit(jobidFilter))

          dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, EndTimeFromNew)

          transDataFlowLogger.info(TRANSFLOWPROCESS_INFO + ": Last time used is being inserted")
        }
        else {
          transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": There were no data from source")
          val EndTimeNoRecords: DataFrame = Seq(EndTime).toDF("lastUsedTime").withColumn("jobid", lit(jobidFilter))
          dependent.StoreDateToHive(DBNAME, REDI_CONTROL_FOR_EXTERNAL_TABLE, APPEND_MODE, EndTimeNoRecords)
        }
      }
      transDataFlowLogger.error(TRANSFLOWPROCESS_INFO + ": End of Micro batch : " + Calendar.getInstance.getTime)
      //nextRunWithoutError = false
      hiveSession.close()
    }
  }
}


