package com.aciworldwide.ra.redi.rstransflow.actions

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.rstransflow.controllers.HistoricalRSExecIngestionController
import org.apache.log4j.LogManager
import org.apache.spark.sql.SparkSession

object HistoricalRSExecIngestProcess extends BaseController with Loggers with Serializable with ReDiConstants {

  @transient lazy val histMainIngestionDatalogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    histMainIngestionDatalogger.error(MAINFLOWINGESTIONPROCESS_INFO +":Start of Historical Transaction flow from RS EXEC")
    try {
      val sparkSession: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
      val historicalRSExecIngestionController = new HistoricalRSExecIngestionController(sparkSession)
      historicalRSExecIngestionController.RSTranflowPipeline()
    } catch {
      case e: Exception => histMainIngestionDatalogger.error(MAINFLOWINGESTIONPROCESS_ERROR +":We have an error in the Historical Transaction flow from RS EXEC " + e)
    } finally {
      histMainIngestionDatalogger.error(MAINFLOWINGESTIONPROCESS_INFO +":End of Historical Transaction flow from RS EXEC")
    }
  }
}
