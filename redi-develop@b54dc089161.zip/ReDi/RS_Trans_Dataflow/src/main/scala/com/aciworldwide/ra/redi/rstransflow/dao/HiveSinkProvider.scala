package com.aciworldwide.ra.redi.rstransflow.dao

import org.apache.spark.sql.SQLContext
import org.apache.spark.sql.execution.streaming.Sink
import org.apache.spark.sql.sources.{DataSourceRegister, StreamSinkProvider}
import org.apache.spark.sql.streaming.OutputMode

class HiveSinkProvider extends DataSourceRegister with StreamSinkProvider{

  override def createSink(sqlContext: SQLContext,
                          parameters: Map[String, String],
                          partitionColumns: Seq[String],
                          outputMode: OutputMode): Sink = {
    new HiveSink(parameters)
  }

  override def shortName(): String = "aci.hive"
}
