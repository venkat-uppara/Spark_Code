package com.aciworldwide.ra.redi.rstransflow.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.dao.TransFlowDao
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * @author : Mayank M
  * @version : Initial Draft 1.0 01/02/2019
  * @note : This process is to ingest the data into the ACID table in Hive from kafka source
  *
  *  @author : Mayank M
  *  @version : Initial Draft 1.1 11/03/2019
  *  @note : Changes done to incorporate card decryption, adding addional column source and making all timezones as UTC
  *
  *  @author : Mayank M
  *  @version : Initial Draft 1.1 11/03/2019
  *  @note : Added changes to resolve issue on databricks lib
  *
  *
  */


// Object created because if the "val parser = new Schema.Parser" is in class then it will throw object not serializable exception
//object InformationSchema {
//
//  //schemaRegistry URL here
//  val schemaRegistryURL: String = ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL")
//
//  val topicName: String = ConfigFactory.load().getString("local.common.kafka.transactionkafkatopic")
//  val subjectValueName: String = topicName + "-value"
//
//  //create RestService object
//  val restService = new RestService(schemaRegistryURL)
//
//  //gets latest version of type entities.Schema object.
//  val valueRestResponseSchema: entities.Schema = restService.getLatestVersion(subjectValueName)
//
//
//  //Use Avro parsing classes to get Avro Schema
//  val parser = new Schema.Parser
//  val topicValueAvroSchema: Schema = parser.parse(valueRestResponseSchema.getSchema)
//
//
//  val props: Map[String, String] = Map("schema.registry.url" -> schemaRegistryURL)
//  val structure: StructType = SchemaConverters.toSqlType(topicValueAvroSchema).dataType.asInstanceOf[StructType]
//  //    val structure = SchemaConverters.toSqlType(ReDShieldTransaction.SCHEMA$).dataType.asInstanceOf[StructType]
//
//  //Declare SerDe vars before using Spark structured streaming map. Avoids non serializable class exception.
//  var keyDeserializer: StringDeserializer = null
//  var valueDeserializer: KafkaAvroDeserializer = null
//
//  def deserValue(key: String, value: Array[Byte]): String = {
//    if (valueDeserializer == null) {
//      try {
//        valueDeserializer = new KafkaAvroDeserializer
//      }
//      catch {
//        case e: Throwable => logRegularMessage("We have an error in intitializing KafkaAvroDeserializer" + e)
//      }
//      valueDeserializer.configure(props.asJava, false) //isKey = false
//    }
//
//    val deserializedValueJsonString = valueDeserializer.deserialize(topicName, value, topicValueAvroSchema).toString
//    deserializedValueJsonString
//  }
//}


class RSExecIngestionController(sparkSession: SparkSession) extends BaseController with ReDiConstants with CommonUtils with Serializable {

  import sparkSession.implicits._

  val TransFlowDao = new TransFlowDao(sparkSession)

  @transient lazy val mainIngestionDatalogger = LogManager.getLogger(getClass.getName)

  def udfOIdDateFormatChange = udf((oidDate: String) => {
    var date = ""
    if (oidDate != null) {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(INGESTIONDATEFORMATYYYYMMDDHHMMSS)
      date = outputFormat.format(inputFormat.parse(oidDate))
    }
    date
  })

  // This function updates the realFraud for each transactions related to SDSFraud
  def sdsUpdates(coreDf: DataFrame): DataFrame = {
    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":updating sdsFraudFlagForTheMircoBatch")
    val sdsUpdates = coreDf.withColumnRenamed("realfraud", "reference_realfraud")
      .withColumn("realfraud",
        when($"reference_realfraud" === lit("N")
          //          && array_contains($"clientset", "FDAUTHDECL")
          && $"clientset".contains("FDAUTHDECL")
          && $"report" === lit("0200"), "Y")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSCHDEN")
            && $"clientset".contains("FDSDSCHDEN")
            && ($"report" =!= lit("0150") || $"report".isNull)
            && (
            $"SDSAnswerflag".contains("C") || $"SDSAnswerflag".contains("D")
            ), "Y")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSCODES")
            && $"clientset".contains("FDSDSCODES")
            && $"report".isin("2000", "1300"), "Y")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSDENY")
            && $"clientset".contains("FDSDSDENY")
            && $"report" =!= lit("0150")
            && $"SDSAnswerflag".contains("D"), "Y")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDREP2000")
            && $"clientset".contains("FDREP2000")
            && $"report" === lit("2000"), "Y")
          /*
          IHCFDecision ignored due to being an inactive service.
           */
          .otherwise($"reference_realfraud"))
      .withColumnRenamed("realfraudtype", "reference_realfraudtype")
      .withColumn("realfraudtype",
        when($"reference_realfraud" === lit("N")
          //          && array_contains($"clientset", "FDAUTHDECL")
          && $"clientset".contains("FDAUTHDECL")
          && $"report" === lit("0200"), "AUTHDECL")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSCHDEN")
            && $"clientset".contains("FDSDSCHDEN")
            && ($"report" =!= lit("0150") || $"report".isNull)
            && (
            $"SDSAnswerflag".contains("C") || $"SDSAnswerflag".contains("D")
            ), "SDSCHDEN")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSCODES")
            && $"clientset".contains("FDSDSCODES")
            && $"report".isin("2000", "1300"), "SDSCODES")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDSDSDENY")
            && $"clientset".contains("FDSDSDENY")
            && $"report" =!= lit("0150")
            && $"SDSAnswerflag".contains("D"), "SDSDENY")
          .when($"reference_realfraud" === lit("N")
            //            && array_contains($"clientset", "FDREP2000")
            && $"clientset".contains("FDREP2000")
            && $"report" === lit("2000"), "REP2000")

          /*
          IHCFDecision ignored due to being an inactive service.
           */
          .otherwise($"reference_realfraudtype")
      )
      .withColumn("ClientDate", getTZConvertedDate($"OIDDate", $"TZClient"))
      .withColumn("subClientDate", getTZSubConvertedDate($"OIDDate", $"tzsubclient"))
      .withColumn("RealFraudDate", when($"RealFraud" === lit("Y"), $"ClientDate").otherwise(lit(null)))
      .withColumn("RealFraudDateBAE", when($"RealFraud" === lit("Y"), current_time_utc()).otherwise(lit(null)))
      //      .withColumn("REALFRAUDDATEBAEEPOCH", when($"RealFraud" === lit("Y"), current_time_unix_timestamp()).otherwise(lit(null)))
      .drop("clientset")
      .drop("reference_realfraud")
      .drop("reference_realfraudtype")
      .drop("SDSAnswerflag")
      .drop("TZClient")
      .drop("tzsubclient")

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":completion of the updates to sdsFraudFlagForTheMircoBatch")

    sdsUpdates

  }

  // This function add OIDDATEYYYYMMDD field to every transactions
  def toJsonOIDDATEYYYYMMDDTransform(SDSupdateDf: DataFrame): DataFrame = {

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":updating oiddateyyyymmdd for the MircoBatch")
    val sourceFilter: String = ConfigFactory.load().getString("local.common.realtime_transflow.sourceFilter")

    val finalCoreDf = SDSupdateDf.select($"Aba", $"Accept", $"Accttype", $"AchResponse", $"AdminUserCode", $"AgentBrand", $"AgentDeviceId", $"AgentType", $"Amount1", $"Amount2", $"Anchorf", $"Aol", $"Apacs", $"ApprepInstallMal", $"ApprepInstallSus", $"ApprepRunMal", $"ApprepRunSus", $"ApprepSelfhashCat", $"Asn", $"Auth3dsResult", $"Auth3dsXid", $"AuthCode", $"AuthAmt", $"Authdt", $"AuthResp", $"Authtm", $"Authtz", $"AvsResponse", $"BadScore", $"BciScore", $"BcoScore", $"BillAddress2", $"BillApt", $"BillCity", $"BillCountry", $"BillScore", $"BillState", $"BillStatus", $"BillStreet", $"BillZipcd", $"BpnScore", $"BrowserConfiguredLang", $"BrowserLang", $"BrowserType", $"BrowserVersion", $"BziScore", $"CalcAuthCode", $"CardDetails", $"CardExpdt", $"CardGltof", $"CardNo", $"CardnoDes3", $"CardSeqnum", $"CardType", $"Carrier", $"Cavvaav", $"CinPresent", $"CinResponse", $"ClientId", $"ClIpCnt1", $"Cltof", $"CltofMin", $"CmplTrck2Data", $"Confirmation", $"CookieEnabled", $"Cop2Report", $"Cop2Noscore", $"CorpAddress2", $"CorpCity", $"CorpCountry", $"CorpFax", $"CorpName", $"CorpPhone", $"CorpPonbr", $"CorpPurchase", $"CorpPurchDesc", $"CorpState", $"CorpStreet", $"CorpSuite", $"CorpZipcd", $"CredDebInd", $"CurrCd", $"CustAge", $"CustBdate", $"CustCookies", $"CustEmail", $"CustFax", $"CustFirstName", $"CustGender", $"CustHomePhone", $"CustId", $"CustIdCltof", $"CustIdCltofMin", $"CustIp", $"CustLastName", $"CustMaxage", $"CustMidName", $"CustMinAge", $"CustSalutation", $"CustSsn", $"CustTm", $"CustTranDt", $"CustWorkPhone", $"Cvv2Data", $"Cvv2DataOld", $"Decision", $"DefFormFill", $"Deny", $"DevMatchRes", $"DeviceConfidence", $"DeviceFirstSeen", $"DeviceId", $"DeviceNew", $"DeviceProfileComposite", $"DeviceTof", $"DeviceType", $"DeviceTz", $"DeviceAlias", $"DialIndicator1", $"DialIndicator2", $"DlhId", $"DriverLicense", $"EcommFlag", $"EmailCltof", $"EmailCltofMin", $"EmailGltof", $"EmailGltofMin", $"EmlScore", $"EmvCardVrfyRslts", $"EmvTermType", $"EmvTrmnlVrfyRslt", $"EmvUsrFlr", $"EnabledCk", $"EnabledFl", $"EnabledIm", $"EnabledJs", $"Err", $"ErrorCount", $"ErrorMessage", $"ErrorMsg", $"ExpDate", $"Fiid", $"FlashEnabled", $"FlashInstalled", $"FlashVersion", $"ForgotPwd", $"FuzzyDeviceConf", $"FuzzyDeviceId", $"FuzzyDeviceMtchRes", $"GeopointError", $"GeopointResult", $"GiftCardType", $"GiftMsg", $"Handling", $"HpFingerPrint", $"HpFingerPrintDiff", $"HpFingerPrintMatch", $"HpUnknownDiff", $"HwGpsAccuracy", $"HwLatitude", $"HwLongitude", $"IovAdminCd", $"IovationError", $"IovFld", $"IovSubId", $"IpAddrCity", $"IpAddrLocCountryCd", $"IpAddrProxy", $"IpAddrRegion", $"IpaScore", $"IpidFld", $"IssuedIg", $"JbRoot", $"JbRootReason", $"JsEnabled", $"LoadDate", $"LoadHost", $"LoadProcessorId", $"LoadProcessorType", $"LocalAttrib1", $"LocalAttrib2", $"LocalAttrib3", $"LocalAttrib4", $"LocalAttrib5", $"LocalAttrib6", $"LocalAttrib7", $"LocalAttrib8", $"LocalAttrib9", $"MerchantInt", $"MerchantCountry", $"MerchantId", $"MerchantNm", $"MerchantSic", $"MerchantZipCd", $"MerchStr", $"Message", $"MessageInt1", $"MessageInt2", $"MessageType1", $"MessageType2", $"Model", $"Neural", $"NeuralFlag", $"Noscore", $"numruleinfo", $"OrderId", $"Oid", $"oiddate", $"oiddate_EST", $"OrdScore", $"OrderStatus", $"OrderBin", $"OrderDt", $"OrderTm", $"OrderTz", $"Os", $"PassExpDt", $"PassIssueCountry", $"PassMrz1", $"PassMrz2", $"PassNationalityCd", $"PassPersonalNo", $"PassportNo", $"Password", $"PayMethod", $"PfnScore", $"PhoneCltof", $"PhoneCltofMin", $"PhoneGltof", $"PhoneGltofMin", $"PinIndx", $"PlnScore", $"Pn2Score", $"PolicyScore", $"PosCondCode", $"PosEntryMod", $"Prenote", $"PreviousCust", $"ProdInd", $"ProxyIp", $"ProxyType", $"PwsId", $"PwsScore", $"PwsFirstName", $"PwsLastName", $"PwsPassword", $"PwsUsername", $"QuovaFieldAol", $"QuovaFieldMetroDistance", $"QuovaFieldMetroCity", $"QuovaFieldMetroState", $"QuovaFieldReturnCode", $"Rcf", $"RcfFlag", $"RealIpAddr", $"RealIpIsp", $"RealIpSource", $"Reason", $"Reason1", $"Reason2", $"Reason3", $"ReasonCode", $"Recommendation", $"RedFuzRsp", $"RedIovRsp", $"RedPwsRsp", $"RedRpsRsp", $"RedSaeRsp", $"RedTmxRsp", $"RegLoyalty", $"RegPromos", $"RejectLogin", $"Report", $"RequestDuration", $"RequestId", $"RerspCd", $"ReRuleId", $"Response", $"ResponseCode", $"ResponseType", $"ReStatCd", $"Result", $"ReturnAllowed", $"RiskRating", $"RpsStatus", $"RpsAuthId", $"RpsId", $"RpsKey", $"RtlrsicCode", $"RulesMatched", $"RulesScore", $"Score", $"SdsFldstr", $"Server", $"ServerId", $"Service", $"Services", $"ServTo", $"SessionId", $"SettlementCurrCd", $"ShipAddress2", $"ShipApt", $"ShipCity", $"ShipComments", $"ShipCountry", $"ShipEmail", $"ShipFax", $"ShipFirstName", $"ShipInstruction", $"ShipLastName", $"ShipmentNo", $"Shipmethod", $"ShipMidName", $"ShipPhone", $"ShipSalutation", $"ShipScore", $"ShipState", $"ShipStreet", $"ShipZipcd", $"Source", $"StartTime", $"Status", $"SubclientId", $"SubscriberId", $"SubscriberPassCd", $"SubTotal", $"ServiceProcess", $"Tax", $"TermCity", $"TermCntr", $"Termid", $"TerminalId1", $"TerminalId2", $"TerminalType", $"TermNameLoc", $"TermPstlCode", $"TermSt", $"TermStr", $"TimeStampA", $"TmxApiKey", $"TmxEventType", $"TmxOrgId", $"TmxPolicy", $"TmxServiceType", $"Tof", $"Tokenid", $"Total", $"TrackingNum", $"TrackingNumber", $"TrackingInt", $"TranAmt1", $"TranAmt4", $"TranAmt5", $"TranAuthSrc", $"TranCategory", $"TranCode", $"TranRsnCode", $"TransactionId", $"TranType", $"TrueIp", $"TxDateTime", $"UserCode", $"UserData01", $"UserData02", $"UserData03", $"UserData04", $"UserData05", $"UserData06", $"UserData07", $"UserData08", $"UserData09", $"UserData10", $"UserData11", $"UserData12", $"UserData13", $"UserData14", $"UserData15", $"UserData16", $"UserData17", $"UserData18", $"UserData19", $"UserData20", $"UserData21", $"UserData22", $"UserData23", $"UserData24", $"UserData25", $"Version", $"VirtBillShip", $"VirtBillZipMatch", $"VirtBin", $"VirtCardBin", $"VirtCardClass", $"VirtCustEmailDomain", $"VirtCustEmailMatch", $"VirtExpired", $"VirtFuzBillScore", $"VirtFuzRsp", $"VirtFuzShipScore", $"VirtIovBlng", $"VirtIovCk", $"VirtIovCntryCd", $"VirtIovDeviceId", $"VirtIovDtype", $"VirtIovFlsh", $"VirtIovJs", $"VirtIovProf", $"VirtIovProxy", $"VirtIovRcnt", $"VirtIovRealIp", $"VirtIovReject", $"VirtIovRslt", $"VirtIovRsn", $"VirtIovRsp", $"VirtIovTof", $"VirtIpidAddrType", $"VirtIpidAnonymizer", $"VirtIpidAol", $"VirtIpidAreaCode", $"VirtIpidAsn", $"VirtIpidCarrier", $"VirtIpidCfCountry", $"VirtIpidCity", $"VirtIpidConnSpeed", $"VirtIpidConnType", $"VirtIpidContinent", $"VirtIpidCountry", $"VirtIpidCountryEbg", $"VirtIpidDma", $"VirtIpidIpAddr", $"VirtIpidLat", $"VirtIpidLong", $"VirtIpidMsa", $"VirtIpidPmsa", $"VirtIpidPostal", $"VirtIpidrtMethod", $"VirtIpidSld", $"VirtIpidTld", $"VirtIpidTz", $"VirtIpidUsMetro", $"VirtIpidUsRegion", $"VirtIpidUsState", $"VirtMod10Fail", $"VirtPpAnchorf", $"VirtPpAnchorr", $"VirtPpFmOverlap", $"VirtPpFmScore", $"VirtPpLastSeen", $"VirtPpTof", $"VirtPpTofMin", $"VirtPpTrans", $"VirtPrismRsn1", $"VirtPrismRsn2", $"VirtPrismRsn3", $"VirtPrismScore", $"VirtPwsEml", $"VirtPwsIpa", $"VirtPwsPfn", $"VirtPwsPln", $"VirtPwsRsp", $"VirtPwsScore", $"VirtRecipEmailMatch", $"VirtRecipZipMatch", $"VirtRpsRsp", $"VirtRpsStatus", $"VirtSaeAnchorF", $"VirtSaeCardCltof", $"VirtSaeCardCltofMin", $"VirtSaeCardGltof", $"VirtSaeCardGltofMin", $"VirtSaeClCardCnt1", $"VirtSaeClCardCnt7", $"VirtSaeClCardSum1", $"VirtSaeClCardSum7", $"VirtSaeClCustidCnt1", $"VirtSaeClCustidSum1", $"VirtSaeClCustIpSum1", $"VirtSaeCldevBin1", $"VirtSaeCldevCard1", $"VirtSaeCldevCard7", $"VirtSaeCldeveMail1", $"VirtSaeClDevemlDom1", $"VirtSaeClDevIp1", $"VirtSaeClEmailCnt1", $"VirtSaeClEmailSum1", $"VirtSaeClipCnt1", $"VirtSaeCltof", $"VirtSaeCltofMin", $"VirtSaeCustIdCltof", $"VirtSaeCustIdCltofMin", $"VirtSaeEmailCltof", $"VirtSaeEmailCltofMin", $"VirtSaeEmailGltof", $"VirtSaeEmailGltofMin", $"VirtSaeGlCardCnt1", $"VirtSaeGlCardCnt7", $"VirtSaeGlCardSum1", $"VirtSaeGlCardSum7", $"VirtSaeGlCustIpSum1", $"VirtSaeGlDevBin1", $"VirtSaeGlDevCard1", $"VirtSaeGlDevCard7", $"VirtSaeGlDevEmail1", $"VirtSaeGlDevemlDom1", $"VirtSaeGlDevIp1", $"VirtSaeGlEmailCnt1", $"VirtSaeGlEmailSum1", $"VirtSaeGlIpCnt1", $"VirtSaeGltof", $"VirtSaeGltofMin", $"VirtSaePhoneCltof", $"VirtSaePhoneCltofMin", $"VirtSaePhoneGltof", $"VirtSaePhoneGltofMin", $"VirtSaersp", $"VirtSaeMetaDataVersion", $"VirtSaeUsrdef1", $"VirtSaeUsrdef10", $"VirtSaeUsrdef11", $"VirtSaeUsrdef12", $"VirtSaeUsrdef13", $"VirtSaeUsrdef14", $"VirtSaeUsrdef15", $"VirtSaeUsrdef16", $"VirtSaeUsrdef17", $"VirtSaeUsrdef18", $"VirtSaeUsrdef19", $"VirtSaeUsrdef2", $"VirtSaeUsrdef20", $"VirtSaeUsrdef21", $"VirtSaeUsrdef22", $"VirtSaeUsrdef23", $"VirtSaeUsrdef24", $"VirtSaeUsrdef25", $"VirtSaeUsrdef26", $"VirtSaeUsrdef27", $"VirtSaeUsrdef28", $"VirtSaeUsrdef29", $"VirtSaeUsrdef3", $"VirtSaeUsrdef30", $"VirtSaeUsrdef31", $"VirtSaeUsrdef32", $"VirtSaeUsrdef33", $"VirtSaeUsrdef34", $"VirtSaeUsrdef35", $"VirtSaeUsrdef36", $"VirtSaeUsrdef37", $"VirtSaeUsrdef38", $"VirtSaeUsrdef39", $"VirtSaeUsrdef4", $"VirtSaeUsrdef40", $"VirtSaeUsrdef41", $"VirtSaeUsrdef42", $"VirtSaeUsrdef43", $"VirtSaeUsrdef44", $"VirtSaeUsrdef45", $"VirtSaeUsrdef46", $"VirtSaeUsrdef47", $"VirtSaeUsrdef48", $"VirtSaeUsrdef49", $"VirtSaeUsrdef5", $"VirtSaeUsrdef50", $"VirtSaeUsrdef6", $"VirtSaeUsrdef7", $"VirtSaeUsrdef8", $"VirtSaeUsrdef9", $"VirtShipEmailMatch", $"VirtShipZipMatch", $"VirtTmxAgentBrand", $"VirtTmxAgentType", $"VirtTmxBrowserLang", $"VirtTmxDeviceId", $"VirtTmxEnabledCk", $"VirtTmxEnabledFl", $"VirtTmxEnabledIm", $"VirtTmxEnabledJs", $"VirtTmxFuzzyDeviceId", $"VirtTmxOs", $"VirtTmxPolicyScore", $"VirtTmxProxyIp", $"VirtTmxProxyType", $"VirtTmxReasonCode", $"VirtTmxRiskRating", $"VirtTmxRsp", $"VirtTmxTrueIp", $"VirtTreRsp", $"VirtUsdTotal", $"VirtUtf8", $"Website", $"Wrapped", $"XBillState", $"XBillStreet", $"XBillZipcd", $"XCustEmail", $"XCustFirstName", $"XCustLastName", $"XShipEmail", $"XShipFirstName", $"XShipLastName", $"XShipState", $"XShipStreet", $"XShipZipcd", $"XTransactionid", $"XUserData09", $"RuleMaster", $"RuleCategoryFlag", $"ProductDetail", $"HashCardNo", $"REDI_XCUSTEMAIL", $"XCUSTEMAILDOMAIN", $"realfraud", $"realfraudtype", $"RealFraudDate", $"RealFraudDateBAE", $"clientdate", $"subClientDate", $"Whenloaded")
      .withColumn("wholoaded", lit(System.getProperty("user.name") + "_MainIngestion"))
      .withColumn("whenupdated", lit(""))
      .withColumn("whoupdated", lit(""))
      .withColumn("DATASOURCE", lit(sourceFilter))
      .withColumn("JOBID", lit(""))
      .withColumn("oiddateyyyymmdd", oIdDateWithoutTimePart($"oiddate"))

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":updating oiddateyyyymmdd for the MircoBatch")

    finalCoreDf

  }


  // This function does the main derser and transformations for all the fields required for BAE
  def transformTransactionData(df: DataFrame): DataFrame = {

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":deser and transformation started for the MircoBatch")


    // This will deser the records coming in from Exec Kafka

    //      .select($"key".as[String], $"value".as[Array[Byte]])
    //      .map(
    //        row => {
    //          InformationSchema.deserValue(row._1, row._2)
    //        }
    //      ).select(from_json($"value", InformationSchema.structure).as("data")).select("data.*")
    val df2 = df
      .withColumn("Whenloaded", current_time_utc())
      //      .withColumn("Whenloaded", current_timestamp())
      .withColumnRenamed("oiddate", "oiddate_EST")
      .withColumn("oiddate_EST", expr("substring(oiddate_EST, 1, 14)"))
      //      .withColumn("oiddate", concat($"oiddate_EST" , expr("substring(Oid, 30, 3)")))
      //      .withColumn("oiddate", $"oiddate_EST")
      .withColumn("oiddate", convertedtzForOidDate($"oiddate_EST"))
          .withColumnRenamed("CardNo", "CardNo_plain")
              .withColumn("CardNo", encryptCardNo($"CardNo_plain"))


    // This initializes the hivewarehouse Session
    val hive = HiveWarehouseSession.session(sparkSession).build()

    //fetching required fields from the table rbi_ref_client
    //The table name is temp because client set column type is still not finalized
    val ref_table = hive.executeQuery("select clientId, subclientid, clientset, TZClient, tzsubclient,affiliate from " + ConfigFactory.load().getString("local.common.kafka.HiveRBIRefClient"))

    //Static join between a streaming df and a static table
       val joindCoreRef = df2.join(ref_table, Seq("clientid", "subclientid"), "left_outer")
   // val joindCoreRef = df2.join(ref_table, Seq("clientid", "subclientid"))

    /*Selection of required fields for the rest of the transformations. Then doing transformations for Hashcardno,XCustEmail,XcustEmailDomain
     and putting sdsflag for the later transformation for sdsFraud Flag updates.
    */

    val coreDf = joindCoreRef.select($"Aba", $"Accept", $"Accttype", $"AchResponse", $"AdminUserCode", $"AgentBrand", $"AgentDeviceId", $"AgentType", $"Amount1", $"Amount2", $"Anchorf",
      $"Aol", $"Apacs", $"ApprepInstallMal", $"ApprepInstallSus", $"ApprepRunMal", $"ApprepRunSus", $"ApprepSelfhashCat", $"Asn", $"Auth3dsResult", $"Auth3dsXid", $"AuthCode",
      $"AuthAmt", $"Authdt", $"AuthResp", $"Authtm", $"Authtz", $"AvsResponse", $"BadScore", $"BciScore", $"BcoScore", $"BillAddress2", $"BillApt", $"BillCity", $"BillCountry",
      $"BillScore", $"BillState", $"BillStatus", $"BillStreet", $"BillZipcd", $"BpnScore", $"BrowserConfiguredLang", $"BrowserLang", $"BrowserType", $"BrowserVersion",
      $"BziScore", $"CalcAuthCode", $"CardDetails", $"CardExpdt", $"CardGltof", $"CardNo", $"CardnoDes3", $"CardSeqnum", $"CardType", $"Carrier", $"Cavvaav", $"CinPresent",
      $"CinResponse", $"ClientId", $"ClIpCnt1", $"Cltof", $"CltofMin", $"CmplTrck2Data", $"Confirmation", $"CookieEnabled", $"Cop2Report", $"Cop2Noscore", $"CorpAddress2",
      $"CorpCity", $"CorpCountry", $"CorpFax", $"CorpName", $"CorpPhone", $"CorpPonbr", $"CorpPurchase", $"CorpPurchDesc", $"CorpState", $"CorpStreet", $"CorpSuite", $"CorpZipcd",
      $"CredDebInd", $"CurrCd", $"CustAge", $"CustBdate", $"CustCookies", $"CustEmail", $"CustFax", $"CustFirstName", $"CustGender", $"CustHomePhone", $"CustId", $"CustIdCltof",
      $"CustIdCltofMin", $"CustIp", $"CustLastName", $"CustMaxage", $"CustMidName", $"CustMinAge", $"CustSalutation", $"CustSsn", $"CustTm", $"CustTranDt", $"CustWorkPhone", $"Cvv2Data",
      $"Cvv2DataOld", $"Decision", $"DefFormFill", $"Deny", $"DevMatchRes", $"DeviceConfidence", $"DeviceFirstSeen", $"DeviceId", $"DeviceNew", $"DeviceProfileComposite", $"DeviceTof",
      $"DeviceType", $"DeviceTz", $"DeviceAlias", $"DialIndicator1", $"DialIndicator2", $"DlhId", $"DriverLicense", $"EcommFlag", $"EmailCltof", $"EmailCltofMin", $"EmailGltof",
      $"EmailGltofMin", $"EmlScore", $"EmvCardVrfyRslts", $"EmvTermType", $"EmvTrmnlVrfyRslt", $"EmvUsrFlr", $"EnabledCk", $"EnabledFl", $"EnabledIm", $"EnabledJs", $"Err", $"ErrorCount",
      $"ErrorMessage", $"ErrorMsg", $"ExpDate", $"Fiid", $"FlashEnabled", $"FlashInstalled", $"FlashVersion", $"ForgotPwd", $"FuzzyDeviceConf", $"FuzzyDeviceId", $"FuzzyDeviceMtchRes",
      $"GeopointError", $"GeopointResult", $"GiftCardType", $"GiftMsg", $"Handling", $"HpFingerPrint", $"HpFingerPrintDiff", $"HpFingerPrintMatch", $"HpUnknownDiff", $"HwGpsAccuracy",
      $"HwLatitude", $"HwLongitude", $"IovAdminCd", $"IovationError", $"IovFld", $"IovSubId", $"IpAddrCity", $"IpAddrLocCountryCd", $"IpAddrProxy", $"IpAddrRegion", $"IpaScore", $"IpidFld",
      $"IssuedIg", $"JbRoot", $"JbRootReason", $"JsEnabled", $"LoadDate", $"LoadHost", $"LoadProcessorId", $"LoadProcessorType", $"LocalAttrib1", $"LocalAttrib2", $"LocalAttrib3",
      $"LocalAttrib4", $"LocalAttrib5", $"LocalAttrib6", $"LocalAttrib7", $"LocalAttrib8", $"LocalAttrib9", $"MerchantInt", $"MerchantCountry", $"MerchantId", $"MerchantNm", $"MerchantSic",
      $"MerchantZipCd", $"MerchStr", $"Message", $"MessageInt1", $"MessageInt2", $"MessageType1", $"MessageType2", $"Model", $"Neural", $"NeuralFlag", $"Noscore",
      $"numruleinfo", $"OrderId", $"Oid", $"oiddate", $"oiddate_EST", $"OrdScore", $"OrderStatus", $"OrderBin", $"OrderDt", $"OrderTm", $"OrderTz", $"Os", $"PassExpDt",
      $"PassIssueCountry", $"PassMrz1", $"PassMrz2", $"PassNationalityCd", $"PassPersonalNo", $"PassportNo", $"Password", $"PayMethod", $"PfnScore", $"PhoneCltof", $"PhoneCltofMin",
      $"PhoneGltof", $"PhoneGltofMin", $"PinIndx", $"PlnScore", $"Pn2Score", $"PolicyScore", $"PosCondCode", $"PosEntryMod", $"Prenote", $"PreviousCust", $"ProdInd", $"ProxyIp",
      $"ProxyType", $"PwsId", $"PwsScore", $"PwsFirstName", $"PwsLastName", $"PwsPassword", $"PwsUsername", $"QuovaFieldAol", $"QuovaFieldMetroDistance", $"QuovaFieldMetroCity",
      $"QuovaFieldMetroState", $"QuovaFieldReturnCode", $"Rcf", $"RcfFlag", $"RealIpAddr", $"RealIpIsp", $"RealIpSource", $"Reason", $"Reason1", $"Reason2", $"Reason3",
      $"ReasonCode", $"Recommendation", $"RedFuzRsp", $"RedIovRsp", $"RedPwsRsp", $"RedRpsRsp", $"RedSaeRsp", $"RedTmxRsp", $"RegLoyalty", $"RegPromos", $"RejectLogin", $"Report",
      $"RequestDuration", $"RequestId", $"RerspCd", $"ReRuleId", $"Response", $"ResponseCode", $"ResponseType", $"ReStatCd", $"Result", $"ReturnAllowed", $"RiskRating", $"RpsStatus",
      $"RpsAuthId", $"RpsId", $"RpsKey", $"RtlrsicCode", $"RulesMatched", $"RulesScore", $"Score", $"SdsFldstr", $"Server", $"ServerId", $"Service", $"Services", $"ServTo", $"SessionId",
      $"SettlementCurrCd", $"ShipAddress2", $"ShipApt", $"ShipCity", $"ShipComments", $"ShipCountry", $"ShipEmail", $"ShipFax", $"ShipFirstName", $"ShipInstruction", $"ShipLastName",
      $"ShipmentNo", $"Shipmethod", $"ShipMidName", $"ShipPhone", $"ShipSalutation", $"ShipScore", $"ShipState", $"ShipStreet", $"ShipZipcd", $"Source", $"StartTime", $"Status",
      $"SubclientId", $"SubscriberId", $"SubscriberPassCd", $"SubTotal", $"ServiceProcess", $"Tax", $"TermCity", $"TermCntr", $"Termid", $"TerminalId1",
      $"TerminalId2", $"TerminalType", $"TermNameLoc", $"TermPstlCode", $"TermSt", $"TermStr", $"TimeStamp".alias("TimeStampA"), $"TmxApiKey", $"TmxEventType", $"TmxOrgId", $"TmxPolicy",
      $"TmxServiceType", $"Tof", $"Tokenid", $"Total", $"TrackingNum", $"TrackingNumber", $"TrackingInt", $"TranAmt1", $"TranAmt4", $"TranAmt5", $"TranAuthSrc", $"TranCategory", $"TranCode",
      $"TranRsnCode", $"TransactionId", $"TranType", $"TrueIp", $"TxDateTime", $"UserCode", $"UserData01", $"UserData02", $"UserData03", $"UserData04", $"UserData05", $"UserData06",
      $"UserData07", $"UserData08", $"UserData09", $"UserData10", $"UserData11", $"UserData12", $"UserData13", $"UserData14", $"UserData15", $"UserData16", $"UserData17", $"UserData18",
      $"UserData19", $"UserData20", $"UserData21", $"UserData22", $"UserData23", $"UserData24", $"UserData25", $"Version", $"VirtBillShip", $"VirtBillZipMatch", $"VirtBin", $"VirtCardBin",
      $"VirtCardClass", $"VirtCustEmailDomain", $"VirtCustEmailMatch", $"VirtExpired", $"VirtFuzBillScore", $"VirtFuzRsp", $"VirtFuzShipScore", $"VirtIovBlng", $"VirtIovCk",
      $"VirtIovCntryCd", $"VirtIovDeviceId", $"VirtIovDtype", $"VirtIovFlsh", $"VirtIovJs", $"VirtIovProf", $"VirtIovProxy", $"VirtIovRcnt", $"VirtIovRealIp", $"VirtIovReject",
      $"VirtIovRslt", $"VirtIovRsn", $"VirtIovRsp", $"VirtIovTof", $"VirtIpidAddrType", $"VirtIpidAnonymizer", $"VirtIpidAol", $"VirtIpidAreaCode", $"VirtIpidAsn", $"VirtIpidCarrier",
      $"VirtIpidCfCountry", $"VirtIpidCity", $"VirtIpidConnSpeed", $"VirtIpidConnType", $"VirtIpidContinent", $"VirtIpidCountry", $"VirtIpidCountryEbg", $"VirtIpidDma", $"VirtIpidIpAddr",
      $"VirtIpidLat", $"VirtIpidLong", $"VirtIpidMsa", $"VirtIpidPmsa", $"VirtIpidPostal", $"VirtIpidrtMethod", $"VirtIpidSld", $"VirtIpidTld", $"VirtIpidTz", $"VirtIpidUsMetro",
      $"VirtIpidUsRegion", $"VirtIpidUsState", $"VirtMod10Fail", $"VirtPpAnchorf", $"VirtPpAnchorr", $"VirtPpFmOverlap", $"VirtPpFmScore", $"VirtPpLastSeen", $"VirtPpTof", $"VirtPpTofMin",
      $"VirtPpTrans", $"VirtPrismRsn1", $"VirtPrismRsn2", $"VirtPrismRsn3", $"VirtPrismScore", $"VirtPwsEml", $"VirtPwsIpa", $"VirtPwsPfn", $"VirtPwsPln", $"VirtPwsRsp", $"VirtPwsScore",
      $"VirtRecipEmailMatch", $"VirtRecipZipMatch", $"VirtRpsRsp", $"VirtRpsStatus", $"VirtSaeAnchorF", $"VirtSaeCardCltof", $"VirtSaeCardCltofMin", $"VirtSaeCardGltof",
      $"VirtSaeCardGltofMin", $"VirtSaeClCardCnt1", $"VirtSaeClCardCnt7", $"VirtSaeClCardSum1", $"VirtSaeClCardSum7", $"VirtSaeClCustidCnt1", $"VirtSaeClCustidSum1", $"VirtSaeClCustIpSum1",
      $"VirtSaeCldevBin1", $"VirtSaeCldevCard1", $"VirtSaeCldevCard7", $"VirtSaeCldeveMail1", $"VirtSaeClDevemlDom1", $"VirtSaeClDevIp1", $"VirtSaeClEmailCnt1", $"VirtSaeClEmailSum1",
      $"VirtSaeClipCnt1", $"VirtSaeCltof", $"VirtSaeCltofMin", $"VirtSaeCustIdCltof", $"VirtSaeCustIdCltofMin", $"VirtSaeEmailCltof", $"VirtSaeEmailCltofMin", $"VirtSaeEmailGltof",
      $"VirtSaeEmailGltofMin", $"VirtSaeGlCardCnt1", $"VirtSaeGlCardCnt7", $"VirtSaeGlCardSum1", $"VirtSaeGlCardSum7", $"VirtSaeGlCustIpSum1", $"VirtSaeGlDevBin1", $"VirtSaeGlDevCard1",
      $"VirtSaeGlDevCard7", $"VirtSaeGlDevEmail1", $"VirtSaeGlDevemlDom1", $"VirtSaeGlDevIp1", $"VirtSaeGlEmailCnt1", $"VirtSaeGlEmailSum1", $"VirtSaeGlIpCnt1", $"VirtSaeGltof",
      $"VirtSaeGltofMin", $"VirtSaePhoneCltof", $"VirtSaePhoneCltofMin", $"VirtSaePhoneGltof", $"VirtSaePhoneGltofMin", $"VirtSaersp", $"VirtSaeMetaDataVersion", $"VirtSaeUsrdef1",
      $"VirtSaeUsrdef10", $"VirtSaeUsrdef11", $"VirtSaeUsrdef12", $"VirtSaeUsrdef13", $"VirtSaeUsrdef14", $"VirtSaeUsrdef15", $"VirtSaeUsrdef16", $"VirtSaeUsrdef17", $"VirtSaeUsrdef18",
      $"VirtSaeUsrdef19", $"VirtSaeUsrdef2", $"VirtSaeUsrdef20", $"VirtSaeUsrdef21", $"VirtSaeUsrdef22", $"VirtSaeUsrdef23", $"VirtSaeUsrdef24", $"VirtSaeUsrdef25", $"VirtSaeUsrdef26",
      $"VirtSaeUsrdef27", $"VirtSaeUsrdef28", $"VirtSaeUsrdef29", $"VirtSaeUsrdef3", $"VirtSaeUsrdef30", $"VirtSaeUsrdef31", $"VirtSaeUsrdef32", $"VirtSaeUsrdef33", $"VirtSaeUsrdef34",
      $"VirtSaeUsrdef35", $"VirtSaeUsrdef36", $"VirtSaeUsrdef37", $"VirtSaeUsrdef38", $"VirtSaeUsrdef39", $"VirtSaeUsrdef4", $"VirtSaeUsrdef40", $"VirtSaeUsrdef41", $"VirtSaeUsrdef42",
      $"VirtSaeUsrdef43", $"VirtSaeUsrdef44", $"VirtSaeUsrdef45", $"VirtSaeUsrdef46", $"VirtSaeUsrdef47", $"VirtSaeUsrdef48", $"VirtSaeUsrdef49", $"VirtSaeUsrdef5", $"VirtSaeUsrdef50",
      $"VirtSaeUsrdef6", $"VirtSaeUsrdef7", $"VirtSaeUsrdef8", $"VirtSaeUsrdef9", $"VirtShipEmailMatch", $"VirtShipZipMatch", $"VirtTmxAgentBrand", $"VirtTmxAgentType", $"VirtTmxBrowserLang",
      $"VirtTmxDeviceId", $"VirtTmxEnabledCk", $"VirtTmxEnabledFl", $"VirtTmxEnabledIm", $"VirtTmxEnabledJs", $"VirtTmxFuzzyDeviceId", $"VirtTmxOs", $"VirtTmxPolicyScore", $"VirtTmxProxyIp", $"VirtTmxProxyType", $"VirtTmxReasonCode", $"VirtTmxRiskRating", $"VirtTmxRsp", $"VirtTmxTrueIp", $"VirtTreRsp", $"VirtUsdTotal", $"VirtUtf8", $"Website", $"Wrapped", $"XBillState", $"XBillStreet", $"XBillZipcd", $"XCustEmail", $"XCustFirstName", $"XCustLastName", $"XShipEmail", $"XShipFirstName", $"XShipLastName", $"XShipState", $"XShipStreet", $"XShipZipcd", $"XTransactionid", $"XUserData09", $"RuleMaster", $"RuleCategoryFlag", $"ProductDetail", $"Whenloaded", $"clientset", $"TZClient", $"TZsubClient",$"affiliate")
      .withColumn("HashCardNo", funcHashCardNo($"CardNo"))
      //      .withColumn("HashCardNo", lit(""))
      .withColumn("REDI_XCUSTEMAIL", when($"xCustEmail".contains("@"), lower(col("xCustEmail"))).otherwise($"xCustEmail"))
      .withColumn("TempxCustEmailDomain", when($"xCustEmail".contains("@"), split(col("xCustEmail"), "@")(1)).otherwise(lit(null)))
      .withColumn("XCUSTEMAILDOMAIN", when(col("TempxCustEmailDomain").isNull, lit(null)).otherwise(expr("substring(TempxCustEmailDomain,1,50)")))
      .drop("TempxCustEmailDomain")
      .withColumn("SDSAnswerflag", returnFlag(joindCoreRef("NumRuleInfo.ServiceName"), joindCoreRef("NumRuleInfo.Answer")))
      .withColumn("realfraud", updateRealFraudYN(joindCoreRef("rulemaster.rulesource"),joindCoreRef("rulemaster.ruleid"),joindCoreRef("rulemaster.rulename"),$"affiliate",$"clientid",$"Recommendation"))
      .withColumn("realfraudtype", when(col("realfraud")=== lit("Y"),lit("FRAUDRUL")).otherwise(lit("N")))
      .withColumn("oiddate", when($"oiddate".isNotNull, udfOIdDateFormatChange($"oiddate")).otherwise($"oiddate"))
      .withColumn("oiddate", concat($"oiddate", expr("substring(Oid, 30, 3)")))

    //This function will update the realFraudflag, realfraudtype, realfraudfDate,realfraudfDateBAE etc
    val SDSupdateDf = sdsUpdates(coreDf)

    //This function will update the realFraudflag, realfraudtype, realfraudfDate,realfraudfDateBAE etc
    val execDfForBae = toJsonOIDDATEYYYYMMDDTransform(SDSupdateDf)

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":deser and transformation ended for the MircoBatch")

    execDfForBae

  }

  def RSTranflowPipeline(): Unit = {
    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":Transformation for the MircoBatch started")

    TransFlowDao.WriteTransactionData(transformTransactionData(TransFlowDao.readTransactionsFromKafka()))

    mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":Transformation for the MircoBatch ended")
  }
}
