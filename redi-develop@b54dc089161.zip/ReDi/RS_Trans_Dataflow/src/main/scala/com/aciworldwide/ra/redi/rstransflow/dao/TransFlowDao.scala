package com.aciworldwide.ra.redi.rstransflow.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.rstransflow.actions.RSExecIngestProcess.logRegularMessage
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, SparkSession}
import za.co.absa.abris.avro.read.confluent.SchemaManager
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY
import za.co.absa.abris.avro.AvroSerDe._

class TransFlowDao(sc: SparkSession) extends Serializable with ReDiConstants {

    //  val hive = HiveWarehouseSession.session(sc).build()
    //  hive.setDatabase(MAINFLOW_DATABASE)

    val schemaRegistryConfs = Map(
        SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"),
        SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> ConfigFactory.load().getString("local.common.kafka.transactionkafkatopic"),
        SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME, // choose a subject name strategy
        SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest" // set to "latest" if you want the latest schema version to used
    )

    @transient lazy val mainIngestionDatalogger = LogManager.getLogger(getClass.getName)

    def readTransactionsFromKafka(): DataFrame = {
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":read stream for the MircoBatch started")
        sc
          .readStream
          .format(KAFKA_SOURCE)
          .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
          .option(SUBSCRIBE, ConfigFactory.load().getString("local.common.kafka.transactionkafkatopic"))
          .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.maxOffsetsPerTrigger"))
          .option("failOnDataLoss", "false")
          .option("startingOffsets", "latest")
          .option(KAFKASECURITYPROTOCOL, SASL_SSL)
          .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
          .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
          .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
          .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
          .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
          .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
          .option(KAFKASASLMECHANISM, GSSAPI)
          .load()
          .fromConfluentAvro("value", None, Some(schemaRegistryConfs))(RETAIN_SELECTED_COLUMN_ONLY) // invoke the library passing over parameters to access the Schema Registry
    }


    def WriteTransactionData(df: DataFrame): Unit = {
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":Write stream for the MircoBatch started")
        try {
            df
              .writeStream
              .format(HiveWarehouseSession.STREAM_TO_STREAM)
              .trigger(Trigger.ProcessingTime(ConfigFactory.load().getString("local.common.kafka.processingTime")))
              .option(DATABASE, MAINFLOW_DATABASE)
              .option(TABLE, ConfigFactory.load().getString("local.common.kafka.HiveSinkTableCore"))
              .option(METASTOREURI, ConfigFactory.load().getString("local.common.kafka.metastoreUri"))
              .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.kafka.transactiontopicCheckpointlocationCore"))
              .start()
              .awaitTermination()
        }
        catch {
            case e: Throwable => logRegularMessage("We have an error in in writing the writing the records to Hive tables" + e)
        }
        mainIngestionDatalogger.info(MAINFLOWINGESTIONPROCESS_INFO + ":read stream for the MircoBatch ended")

    }


    def gettheDataFromHive(sc: SparkSession, tablename: String): DataFrame = {
        val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sc).build()
        hiveSession.executeQuery(s"select * from $tablename")
    }

    /**
      * The procedure for fetching country dimension -- MERF-9239
      */

    def getCountryDimension(tablename: String): DataFrame = {
        gettheDataFromHive(sc, tablename)
    }

    def getCurrencyRates(tablename: String): DataFrame = {
        gettheDataFromHive(sc, tablename)
    }
}

