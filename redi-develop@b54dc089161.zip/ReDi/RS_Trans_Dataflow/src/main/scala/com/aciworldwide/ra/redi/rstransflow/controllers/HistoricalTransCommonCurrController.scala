package com.aciworldwide.ra.redi.rstransflow.controllers

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.schemas.CurrencyRates
import com.aciworldwide.ra.redi.rstransflow.services.ReDiSerializers
import com.aciworldwide.ra.redi.rstransflow.utils.RSTransFlowCommonUtils
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

class HistoricalTransCommonCurrController(spark: SparkSession) extends Loggers with ReDiSerializers
  with Serializable with DatabaseServices with ReDiTableSchemas with RSTransFlowCommonUtils with CommonUtils with ReDiConstants {

  @transient lazy val hisotricalCurrLogger = LogManager.getLogger(getClass.getName)
  var dfRbiRefClientData: DataFrame = _
  dfRbiRefClientData = gettheDataFromHiveForRef(spark, REDI_RBI_REF_CLIENT)
  val format = new java.text.SimpleDateFormat(clientDateyyymmdd)
  var currencyRates: DataFrame = null
  var currencyList: List[CurrencyRates] = null
  var currentDate: Date = null
  var currMap: Map[String, String] = _


  import spark.implicits._

  def currencyRatesFromHive(): List[CurrencyRates] = {
    hisotricalCurrLogger.info(TRANSFLOWPROCESS_INFO + ": Inside currencyRatesFromHive Method")
    currencyRates = gettheDataFromHive(spark, currency_convrates_table).select("destcurrencycode", "conversionrate", "currencydate").distinct()
      .groupBy("destcurrencycode", "currencydate").agg(max("conversionrate").as("conversionrate")).orderBy(asc("destcurrencycode"))
      .filter($"currencydate".isNotNull && $"destcurrencycode".isNotNull)


    currencyList = currencyRates.select($"currencydate", $"DestCurrencyCode", $"ConversionRate")
      .collect().map(row => CurrencyRates(if (row.get(0) == null || row.get(0) == "NULL") null else row.getDate(0), if (row.isNullAt(1)) "" else row.getString(1), if (row.isNullAt(2)) 0 else row.getDouble(2))).toList.sortBy(_.currencydate).reverse
    hisotricalCurrLogger.info(TRANSFLOWPROCESS_INFO + ": Completed currencyRatesFromHive Method")
    currencyList
  }

  def getEqualOrNearestCurrencyRate(currencyCode: String, clientDate: String): Double = {
    var currencyRate: Double = 0

    def max(s1: CurrencyRates, s2: CurrencyRates): CurrencyRates = if (s1.currencydate.compareTo(s2.currencydate) >= 0) s1 else s2

    //hisotricalCurrLogger.info(TRANSFLOWPROCESS_INFO + ": Inside getEqualOrNearestCurrencyRate Method" + currencyList.size)


    if (currencyCode != null && !currencyCode.trim.isEmpty && clientDate != null && !clientDate.isEmpty && currencyList != null && currencyList.nonEmpty) {


      val currFilterList = currencyList
        .filter(x => (x.currencydate.toString.equals(clientDate) || x.currencydate.before(format.parse(clientDate)))
          && x.DestCurrencyCode == currencyCode).reverse
      if (currFilterList.nonEmpty) {
        val res = currFilterList.reduceLeft(max)
        currencyRate = res.ConversionRate
      }
      currencyRate
    }
    else {
      currencyRate
    }
  }

  def getClientDateFormatForCurr: UserDefinedFunction = udf((clientDate: String) => {
    val inputFormat = new SimpleDateFormat(historical_clientDate_format)
    val outputFormat = new SimpleDateFormat(clientDateyyymmdd)
    if (clientDate != null && !clientDate.trim.isEmpty) {
      val date = outputFormat.format(inputFormat.parse(clientDate))
      date
    }

    else {
      ""
    }
  })

  def convertedCurrency: UserDefinedFunction = udf((sourceConversionRate: Double, destConversionRate: Double, noOfUnits: String) => {
    var convertedCurrency: Double = 0.0


    if (destConversionRate > 0 && sourceConversionRate > 0 && noOfUnits.matches("[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)")) {
      convertedCurrency = ((1 / sourceConversionRate) * destConversionRate) * noOfUnits.toDouble
      convertedCurrency = BigDecimal(convertedCurrency).setScale(2, BigDecimal.RoundingMode.HALF_UP).toDouble
    }
    convertedCurrency
  })

  def getConversionRate: UserDefinedFunction = udf((curr: String, clientDate: String) => {
    getEqualOrNearestCurrencyRate(curr, clientDate)
  })


  def currClientSubclient: UserDefinedFunction = udf((clientID: String, clientcurr: String, currcd: String) => {
    var curr: String = "novalue"
    if (clientcurr == null || (clientcurr != null && clientcurr.trim.isEmpty)) {
      if (currMap!=null && currMap.isDefinedAt(clientID)) {
        var clientcurr = currMap.get(clientID)
        if (!clientcurr.get.trim.isEmpty) {
          curr = clientcurr.get
        } else {
          curr
        }
      }
    }
    else if (clientcurr != null && !clientcurr.trim.isEmpty) {
      curr = clientcurr
    }
    curr
  })

  def currSubclient: UserDefinedFunction = udf((subclientcurr: String) => {
    var curr: String = "novalue"

    if (subclientcurr != null && !subclientcurr.trim.isEmpty) {
      curr = subclientcurr
    }
    curr

  })

  def currencyConversion(df: DataFrame): DataFrame = {
    hisotricalCurrLogger.info(TRANSFLOWPROCESS_INFO + ": Inside Transformation of fntr:currencyConversion")
    val cal = Calendar.getInstance()
    val d1 = format.parse(format.format(cal.getTime))
    if (currencyList == null) {
      currencyList = currencyRatesFromHive()
      currentDate = d1
    }
    else if (currencyList != null && currentDate != null && d1.after(currentDate)) {
      currencyList = currencyRatesFromHive()
      currentDate = d1
    }
    val window = Window.partitionBy("clientid").orderBy($"curroccurance".desc, $"clientcurr".asc)

    currMap = dfRbiRefClientData.select("clientid", "clientcurr").filter($"clientcurr".isNotNull && trim($"clientcurr") =!= lit("")).
      groupBy("clientid", "clientcurr").agg(count($"clientcurr").as("curroccurance")).withColumn("row_number_curr", row_number().over(window)).
      filter($"row_number_curr" === 1).collect().map(row => (if (row.isNullAt(0)) "" else row.getString(0), if (row.isNullAt(1)) "" else row.getString(1))).toMap


    val rbirefClientDF = dfRbiRefClientData.select($"ClientID", $"SubClientID", $"clientcurr", $"subclientcurr")
    var allCurrencyTotal = df.join(rbirefClientDF, Seq("clientId", "subClientId"), "left_outer")
    allCurrencyTotal = allCurrencyTotal
      .withColumn("CURRCLIENTTEMP", currClientSubclient($"ClientID", $"clientcurr", $"currCd"))
      .withColumn("CURRCLIENT", when(!$"CURRCLIENTTEMP".equalTo("novalue"), col("CURRCLIENTTEMP")).otherwise($"currcd"))
      .withColumn("CURRSUBCLIENT", when(!currSubclient($"subclientcurr").equalTo("novalue"), col("subclientcurr")).otherwise(col("CURRCLIENT")))
      .withColumn("clientdateforcurr", when($"clientdate".isNotNull, getClientDateFormatForCurr($"clientdate")))
      .withColumn("currCdConversionRate", when($"clientdate".isNotNull, getConversionRate($"currCd", $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("GBPConversionRate", when($"clientdate".isNotNull, getConversionRate(lit("GBP"), $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("USDConversionRate", when($"clientdate".isNotNull, getConversionRate(lit("USD"), $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("EURConversionRate", when($"clientdate".isNotNull, getConversionRate(lit("EUR"), $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("CurrClientConversionRate", when($"clientdate".isNotNull, getConversionRate($"CURRCLIENT", $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("CurrSubClientConversionRate", when($"clientdate".isNotNull, getConversionRate($"CURRSUBCLIENT", $"clientdateforcurr")).otherwise(lit(0)))
      .withColumn("total", col("total").cast("decimal(14,2)"))
      .withColumn("TotalGBP", when(col("currCd") === lit("GBP"), col("total"))
        .otherwise(convertedCurrency(col("currCdConversionRate"), col("GBPConversionRate"), col("total"))))
      .withColumn("TotalUSD", col("VirtUsdTotal"))
      .withColumn("TotalEUR", when(col("currCd") === lit("EUR"), col("total"))
        .otherwise(convertedCurrency(col("currCdConversionRate"), col("EURConversionRate"), col("total"))))
      .withColumn("TotalClient", when(col("currCd") === col("CURRCLIENT"), col("total"))
        .otherwise(convertedCurrency(col("currCdConversionRate"), col("CurrClientConversionRate"), col("total"))))
      .withColumn("TotalSubClient", when(col("currCd") === col("CURRSUBCLIENT"), col("total"))
        .otherwise(convertedCurrency(col("currCdConversionRate"), col("CurrSubClientConversionRate"), col("total"))))
    allCurrencyTotal = allCurrencyTotal
      .drop($"clientcurr")
      .drop($"subclientcurr")
      .drop($"CURRCLIENTTEMP")
      .drop($"clientdateforcurr")
      .drop($"currCdConversionRate")
      .drop($"GBPConversionRate")
      .drop($"USDConversionRate")
      .drop($"EURConversionRate")
      .drop($"CurrClientConversionRate")
      .drop($"CurrSubClientConversionRate")
    allCurrencyTotal
  }
}
