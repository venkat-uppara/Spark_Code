package com.aciworldwide.ra.redi.rstransflow.dao

import com.typesafe.config.ConfigFactory
import org.apache.spark.internal.Logging
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.execution.streaming.Sink

class HiveSink(parameters: Map[String, String]) extends Sink with Logging {

  /**
    * Saving DataFrame to Hive table. The table name must be specified in the configuration.
    *
    * @param dataFrame default spark DataFrame[Row]
    */
  private def saveToHive(dataFrame: DataFrame): Unit = {
    dataFrame.write
      .insertInto(ConfigFactory.load().getString("local.common.kafka.HiveSinkTable"))
  }

  override def addBatch(batchId: Long, dataFrame: DataFrame): Unit = {
    logDebug(s"Starting to write batch #$batchId")
    println("I am in addBatch")
    saveToHive(dataFrame)
    logDebug(s"Batch #$batchId has been written")
  }
}
