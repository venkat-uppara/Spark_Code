/**
  * @author : Janakiraman Sivasailam (JS)
  *         : Prabhu Bellibhojan (PBB)
  *         : Krishnaprasad Ramkumar (KP)
  * @version : 1.0 Initial Draft
  * @usecase : MERF-9079 (Transaction Load Transfomation Process)
  * @note       : The code developed as part of MERF-9079, is used to push the data from Exec Kafka into the Final Tables.
  *             1. Trans Master data load developed by JS.
  *             2. Trans Detail data load developed by PBB.
  *             3. Trans Rule Hits data load developed by KP.
  */

package com.aciworldwide.ra.redi.rstransflow.actions

/** Dependencies
  * Importing the dependent classes, objects or traits as required in the below processes
  */

import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.rstransflow.controllers.TransFlowController
import org.apache.logging.log4j.LogManager

/** Transaction Flow Process
  * The transformation process of the transactions from Exec Kafka is done as part of this process.
  * The transformation is done on the data loaded from the external hive table and the transformed data is loaded into the respective final tables.
  */
object TransFlowProcessAction extends TransFlowController with EstablishConnections with Loggers with Serializable {

  @transient lazy val transFlowLogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    /** Starting the Transformation process
      * Logging the start of the transformation process */
    transFlowLogger.error(TRANSFLOWPROCESS_INFO + ": Start of Transformation Process, this is to Transform Incremental Transaction Flow Data")
    try {
      /** Invoking the Base Controller Process
        * This is used to initiate the transformation process for transaction load.
        * This base controller contains details of the process that needs to be inovked and it initiates them in the order defined */
      transFlowProcesTransformations()
    } catch {
      /** Exception in the Transformation process
        * Logging the exception that occurred in the transformation process */
      case e: Exception => transFlowLogger.info(TRANSFLOWPROCESS_INFO + ": We have an error in the Transformation Process")
        e.printStackTrace()
    } finally {
      /** End of the Transformation process
        * Logging the end of the transformation process */
      transFlowLogger.error(TRANSFLOWPROCESS_INFO + ": End of Transformation Process, this is to Transform Incremental Transaction Flow Data")
    }
  }
}