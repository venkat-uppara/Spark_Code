package com.aciworldwide.ra.redi.transflowtest.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.redshield.core.ods.executive.ReDShieldTransaction
import com.databricks.spark.avro.SchemaConverters
import org.apache.avro.Schema
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.scalatest.{BeforeAndAfterEach, FunSuite}

class DVERulesTest extends FunSuite with BeforeAndAfterEach with ReDiConstants with Serializable {

  //Success
  test("BasicTransRuleHitsColumnsTest") {

    val session = SparkSession.builder()
      .config("spark.sql.caseSensitive", "false")
      .config("spark.default.parallelism", "1")
      .config("spark.sql.shuffle.partitions", "1")
      .appName("test")
      .master("local[*]")
      .getOrCreate()

    val parser = new Schema.Parser
    val schema: Schema = parser.parse(ReDShieldTransaction.SCHEMA$.toString)
    val structure: StructType = SchemaConverters.toSqlType(schema).dataType.asInstanceOf[StructType]

    import session.implicits._

    val tref = Seq(("000050000001TAH20181124073716856", "DVE", "2018-11-24 02:37:16", "02 Ireland", "Internet Top-ups", "000040", "000002", "Accept", "2017-10-04 07:02:25", "N", "20171004"),
      ("00004101002344481CQR20171004110225000", "TRE", "2018-11-24 02:37:16", "02 Ireland", "Internet Top-ups", "000040", "000002", "Accept", "2017-10-04 07:02:25", "N", "20171004"),
      ("000050000022TAK20181126045828600", "XYZ", "2018-11-24 02:37:16", "02 Ireland", "Internet Top-ups", "000040", "000002", "Accept", "2017-10-04 07:02:25", "N", "20171004"))
      .toDF("oid", "rulesource", "ClientDate", "ClientName", "SubClientName", "ClientId", "SubClientId", "Recommend", "SubClientDate", "IgnoreRules", "OIDDateYYYYMMDD")
      .withColumn("ClientMonthText", date_format(to_date($"ClientDate", "yyyy-MM-dd HH:mm:ss"), "MMM yyyy"))
      .withColumn("ClientYYMMDD", when(col("rulesource").isin("DVE", "TRE", "TSW"), date_format(col("ClientDate"), "yyMMdd")))
      .withColumn("ClientName", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("ClientName")))
      .withColumn("SubClientName", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("SubClientName")))
      .withColumn("ClientId", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("ClientId")))
      .withColumn("SubClientId", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("SubClientId")))
      .withColumn("ActualRecommend", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("Recommend")))
      .withColumn("SubClientMonthText", date_format(to_date($"SubClientDate", "yyyy-MM-dd HH:mm:ss"), "MMM yyyy"))
      .withColumn("SubClientYYMMDD", when(col("rulesource").isin("DVE", "TRE", "TSW"), date_format(col("SubClientDate"), "yyMMdd")))
      .withColumn("NonCoreTxn", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("IgnoreRules")))
      .withColumn("ROIDDateYYMMDD", when(col("rulesource").isin("DVE", "TRE", "TSW"), col("OIDDateYYYYMMDD")))

    tref.show()

  }
  /*

    //Success for all except Subclient columns
    test("RBIRefDatesColumnsTest") {

      val session = SparkSession.builder()
        .config("spark.sql.caseSensitive", "false")
        .config("spark.default.parallelism", "1")
        .config("spark.sql.shuffle.partitions", "1")
        .appName("test")
        .master("local[*]")
        .getOrCreate()

      val parser = new Schema.Parser
      val schema: Schema = parser.parse(ReDShieldTransaction.SCHEMA$.toString)
      val structure: StructType = SchemaConverters.toSqlType(schema).dataType.asInstanceOf[StructType]

      import session.implicits._

      //val arr = Array("a", "b", "CREDECLINE")

      val inputDF = Seq(("000050000001TAH20181124073716856", "DVE", "000040","2018-12-24 02:37:16", "2018-10-04 07:02:25"),
        ("00004101002344481CQR20171004110225000", "TRE", "000040", "2018-12-24 02:37:16", "2018-10-04 07:02:25"),
        ("000050000022TAK20181126045828600", "XYZ", "000040", "2015-10-04 07:02:25", "2015-10-04 07:02:25"),
        ("000050000022TAB20181126045828600", "TSW", "000060", "2015-10-04 07:02:25", "2015-10-04 07:02:25"))
      .toDF("oid", "rulesource", "clientid", "CDate", "SCDate")
        .withColumn("ClientDate", date_format(to_date($"CDate", "yyyy-MM-dd HH:mm:ss"), "yyMMdd"))
        .withColumn("SubClientDate", date_format(to_date($"SCDate", "yyyy-MM-dd HH:mm:ss"), "yyMMdd"))
        .withColumn("clientset", array(lit("WKSUNSAT"), lit("CREDECLINE")))

      inputDF.show()

      val tref = inputDF.filter(col("rulesource").isin("DVE", "TRE", "TSW"))
      tref.show()

      val refdatesDF = Seq(("2018-12-24 02:37:16","Sun23Dec-Sat29Dec","Sat22Dec-Fri28Dec","181223","181222","Mon24Dec"), ("2015-10-04 07:02:25","Sun04Oct-Sat10Oct","Sat03Oct-Fri09Oct","151004", "151003","Sun04Oct"), ("2018-10-04 07:02:25","Sun30Sep-Sat06Oct","Sat29Sep-Fri05Oct","180930","180929","Thu04Oct"))
        .toDF("dateX", "WeekBTextMed", "WeekTextMed","WeekBYYMMDD", "WeekYYMMDD", "DateTextShort")
        .withColumn("dateyymmdd", date_format(to_date($"dateX", "yyyy-MM-dd HH:mm:ss"), "yyMMdd"))

      refdatesDF.show()

  /*    val refdatesDF1 = Seq(("2018-12-24 02:37:16","Sun23Dec-Sat29Dec","Sat22Dec-Fri28Dec","181223","181222","Mon24Dec"), ("2015-10-04 07:02:25","Sun04Oct-Sat10Oct","Sat03Oct-Fri09Oct","151004", "151003","Sun04Oct"), ("2018-10-04 07:02:25","Sun30Sep-Sat06Oct","Sat29Sep-Fri05Oct","180930","180929","Thu04Oct"))
        .toDF("dateX", "WeekBTextMed", "WeekTextMed","WeekBYYMMDD", "WeekYYMMDD", "DateTextShort")
        .withColumn("dateyymmdd", date_format(to_date($"dateX", "yyyy-MM-dd HH:mm:ss"), "yyMMdd"))

      refdatesDF1.show()*/

      val refclientDF = Seq(("000050000001TAH20181124073716856","000040"), ("00004101002344481CQR20171004110225000","000040"), ("000050000022TAK20181126045828600","000040"), ("000050000022TAQ20181126045828600", "000059"))
        .toDF("oid", "ref_ClientID")
        .withColumn("ref_ClientSet", array(lit("WKSUNSAT"), lit("CREDECLINE")))

      refclientDF.show()

  //      .join(refdatesDF, to_date(tref.col("ClientDate"), "yymmdd")  === to_date(refdatesDF.col("dateyymmdd"), "yymmdd"), "left_outer")

      val withClientDatesDF = tref
        .join(refdatesDF, tref.col("ClientDate") === refdatesDF.col("dateyymmdd"), "left_outer")
        .join(refclientDF,tref.col("clientid") === refclientDF.col("ref_ClientID"),"left_outer")
        .withColumn("ClientWeekText",
          when(array_contains(col("ref_ClientSet"), "WKSUNSAT"),refdatesDF.col("WeekBTextMed"))
            .otherwise(col("WeekTextMed")))
        .withColumn("ClientWeekYYMMDD",
          when(array_contains($"ref_ClientSet", "WKSUNSAT"),col("WeekBYYMMDD"))
            .otherwise(col("WeekYYMMDD")))
        .withColumn("ClientDateShort", col("DateTextShort"))
        .drop("CDate")
        .drop("SCDate")
        .drop("DateX")
        .drop("CDate")
        .drop("SCDate")
        .drop("ClientSet")
        .drop("DateX")
        .drop("WeekBTextMed")
        .drop("WeekTextMed")
        .drop("WeekBYYMMDD")
        .drop("WeekYYMMDD")
        .drop("DateTextShort")
        .drop("ref_ClientID")
        .drop("ref_clientset")
        .drop("dateyymmdd")
      withClientDatesDF.show()

      //Not working for below, gives Cartesian Product error
      val withSubclientDatesDF = withClientDatesDF
        .join(refdatesDF, withClientDatesDF.col("SubClientDate") === refdatesDF.col("dateyymmdd"), "left_outer")
        .withColumn("SubClientWeekText",col("WeekTextMed"))
        .withColumn("SubClientWeekYYMMDD",col ("WeekYYMMDD"))
        .withColumn("SubClientDateShort",col ("DateTextShort"))

      withSubclientDatesDF.show()

    }

   /* //Success
    test("dverulehitsBandAndDescPositive") {

      val session = SparkSession.builder()
        .config("spark.sql.caseSensitive", "false")
        .config("spark.default.parallelism", "1")
        .config("spark.sql.shuffle.partitions", "1")
        .appName("test")
        .master("local[*]")
        .getOrCreate()

      val parser = new Schema.Parser
      val schema: Schema = parser.parse(ReDShieldTransaction.SCHEMA$.toString)
      val structure: StructType = SchemaConverters.toSqlType(schema).dataType.asInstanceOf[StructType]

      import session.implicits._

      val dvef = Seq(("XXXXXXYYYYYYZZZ20180815141740564", "1"))
        .toDF("oid", "dverulehits")
        .withColumn("dverulehitsband",updateRuleHitsBandAndDesc(col("dverulehits"),lit("dverulehitsband")))
        .withColumn("dverulehitsbanddesc",updateRuleHitsBandAndDesc(col("dverulehits"),lit("dverulehitsbanddesc")))

      dvef.show()

    }

    //Success
    test("dverulehitsBandAndDescNegative") {

      val session = SparkSession.builder()
        .config("spark.sql.caseSensitive", "false")
        .config("spark.default.parallelism", "1")
        .config("spark.sql.shuffle.partitions", "1")
        .appName("test")
        .master("local[*]")
        .getOrCreate()

      val parser = new Schema.Parser
      val schema: Schema = parser.parse(ReDShieldTransaction.SCHEMA$.toString)
      val structure: StructType = SchemaConverters.toSqlType(schema).dataType.asInstanceOf[StructType]

      import session.implicits._

      val dvef = Seq(("XXXXXXYYYYYYZZZ20180815141740564", "-101"))
        .toDF("oid", "dverulehits")
        .withColumn("dverulehitsband",updateRuleHitsBandAndDesc(col("dverulehits"),lit("dverulehitsband")))
        .withColumn("dverulehitsbanddesc",updateRuleHitsBandAndDesc(col("dverulehits"),lit("dverulehitsbanddesc")))

      dvef.show()

    }

    //Success
    def updateRuleHitsBandAndDesc = udf((ruleBandValuep:String,ruleBand:String)=>{
      var bandvalue: Int = 0
      if (ruleBandValuep != null && !ruleBandValuep.equalsIgnoreCase("null") && !ruleBandValuep.isEmpty) {
        bandvalue = ruleBandValuep.toInt
      }

      ruleBand match {

        case "dverulehitsband" =>
          bandvalue match {
            case dveruleBand101 if dveruleBand101 >= 101 => "RH9999"
            case dveruleBand51  if dveruleBand51 >= 51  => "RH0051"
            case dveruleBand21  if dveruleBand21 >= 21  => "RH0021"
            case dveruleBand11  if dveruleBand11 >= 11  => "RH0011"
            case dveruleBand06  if dveruleBand06 >= 6  => "RH0006"
            case dveruleBand05  if dveruleBand05 == 5  => "RH0005"
            case dveruleBand04  if dveruleBand04 == 4  => "RH0004"
            case dveruleBand03  if dveruleBand03 == 3  => "RH0003"
            case dveruleBand02  if dveruleBand02 == 2   => "RH0002"
            case dveruleBand01  if dveruleBand01 == 1   => "RH0001"
            case _ => "RH0000"
          }

        //Added for MERf-9138 - DVE Rule Hits --> Rule hits Band and Band Description
        case "dverulehitsbanddesc" =>
          bandvalue match {
            case dveruleDesc101 if dveruleDesc101 >= 101	=> "More than 100"
            case dveruleDesc51  if dveruleDesc51 >= 51	=> "51-100"
            case dveruleDesc21  if dveruleDesc21 >= 21	=> "21-50"
            case dveruleDesc11  if dveruleDesc11 >= 11	=> "11-20"
            case dveruleDesc06  if dveruleDesc06 >= 6	=> "6-10"
            case dveruleDesc05  if dveruleDesc05 == 5	=> "5"
            case dveruleDesc04  if dveruleDesc04 == 4	=> "4"
            case dveruleDesc03  if dveruleDesc03 == 3	=> "3"
            case dveruleDesc02  if dveruleDesc02 == 2	=> "2"
            case dveruleDesc01  if dveruleDesc01 == 1	=> "1"
            case _ => "0"
          }

      }


    })*/

  /*  test("outcomerec") {

      val session = SparkSession.builder()
        .config("spark.sql.caseSensitive", "false")
        .config("spark.default.parallelism", "1")
        .config("spark.sql.shuffle.partitions", "1")
        .appName("test")
        .master("local[*]")
        .getOrCreate()

      val parser = new Schema.Parser
      val schema: Schema = parser.parse(ReDShieldTransaction.SCHEMA$.toString)
      val structure: StructType = SchemaConverters.toSqlType(schema).dataType.asInstanceOf[StructType]

      import session.implicits._

      val TMDF = Seq(("000050000001TAH20181124073716856", "Deny", "05", "000040", "9ABC01", "0150"),
        ("000050000001TAP20181124073716856", "Accept", "00", "000040", "BBBC01", "0150"),
        ("000050000001TAL20181124073716856", "Challenge", "05", "000040", "t_BBBC", "1300"),
        ("000050000001TAM20181124073716856", "Accept", "00", "000040", "BBBC01", "2100"),
        ("000050000001TAZ20181124073716856", "Accept", "05", "000041", "9ABC01", "2000"))
        .toDF("oid", "recommend", "authresp", "clientid", "ruleId", "report")

      TMDF.show()

      val refClientDF = Seq(("000050000001TAH20181124073716856", "000040"),
        ("000050000001TAP20181124073716856", "000042"),
        ("000050000001TAL20181124073716856", "000039"),
        ("000050000001TAM20181124073716856", "000041"))
        .toDF("refClientDF_oid","clientid")
        .withColumn("clientset", array(lit("CREDECLINE"), lit("DUMMY"), lit("ABC")))

      refClientDF.show()

      val TMREFCLIENTDF = TMDF.join(refClientDF, TMDF.col("clientid").cast("string").isin(refClientDF.col("clientid").cast("string")), "inner" )

      TMREFCLIENTDF.show()

      val ruleHitsDF = Seq(("000050000001TAH20181124073716856", "9ABC01"),
        ("000050000001TAP20181124073716856", "BBBC01"),
        ("000050000001TAL20181124073716856", "t_BBBC"),
        ("000050000001TAW20181124073716856", "9ABC01"))
        .toDF("oid", "ruleId")

      ruleHitsDF.show()

      val transRuleHitsDF1 = ruleHitsDF.select($"oid").where($"ruleid" like "9%").distinct()
          .withColumnRenamed("oid","transRuleHitsDF1_oid")
      transRuleHitsDF1.show()

      val transRuleHitsDF2 = ruleHitsDF.select($"oid").where($"ruleid" like "B%").distinct()
        .withColumnRenamed("oid","transRuleHitsDF2_oid")
      transRuleHitsDF2.show()

      val transRuleHitsDF3 = ruleHitsDF.select($"oid").where($"ruleid" like "t_%").distinct()
        .withColumnRenamed("oid","transRuleHitsDF3_oid")
      transRuleHitsDF3.show()

      TMREFCLIENTDF
        .join(transRuleHitsDF1, TMREFCLIENTDF.col("oid") === transRuleHitsDF1.col("transRuleHitsDF1_oid"), "left_outer" )
        .join(transRuleHitsDF2, TMREFCLIENTDF.col("oid") === transRuleHitsDF2.col("transRuleHitsDF2_oid"), "left_outer" )
        .join(transRuleHitsDF3, TMREFCLIENTDF.col("oid") === transRuleHitsDF3.col("transRuleHitsDF3_oid"), "left_outer" )


      TMREFCLIENTDF.show()

      val outcomerecDF = TMREFCLIENTDF
        .withColumn("outcomerec",
          when(col("recommend") === "Deny" and coalesce($"authresp", lit("00")) === "05" and array_contains($"ClientSet", "CREDECLINE"), "Decline")
            otherwise (when(col("recommend") === "Accept" and col("report") === "0150" and array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))
  //          otherwise (when(TMREFCLIENTDF.col("oid").isin(transRuleHitsDF1.col("transRuleHitsDF1_oid")), col("recommend"))
            //otherwise (when(TMREFCLIENTDF.col("oid").isin(transRuleHitsDF2.col("transRuleHitsDF2_oid")), col("recommend"))
            otherwise(when(col("report") isin("1300", "2000") and array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))
            //otherwise(when(TMREFCLIENTDF.col("oid").isin(transRuleHitsDF3.col("transRuleHitsDF3_oid")), col("recommend"))
            otherwise(when(col("recommend") === "Deny" and col("report") === "0250" and array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))
            otherwise(when(col("recommend") isin("Challenge", "Deny") and array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))
            otherwise(when(col("recommend") === "Accept" and array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))
            otherwise(when(array_contains($"ClientSet", "CREDECLINE" ), col("recommend") )
            otherwise(when(!array_contains($"ClientSet", "CREDECLINE" ), col("recommend"))

            ))))))))

            outcomerecDF.show()

      val outcomereasonDF = outcomerecDF
        .withColumn("outcomereason",
          when(col("recommend") === "Deny" and coalesce($"authresp", lit("00")) === "05" and array_contains($"ClientSet", "CREDECLINE"), "Auth Decline")
            otherwise (when(col("recommend") === "Accept" and col("report") === "0150" and array_contains($"ClientSet", "CREDECLINE" ),"Always")
            //otherwise (when(outcomerecDF.col("oid").isin(transRuleHitsDF1.col("transRuleHitsDF1_oid")), "Click/Block")
            //otherwise (when(outcomerecDF.col("oid").isin(transRuleHitsDF2.col("transRuleHitsDF2_oid")), "ReD Manual"))
            otherwise(when(col("report") isin("1300", "2000") and array_contains($"ClientSet", "CREDECLINE" ), "SDS")
            //otherwise(when(outcomerecDF.col("oid").isin(transRuleHitsDF3.col("transRuleHitsDF3_oid")), "TSW")
            otherwise(when(col("recommend") === "Deny" and col("report") === "0250" and array_contains($"ClientSet", "CREDECLINE" ), "Always")
            otherwise(when(col("recommend") isin("Challenge", "Deny") and array_contains($"ClientSet", "CREDECLINE" ), "Rule")
            otherwise(when(col("recommend") === "Accept" and array_contains($"ClientSet", "CREDECLINE" ), "NoRule")
            otherwise(when(array_contains($"ClientSet", "CREDECLINE" ), col("recommend") )
            //otherwise( when(    !(array_contains($"ClientSet", "CREDECLINE" )), returnValueForKey( col("report"), lit("outcomereason")) )
            otherwise(returnValueForKey( col("report"), lit("outcomereason"))

            ))))))))

            outcomereasonDF.show()

    }

    def returnValueForKey = udf((matchString:String, keyString:String)=>{

      if (keyString != null && !keyString.isEmpty) {

        keyString match {

          //Added for MERf-9138 - DVE Rule Hits --> Rule hits Band and Band Description
          case "outcomereason" =>
            matchString match {
              case report0000 if matchString == "0000" => "NoRule"
              case report0100 if matchString == "0100" => "NoRule"
              case report0150 if matchString == "0150" => "Always"
              case report0200 if matchString == "0200" => "Auth Decline"
              case report0250 if matchString == "0250" => "Always"
              case report0330 if matchString == "0330" => "Rule"
              case report0700 if matchString == "0700" => "Rule"
              case report0800 if matchString == "0800" => "TSW"
              case report1300 if matchString == "1300" => "SDS"
              case report2000 if matchString == "2000" => "SDS"
              case _ => ""
            }

        }

      }
    })*/
  */


}
