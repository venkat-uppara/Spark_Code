/*
package com.aciworldwide.ra.redi.transflowtest.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.rstransflow.controllers.TransDetailController
import com.aciworldwide.ra.redi.transflowtest.services.ReDiTransflowTestSpec
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

case class FormatDescTfn (CardType : String,
                          PayMethod : String,
                          TranType : String,
                          AuthResp : String,
                          AVSResponse : String,
                          Carrier : String,
                          CINPresent : String,
                          CINResponse : String,
                          TranCategory : String )

class DescriptionTransTestClass extends FlatSpec  with BaseController with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTransflowTestSpec with ReDiConstants {

  val sparkSession: SparkSession = createSparkSession(TRANSDETAILTESTAPP)
  private val FormatDescTfnArr = Array(
    FormatDescTfn("A", "O", "P", "08", "X", "F", "1", "M", "P" ),
    FormatDescTfn("Z", "Z", "Z", "99", "B", "Z", "5", "Z", "Z" ),
    FormatDescTfn(null, null, null, null, null, null, null, null, null)
  )

  val RSTransFlowController= new TransDetailController(sparkSession)

  import sparkSession.implicits._

  var res :DataFrame =_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    val dfCC  = _sqlc.sparkContext.parallelize(FormatDescTfnArr).toDF()//.as[FormatCCTxfn]
    dfCC.collect().foreach(println)

    res = RSTransFlowController.addDescTransformation(dfCC)
  }

  "Test for validating CrdTypeDesc for CardType A. This" should  "Display the CrdTypeDesc " in {
    val col1 = res.select("CardTypeDesc").where(res("CardType") === "A")
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === "Amex"
  }

  "Test for validating CrdTypeDesc for CardType Z. This" should  "Display the CrdTypeDesc " in {
    val col1 = res.select("CardTypeDesc").where(res("CardType") === "Z")
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === "Unknown CardType Z"
  }

  "Test for validating CrdTypeDesc for CardType null. This" should  "Display the CrdTypeDesc " in {
    val col1 = res.select("CardTypeDesc").where(res("CardType") === null)
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === ""
  }

  "Test for validating PayMethodDesc for PayMethod A. This" should  "Display the PayMethodDesc " in {
    val col1 = res.select("PayMethodDesc").where(res("PayMethod") === "O")
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === "Card Not Present - Online"
  }

  "Test for validating PayMethodDesc for PayMethod Z. This" should  "Display the PayMethodDesc " in {
    val col1 = res.select("PayMethodDesc").where(res("PayMethod") === "Z")
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === "Unknown PayMethod Z"
  }

  "Test for validating PayMethodDesc for PayMethod null. This" should  "Display the PayMethodDesc " in {
    val col1 = res.select("PayMethodDesc").where(res("PayMethod") === null)
    val dd = col1.collect().map(col => col.getString(0)).mkString(" ")
    dd should be === ""
  }
}
*/
