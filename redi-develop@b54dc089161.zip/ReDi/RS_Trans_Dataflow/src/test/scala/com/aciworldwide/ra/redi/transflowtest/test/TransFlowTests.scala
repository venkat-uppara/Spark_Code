//package com.aciworldwide.ra.redi.transflowtest.test
//
//import com.aciworldwide.ra.redi.common.dao.CurrencyDataDao
//import com.aciworldwide.ra.redi.common.schemas.CurrencyResponseSchema
//import com.aciworldwide.ra.redi.rstransflow.controllers.RSTransFlowController
//import com.aciworldwide.ra.redi.rstransflow.dao.RSTransFlowDao
//import org.scalatest.{BeforeAndAfter, FlatSpec, GivenWhenThen, Matchers}
//import org.scalatest.concurrent.Eventually
//import com.aciworldwide.ra.redi.rstransflow.utils.CommonUtils
//import com.aciworldwide.ra.redi.transflowtest.services.ReDiTransflowTestSpec
//import com.typesafe.config.ConfigFactory
//import org.apache.spark.sql.catalyst.expressions.GreaterThanOrEqual
//import org.apache.spark.sql.sources.GreaterThan
//import org.apache.spark.sql.streaming.OutputMode
//import org.apache.spark.sql.{DataFrame, Dataset, sources}
//
//class TransFlowTests extends FlatSpec with CommonUtils with Matchers with Eventually
//  with BeforeAndAfter with ReDiTransflowTestSpec{
//
//  private val currencyrateresponse = Array(
//    CurrencyResponseSchema("1.000000000000","1-01-01 00:00:00","9999-12-31 23:59:59","BMD","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1.000000000000","1-01-01 00:00:00","9999-12-31 23:59:59","CUC","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1.000000000000","1-01-01 00:00:00","9999-12-31 23:59:59","USD","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("3.673181000000","2018-07-13 14:08:45","9999-12-31 23:59:59","AED","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("72.249990000000","2018-07-13 14:08:45","9999-12-31 23:59:59","AFN","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1.789003000000","2018-07-13 14:08:45","9999-12-31 23:59:59","AWG","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1785.500000000000","2018-07-13 14:08:45","9999-12-31 23:59:59","BIF","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1.352300000000","2018-07-13 14:08:45","9999-12-31 23:59:59","BND","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("1616.000000000000","2018-07-13 14:08:45","9999-12-31 23:59:59","CDF","2018-07-15 15:19:26.743"),
//    CurrencyResponseSchema("178.000000000000","2018-07-13 14:08:45","9999-12-31 23:59:59","DJF","2018-07-15 15:19:26.743")
//
//
//  )
//
//  private var rsTransflowControl: RSTransFlowController = _
//  private var currencyDataDao: CurrencyDataDao = _
//  private var currrates: Dataset[CurrencyResponseSchema] = _
//  private var rsTransFlowDao: RSTransFlowDao = _
//
//  override def beforeAll(): Unit = {
//    super.beforeAll()
//    val _sqlc = sc
//    import _sqlc.implicits._
//
//    rsTransflowControl = new RSTransFlowController()
//    currencyDataDao = new CurrencyDataDao(_sqlc)
//    rsTransFlowDao = new RSTransFlowDao(_sqlc)
//
//    currrates = _sqlc.sparkContext.parallelize(currencyrateresponse).toDF().as[CurrencyResponseSchema]
//    currrates.collect().foreach(println)
//
//
//  }
//
//  def WriteTransactionData(map: Map[String, DataFrame]) = {
//    val frame = map("detail")
//    val df= frame.writeStream
//      .queryName("transflowStreamOutput")
//      .format("memory")
//      .outputMode("append")
//      .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.kafka.transactiontopictestCheckpointlocation"))
//      .start().processAllAvailable()
//
//
//
//  }
//
//  "This test is used to test the currency conversion." should "be" in {
//    var conversionAmount: Double = 0.0
//    conversionAmount = convertCurrency(sc,rsTransflowControl.getCurrencyRates(),"AED","CDF",10)
//    conversionAmount shouldBe 4399.651730538755
//  }
//
//
//
//  "This test is used to test the streaming data if the result is empty." should "be" in {
//    WriteTransactionData(rsTransflowControl.transformTransactionData(
//      rsTransFlowDao.readTransactionsFromKafka()))
//    val result = sc.sql("Select * from transflowStreamOutput").collectAsList()
//    result.isEmpty shouldBe(false)
//  }
//
//  "This test is used to test the streaming data  size." should "be" in {
//    WriteTransactionData(rsTransflowControl.transformTransactionData(
//      rsTransFlowDao.readTransactionsFromKafka()))
//    val result = sc.sql("Select * from transflowStreamOutput")
//    result.take(1) shouldBe 1
//
//  }
//
//}
