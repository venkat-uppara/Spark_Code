package com.aciworldwide.ra.redi.rstransflow.controllers

import java.sql.Timestamp
import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.{to_timestamp, udf}
import org.scalatest.{BeforeAndAfterEach, FunSuite}

class TransCoreControllerTest extends FunSuite with BeforeAndAfterEach with ReDiConstants {
  val session = SparkSession.builder().appName("test").master("local[*]").getOrCreate()

  override def beforeEach() {
  }

  def oIdDateWithoutTimePart = udf((oidDate: Timestamp) => {
    val inputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
    val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
    val date = outputFormat.format(oidDate)
    date
  })

  test("oIdDateWithoutTimePart") {
    import session.sqlContext.implicits._

    Seq(("20181022133715"))
      .toDF("oiddate")
      .withColumn("newoiddate", to_timestamp($"oiddate", "yyyyMMddHHmmss"))
      .withColumn("finaloiddate", oIdDateWithoutTimePart($"newoiddate"))
      .show()

    //println(oIdDateWithoutTimePart("20181022133715"))
    //assert(oIdDateWithoutTimePart("20181022133715") == ("20181019"))
  }

}
