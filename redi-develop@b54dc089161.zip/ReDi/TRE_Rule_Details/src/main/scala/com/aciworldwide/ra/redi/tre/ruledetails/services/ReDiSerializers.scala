package com.aciworldwide.ra.redi.tre.ruledetails.services


//import com.aciworldwide.ra.kafka.serialization
import org.apache.avro.io.Decoder
import org.apache.avro.io.DecoderFactory
import org.apache.avro.specific.SpecificDatumReader
import java.io._

import com.aciworldwide.ra.model.RuleDescription
import org.apache.avro.hadoop.io.AvroDeserializer

/**
  * @author : Mayank M 08.08.2018
  * This method is used to deserialize data(which comes as Byte Array from the topic).
  * First bytes will be converted into values and values will be mapped to the respective columns
  * Mapping requires schema which can get retrieved from class created using .avsc file provided

  */

trait ReDiSerializers {

  /*def deserialize(topic: String, bytes: Array[Byte]): String = {
    val des = new AvroDeserializer[RuleDescription](classOf[RuleDescription])
    val transaction = des.deserialize(topic, bytes)
    return transaction.toString
  }
*/
  /**
    * @author : Mayank M 08.08.2018
    * This method is used to deserialize data(which comes as Byte Array from the topic).
    * First bytes will be converted into values and values will be mapped to the respective columns
    * Mapping requires schema which can get retrieved from class created using .avsc file provided
    * Takes Array of Bytes as input parameters
    */
  private def deserialize(bytes: Array[Byte]) = {

    val trans = new RuleDescription

    val datumReader: SpecificDatumReader[RuleDescription] =
      new SpecificDatumReader[RuleDescription](trans.getSchema)
    val decoder: Decoder = DecoderFactory.get.binaryDecoder(bytes, null)

    var result: RuleDescription = null

    try {
      result = datumReader.read(null, decoder)
    } catch {
      case e: IOException => e.printStackTrace()
    }
    result.toString
  }

}
