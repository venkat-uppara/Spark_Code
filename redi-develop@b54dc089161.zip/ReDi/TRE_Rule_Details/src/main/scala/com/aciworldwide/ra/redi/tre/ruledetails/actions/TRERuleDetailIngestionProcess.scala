package com.aciworldwide.ra.redi.tre.ruledetails.actions

import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.tre.ruledetails.controllers.TRERuleDetailIngestionController
import org.apache.logging.log4j.LogManager
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.tre.ruledetails.actions.TRERuleDetailTransformationAction.{RSTRANSFLOWTRANSAPP, createSparkSession}
import org.apache.spark.sql.SparkSession

object TRERuleDetailIngestionProcess extends BaseController with Loggers with Serializable with ReDiConstants {
  /**
    * Single process which invokes the process that addresses the Tre Rule Details
    */
  @transient lazy val TRERuleDetailIngestionDatalogger = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    TRERuleDetailIngestionDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":Start of ingestion and tranformation of Tre Rule details  flow from  TRE Kafka")
    try {
      val spark: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
      val TREDetails_transformation = new TRERuleDetailIngestionController(spark)
      TREDetails_transformation.TreRuleDetailPipeline()
    } catch {
      case e: Exception => TRERuleDetailIngestionDatalogger.error(TRERuleDetailIngestionProcess_ERROR + ":We have an error in the Tre Rule details  flow from  TRE Kafka " + e.printStackTrace())
    } finally {
      TRERuleDetailIngestionDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":Ingestion of Tre Rule details  flow from  TRE Kafka Is completed ")
    }
  }
}