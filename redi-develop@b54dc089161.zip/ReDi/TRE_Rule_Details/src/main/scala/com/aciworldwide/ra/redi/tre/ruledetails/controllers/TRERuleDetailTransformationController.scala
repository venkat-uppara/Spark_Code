package com.aciworldwide.ra.redi.tre.ruledetails.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.control.Breaks._
import org.apache.logging.log4j.LogManager
import com.aciworldwide.ra.redi.common.utils
import com.aciworldwide.ra.redi.common.utils.CommonUtils

class TRERuleDetailTransformationController(spark : SparkSession) extends  ReDiConstants with Loggers
  with ReDiTableSchemas with DatabaseServices with CommonUtils {

  @transient lazy val treRuleDetailsTranformationDatalogger = LogManager.getLogger(getClass.getName)

  import spark.implicits._

  // To be moved to Common.DateUtils
  def convertDateFormat(inputdate: String, inputDateFormat: String, targetDateFormat: String): String = {
    val simpleformat = new SimpleDateFormat(inputDateFormat)
    val targetformat = new SimpleDateFormat(targetDateFormat)
    String.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }

  // To be moved to Common.CommonUtils
  /*def addtransflowAuditColumns(inputdataFrame: DataFrame): DataFrame = {
    val outputDataFrame = inputdataFrame
      //.withColumn(WHENLOADED, current_timestamp())
      .withColumn(WHOLOADED, lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn(WHENUPDATED, current_timestamp())
      .withColumn(WHOUPDATED, lit(WHO_LOADED_UPDATED_INSERT))
    outputDataFrame
  }*/

  def convertToDateFormatYYYYMMDD: UserDefinedFunction = udf((inputDate: String) => {
    convertDateFormat(inputDate, DATEFORMATTREACTIONDATE, DATEFORMATYYYYMMDDHHMMSS)
  })

  def convertRecommendCase: UserDefinedFunction = udf((recommend: String) => {
    val recomm = recommend.toLowerCase().split(' ').map(_.capitalize).mkString(" ")
    recomm
  })

  /** **************STORING DATA TO HIVE **********************************/
  /*def storeInputTransMastertoHive(finalCoreDF: DataFrame): Unit = {
    /*logRegularMessage("Add audit columns to result data frame and reorder.")*/
    logRegularMessage("Starting to push the data into Hive table " + TRE_RULE_DETAILS_TABLE)
    StorethedataintoHive(TRE_RULE_DETAILS_TABLE, APPEND_MODE, finalCoreDF)
    logRegularMessage("Number of rows inserted in Transaction Master: " + finalCoreDF.count)
  }*/

  def performTransformTRERuleDetailData( ingDataFrame : DataFrame): DataFrame = {

    treRuleDetailsTranformationDatalogger.debug(TRERuleDetailTransformationAction_DEBUG + ":Started Rule Details tranformation")
    /*    var nextRunWithoutError = true
        while (nextRunWithoutError) {
          logRegularMessage("Start processing next batch.")
          val EndTimeFrom: DataFrame = spark.sql("select max(Whenloaded) from " + ConfigFactory.load().getString("local.common.tre_rule_details.ruleorcfileloc"))

          val EndTime = EndTimeFrom.first()(0)

          val StartTime = spark.sql("select max(lastUsedTime) from " + REDI_CONTROL_TRE_FOR_EXTERNAL_TABLE).first()(0)

          logRegularMessage("From time: " + StartTime + " to time: " + EndTime)
          breakable {
            if (StartTime == EndTime) {
              logRegularMessage("No data to be fetched")
              break()
            }


            val inputDF: DataFrame = spark.sql(s"select * from " + ConfigFactory.load().getString("local.common.tre_rule_details.ruleorcfileloc") + s" where whenloaded > '$StartTime' and whenloaded <= '$EndTime'").cache()
            //
            logRegularMessage("Number of input rows coming: " + inputDF.count)*/

    val treDF = ingDataFrame.select($"ruleId", $"ruleName", $"description", $"recommend", $"actionDate", $"remarks", $"rcf", $"whenloaded",
      $"isActive", $"actionType", $"version", explode_outer($"clientinfo").as("ClientInformation"), $"version".cast("integer").alias("updatecount"))
      .select($"ruleId", $"ruleName", $"description", $"recommend", date_format($"actionDate", DATEFORMATTREACTIONDATE).alias("actionDate")/*to_timestamp($"actionDate", DATEFORMATTREACTIONDATE).alias("actionDate")*/, $"remarks",
        $"ClientInformation.clientId".alias("clientId"), $"ClientInformation.subclientId".alias("subClientId"),
        $"rcf", $"isActive".cast("String").alias("active"), $"actionType", $"updatecount",$"whenloaded")
      .withColumn("descriptionredi", lit($"description"))
      .withColumn("recommendredi", convertRecommendCase(col("recommend")))
      //.withColumn("updatecount", col("version"))
      .withColumn("ruleactionDateYYYYMMDD", convertToDateFormatYYYYMMDD($"actionDate"))
      .withColumn("client12", concat($"clientid", $"subclientid"))
      .withColumn("ruleSource", lit("TRE"))
      .withColumn("rulegroup", when(col("ruleSource") === "TRE", "TR")
        .when(col("description") like "click and block%", "CB")
        .when(col("description") like "manually created by red%", "MA")
        .when(col("description") like "automated block%", "AB")
        .when((col("description") like "%prodcd%") or (col("description") like "%proddesc%") or (col("description") like "%manpartno%") or (col("description") like "%prodsku%"), "PR")
        .when((col("description") like "%country%") or (col("description") like "%cntry%") or (col("description") like "%continent%"), "CO")
        .when(col("description") like "%state%", "ST")
        .when(col("description") like "%city%", "CI")
        .when(col("description") like "%zip%", "ZI")
        .when(col("description") like "%avs%", "AV")
        .when((col("description") like "%custid%") or (col("description") like "%custemail%") or (col("description") like "%custip%") or (col("description") like "%custhomephone%"), "CU")
        .when(col("description") like "%cardno%", "CD")
        .when((col("description") like "%address%") or (col("description") like "%street%"), "AD")
        .when((col("description") like "%custfirstname%") or (col("description") like "%custlastname%") or (col("description") like "%custsurname%"), "CN")
        .when(col("description") like "%domain%", "DM")
        .otherwise(lit("XX"))
      )
      .withColumn("RuleGroupShort", when(col("ruleSource") === "TRE", "TitaniumRule")
        .when(col("description") like "click and block%", "Click/Block")
        .when(col("description") like "manually created by red%", "Manual (ReD)")
        .when(col("description") like "automated block%", "Auto Block")
        .when((col("description") like "%prodcd%") or (col("description") like "%proddesc%") or (col("description") like "%manpartno%") or (col("description") like "%prodsku%"), "Other Products")
        .when((col("description") like "%country%") or (col("description") like "%cntry%") or (col("description") like "%continent%"), "Country")
        .when(col("description") like "%state%", "State")
        .when(col("description") like "%city%", "City")
        .when(col("description") like "%zip%", "Zip Code")
        .when(col("description") like "%avs%", "AVS")
        .when((col("description") like "%custid%") or (col("description") like "%custemail%") or (col("description") like "%custip%") or (col("description") like "%custhomephone%"), "Customer")
        .when(col("description") like "%cardno%", "Card No")
        .when((col("description") like "%address%") or (col("description") like "%street%"), "Address")
        .when((col("description") like "%custfirstname%") or (col("description") like "%custlastname%") or (col("description") like "%custsurname%"), "Cust Name")
        .when(col("description") like "%domain%", "Domain")
        .otherwise(lit("Other"))
      )
      .withColumn("rulegrouptext", when(col("ruleSource") === "TRE", "Titanium Rules")
        .when(col("description") like "click and block%", "Click AND Block")
        .when(col("description") like "manually created by red%", "Manually Created by ReD")
        .when(col("description") like "automated block%", "Automated Block")
        .when((col("description") like "%prodcd%") or (col("description") like "%proddesc%") or (col("description") like "%manpartno%") or (col("description") like "%prodsku%"), "Other Products")
        .when((col("description") like "%country%") or (col("description") like "%cntry%") or (col("description") like "%continent%"), "Country related")
        .when(col("description") like "%state%", "State related")
        .when(col("description") like "%city%", "City related")
        .when(col("description") like "%zip%", "Zip Code related")
        .when(col("description") like "%avs%", "AVS related")
        .when((col("description") like "%custid%") or (col("description") like "%custemail%") or (col("description") like "%custip%") or (col("description") like "%custhomephone%"), "Customer Specific")
        .when(col("description") like "%cardno%", "Card Specific")
        .when((col("description") like "%address%") or (col("description") like "%street%"), "Address/Street")
        .when((col("description") like "%custfirstname%") or (col("description") like "%custlastname%") or (col("description") like "%custsurname%"), "Customer Name Related")
        .when(col("description") like "%domain%", "Domain Related")
        .otherwise(lit("Other"))
      )
      .withColumn("RuleGroupOrder", lit(""))
      .withColumn("RuleCases", lit(""))
      .withColumn("RecommendSort", lit("").cast("integer").alias("RecommendSort"))
      .withColumn("FraudYN", lit(""))
      .withColumn("CompoundStart", lit(""))
      .withColumn("CompoundEnd", lit(""))

    val ruleDtls = reorderSourceTableSchema(TRE_DETAILS_COL_ORDER, addAuditColumns(treDF))
    val ruleDtls1 = ruleDtls.withColumn("WHENLOADED",date_format(col(WHENLOADED),"yyyy-MM-dd HH:mm:ss")).withColumn(WHENUPDATED,date_format(col(WHENUPDATED),"yyyy-MM-dd HH:mm:ss"))

    /*storeInputTransMastertoHive(reorderSourceTableSchema(TRE_DETAILS_COL_ORDER, addtransflowAuditColumns(treDF)))

    nextRunWithoutError = true
    logRegularMessage("Absolute flag is :" + nextRunWithoutError)

    EndTimeFrom.write
      .insertInto(REDI_CONTROL_TRE_FOR_EXTERNAL_TABLE)
*/
    treRuleDetailsTranformationDatalogger.debug(TRERuleDetailTransformationAction_DEBUG + ":Last time used is being inserted")

    treRuleDetailsTranformationDatalogger.debug(TRERuleDetailTransformationAction_DEBUG + ":Completed TRE Rule Details Transformations")

    ruleDtls1

  }
}
