package com.aciworldwide.ra.redi.tre.ruledetails.dao

import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import org.apache.spark.sql.{DataFrame, SparkSession}

class DveTswIngestionAndTransDao(sc: SparkSession) extends DateUtils with Loggers with DatabaseServices {

  /**
    * setupConnections is used to instantiate the SetupConnections
    * This will be used across the methods for creating connections with the databases, so declaring this globally */

    
  val setupConnections = new SetupConnections


  def fetchDveTswRuleDetailsDataFromODS(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to fetch new/updated data for RULE_DETAILS process from Oracle. " + schemaname + "." + tablename)
    val dveTswData = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Fetched new/updated data for RULE_DETAILS  Data. " + schemaname + "." + tablename)
    dveTswData
  }

}
