package com.aciworldwide.ra.redi.tre.ruledetails.actions

import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.tre.ruledetails.controllers.DveTswIngestionAndTransController

object DveTswIngestionAndTransAction extends  DveTswIngestionAndTransController with Loggers with Serializable
{
  def main(args: Array[String]): Unit = {
    try{
      processDveTswForRuleDetails()
    } catch {
      case e: Exception => logRegularMessage("We have an error in the Incremental DVE TDW Rule Details")
        e.printStackTrace()
    }
    finally {
      logRegularMessage("End of Incremental Load for For Rule Details")
    }
  }
}
