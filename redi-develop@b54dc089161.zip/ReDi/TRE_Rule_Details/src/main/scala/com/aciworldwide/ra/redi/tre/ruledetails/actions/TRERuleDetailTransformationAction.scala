package com.aciworldwide.ra.redi.tre.ruledetails.actions

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.tre.ruledetails.controllers.TRERuleDetailTransformationController
import org.apache.spark.sql.SparkSession

object TRERuleDetailTransformationAction extends BaseController with Loggers with ReDiConstants with Serializable {
  /**
    * Single process which invokes the process that addresses the Tre Rule Details
    */
  def main(args: Array[String]): Unit = {
    logRegularMessage("Start of ingestion of Tre Rule details  flow from  TRE Kafka")
    try {
      val spark: SparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
      val TREDetails_transformation = new TRERuleDetailTransformationController(spark)
      //TREDetails_transformation.performTransformTRERuleDetailData()
    } catch {
      case e: Exception => logRegularMessage("We have an error in the Tre Rule details  flow from  TRE Kafka " + e.printStackTrace())
    } finally {
      logRegularMessage("Ingestion of Tre Rule details  flow from  TRE Kafka Is completed ")
    }
  }
}



