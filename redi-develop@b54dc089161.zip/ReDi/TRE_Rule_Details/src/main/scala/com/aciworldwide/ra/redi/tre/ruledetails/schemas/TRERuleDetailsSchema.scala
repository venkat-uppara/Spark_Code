package com.aciworldwide.ra.redi.tre.ruledetails.schemas

import java.sql.Timestamp


case class ClientInfoSchema (clientId:String,subclientId:String)

case class TRERuleDetailsSchema (ruleid:String,
                                 rulename:String,
                                 description:String,
                                 recommend:String,
                                 actiondate:Timestamp,
                                 remarks:String,
                                 rcf:String,
                                 whenloaded:Timestamp,
                                 isActive:String,
                                 actiontype:String,
                                 version:Int,
                                 clientinfo:Array[ClientInfoSchema]
                                )