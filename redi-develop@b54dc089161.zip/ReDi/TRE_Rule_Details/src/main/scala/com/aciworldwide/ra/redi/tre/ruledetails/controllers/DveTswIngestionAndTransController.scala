package com.aciworldwide.ra.redi.tre.ruledetails.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.DatabaseServices
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.tre.ruledetails.dao.DveTswIngestionAndTransDao
import com.aciworldwide.ra.redi.tre.ruledetails.functions.Ingestion
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class DveTswIngestionAndTransController extends BaseController with ReDiConstants
  with ReDiTableSchemas with DatabaseServices with CommonUtils {
  @transient override lazy val logger = LogManager.getLogger(getClass.getName)

  val sparkSession: SparkSession = createSparkSession(DVETSWINGESTIONTRANSFORMATIONAPP)
  val dveTswDao = new DveTswIngestionAndTransDao(sparkSession)
  val hive = HiveWarehouseSession.session(sparkSession).build()
  hive.setDatabase(REDI_DATABASE)

  import sparkSession.implicits._


  def updateControlTables(ruledetailsDf: DataFrame, maxcolumn: String, processName: String,startTime:String): Unit = {
    /** Ingestion Process Step: 05
      * Reading the Dataframe for getting the MAXIMUM of HWM Column from the data Ingested from Oracle
      * This value is pushed into Hive Control Table.
      * Updating the Maximum HWM Column into Hive Control table and Marking the end of process */

    val endTimeCSIDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(ruledetailsDf, maxcolumn, processName,PROCESS_CONTROL_COMPLETED, startTime,  endTimeCSIDataLoad.toString, "Completed the  Fetch from ODS into HDFS",DVE_TSW_PROCESS)
  }

  /*def storeDataToHdfs(df: DataFrame): Unit = {
    logger.info("Starting to load data into HDFS location")
    saveDataintoHDFS(df, JDBC_TO_AVRO_FORMAT, ConfigFactory.load().getString("local.common.hdfs.DVE_TSW_RULE_DETAIL_DATA_HDFS"), HDFS_STORAGE_DATE_EXT)
    logger.info("Finished loading the data into HDFS location")
  }*/

  def processDveTswForRuleDetails(): Unit = {
    logger.info(DVETSWDataIngestionProcess_INFO + "Inside processDveTswForRuleDetails method")


    val dveHwm = getHWM(RULE_DETAILS_DVE_TSW_CONTROLKEY)
    val ruleDetailsData = getRuleDetails(dveHwm)
    val startTimeDVETSW = getCurrentdateTimeStamp
    startControlTableDataProcess(ruleDetailsData, REDI_DVE_TSW_RULE_DETAILS_HWM_COLUMN_FOR_CONTROL, RULE_DETAILS_DVE_TSW_CONTROLKEY, PROCESS_CONTROL_STARTED, startTimeDVETSW.toString, "", "Fetched records from DVE TSW   table",DVE_TSW_PROCESS)

    if (ruleDetailsData != null) {
      logger.info(DVETSWDataIngestionProcess_INFO+"Before Control Table Process : " + getCurrentdateTimeStamp)

      val ruleDetailsCount = ruleDetailsData.count()
      val ruleCols = getDveTswRuleDetailsSelectColumns(ruleDetailsData)
      startControlTableDataProcess(ruleCols, REDI_DVE_TSW_RULE_DETAILS_HWM_COLUMN_FOR_CONTROL, RULE_DETAILS_DVE_TSW_CONTROLKEY, PROCESS_CONTROL_INPROGRESS, startTimeDVETSW.toString, "", "Fetched records from DVE TSW   table",DVE_TSW_PROCESS)
      val dveTswDf = Ingestion.dveTswruleDetailsTransformations(sparkSession, ruleCols)
      val velDf = fetchVelocityLimitsHistory
      val allTransformationsForDveTswDf = ruleNameTransformation(dveTswDf, velDf)
      storeDataToHive(reorderSourceTableSchema(TRE_DETAILS_COL_ORDER, addAuditColumns(allTransformationsForDveTswDf)))

      if (ruleDetailsCount > 0) {
        updateControlTables(allTransformationsForDveTswDf, REDI_DVE_TSW_RULE_DETAILS_HWM_COLUMN_FOR_CONTROL, RULE_DETAILS_DVE_TSW_CONTROLKEY,startTimeDVETSW.toString)
      }
    }
    else {
      logger.info(DVETSWDataIngestionProcess_INFO + "No Records for DVE TSW Rule Details")
    }
    logger.info(DVETSWDataIngestionProcess_INFO + "Completed processDveTswForRuleDetails method")
  }

  def storeDataToHive(finalCoreDF: DataFrame): Unit = {
    logger.info(DVETSWDataIngestionProcess_INFO +"Starting to push the data into Hive table " + TRE_RULE_DETAILS_TABLE)
    finalCoreDF
      .write
      .format(HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR)
      .option("table", TRE_RULE_DETAILS_TABLE)
      .mode(SaveMode.Append)
      .save()
    logger.info(DVETSWDataIngestionProcess_INFO +"Number of rows inserted in Rules details for DVE and TSW: " + finalCoreDF.count)
  }

  def getHWM(controlKey: String): String = {
    logger.info(DVETSWDataIngestionProcess_INFO + "Started Getting highwater mark column")
    val hwmMaxDate = hive.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    logger.info(DVETSWDataIngestionProcess_INFO + "Completed Getting data from High Water Mark Column")
    hwmMaxDate
  }

  def getDveTswRuleDetailsSelectColumns(ruledetails: DataFrame): DataFrame = {
    var dveTswDf: DataFrame = null
    dveTswDf = ruledetails.select($"rule_id".as("ruleid"),
      $"description",
      $"rule_source".as("rulesource"),
      $"remarks",
      $"client_id".as("clientid"),
      $"sub_client_id".as("subclientid"),
      $"rcf",
      $"active",
      $"update_count".as("updatecount"),
      $"recommend",
      $"add_date",
      $"delete_date",
      $"update_date",
      $"addorupdatedate"
    )
    dveTswDf
  }

  def getRuleDetails(hwm: String): DataFrame = {
    var data: DataFrame = null
    if (hwm == null) {
      logger.error(DVETSWDataIngestionProcess_ERROR + "Error/There is no Hive Water Mark Column in Process Conrol Table for " + hwm)
      data
    }
    else {
      val startTimeDVERTSWDataLoad = getCurrentdateTimeStamp
      logger.info(DVETSWDataIngestionProcess_INFO + "Started Fetching records from ODS  RULE_DETAILS Table")
      val query = "(select * from  " + REDI_DVE_TSW_ODS_TABLE_NAME + " where  coalesce(" + REDI_DVE_TSW_RULE_DETAILS_HWM_COLUMN + ") > to_timestamp('" + hwm + "', 'YYYY-MM-DD HH24:MI:SS.FF')) RULE_DETAILS"
      data = fetchDevTswData(query, ORACLE_CONN_TYPE, MODSREP_DATABASE)
      data = data.withColumn("addorupdatedate", coalesce($"update_date", $"add_date"))
      logger.info( DVETSWDataIngestionProcess_INFO+ "Completed Fetching records from the ODS RULE_DETAILS Table")
      data
    }
  }

  def fetchDevTswData(tablename: String, connectiontype: String, schemaname: String): DataFrame = {
    logger.info(DVETSWDataIngestionProcess_INFO+ "Starting to Fetch RuleDetails data into the processing layer " + schemaname + "." + tablename)
    dveTswDao.fetchDveTswRuleDetailsDataFromODS(tablename, connectiontype, schemaname, RULE_DETAIL_DATA_CODE_PARTS)
  }

  def ruleNameTransformation(ruleDetails: DataFrame, velocityLimits: DataFrame): DataFrame = {
    logger.info(DVETSWDataIngestionProcess_INFO+ "Inside ruleNameTransformation method")
    ruleDetails.join(velocityLimits, Seq("ruleid"), "left_outer")
  }

  def fetchVelocityLimitsHistory: DataFrame = {
    logger.info(DVETSWDataIngestionProcess_INFO+ "Inside fetchVelocityLimitsHistory method")
    val velocityLimitHistory = hive
      .table(VELOCITY_LIMITS_HISTORY_VIEW)
      .select("ruleid", "rulename")
    velocityLimitHistory
  }
}
