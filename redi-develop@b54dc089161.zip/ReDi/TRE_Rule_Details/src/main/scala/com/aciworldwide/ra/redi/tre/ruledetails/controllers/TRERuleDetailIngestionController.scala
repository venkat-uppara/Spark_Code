package com.aciworldwide.ra.redi.tre.ruledetails.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.tre.ruledetails.dao.TRERuleDetailDataFlowDao
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._

//object information {
//  val schemaRegistryURL = ConfigFactory.load().getString("local.common.tre_rule_details.schemaRegistryURL")
//
//  val topicName = ConfigFactory.load().getString("local.common.tre_rule_details.treRuleDetailkafkatopic")
//  val subjectValueName = topicName + "-value"
//
//  //create RestService object
//  val restService = new RestService(schemaRegistryURL)
//
//  //gets latest version of type entities.Schema object.
//  val valueRestResponseSchema: entities.Schema = restService.getLatestVersion(subjectValueName)
//
//
//  //Use Avro parsing classes to get Avro Schema
//  val parser = new Schema.Parser
//  val topicValueAvroSchema: Schema = parser.parse(valueRestResponseSchema.getSchema)
//  val props = Map("schema.registry.url" -> information.schemaRegistryURL)
//  val structure: StructType = SchemaConverters.toSqlType(information.topicValueAvroSchema).dataType.asInstanceOf[StructType]
//
//  //Declare SerDe vars before using Spark structured streaming map. Avoids non serializable class exception.
//  var keyDeserializer: StringDeserializer = null
//  var valueDeserializer: KafkaAvroDeserializer = null
//
//  var ruleDtlTransfrm:TRERuleDetailTransformationController = _
//  var transformedRuleDetail:DataFrame = _
//
//
//
//  def deserValue(key: String, value: Array[Byte]): String = {
//    if (valueDeserializer == null) {
//      valueDeserializer = new KafkaAvroDeserializer
//      valueDeserializer.configure(props.asJava, false) //isKey = false
//    }
//    val deserializedValueJsonString = valueDeserializer.deserialize(information.topicName, value, information.topicValueAvroSchema).toString
//    deserializedValueJsonString
//  }
//
//}

class TRERuleDetailIngestionController(spark : SparkSession) extends BaseController with ReDiConstants with ReDiTableSchemas {
  /** CC Salt Hashing value **/



  def TreRuleDetailPipeline(): Unit = {
    //val sparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
    val treRuleDetailDataFlowDao = new TRERuleDetailDataFlowDao(spark)
    val ruleDtlTransfrm = new TRERuleDetailTransformationController(spark)
    val readRule = treRuleDetailDataFlowDao.readTRERuleDetaiFromKafka()
    val transformedRule = readRule

      //      .select($"key".as[String], $"value".as[Array[Byte]])
      //      .map(
      //        row => {
      //          information.deserValue(row._1, row._2)
      //        }
      //      ).select(from_json($"value", information.structure).as("data")).select("data.*")

      .withColumn("Whenloaded",lit(current_timestamp()))
    val transformedRuleDetail = ruleDtlTransfrm.performTransformTRERuleDetailData(transformedRule)
    treRuleDetailDataFlowDao.WriteTRERuleDetailData(transformedRuleDetail)
  }
}
