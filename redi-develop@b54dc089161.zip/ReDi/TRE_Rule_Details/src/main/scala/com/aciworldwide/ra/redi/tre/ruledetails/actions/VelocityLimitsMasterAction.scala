package com.aciworldwide.ra.redi.tre.ruledetails.actions
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.tre.ruledetails.controllers.VelocityLimitsMasterController
import org.apache.logging.log4j.LogManager


object VelocityLimitsMasterAction extends  VelocityLimitsMasterController  with Serializable{

  @transient lazy val VelocityLimitMaterActionLogger = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    VelocityLimitMaterActionLogger.debug(VLMDataIngestionProcess_DEBUG + " :Start of BED Update process")
    try{
      processVelocitylimitMaster()
    } catch {
      case e: Exception => VelocityLimitMaterActionLogger.error(VLMDataIngestionProcess_ERROR+"We have an error in the Incremental VelocitylimitMaster Process" )
        e.printStackTrace()
        System.exit(1)
    } finally {
      VelocityLimitMaterActionLogger.debug(VLMDataIngestionProcess_DEBUG + "End of incremental load")
    }
  }

}