package com.aciworldwide.ra.redi.tre.ruledetails.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.aciworldwide.ra.redi.tre.ruledetails.dao.VelocityLimitMasterDao
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.hive.common.util.DateUtils._
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

class VelocityLimitsMasterController extends BaseController with ReDiConstants
  with ReDiTableSchemas with DatabaseServices with CommonUtils  {

  @transient lazy val VelocityLimitMaterControllerLogger = LogManager.getLogger(getClass.getName)
  val sparkSession: SparkSession = createSparkSession(VELOCITYLIMITMASTERAPP)
  val VelocitylimitDao = new VelocityLimitMasterDao(sparkSession)
  val hive = HiveWarehouseSession.session(sparkSession).build()
  hive.setDatabase(DBNAME)

  import sparkSession.implicits._


  def getRawDataFrameHWMColumn: String = {

    VELOCITY_LIMIT_MASTER_TABLE_HWM_COLUMN
  }


  def getOverDataTableName(): String = {
    VELOCITY_LIMIT_MASTER_TABL
  }


  def getDatabaseSchema(): String = {
    RULEMGR_DATABASE
  }

  def getHWMId(controlKey: String): String = {

    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO + "Starting to fetch HWM Value")
    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO + "Process Control Table Name:- " + REDI_PROCESS_CONTROL)
    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO + "Process Control Key  Name:- " + controlKey)
    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO + "Process Status  :- " + PROCESS_CONTROL_COMPLETED)
    var hwmDate = hive.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'"
      + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    hwmDate
  }

  def getODSWhereCondition(value: String): String = " WHERE " + getRawDataFrameHWMColumn + ">=to_timestamp('" + value + "', 'YYYY-MM-DD HH24:MI:SS.FF3')"


  def fetchRawDataFrmvellim(VELLIMHWM: String, tableName: String): DataFrame = {
    val vellimQuery = "( SELECT * FROM" +
      " " + getDatabaseSchema + "." + tableName + getODSWhereCondition(VELLIMHWM) + ") VELOCITY_LIMIT"

    //println(vellimQuery)
    val velhistTableDF = VelocitylimitDao.fetchVelocityLimitMasterDataFromODS(vellimQuery, ORACLE_CONN_TYPE, getDatabaseSchema, VEL_LIM_CODE_PARTS)
    velhistTableDF
  }

  def getDataFromODs(df: DataFrame): DataFrame = {
    df.select($"CLIENT_ID".as("ClientId"),
      $"SUBCLIENT_ID".as("SubclientId"),
      $"FIELD_NAME".as("rulename"),
      $"FIELD_VALUE".as("fieldvalue"),
      $"PROCESS_TYPE".as("processtype"),
      $"THRESHOLD_COUNT".as("thresholdcount"),
      $"THRESHOLD_SUM".as("thresholdsum"),
      $"WINDOW_TIME".as("windowtime"),
      $"WINDOW_UNITS".as("windowunits"),
      $"STANDARD_UNITS".as("standardunits"),
      $"VELOCITY_ID".as("velocityid"),
      $"FIELD_TYPE".as("fieldtype"),
      $"PRIORITY".as("priority"),
      $"THRESHOLD_SUM_FIELD".as("thresholdsumfield"),
      $"GROUP_ID".as("groupid"),
      $"ACTIVE_START".as("activestart"),
      $"ACTIVE_END".as("activeend"),
      $"FIELD_VALUE_CATEGORY".as("fieldvaluecategory"),
      $"SEARCH_CLIENT_ID".as("searchclientid"),
      $"SEARCH_SUBCLIENT_ID".as("searchsubclientid"),
      $"ADD_HISTORY".as("addhistory"),
      $"RCF".as("rcf"),
      $"RULE_SOURCE".as("rulesource"),
      $"DESCRIPTION_SOURCE".as("descriptionsource"),
      $"RULE_OR_BLOCK".as("ruleorblock"),
      $"PERMISSION_LEVEL".as("permissionlevel"),
      $"EXTERNAL_FLAG".as("externalflag"),
      $"EXPIRATION_DATE".as("expirationdate"),
      $"COST_FACTOR".as("costfactor"),
      $"USER_ID".as("userid"),
      $"TIMESTAMP".as("loadtimestamp"),
      $"ACTION_TYPE".as("actiontype"),
      $"HOST_NAME".as("hostname"),
      $"REMARKS".as("remarks"),
      $"BRIEF_DESCRIPTION".as("briefdescription"),
      $"DESCRIPTION".as("description"),
      $"CASE_ID".as("caseid"),
      $"OS_USER".as("osuser"),
      $"ACTIVATE_SET".as("activateset"),
      $"MEMBER_OF_SET".as("memberofset"),
      $"TERMINATE".as("terminate"),
      $"GROUP_MEMBER_CNT".as("groupmembercnt"),
      $"DB_USER".as("dbuser")
    )

  }

  def storeDataToHDFS(df: DataFrame, tablename: String): Unit = {
    logRegularMessage("Starting to load data into HDFS location")
    if (tablename == VELOCITY_LIMIT_MASTER_TABL) {
      saveDataintoHDFS(df, "ORC", ConfigFactory.load().getString("local.common.hdfs.VELOCITY_LIMIT_MASTER_HDFS"), HDFS_STORAGE_DATE_EXT)
    }

    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO+"Finished loading the data into HDFS location")

  }

  def updateControlTables(vellimDf: DataFrame, maxcolumn: String, processName: String): Unit = {

    val endTimevellimmasterDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(vellimDf, maxcolumn, processName, PROCESS_CONTROL_COMPLETED, "", endTimevellimmasterDataLoad.toString, "Completed the  Fetch from ODS into HDFS",VELOCITY_LIMITS_MASTER_PROCESS)
  }

  def storeDataToHive(finalvellimitDF: DataFrame): Unit = {
    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO+"Starting to push the data into Hive table " + VELOCITY_LIMIT_MASTER_TABLE)
    storeDataIntoHive(VELOCITY_LIMIT_MASTER_TABLE, APPEND_MODE, finalvellimitDF)
    VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO+"Number of rows inserted in velocity limit Master: " + finalvellimitDF.count)
  }

  def transformationDerivedColumns(df: DataFrame): DataFrame = {
    val velcoitytransdf=  df.withColumn("client12", lit(" "))
      .withColumn("CompoundId", lit(" "))
      .withColumn("RuleId", when(col("GroupId").isNotNull,col("GroupId")).otherwise(col("VelocityId")))
      .withColumn("RuleType", lit(" "))
      .withColumn("RuleState", lit(" "))
      .withColumn("OldRuleDescription", lit(" "))
      .withColumn("ActionDate", lit(" "))
      .withColumn("UserName", lit(" "))
      .withColumn("RuleDescription",lit(" "))
      .withColumn("OldRuleDescription",lit(" "))
    velcoitytransdf
  }


  def processVelocitylimitMaster(): Unit = {
    VelocityLimitMaterControllerLogger.debug(VLMDataIngestionProcess_INFO+"Inside processVelocitylimitMaster method")

    val velocitylimitHWM = getHWMId(REDI_VELOCITY_LIMITS_MASTER_CONTROL_KEY)
    var rawvelocitylimitmaster: DataFrame = null

    if (velocitylimitHWM == null) {
      VelocityLimitMaterControllerLogger.error(VLMDataIngestionProcess_ERROR+"There is a error in the " + REDI_VELOCITY_LIMITS_MASTER_CONTROL_KEY + " value stored in Hive" + velocitylimitHWM)
    } else {
      var rawvellimitDF = transformationDerivedColumns(getDataFromODs(fetchRawDataFrmvellim(velocitylimitHWM, VELOCITY_LIMIT_MASTER_TABL)))
      VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO+"Total Count is for " + VELOCITY_LIMIT_MASTER_TABL + "=" + rawvellimitDF.count())
      storeDataToHDFS(rawvellimitDF, VELOCITY_LIMIT_MASTER_TABL)
      storeDataToHive(reorderSourceTableSchema(VELOCITY_LIMIT_MASTER_COL_ORDER, addAuditColumns(rawvellimitDF)))
      updateControlTables(rawvellimitDF, "loadtimestamp", REDI_VELOCITY_LIMITS_MASTER_CONTROL_KEY)
      VelocityLimitMaterControllerLogger.info(VLMDataIngestionProcess_INFO+"Ending the Process")
    }
  }
}
