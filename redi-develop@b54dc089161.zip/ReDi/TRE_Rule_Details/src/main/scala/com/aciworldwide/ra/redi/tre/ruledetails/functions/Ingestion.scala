package com.aciworldwide.ra.redi.tre.ruledetails.functions

import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object Ingestion {
  @transient lazy private val logger = LogManager.getLogger(getClass.getName)

  def dveTswruleDetailsTransformations(spark: SparkSession, df: DataFrame): DataFrame = {
    logger.info("Inside dveTswruleDetailsTransformations method")

    import spark.implicits._

    df
      .withColumn("recommend", when($"recommend".isNotNull,recommendUdf($"recommend")).otherwise(lit("")))
      .withColumn("descriptionredi", when($"description".isNull, "").otherwise(lower(col("description"))))
      .withColumn("descriptionlowercase", when($"description".isNull, "").otherwise(lower(col("description"))))
      .withColumn("recommendredi",
        when(col("description").like("accept(hard%") && col("recommend").notEqual("Hard Accept"), lit("Hard Accept"))
          .when(col("description").like("accept(soft%") && col("recommend").notEqual("Soft Accept"), lit("Soft Accept"))
          .otherwise(col("recommend")))
      .withColumn("actiondate", greatest(col("add_date"), col("update_date"), col("delete_date")))
      .withColumn("actiontype", when(col("add_date").equalTo(col("actiondate")), lit("ADD"))
        .when(col("update_date").equalTo(col("actiondate")), lit("UPDATE"))
        .when(col("delete_date").equalTo(col("actiondate")), lit("DELETE")))
      .withColumn("client12", concat(col("clientid"), col("subclientid")))
      .withColumn("ruleactiondateyyyymmdd", date_format(to_timestamp($"actionDate", "yyyy-MM-dd HH:mm:ss"), "yyyyMMdd"))
      .withColumn("rulegroup", when(col("ruleSource") === "TSW", "TS")
        .when(col("descriptionlowercase").like("click and block%"), "CB")
        .when(col("descriptionlowercase").like("manually created by red%"), "MA")
        .when(col("descriptionlowercase").like("automated block%"), "AB")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%1700%")
          or col("descriptionlowercase").like("%1760%")), "EL")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%7000%")
          or col("descriptionlowercase").like("%gift card%")), "GC")
        .when(col("descriptionlowercase") like "%prodcd%" or col("descriptionlowercase").like("%proddesc%") or
          col("descriptionlowercase").like("%manpartno%") or col("descriptionlowercase").like("%prodsku%"), "PR")
        .when(col("descriptionlowercase").like("%country%") or col("descriptionlowercase").like("%cntry%") or
          col("descriptionlowercase").like("%continent%"), "CO")
        .when(col("descriptionlowercase").like("%state%"), "ST")
        .when(col("descriptionlowercase").like("%city%"), "CI")
        .when(col("descriptionlowercase").like("%zip%"), "ZI")
        .when(col("descriptionlowercase").like("%avs%"), "AV")
        .when((col("descriptionlowercase").like("%custid%") or col("descriptionlowercase").like("%custemail%") or
          col("descriptionlowercase").like("%custip%")) or col("descriptionlowercase").like("%custhomephone%"), "CU")
        .when(col("descriptionlowercase").like("%cardno%"), "CD")
        .when(col("descriptionlowercase").like("%address%") or col("descriptionlowercase").like("%street%"), "AD")
        .when(col("descriptionlowercase").like("%custfirstname%") or col("descriptionlowercase").like("%custlastname%")
          or col("descriptionlowercase").like("%cust surname%"), "CN")
        .when(col("descriptionlowercase").like("%domain%"), "DM")
        .otherwise(lit("XX"))
      )
      .withColumn("rulegroupshort", when(col("ruleSource") === "TSW", "Tumble/Swap")
        .when(col("descriptionlowercase").like("click and block%"), "Click/Block")
        .when(col("descriptionlowercase").like("manually created by red%"), "Manual (ReD)")
        .when(col("descriptionlowercase").like("automated block%"), "Auto Block")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%1700%")
          or col("descriptionlowercase").like("%1760%")), "ELECTRONICS")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%7000%")
          or col("descriptionlowercase").like("%gift card%")), "Gift Cards")
        .when(col("descriptionlowercase").like("%prodcd%") or col("descriptionlowercase").like("%proddesc%") or
          col("descriptionlowercase").like("%manpartno%") or col("descriptionlowercase").like("%prodsku%"),
          "Other Products")
        .when(col("descriptionlowercase").like("%country%") or col("descriptionlowercase").like("%cntry%") or
          col("descriptionlowercase").like("%continent%"), "Country")
        .when(col("descriptionlowercase").like("%state%"), "State")
        .when(col("descriptionlowercase").like("%city%"), "City")
        .when(col("descriptionlowercase").like("%zip%"), "Zip Code")
        .when(col("descriptionlowercase").like("%avs%"), "AVS")
        .when(col("descriptionlowercase").like("%custid%") or col("descriptionlowercase").like("%custemail%") or
          col("descriptionlowercase").like("%custip%") or col("descriptionlowercase").like("%custhomephone%"), "Customer")
        .when(col("descriptionlowercase").like("%cardno%"), "Card No")
        .when(col("descriptionlowercase").like("%address%") or col("descriptionlowercase").like("%street%"), "Address")
        .when(col("descriptionlowercase").like("%custfirstname%") or col("descriptionlowercase").like("%custlastname%") or
          col("descriptionlowercase").like("%cust surname%"), "Cust Name")
        .when(col("descriptionlowercase").like("%domain%"), "Domain")
        .otherwise(lit("Other")))
      .withColumn("rulegrouptext", when(col("ruleSource") === "TSW", "Tumble/Swap Rules")
        .when(col("descriptionlowercase").like("click and block%"), "Click AND Block")
        .when(col("descriptionlowercase").like("manually created by red%"), "Manually Created by ReD")
        .when(col("descriptionlowercase").like("automated block%"), "Automated Block")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%1700%")
          or col("descriptionlowercase").like("%1760%")), "ELECTRONICS 1700/1760")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%7000%")
          or col("descriptionlowercase").like("%gift card%")), "Gift Cards")
        .when(col("descriptionlowercase").like("%prodcd%") or col("descriptionlowercase").like("%proddesc%") or
          col("descriptionlowercase").like("%manpartno%") or col("descriptionlowercase").like("%prodsku%"), "Other Products")
        .when(col("descriptionlowercase").like("%country%") or col("descriptionlowercase").like("%cntry%") or col("descriptionlowercase").like("%continent%"), "Country related")
        .when(col("descriptionlowercase").like("%state%"), "State related")
        .when(col("descriptionlowercase").like("%city%"), "City related")
        .when(col("descriptionlowercase").like("%zip%"), "Zip Code related")
        .when(col("descriptionlowercase").like("%avs%"), "AVS related")
        .when(col("descriptionlowercase").like("%custid%") or col("descriptionlowercase").like("%custemail%") or
          col("descriptionlowercase").like("%custip%") or col("descriptionlowercase").like("%custhomephone%"), "Customer Specific")
        .when(col("descriptionlowercase").like("%cardno%"), "Card Specific")
        .when(col("descriptionlowercase").like("%address%") or col("descriptionlowercase").like("%street%"), "Address/Street")
        .when(col("descriptionlowercase").like("%custfirstname%") or col("descriptionlowercase").like("%custlastname%")
          or col("descriptionlowercase").like("%cust surname%"), "Customer Name Related")
        .when(col("descriptionlowercase").like("%domain%"), "Domain Related")
        .otherwise(lit("Other")))
      .withColumn("rulegrouporder", when(col("ruleSource") === "TSW", "160")
        .when(col("descriptionlowercase").like("click and block%"), "10")
        .when(col("descriptionlowercase").like("manually created by red%"), "20")
        .when(col("descriptionlowercase").like("automated block%"), "25")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%1700%")
          or col("descriptionlowercase").like("%1760%")), "30")
        .when(col("clientid").equalTo("000022") && (col("descriptionlowercase").like("%7000%")
          or col("descriptionlowercase").like("%gift card%")), "40")
        .when(col("descriptionlowercase").like("%prodcd%") or col("descriptionlowercase").like("%proddesc%") or
          col("descriptionlowercase").like("%manpartno%") or col("descriptionlowercase").like("%prodsku%"), "50")
        .when(col("descriptionlowercase").like("%country%") or col("descriptionlowercase").like("%cntry%") or
          col("descriptionlowercase").like("%continent%"), "60")
        .when(col("descriptionlowercase").like("%state%"), "70")
        .when(col("descriptionlowercase").like("%city%"), "80")
        .when(col("descriptionlowercase").like("%zip%"), "90")
        .when(col("descriptionlowercase").like("%avs%"), "100")
        .when(col("descriptionlowercase").like("%custid%") or col("descriptionlowercase").like("%custemail%") or
          col("descriptionlowercase").like("%custip%") or col("descriptionlowercase").like("%custhomephone%"), "110")
        .when(col("descriptionlowercase").like("%cardno%"), "120")
        .when(col("descriptionlowercase").like("%address%") or col("descriptionlowercase").like("%street%"), "130")
        .when(col("descriptionlowercase").like("%custfirstname%") or col("descriptionlowercase").like("%custlastname%") or
          col("descriptionlowercase").like("%cust surname%"), "140")
        .when(col("descriptionlowercase").like("%domain%"), "150")
        .otherwise(lit("999")))
      .withColumn("rulecases", lit("99"))
      .withColumn("recommendsort", recommendSort(upper($"recommend")))
      .withColumn("fraudyn", when(upper(col("recommend")).equalTo("DENY") &&
        (col("ruleid").like("B%") || col("ruleid").like("9%")), lit("Y"))
        .otherwise("N"))
      .withColumn("compoundstart", lit(""))
      .withColumn("compoundend", lit(""))

  }

  def recommendSort: UserDefinedFunction = udf((recommend: String) => convertRecommendation(recommend))

  def convertRecommendation(recommend: String) = {
    recommend match {
      case "ALLOW" => 25
      case "ALWAYS ACCEPT" => 20
      case "ALWAYS ALLOW" => 21
      case "ALWAYS DENY" => 10
      case "CHALLENGE" => 60
      case "DENY" => 50
      case "HARD ACCEPT" => 30
      case "ACCEPT(HARD)" => 30
      case "HARD CHALLENGE" => 40
      case "SOFT DENY" => 80
      case "SOFT ACCEPT" => 70
      case "SOFT CHALLENGE" => 90
      case "CHALLENGE(SOFT)" => 90
      case "NO RECOMMENDATION" => 100
      case "RECORD RULE ID" => 100
      case "OBSERVE" => 100
      case "UNKNOWN" => 990
      case _ => 999
    }
  }

  def recommendUdf: UserDefinedFunction = udf((recommend: String) => recommendTrans(recommend))

  def recommendTrans(recommend: String) = {
    recommend.toUpperCase() match {
      case "ALLOW" => "Allow"
      case "ALWAYS ACCEPT" => "Always Accept"
      case "ALWAYS ALLOW" => "Always Allow"
      case "ALWAYS DENY" => "Always Deny"
      case "CHALLENGE" => "Challenge"
      case "CHALLANGE" => "Challenge"
      case "DENY" => "Deny"
      case "HARD ACCEPT" => "Hard Accept"
      case "ACCEPT(HARD)" => "Hard Accept"
      case "HARD CHALLENGE" => "Hard Challenge"
      case "SOFT DENY" => "Soft Deny"
      case "SOFT ACCEPT" => "Soft Accept"
      case "SOFT CHALLENGE" => "Soft Challenge"
      case "CHALLENGE(SOFT)" => "Soft Challenge"
      case "NO RECOMMENDATION" => "Silent"
      case "RECORD RULE ID" => "Silent"
      case "OBSERVE" => "Silent"
      case _=> recommend
    }
  }



}
