package com.aciworldwide.ra.redi.tre.ruledetails.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import za.co.absa.abris.avro.AvroSerDe._
import za.co.absa.abris.avro.read.confluent.SchemaManager
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY


/*class TREHiveSinkProvider extends StreamSinkProvider {
  override def createSink(sqlContext: SQLContext,
                          parameters: Map[String, String],
                          partitionColumns: Seq[String],
                          outputMode: OutputMode): Sink = {
    new TREHiveSink()
  }
}



class TREHiveSink() extends Sink with Logging with ReDiConstants {

  /**
    * Saving DataFrame to Hive table. The table name must be specified in the configuration.
    *
    * @param dataFrame default spark DataFrame[Row]
    */
  private def saveToHive(dataFrame: DataFrame): Unit = {
    dataFrame.write.insertInto(EXT_TRE_RULE_DETAILS_TABLE)
  }

  override def addBatch(batchId: Long, dataFrame: DataFrame): Unit = {
    logDebug(s"Starting to write batch #$batchId")
    saveToHive(dataFrame)
    logDebug(s"Batch #$batchId has been written")
  }
}*/

class TRERuleDetailDataFlowDao(sc: SparkSession) extends Serializable
  with ReDiConstants with CommonUtils with DatabaseServices with EstablishConnections {

  @transient lazy val TRERuleDetailDaoDatalogger = LogManager.getLogger(getClass.getName)

  val schemaRegistryConfs = Map(
    SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> ConfigFactory.load().getString("local.common.tre_rule_details.schemaRegistryURL"),
    SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> ConfigFactory.load().getString("local.common.tre_rule_details.treRuleDetailkafkatopic"),
    SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME, // choose a subject name strategy
    SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest" // set to "latest" if you want the latest schema version to used
  )

  def WriteTRERuleDetailData(df: DataFrame) = {
    /*
        df.writeStream
          .format("orc")
          //.format("parquet")
          .option("path",ConfigFactory.load().getString("local.common.hdfs.TRE_RULE_DETAIL_DATA_HDFS"))
          .outputMode(OutputMode.Append())
          .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.tre_rule_details.treRuleDetailtopicCheckpointlocation"))
          .queryName(KAFKA_WRITE_QUERYNAME)
          .start()
          .awaitTermination()
    */
    TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":Starting to push the data into Hive tables " + TRE_RULE_DETAILS_TABLE)
    try {
      df.writeStream
        .format(HiveWarehouseSession.STREAM_TO_STREAM)
        .outputMode(OutputMode.Append())
        .trigger(Trigger.ProcessingTime(ConfigFactory.load().getString("local.common.tre_rule_details.processingTime")))
        .option("database", ConfigFactory.load().getString("local.common.kafka.hiveDBName"))
        .option("table", ConfigFactory.load().getString("local.common.tre_rule_details.table_name"))
        .option("metastoreUri", ConfigFactory.load().getString("local.common.kafka.metastoreUri"))
        .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.tre_rule_details.treRuleDetailtopicCheckpointlocation"))
        .start()
        .awaitTermination()
    } catch {
      case exp: Exception => TRERuleDetailDaoDatalogger.error(TRERuleDetailIngestionProcess_ERROR + ": We have an error on storing data into redi.RULE_DETAILS" + exp)
    } finally {
      TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":End of Storing TreRuleDetails data into Hive")
    }
    TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":successfully stored data into Hive")

  }


  def readTRERuleDetaiFromKafka(): DataFrame = {

    TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":Starting to read the data from Kafka ")
    var readStreamDf: DataFrame = null
    try {
      readStreamDf = sc.readStream
        .format(KAFKA_SOURCE)
        .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.tre_rule_details.bootstrapservers"))
        .option(SUBSCRIBE, ConfigFactory.load().getString("local.common.tre_rule_details.treRuleDetailkafkatopic"))
        .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.tre_rule_details.maxOffsetsPerTrigger"))
        .option(KAFKASECURITYPROTOCOL, SASL_SSL)
        .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
        .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
        .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
        .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
        .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
        .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
        .option(KAFKASASLMECHANISM, GSSAPI)
        .load()
        .fromConfluentAvro("value", None, Some(schemaRegistryConfs))(RETAIN_SELECTED_COLUMN_ONLY) // invoke the library passing over parameters to access the Schema Registry
    } catch {
      case exp: Exception => TRERuleDetailDaoDatalogger.error(TRERuleDetailIngestionProcess_ERROR + ": We have an error on while reading the data from Kafka " + exp)
    } finally {
      TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":End of Storing ClientMaster data into Hive")
    }
    TRERuleDetailDaoDatalogger.debug(TRERuleDetailIngestionProcess_DEBUG + ":successfully stored data into Hive")
    readStreamDf
  }
}
