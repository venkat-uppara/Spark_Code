package com.aciworldwide.ra.redi.tre.ruledetailstest.test

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.tre.ruledetails.controllers.TRERuleDetailTransformationController
import com.aciworldwide.ra.redi.tre.ruledetails.dao.TRERuleDetailDataFlowDao
import com.aciworldwide.ra.redi.tre.ruledetails.schemas.{ClientInfoSchema, TRERuleDetailsSchema}
import com.aciworldwide.ra.redi.tre.ruledetailstest.services.ReDiTreRuleDetailsTestSpec
import org.apache.hadoop.hive.ql.exec.spark.session
import org.apache.spark.sql.{DataFrame, SQLContext, SparkSession}
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually

class TRERuleDetailsTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTreRuleDetailsTestSpec with ReDiConstants {


  private val CLIENTINFO = Array(ClientInfoSchema("DEMOJD","%"))
  private val CLIENTINFO_1 = Array(ClientInfoSchema("000031","000545"))

  private val TRERULEDETAILS = Array(
    TRERuleDetailsSchema("JB748249-B2","","","ACCEPT",new java.sql.Timestamp(System.currentTimeMillis()),"","",new java.sql.Timestamp(System.currentTimeMillis()),"","",99,CLIENTINFO),
    TRERuleDetailsSchema("JB748249-B1","","click and block","DENY",new java.sql.Timestamp(System.currentTimeMillis()),"","",new java.sql.Timestamp(System.currentTimeMillis()),"","",99,CLIENTINFO) ,
    TRERuleDetailsSchema("JB748249-B3","","","",new java.sql.Timestamp(System.currentTimeMillis()),"","",new java.sql.Timestamp(System.currentTimeMillis()),"","",99,CLIENTINFO_1),
    TRERuleDetailsSchema("JB748249-B4","","","Challenge",new java.sql.Timestamp(System.currentTimeMillis()),"","",new java.sql.Timestamp(System.currentTimeMillis()),"","",99,CLIENTINFO)
  )
  val actionDate = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS).format(new java.sql.Timestamp(System.currentTimeMillis()))
  /*private val TRERULEDETAILS = Array(
    TRERuleDetailsSchema("JB748249-B2","","","","TRE","Always Allow",new java.sql.Timestamp(System.currentTimeMillis()),
      "","DEMOJD","%","","",2,CLIENTINFO,"DEMOJD%","20130327","","","","","",99,"N","","",new java.sql.Timestamp(System.currentTimeMillis()),"",new java.sql.Timestamp(System.currentTimeMillis()),"","")
  )*/

  private var treRuleDetailDataFlowDao: TRERuleDetailDataFlowDao = _
  private var ruledetailController: TRERuleDetailTransformationController = _
  private var ruledtlDF: DataFrame = _


  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc

    import _sqlc.implicits._

    ruledtlDF = _sqlc.sparkContext.parallelize(TRERULEDETAILS).toDF()
    treRuleDetailDataFlowDao = new TRERuleDetailDataFlowDao(_sqlc)
    ruledetailController = new TRERuleDetailTransformationController(_sqlc)
  }

  //Check any test cases can be added for ingestion




  //Test cases for transformations

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details recommendredi data 1 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rediRecommend = transformedruledetail.select("recommendredi").where(transformedruledetail("ruleid")=== "JB748249-B2")
    val rediRecommendVal = rediRecommend.collect().map(col => col.getString(0)).mkString(" ")
    rediRecommendVal should be === "Accept"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details recommendredi  data 2 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rediRecommend = transformedruledetail.select("recommendredi").where(transformedruledetail("ruleid")=== "JB748249-B1")
    val rediRecommendVal = rediRecommend.collect().map(col => col.getString(0)).mkString(" ")
    rediRecommendVal should be === "Deny"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details recommendredi data 4 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rediRecommend = transformedruledetail.select("recommendredi").where(transformedruledetail("ruleid")=== "JB748249-B4")
    val rediRecommendVal = rediRecommend.collect().map(col => col.getString(0)).mkString(" ")
    rediRecommendVal should be === "Challenge"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details recommendredi data 5 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rediRecommend = transformedruledetail.select("recommendredi").where(transformedruledetail("ruleid")=== "JB748249-B4")
    val rediRecommendVal = rediRecommend.collect().map(col => col.getString(0)).mkString(" ")
    rediRecommendVal should not be "CHALLANGE"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details ruleactionDateYYYYMMDD data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val ruleactionDate = transformedruledetail.select("ruleactionDateYYYYMMDD").where(transformedruledetail("ruleid")=== "JB748249-B2")
    val ruleactionDateVal = ruleactionDate.collect().map(col => col.getString(0)).mkString(" ")
    ruleactionDateVal should be === actionDate
  }


  "This test will test the final transformed rule details data. this" should "Display the transformed rule details client12 data 1 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val ruleid = transformedruledetail.select("client12").where(transformedruledetail("ruleid")=== "JB748249-B2")
    val ruleidVal = ruleid.collect().map(col => col.getString(0)).mkString(" ")
    ruleidVal should be === "DEMOJD%"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details client12 data 2 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val ruleid = transformedruledetail.select("client12").where(transformedruledetail("ruleid")=== "JB748249-B3")
    val ruleidVal = ruleid.collect().map(col => col.getString(0)).mkString(" ")
    ruleidVal should be === "000031000545"
  }
  "This test will test the final transformed rule details data. this" should "Display the transformed rule details client12 data 3 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val ruleid = transformedruledetail.select("client12").where(transformedruledetail("ruleid")=== "JB748249-B3")
    val ruleidVal = ruleid.collect().map(col => col.getString(0)).mkString(" ")
    ruleidVal should not be  "000031"
  }


  "This test will test the final transformed rule details data. this" should "Display the transformed rule details ruleSource data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val ruleSource = transformedruledetail.select("ruleSource").where(transformedruledetail("ruleid")=== "JB748249-B2")
    val ruleSourceVal = ruleSource.collect().map(col => col.getString(0)).mkString(" ")
    ruleSourceVal should be === "TRE"
  }



  "This test will test the final transformed rule details data. this" should "Display the transformed rule details rulegroup data 1 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("rulegroup").where(transformedruledetail("ruleid")=== "JB748249-B2" && transformedruledetail("ruleSource")=== "TRE" )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === "TR"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details rulegroup data 2 " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("rulegroup").where(transformedruledetail("ruleid")=== "JB748249-B2" && transformedruledetail("ruleSource")=== "TRE" )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should not be  "CB"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details RuleGroupShort data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("RuleGroupShort").where(transformedruledetail("ruleid")=== "JB748249-B2" && transformedruledetail("ruleSource")=== "TRE"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === "TitaniumRule"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details rulegrouptext data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("rulegrouptext").where(transformedruledetail("ruleid")=== "JB748249-B2" && transformedruledetail("ruleSource")=== "TRE"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === "Titanium Rules"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details RuleGroupOrder data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("RuleGroupOrder").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === ""
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details RuleCases data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("RuleCases").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === ""
  }


  "This test will test the final transformed rule details data. this" should "Display the transformed rule details RecommendSort data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("RecommendSort").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === "null"
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details FraudYN data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("FraudYN").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === ""
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details CompoundStart data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("CompoundStart").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === ""
  }

  "This test will test the final transformed rule details data. this" should "Display the transformed rule details CompoundEnd data " in {
    val transformedruledetail = ruledetailController.performTransformTRERuleDetailData(ruledtlDF)
    val rulegroup = transformedruledetail.select("CompoundEnd").where(transformedruledetail("ruleid")=== "JB748249-B2"  )
    val rulegroupVal = rulegroup.collect().map(col => col.getString(0)).mkString(" ")
    rulegroupVal should be === ""
  }



}
