package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.{CSIAccessDataController, CSICancelCodesDataController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually


case class Access(accessid:String,USERID:String,accesstype:String,accessresult:String,accessdatetime:String)
case class Users(ClientId:String,SubClientId:String,Client12:String,UserName:String,UserFullName:String,UserId:String)
case class rbiRefClientForAccess(clientId:String,subClientid:String,tzclient:String)


class AccessTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable
{

  private val accessList = Array(
    Access("ff8080814ec0ecb8014ee67c76c70d4f","15002","LOGOUT","SUCCESS","2019-01-18 04:04:46.0"),
    Access("ff8080814ec0ecb8014ee67c76c70d4f","15003","LOGIN","SUCCESS","2019-01-18 02:43:47.0"),
    Access("ff8080814ec0ecb8014ee67c76c70d4f","15004","LOGIN","FAILURE","2019-02-19 00:41:39.0"))


  private val usersList = Array(
    Users("078130","123456","078130123456","Rakesh","Rakesh G","15002"),
    Users("078130","123456","078130123456","ABC","Abc G","15003"),
    Users("078122","123455","078130123456","ABC","Abc G","15004"))

  private val subClientPrfoileList = Array(rbiRefClientForAccess("078130", "123456","AUD"),
    rbiRefClientForAccess("078122", "123455","IST"))



  private var access : CSIAccessDataController = _
  private var accessDF: DataFrame = _
  private var userdDf: DataFrame = _
  private var rbiRefDf: DataFrame = _
  var outputDf:DataFrame=_
  var outputDf1:DataFrame=_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao = new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    accessDF = _sqlc.sparkContext.parallelize(accessList).toDF()
    userdDf = _sqlc.sparkContext.parallelize(usersList).toDF()
    rbiRefDf= _sqlc.sparkContext.parallelize(subClientPrfoileList).toDF()

    access = new CSIAccessDataController(_sqlc, dao)
    outputDf = access.joinedDf(accessDF, userdDf)
    outputDf1=access.addClientDateTime(outputDf,rbiRefDf)
  }

  "This test is for access loginyn  " should "display Y for Success " in {
    val accessdf= outputDf.select("loginyn","userid").filter(outputDf("userid")==="15003")
    val login=accessdf.collect().map(col=>col.getString(0)).mkString("")
    login should be ==="Y"
  }

  "This test is for access logoutyn  " should "display Y for Success " in {
    val accessdf= outputDf.select("logoutyn","userid").filter(outputDf("userid")==="15002")
    val login=accessdf.collect().map(col=>col.getString(0)).mkString("")
    login should be ==="Y"
  }

  "This test is for access loginyn  " should "display N for Failure " in {
    val accessdf= outputDf.select("loginyn","userid").filter(outputDf("userid")==="15004")
    val login=accessdf.collect().map(col=>col.getString(0)).mkString("")
    login should be ==="N"
  }

  "This test is for access logoutyn  " should "display N for Failure " in {
    val accessdf= outputDf.select("logoutyn","userid").filter(outputDf("userid")==="15004")
    val login=accessdf.collect().map(col=>col.getString(0)).mkString("")
    outputDf1.show(false)
    login should be ==="N"
  }

}
