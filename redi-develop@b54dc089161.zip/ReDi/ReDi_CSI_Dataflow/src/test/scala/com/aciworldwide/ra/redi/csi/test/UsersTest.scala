package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.{CSISubclientProfilesDataController, CSIUsersDataController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually


case class UsersData(UserId:String,CREATED_DATE:String,CREATED_BY:String,MODIFIED_DATE:String,MODIFIED_BY:String,DELETED:String,UserName:String,
                     STATUS:String,SALUTATION_CODE:String,FIRST_NAME:String,LAST_NAME:String,MIDDLE_NAME:String,PASSWORD:String,PASSWORD_STATE:String,
                     LEGACY_USER_ID:String,CLIENT_ID:String,SUBCLIENT_ID:String,SALT:String,hashtypeflag:String,UserType:String,LAST_ACCESSED_DATE:String)

class UsersTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable {


  private val usersList = Array(UsersData("16186","01-08-15 02:42:32.888000000 PM","15002","01-08-15 02:42:32.888000000 PM","15002","0","PERFTESTUSER3",
  "ENABLED","","CUSTFNAME","ABDNDJKD","XYZ","123","ACTIVE",
  "","000032","000206","","0","","01-08-15 02:42:32.888000000 PM"),
    UsersData("16186","01-08-15 02:42:32.888000000 PM","15003","01-08-15 02:42:32.888000000 PM","15002","0","ACI",
    "ENABLED","","ACI","Worlwide","Payments","123","ACTIVE",
    "","000031","000205","","0","","01-08-15 02:42:32.888000000 PM"),
    UsersData("16186","01-08-15 02:42:32.888000000 PM","15003","01-08-15 02:42:32.888000000 PM","15002","0","ACI",
      "ENABLED","","ACI","Worlwide","Payments","123","ACTIVE",
      "","999999","43434","","0","","01-08-15 02:42:32.888000000 PM"))


  private var usersData : CSIUsersDataController = _
  private var usersDataDf: DataFrame = _
  var outputDf:DataFrame=_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao= new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    usersDataDf = sc.sparkContext.parallelize(usersList).toDF()
    usersData= new CSIUsersDataController(sc,dao)
    outputDf=usersData.usersTrans(usersDataDf)
    outputDf.show()
  }


  "This test is for clientid  " should "display 000032" in {
    val outDf= outputDf.select("clientid").filter(outputDf("clientid")==="000032")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="000032"
  }

  "This test is for subclientid  " should "display 000206" in {
    val outDf= outputDf.select("subclientid").filter(outputDf("clientid")==="000032")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="000206"
  }

  "This test is for UserMerchantYN  " should "display N" in {
    val outDf= outputDf.select("UserMerchantYN").filter(outputDf("clientid")==="999999")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="N"
  }

  "This test is for UserMerchantYN  " should "display Y" in {
    val outDf= outputDf.select("UserMerchantYN").filter(outputDf("clientid")==="000032")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="Y"
  }

  "This test is for UserFullName  " should "display Aci, Worlwide " in {
    val outDf= outputDf.select("UserFullName").filter(outputDf("clientid")==="000031")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="Aci, Worlwide"
  }

  "This test is for UserShortName  " should "display Aci, Worlwide " in {
    val outDf= outputDf.select("UserFullName").filter(outputDf("clientid")==="000031")
    val output=outDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="Aci, Worlwide"
  }

}
