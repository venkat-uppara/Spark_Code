package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.{CSICancelCodesDataController, CSISubclientProfilesDataController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually


case class CancelCode(profileid:String,CancelDesc:String,cancelcode:String)
case class SubClientProfileForCancel(profileid:String,clientid:String,subclientid:String)



class CancelCodeTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable {

  private val cancelCodeList = Array(CancelCode("7F2CCA90BCBA33C8E05400144FF8C329", "He is Fraud","111"),
    CancelCode("7F2CCA90BCBA33C8E05400144FF8C339", "He is not","111"))

  private val subClientPrfoileList = Array(SubClientProfileForCancel("7F2CCA90BCBA33C8E05400144FF8C329", "555577","123456"),
    SubClientProfileForCancel("7F2CCA90BCBA33C8E05400144FF8C339", "888887","654321"))

  private var cancelCode : CSICancelCodesDataController = _
  private var cancelCodeDf: DataFrame = _
  private var subClientPrfoileDf: DataFrame = _
  var outputDf:DataFrame=_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao= new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    cancelCodeDf = sc.sparkContext.parallelize(cancelCodeList).toDF()
    subClientPrfoileDf = sc.sparkContext.parallelize(subClientPrfoileList).toDF()
    cancelCode= new CSICancelCodesDataController(sc,dao)
    outputDf=cancelCode.joinedDf(cancelCodeDf,subClientPrfoileDf)
    outputDf.show(false)
  }

  "This test for CancelFraudYN  " should "display Y because cancelDesc contains word fraud " in {
    val cancelfraudynDf= outputDf.select("cancelfraudyn","profileid").filter(outputDf("profileid")==="7F2CCA90BCBA33C8E05400144FF8C329")
    val cancelfraudyn=cancelfraudynDf.collect().map(col=>col.getString(0)).mkString("")
    cancelfraudyn should be ==="Y"
  }

  "This test for CancelFraudYN  " should "display N because cancelDesc does not contains word fraud " in {
    val cancelfraudynDf= outputDf.select("cancelfraudyn","profileid").filter(outputDf("profileid")==="7F2CCA90BCBA33C8E05400144FF8C339")
    val cancelfraudyn=cancelfraudynDf.collect().map(col=>col.getString(0)).mkString("")
    cancelfraudyn should be ==="N"
  }

}
