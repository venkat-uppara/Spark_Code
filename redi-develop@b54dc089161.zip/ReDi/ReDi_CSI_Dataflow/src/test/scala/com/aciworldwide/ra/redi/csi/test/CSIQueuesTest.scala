package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.{CSICancelCodesDataController, CSIQueuesController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually

case class Queues(NAME:String,DESCRIPTION:String,CLIENT_ID:String,SUBCLIENT_ID:String,RANK_ORDER:String,QueueCMType:String,CREATED_DATE:String,MODIFIED_DATE:String,
                      QUEUE_TYPE:String,ACTION:String,ID:String,STATUS:String,RECOMMENDATION:String,CRITERIA:String,PRISM_SCORE:String,EFALCON_SCORE:String,EBCARDTYPE:String,
                      EBSHIPMETHOD:String,EBITEMSHIPMETHOD:String,VIRTBILLSHIP:String,BULK_CLICKBLOCK_SETTING:String,CREATED_BY:String,
                      MODIFIED_BY:String,REFERRING_SITE:String,CRITERIA_DEFINITION:String,CRITERIA_EXPRESSION:String,CRITERIA_UI:String,IS_TRANSFERABLE:String,CANCEL_CODE:String,
                      SCHEDULE_START:String,SCHEDULE_END:String,SCHEDULE_UI:String,NOTE:String,ORDER_TYPE:String,PEND_TIME:String)
class CSIQueuesTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable {

  private val queueList = Array(Queues("ff808081646f144e01646f50f73a0009", "ACI Worldwide","55557","123456","1","1","2019-02-11 04:21:13.391","2019-02-11 04:21:13.391",
  "NORMAL","DOIT","123456","ACTIVE","ACCEPT","ONE","ONE","TWO","DDD", "ADDS",
    "O","S","HH","YES","2019-02-11 04:21:13.391",
  "2019-02-11 04:21:13.391","BANG","ACCEPT","DONE","DO","YES","YES","111",
  "ADD","DFDF","QWEW","ABCDSE"),
    Queues("ff808081646f144e01646f50f73a0009", "ACI Worldwide","078130","123456","1","0","2019-02-11 04:21:13.391","2019-02-11 04:21:13.391",
      "NORMAL","DOIT","123456","ACTIVE","ACCEPT","ONE","ONE","TWO","DDD", "ADDS",
      "O","S","HH","YES","2019-02-11 04:21:13.391",
      "2019-02-11 04:21:13.391","BANG","ACCEPT","DONE","DO","YES","YES","111",
      "ADD","DFDF","QWEW","ABCDSE"))

  private var queues : CSIQueuesController = _
  private var queuesDf: DataFrame = _
  var outputDf:DataFrame=_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao= new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    queuesDf = sc.sparkContext.parallelize(queueList).toDF()
    queues= new CSIQueuesController(sc,dao)
    outputDf=queues.csiTransformation(queuesDf)
  }

  "This test for QueueID  " should "display 55557_123456 because QueueCMType is equal to 1 " in {
    val queueDf= outputDf.select("QueueID","QueueCMType","ClientId").filter(outputDf("ClientId")==="55557")
    val QueueID=queueDf.collect().map(col=>col.getString(0)).mkString("")
    QueueID should be ==="55557_123456"
  }

  "This test for QueueNumber  " should "display 123456 because cQueueCMType is equal to 1 " in {
    val queueDf= outputDf.select("QueueNumber","QueueCMType","ClientId").filter(outputDf("ClientId")==="55557")
    val QueueNumber=queueDf.collect().map(col=>col.getString(0)).mkString("")
    QueueNumber should be ==="123456"
  }

  "This test for QueueNumber  " should "display 0 because cQueueCMType is equal to 0 " in {
    val queueDf= outputDf.select("QueueNumber","QueueCMType","ClientId").filter(outputDf("ClientId")==="078130")
    val QueueNumber=queueDf.collect().map(col=>col.getString(0)).mkString("")
    QueueNumber should be ==="0"
  }

  "This test for QueueID  " should "display 123456 because QueueCMType is equal to 0 " in {
    val queueDf= outputDf.select("QueueID","QueueCMType","ClientId").filter(outputDf("ClientId")==="078130")
    val QueueID=queueDf.collect().map(col=>col.getString(0)).mkString("")
    QueueID should be ==="123456"
  }

}
