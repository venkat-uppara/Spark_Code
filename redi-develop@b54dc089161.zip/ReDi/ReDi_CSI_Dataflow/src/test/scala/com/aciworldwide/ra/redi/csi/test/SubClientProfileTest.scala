package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.CSISubclientProfilesDataController
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually

case class SubClientProfile(ID:String,CREATED_DATE:String,CREATED_BY:String,MODIFIED_DATE:String,MODIFIED_BY:String,CANCEL_ORDER_SERVICE_ENABLED:String,CLIENT_ID:String
                            ,SUBCLIENT_ID:String,CM_ENABLED:String,TIEBACK_URL:String,TIEBACK_REQ_HEADER:String,TIEBACK_REQ_BODY:String,TIEBACK_RETRY_DELAY:String
                           ,TIEBACK_RETRY_COUNT:String,TIEBACK_URL_1:String,TIEBACK_URL_2:String,TIEBACK_URL_3:String,TXN_HOLD_TIME:String,TXN_NOTE_1:String
                           ,TXN_NOTE_2:String,TXN_NOTE_3:String,TXN_NOTE_4:String,NUM_RULES:String,NUM_QUEUES:String,SUMMARY_CHALLENGE_PCT_ALERT:String
                           ,SUMMARY_DENY_PCT_ALERT:String,CB_CHALLENGE_PCT_ALERT:String,CB_DENY_PCT_ALERT:String,CB_ACCEPT_PCT_ALERT:String,REPORT_EMAIL:String
                           ,LOGO_FILENAME:String,OUTSORTED_RECOMMENDATIONS:String,CB_FIELDS:String,PEND_TIME:String,MAX_QUEUE_USERS:String,TXN_SEARCH_FIELDS:String
                           ,TXN_RESULT_FIELDS:String,SELECTED_WIDGETS:String,TZ_CODE:String,SESSION_TIMEOUT:String,LOGO_FILE:String,IS_VISIBLE_TO_PRIMARY:String
                           ,TXN_NOTE_5:String,TXN_NOTE_6:String,TXN_NOTE_7:String,TXN_NOTE_8:String,TXN_NOTE_9:String,TXN_NOTE_10:String,MAX_HEAT_MAP_SCORE:String
                           ,VIEW_NON_PRIMARY_SYSTEM_QUEUE:String)


class SubClientProfileTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable {

  private val subClientProfileList = Array(
  SubClientProfile("1A4EAAF8A7EB316AE05400144FFB46A6","07-07-15 02:16:52.462304000","0","07-07-15 02:16:52.462304000","0","0","702343"
                   ,"100326","1","","","","0"
                   ,"1","","","","300",""
                   ,"","","","5","5",""
                   ,"","","","",""
                   ,"","","","",""
                   ,"","","","","",""
                   ,"","","","","","","","",""),
    SubClientProfile("1A4EAAF8A7EB316AE05400144FFB46A6","07-07-15 02:16:52.462304000","0","07-07-15 02:16:52.462304000","0","0","702344"
      ,"100326","0","","","","0"
      ,"1","","","","300",""
      ,"","","","5","5",""
      ,"","","","",""
      ,"","","","",""
      ,"","","","","",""
      ,"","","","","","","","",""),
    SubClientProfile("1A4EAAF8A7EB316AE05400144FFB4333","07-07-15 02:16:52.462304000","0","07-07-15 02:16:52.462304000","0","0","000194"
      ,"789654","0","","","","0"
      ,"1","","","","300",""
      ,"","","","5","5",""
      ,"","","","",""
      ,"","","","",""
      ,"","","","","",""
      ,"","","","","","","","",""))

  private var subClientPRofile : CSISubclientProfilesDataController = _
  private var subClientProfileDf: DataFrame = _
  var outputDf:DataFrame=_

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao= new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    subClientProfileDf = sc.sparkContext.parallelize(subClientProfileList).toDF()
    subClientPRofile= new CSISubclientProfilesDataController(sc,dao)
    outputDf=subClientPRofile.csiTransformation(subClientProfileDf)
    outputDf.show(false)
  }

  "This test is for cmEnabled  " should "display Y for clientid 702343 " in {
   val cmenabledDF= outputDf.select("cmenabled","clientid").filter(outputDf("clientid")==="702343")
    val cmEnabled=cmenabledDF.collect().map(col=>col.getString(0)).mkString("")
    cmEnabled should be ==="Y"
  }

 "This test is for cmEnabled  " should "display N for clienid 702344 " in {
    val cmenabledDF= outputDf.select("cmenabled","clientid").filter(outputDf("clientid")==="702344")
    val cmEnabled=cmenabledDF.collect().map(col=>col.getString(0)).mkString("")
    cmEnabled should be ==="N"
  }

  "This test is for clientid  " should "display be 989194 for clienid 000194 " in {
    val clientidDf= outputDf.select("clientid").filter(outputDf("clientid")==="989194")
    val clientid=clientidDf.collect().map(col=>col.getString(0)).mkString("")
    clientid should be ==="989194"
  }

  "This test is for clientid  " should "display be 702344 for clienid 702344 " in {
    val clientidDf= outputDf.select("clientid").filter(outputDf("clientid")==="702344")
    val clientid=clientidDf.collect().map(col=>col.getString(0)).mkString("")
    clientid should be ==="702344"
  }

  "This test is for client12  " should "display be 702344100326 for clienid 702344 " in {
    val client12Df= outputDf.select("client12","clientid").filter(outputDf("clientid")==="702344")
    val client12=client12Df.collect().map(col=>col.getString(0)).mkString("")
    client12 should be ==="702344100326"
  }

  "This test is for client12  " should "display be 989194789654 for clienid 000194 " in {
    val client12Df= outputDf.select("client12","clientid").filter(outputDf("clientid")==="989194")
    val client12=client12Df.collect().map(col=>col.getString(0)).mkString("")
    client12 should be ==="989194789654"
  }
}
