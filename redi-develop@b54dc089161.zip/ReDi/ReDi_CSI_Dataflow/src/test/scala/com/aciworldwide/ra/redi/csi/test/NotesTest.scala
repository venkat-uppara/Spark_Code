package com.aciworldwide.ra.redi.csi.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.csi.controllers.{CSIAccessDataController, CSINotesDataController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually


case class Notes(ID:String,OID:String,CREATED_DATE:String,CREATED_BY:String,MODIFIED_DATE:String,MODIFIED_BY:String,Note:String,notetype:String,NOTE_SOURCE:String,
                 ORDER_STATUS:String,USER_ACTION:String)
case class UsersNotes(ClientId:String,SubClientId:String,Client12:String,UserName:String,UserFullName:String,UserId:String)




class NotesTest extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants with Serializable {
  private var notes: CSINotesDataController = _
  private var userDf: DataFrame = _
  private var noteDf: DataFrame = _
  var outputDf: DataFrame = _

  private val notesList = Array(
    Notes("8abd31d968846a1201688490b2fe0008","050510000001TAK20190116015241543","2019-01-25 16:01:42.075","15002","2019-01-25 16:01:42.075","","modified by SYSTEM","ABCKSKJSDKD","ACTION",
    "ACCEPT","this notes is correct"),
    Notes("8abd31d968846a1201688490b2fe0444","050510000001TAK20190116015241543","2019-01-25 16:01:42.075","15002","2019-01-25 16:01:42.075","","modified by manual","ABCKSKJSDKD","ACTION",
      "ACCEPT",""),
    Notes("8abd31d968846a1201688490b2fe0555","050510000001TAK20190116015241543","2019-01-25 16:01:42.075","15003","2019-01-25 16:01:42.075","","modified by SYSTEM Pending","ABCKSKJSDKD","ACTION",
      "ACCEPT",""))

  private val usersList = Array(
    UsersNotes("078130","123456","078130123456","Rakesh","Rakesh G","15002"),
    UsersNotes("078130","123456","078130123456","ABC","Abc G","15003"))


  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    val dao = new CSIDataDao(_sqlc)
    import _sqlc.implicits._

    noteDf = _sqlc.sparkContext.parallelize(notesList).toDF()
    userDf = _sqlc.sparkContext.parallelize(usersList).toDF()

    notes = new CSINotesDataController(_sqlc, dao)
    outputDf = notes.joinedDF(noteDf, userDf)
    outputDf.show(false)
  }



  "This test is for systemormanual  " should "display S as note Columns contains word SYSTEM " in {
    val notesDf= outputDf.select("systemormanual","clientid").filter(outputDf("noteid")==="8abd31d968846a1201688490b2fe0008")
    val output=notesDf.collect().map(col=>col.getString(0)).mkString("")
    output should be ==="S"
  }

  "This test is for systemormanual  " should "display M as note Columns  does not contains word SYSTEM " in {
    val notesDf= outputDf.select("systemormanual","noteid").filter(outputDf("noteid")==="8abd31d968846a1201688490b2fe0444")
    val output=notesDf.collect().map(col=>col.getString(0)).mkString("")
    output should be === "M"
  }


  "This test is for NoteAction  " should "display  " in {
    val notesDf= outputDf.select("NoteAction","noteid").filter(outputDf("noteid")==="8abd31d968846a1201688490b2fe0008")
    val output=notesDf.collect().map(col=>col.getString(0)).mkString("")
    output should be === "This notes is correct"
  }

  "This test is for NoteAction  " should "display NOTE as noteaction is empty but systemmanual is M  " in {
    val notesDf= outputDf.select("NoteAction","noteid").filter(outputDf("noteid")==="8abd31d968846a1201688490b2fe0444")
    val output=notesDf.collect().map(col=>col.getString(0)).mkString("")
    output should be === "Note"
  }

  "This test is for NoteAction  " should "display Pend as note value shoud match regex with PEND  " in {
    val notesDf= outputDf.select("NoteAction","noteid").filter(outputDf("noteid")==="8abd31d968846a1201688490b2fe0555")
    val output=notesDf.collect().map(col=>col.getString(0)).mkString("")
    output should be === "Pend"
  }

}
