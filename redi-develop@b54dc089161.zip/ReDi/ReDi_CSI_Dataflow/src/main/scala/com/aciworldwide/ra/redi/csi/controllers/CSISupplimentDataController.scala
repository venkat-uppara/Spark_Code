/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

abstract class CSISupplimentDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao )    extends CSIBaseDataController (sparkSession: SparkSession, csiDataDao: CSIDataDao ) {

  import sparkSession.implicits._

  override def isProcessController (): Boolean = {
    false
  }

  override def getHiveTableName(): String = {
    null //do nothing here as this is supplement class
  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    null //do nothing here as this is supplement class
  }

  override def getLocalHDFSStorageValue(): String = {
    null //do nothing here as this is supplement class
  }

}

