package com.aciworldwide.ra.redi.csi.utils

import java.text.{ParseException, SimpleDateFormat}
import java.util.Calendar

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

trait CSIUtils  extends DateUtils with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices
   {


     @transient lazy val csiUtilsLog = LogManager.getLogger(getClass.getName)


  def addoffset(): String = {


    var simpleDateFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)

    val calendar = Calendar.getInstance()
    calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY) + ConfigFactory.load().getInt("local.common.csi.timeoffset")  )

    formatDateString(calendar.getTimeInMillis(), DATEFORMATYYYY_MM_DD_HHMMSS)
  }

  /** This method is used to connect to Oracle database
    * Retrieve csi data from respective tables overridden methods table. */
  def fetchCSIData(csiDataDao: CSIDataDao, query: String, connectiontype: String, schemaname: String): DataFrame = {
    ("Starting to Fetch csi data into the processing layer " + schemaname + "." + query)
    csiDataDao.fetchCSIData(query, connectiontype, schemaname,CSI_DATA_CODE_PARTS)
  }




  def remapClientIDsForIKEA: UserDefinedFunction = udf((clientId: String, subClientId: String) => {
      var clientId_1 = clientId
      if (clientId != null && clientId.equals("000194")) {
        clientId_1 = clientId_1.concat("9").concat(subClientId.substring(1,2)).concat("194")
      }
      clientId_1
    })


    def remapClient12IDsForIKEA: UserDefinedFunction = udf((client12: String, clientId: String, subClientId: String) => {
      var clientId_1 = client12
      if (clientId != null &&  clientId.equals("000194")) {
        clientId_1 = clientId_1.concat("9").concat(subClientId.substring(1,2)).concat("194").concat(subClientId)
      }
      clientId_1
})

  def dateYYYYMMDDWithoutTimePart = udf ((notedate: String) => {
    var date = ""
   if (notedate == null || notedate.isEmpty)  {
       ""
    }else{
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)

      try {
       date =  outputFormat.format(inputFormat.parse(notedate))
      } catch  {
          case ex : ParseException  => csiUtilsLog.error(CSIDATAPROCESS_ERROR+":Unparseable date")
      }
    }
    date
  })

  def dateYYYYMMDD(date: String): String = {
    var result = ""
    if (date == null || date.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
      try {
        result = outputFormat.format(inputFormat.parse(date))
      } catch {
        case ex: ParseException => csiUtilsLog.error(CSIDATAPROCESS_ERROR+":Unparseable date")
      }
    }
    result
  }

  def storeTransDetailtoHive(ProcessTransDetailDF: DataFrame): Unit = {
    csiUtilsLog.debug(CSIDATAPROCESS_DEBUG+"Started pushing the data into Hive tables " + REDI_TRAN_DETAIL_ON_WRITE_TABLE)
    StorethedataintoHive(REDI_TRAN_DETAIL_ON_WRITE_TABLE, APPEND_MODE, ProcessTransDetailDF)
  }

  def storeInputClientMastertoHive (inputdataset: DataFrame): Boolean ={
    var isClientMastertoHive :Boolean = false;
    csiUtilsLog.debug(CSIDATAPROCESS_DEBUG+"Starting to push the data into Hive tables " + REDI_RBI_REF_CLIENT)
    try {
      StorethedataintoHive(REDI_RBI_REF_CLIENT, APPEND_MODE, inputdataset)
      isClientMastertoHive = true;
    }catch{
      case exce: Exception => csiUtilsLog.error(CSIDATAPROCESS_ERROR+"We have an error on storing data into Hive" +  exce)
        isClientMastertoHive
    } finally {
      csiUtilsLog.debug(CSIDATAPROCESS_ERROR+"End of Storing ClientMaster data into Hive")
      isClientMastertoHive
    }
    isClientMastertoHive
  }

  def toCamelCase ( noteAction: String): String = {

    var outputstring =  noteAction

    if (noteAction != null && noteAction.length > 0) {
      outputstring = noteAction.substring(0, 1).toUpperCase() +
        noteAction.substring(1).toLowerCase()
    }
    outputstring
  }

  def dateFormat = udf((inputDate: String, outputfomat: String) => {

    var date = ""
    if (inputDate == null || inputDate.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(outputfomat)

      try {
        date = outputFormat.format(inputFormat.parse(inputDate))
      } catch {
        case ex: ParseException => csiUtilsLog.error(CSIDATAPROCESS_ERROR+":Unparseable date")
      }
    }
    date
  })



}
