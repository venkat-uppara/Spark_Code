/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */


package com.aciworldwide.ra.redi.csi.controllers


import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSINotesDataController.csiNotesLog
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


object CSINotesDataController extends ReDiConstants with Serializable {

  @transient lazy val csiNotesLog = LogManager.getLogger(getClass.getName)
  val testRegex = ".*Transferred.*".r
  val testRegex1 = ".*Pending.*".r
  val testRegex2 = ".*Tieback.*".r
  val testRegex3 = ".*Released.*".r
  val testRegex4 = ".*Cancelled.*".r
  val testRegex5 = ".*Cancel.*Web.*Serv.*".r

  def getNoteAction(systemorManual: String, noteText: String, noteAction: String): String = {
    //var outputString: String = toCamelCase(noteAction)
    var outputString: String = noteAction
    if (noteAction != null && noteAction.length > 0) {
      outputString = noteAction.substring(0, 1).toUpperCase() +
        noteAction.substring(1).toLowerCase()
    }
    if (noteAction == null || (noteAction != null && (noteAction.isEmpty || noteAction.equals("null")))) {


      if (systemorManual.equals("M")) {
        outputString = "Note"
      } else {


        outputString = noteText match {
          case testRegex() => "Transfer"
          case testRegex1() => "Pend"
          case testRegex2() => "Tieback"
          case testRegex3() => "Released"
          case testRegex4() => "Cancel"
          case testRegex5() => "CancelW/S"
          case _ => noteText
        }
      }
    }
    outputString
  }
}

class CSINotesDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants {

  val QueueNotesCSI1 = new CSI1QueueNotesDataController(sparkSession, csiDataDao)


  import sparkSession.implicits._

  override def getHiveTableName(): String = {
    REDI_CSI_NOTES_HIVE_TABLE
  }

  def updateNoteText = udf((noteText: String) => {
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Inside updateNoteText method")

    var outputstring = noteText

    outputstring = outputstring.replace("x0a", "<br>")
    outputstring = outputstring.replace("x0d", "")
    outputstring = outputstring.replace("x09", " ")
    outputstring = outputstring.replace("\\", "")
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "completed updateNoteText method")
    outputstring

  })


  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiNotesLog.info(CSIDATAPROCESS_INFO + "Inside csiTransformation method")

    val usersDF = hiveSession.executeQuery("Select * from redi.CSI_USERS").select(
      $"ClientId".alias("ClientIdUser"), $"SubClientId".alias("SubClientIdUser"), $"UserName", $"UserFullName", $"UserId")

    var outputDF = joinedDF(inputDataFrame, usersDF)

    outputDF = reorderSourceTableSchema(CSI_TXN_NOTES_TABLE_COL_ORDER, addAuditColumns(outputDF))
    csiNotesLog.info(CSIDATAPROCESS_INFO + "Completed csiTransformation method")
    outputDF
  }


  def joinedDF(notedDf: DataFrame, usersDf: DataFrame): DataFrame = {
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Inside joinedDF method")
    val joinedDF = notedDf.join(usersDf, notedDf.col("CREATED_BY") === usersDf.col("UserId"), "left_outer")

    var outputDF = joinedDF.select(
      $"ID".alias("noteid"),
      $"OID",
      $"CREATED_DATE".alias("NOTEDATETIME"),
      $"CREATED_BY".alias("createdby"),
      $"MODIFIED_DATE".alias("modifieddate"),
      $"MODIFIED_BY".alias("modifiedby"),
      $"Note".alias("notetext"), $"notetype",
      $"NOTE_SOURCE".alias("notesource"),
      $"ORDER_STATUS".alias("NoteStatus"),
      $"clientid",
      $"subclientid",
      $"userid",
      $"username",
      $"CREATED_DATE".alias("notedatetimeclient"),
      $"USER_ACTION",
      $"ClientIdUser",
      $"SubClientIdUser",
      when(col("userfullname").isNotNull, $"userfullname").otherwise($"username").alias("userfullname")
    )
      //.withColumn("NoteAction" , funcAddTransformedColumns($"USER_ACTION" , lit("NoteAction") , lit(true) ).alias("NoteAction"))
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("systemormanual", when(col("notetext").like("%SYSTEM%"), lit("S")).otherwise("M"))
      .withColumn("notedateyyyymmdd", CSICommonMethods.dateYYYYMMDDWithoutTimePart($"notedatetimeclient"))
      .withColumn("NoteAction",
        updateNoteAction(col("systemormanual"), col("NoteText"), col("USER_Action")))
      .withColumn("notetext", updateNoteText(col("notetext")))
      .withColumn("clientid", when(col("clientid") === lit("novalue"), $"ClientIdUser").otherwise($"clientid"))
      .withColumn("subclientid", when(col("subclientid") === lit("novalue"), $"SubClientIdUser").otherwise($"subclientid"))

    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Completed joinedDF method")
    outputDF
  }


  def updateNoteAction = udf((systemorManual: String, noteText: String, noteAction: String) => {
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Inside updateNoteAction UDF")
    val result = CSINotesDataController.getNoteAction(systemorManual, noteText, noteAction)
    result
  })


  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_NOTES_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_NOTES_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_NOTES_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_TXN_NOTES_CONTROL_KEY
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE " + getRawDataFrameHWMColumn() + " > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and " + getRawDataFrameHWMColumn() + "  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  override def setRawDataframe(RawCSIDataDF: DataFrame): Unit = {

    QueueNotesCSI1.CSIDataPipeline()

    val QueueNotesCSI1DF = QueueNotesCSI1.getRawDataframe()

    val df = RawCSIDataDF.withColumn("clientid", lit("novalue"))
      .withColumn("subclientid", lit("novalue"))

    val txnNotesDF = df.union(QueueNotesCSI1DF)

    super.setRawDataframe(txnNotesDF)
  }


  override def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    super.updateControlTables(RawCSIDataDF)

    QueueNotesCSI1.updateControlTables(QueueNotesCSI1.getRawDataframe())

  }

  def csiPreTransformation(inputDataFrame: DataFrame): DataFrame = {
    inputDataFrame.withColumn("NoteType", lit("T2"))
  }

  override def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    var txnNOtesDF = super.fetchRawDataFromODS(CSIHWMID)

    txnNOtesDF = csiPreTransformation(txnNOtesDF)

    txnNOtesDF
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Inside storeInput2Hive method" + this.getClass)
    hiveSession.executeUpdate("delete from REDI.CSI_NOTES_ON_WRITE")
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    hiveSession.executeUpdate("MERGE INTO REDI.CSI_NOTES AS D USING " +
      " (SELECT * FROM REDI.CSI_NOTES_ON_WRITE) AS S ON (D.NOTEID=S.NOTEID AND D.OID=S.OID) WHEN MATCHED THEN " +
      "UPDATE SET OID=S.OID,CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,USERID=S.USERID,USERNAME=S.USERNAME," +
      "USERFULLNAME=S.USERFULLNAME,NOTEID=S.NOTEID,NOTETEXT=S.NOTETEXT,NOTETYPE=S.NOTETYPE,NOTESOURCE=S.NOTESOURCE,SYSTEMORMANUAL=S.SYSTEMORMANUAL," +
      "NOTESTATUS=S.NOTESTATUS,NOTEACTION=S.NOTEACTION,CREATEDBY=S.CREATEDBY,NOTEDATETIME=S.NOTEDATETIME,NOTEDATETIMECLIENT=S.NOTEDATETIMECLIENT," +
      "MODIFIEDBY=S.MODIFIEDBY,MODIFIEDDATE=S.MODIFIEDDATE,WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED,NOTEDATEYYYYMMDD=S.NOTEDATEYYYYMMDD" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.OID,S.CLIENTID,S.SUBCLIENTID,S.USERID,S.USERNAME,S.USERFULLNAME,S.NOTEID,S.NOTETEXT,S.NOTETYPE," +
      "S.NOTESOURCE,S.SYSTEMORMANUAL,S.NOTESTATUS,S.NOTEACTION,S.CREATEDBY,S.NOTEDATETIME,S.NOTEDATETIMECLIENT,S.MODIFIEDBY,S.MODIFIEDDATE," +
      "S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED,S.NOTEDATEYYYYMMDD)")

    val csiPends1DF = inputDataFrame.select($"OID",
      $"UserId",
      $"NoteId",
      $"NoteDateTime".as("penddatetime")
    ).where(col("notetext").like("%SYSTEM%Trans%Pending%") && col("notesource") === "Q1")
      .withColumn("pendsource", lit("C1"))

    val csiPends2DF = inputDataFrame.select($"OID",
      $"UserId",
      $"NoteId",
      $"NoteDateTime".as("penddatetime")
    ).where(col("NoteSource") === "CM" && (col("NoteAction") === "Pend" || col("NoteAction") === "PEND" || col("NoteAction") === "pend"))
      .withColumn("pendsource", lit("C2"))


    val csiPendsDF =
      csiPends1DF.union(csiPends2DF)
    val pends = reorderSourceTableSchema(CSI_PENDS_COL_ORDER, addAuditColumns(csiPendsDF))
    pends.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_PENDS").save()
    csiNotesLog.debug(CSIDATAPROCESS_DEBUG + "Completed storeInput2Hive method" + this.getClass)
  }
}

