/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSIAccessDataController.{CSIDATAPROCESS_DEBUG, csiAccessDataController}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession._
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object CSIAccessDataController extends ReDiConstants with Serializable {

  @transient lazy val csiAccessDataController = LogManager.getLogger(getClass.getName)

  def remapClientIDsForIKEA(clientId: String, subClientId: String): String = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ":inside remapClientIDsForIKEA" + clientId + ":" + subClientId)
    var clientId_1 = clientId
    if (clientId != null && subClientId != null && clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194")
    }
    csiAccessDataController.info("completed remapClientIDsForIKEA:" + clientId_1)
    clientId_1
  }


  def remapClient12IDsForIKEA(client12: String, clientId: String, subClientId: String): String = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ":inside remapClient12IDsForIKEA" + clientId + ":" + subClientId)
    var clientId_1 = client12
    if (clientId != null && subClientId != null && clientId.equals("000194")) {
      clientId_1 = clientId_1.concat("9").concat(subClientId.substring(1, 2)).concat("194").concat(subClientId)
    }
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ":completed remapClient12IDsForIKEA" + clientId + ":" + subClientId)
    clientId_1
  }

  def ConvertTimeZone(inputdate: String, targetTimeZone: String): Timestamp = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ":inside ConvertTimeZone method")
    val simpleformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))
    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }

  def addClientDt(acceeDate: String, timeZone: String, inputFormat: String, outputFormat: String): String = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Inside addClientDt UDF")
    var updDate: String = ""
    if (!acceeDate.isEmpty && acceeDate != null) {
      val ClientDate =
        if (timeZone != null && !timeZone.isEmpty) {
          ConvertTimeZone(acceeDate, timeZone)
        } else {
          ConvertTimeZone(acceeDate, "EST")
        }
      val inputFormatSDF = new SimpleDateFormat(inputFormat)
      val outputFormatSDF = new SimpleDateFormat(outputFormat)
      updDate = outputFormatSDF.format(inputFormatSDF.parse(ClientDate.toString))

    }
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Completed addClientDt UDF")
    updDate
  }

  def convertToDateFormatYYYYMMDD: UserDefinedFunction = udf((inputDate: String) => {
    if (inputDate != null) {
      val inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      val outputFormat = new SimpleDateFormat("yyyyMMdd")
      outputFormat.format(inputFormat.parse(inputDate))
    }
    else {
      ""
    }
  })

}

class CSIAccessDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants
  with Serializable {

  import sparkSession.implicits._


  override def getHiveTableName(): String = {
    REDI_CSI_ACCESS_HIVE_TABLE
  }

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_ACCESS_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_ACCESS_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_ACCESS_ODS_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_ACCESS_CONTROL_KEY
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE ACCESS_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and  ACCESS_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }


  def addClientDateTime(inputDf: DataFrame, rbiRefClient: DataFrame): DataFrame = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Inside addClientDateTime Method")
    val joinedDf = inputDf.join(rbiRefClient, Seq("clientid", "SUBCLIENTID"), "left_outer")
    val addedClientDtDf = joinedDf.withColumn("accessdatetimeclient", when(col("AccessDateTime").isNotNull,
      CSICommonMethods.addClientDt(col("AccessDateTime"), col("TZClient"), lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))
      .withColumn("accessdateyyyymmdd", CSIAccessDataController.convertToDateFormatYYYYMMDD($"AccessDateTime"))
      .withColumn("accessdatetimeclient", when(col("accessdatetimeclient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"accessdatetimeclient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Completed addClientDateTime Method")
    addedClientDtDf
  }

  def addClienttimeZone: UserDefinedFunction = udf((userLastAccess: String, timeZone: String, inputFormat: String, outputFormat: String) => {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Inside addClienttimeZone UDF")
    CSIAccessDataController.addClientDt(userLastAccess, timeZone, inputFormat, outputFormat)
  })

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiAccessDataController.info(CSIDATAPROCESS_INFO + ": Inside csiTransformation Method" + this.getClass)
    val usersDF = hiveSession.executeQuery("Select * from " + REDI_CSI_USERS_TABLE + "").select(
      $"ClientId", $"SubClientId", $"Client12", $"UserName", $"UserFullName", $"UserId", $"whenloaded")
    //val usersDF  = new CSIDataDao(sparkSession).getUsersTable.

    val reorderdedinputDF = inputDataFrame.select($"ID".alias("accessid"), $"USER_ID".alias("USERID"), $"ACCESS_TYPE".alias("accesstype"), $"ACCESS_RESULT".alias("accessresult"), $"ACCESS_DATE".alias("accessdatetime"))


    val outputDataFrame = joinedDf(reorderdedinputDF, usersDF)


    val rbiRefClient = hiveSession.executeQuery("select clientid,SUBCLIENTID,tzclient from  redi.rbi_ref_client").select("clientid", "SUBCLIENTID", "tzclient")
    val updOutputDataFrame = addClientDateTime(outputDataFrame, rbiRefClient).withColumn("accessyymmddclient", CSIAccessDataController.convertToDateFormatYYYYMMDD($"accessdatetimeclient"))
    csiAccessDataController.info(CSIDATAPROCESS_INFO + ": Completed csiTransformation Method csiaccessdatacontroller" + this.getClass)
    reorderSourceTableSchema(CSI_ACCESS_TABLE_COL_ORDER, addAuditColumns(updOutputDataFrame))
  }

  def joinedDf(accessDf: DataFrame, usersDf: DataFrame): DataFrame = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": Inside joinedDf Method")
    val joinedDF = accessDf.join(usersDf, Seq("UserId"), "left_outer")
    val outputDataFrame = joinedDF.select($"clientid",
      $"subclientid",
      $"client12",
      $"userid",
      $"username",
      $"userfullname",
      $"accesstype",
      $"accessresult",
      $"accessdatetime",
      $"accessid"
    )
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("client12", CSICommonMethods.remapClient12IDsForIKEA(concat(col("CLIENTID"), col("SUBCLIENTID")), col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("loginyn", when((col("AccessType") === "LOGIN" && col("AccessResult") === "SUCCESS"), lit("Y")).otherwise(lit("N")))
      .withColumn("logoutyn", when((col("AccessType") === "LOGOUT" && col("AccessResult") === "SUCCESS"), lit("Y")).otherwise(lit("N")))
      .withColumn("deltaminutes", lit(""))
      .withColumn("accessdatetimeclient", lit(""))
      .withColumn("accessyymmddclient", lit(""))
      .withColumn("accessdateyyyymmdd", lit(""))
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ": completed joinedDf Method")
    outputDataFrame
  }

}

