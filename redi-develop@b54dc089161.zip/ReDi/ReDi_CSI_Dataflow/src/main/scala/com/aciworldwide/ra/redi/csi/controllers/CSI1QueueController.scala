/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

class CSI1QueueController (sparkSession: SparkSession, csiDataDao: CSIDataDao )   extends CSISupplimentDataController (sparkSession: SparkSession, csiDataDao: CSIDataDao )  {

  @transient lazy val csi1QueueLog = LogManager.getLogger(getClass.getName)

  private var CSIQUEUES_COLUMN_ORDER = "ID,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,CLIENT_ID,SUBCLIENT_ID,STATUS,QUEUE_TYPE,RANK_ORDER,NAME,DESCRIPTION,REFERRING_SITE,CRITERIA_DEFINITION,CRITERIA_EXPRESSION,CRITERIA_UI,IS_TRANSFERABLE,RECOMMENDATION,CRITERIA,PRISM_SCORE,EFALCON_SCORE,EBCARDTYPE,EBSHIPMETHOD,EBITEMSHIPMETHOD,VIRTBILLSHIP,BULK_CLICKBLOCK_SETTING,CANCEL_CODE,SCHEDULE_START,SCHEDULE_END,SCHEDULE_UI,NOTE,ORDER_TYPE,PEND_TIME,QueueCMType,ACTION"


  import sparkSession.implicits._

  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_CSI1_QUEUES_TABLE_HWM_COLUMN
  }

  override def getStartRawDataFrameHWMColumn(): String = {
    REDI_HIVE_CSI1_QUEUES_TABLE_HWM_COLUMN
  }
  def getODSTableName(): String = {
    REDI_CSI_CSI1_QUEUES_ODS_TABLE_NAME
  }

  def getControlKey(): String = {
    REDI_CSI_CSI1_QUEUES_CONTROL_KEY
  }


  def getODSWhereCondition(value: String): String = {
    " WHERE QID > '" + value + "'"

  }

  override def setRawDataframe(RawCSIDataDF: DataFrame) = {
    csi1QueueLog.info(CSIDATAPROCESS_INFO+":Inside setRawDataframe Method")
    this.rawDataFrame =
      RawCSIDataDF.select(
        $"QID".alias("ID"),
        $"CLIENTID".alias("CLIENT_ID"),
            $"SUB_CLIENTID".alias("SUBCLIENT_ID"),
            $"NAME",
            $"NAME".alias("DESCRIPTION"),
            $"RECOMMENDATION",
            $"GLOB_RANK".alias("RANK_ORDER"),
            $"CRITERIA",
            $"PRISM_SCORE",
            $"EFALCON_SCORE",
            $"EBCARDTYPE",
            $"EBSHIPMETHOD",
            $"EBITEMSHIPMETHOD",
            $"VIRTBILLSHIP",
            $"BULK_CLICKBLOCK_SETTING"

      ).withColumn("CREATED_BY",lit(""))
      .withColumn("CREATED_DATE",lit(""))
      .withColumn("MODIFIED_BY",lit(""))
      .withColumn("MODIFIED_DATE",lit(""))
      .withColumn("STATUS",lit("Y"))
      .withColumn("QUEUE_TYPE",lit(""))
      .withColumn("REFERRING_SITE",lit(""))
      .withColumn("CRITERIA_DEFINITION",lit(""))
      .withColumn("CRITERIA_EXPRESSION",lit(""))
      .withColumn("CRITERIA_UI",lit(""))
      .withColumn("IS_TRANSFERABLE",lit(""))
      .withColumn("CANCEL_CODE",lit(""))
      .withColumn("SCHEDULE_START",lit(""))
      .withColumn("SCHEDULE_END",lit(""))
      .withColumn("SCHEDULE_UI",lit(""))
      .withColumn("NOTE",lit(""))
      .withColumn("ORDER_TYPE",lit(""))
      .withColumn("PEND_TIME", lit(""))
        .withColumn("QueueCMType", lit("1"))
        .withColumn("ACTION", lit(""))


        this.rawDataFrame = reorderSourceTableSchema(CSIQUEUES_COLUMN_ORDER,rawDataFrame)
  }


}

