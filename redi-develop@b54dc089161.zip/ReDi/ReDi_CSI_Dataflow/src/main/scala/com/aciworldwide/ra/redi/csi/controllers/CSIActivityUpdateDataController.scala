/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.{CSICommonMethods, CSIUtils}
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class CSIActivityUpdateDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends DateUtils with CSIUtils with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices {

  import sparkSession.implicits._

  @transient lazy val csiActivityLog = LogManager.getLogger(getClass.getName)
  val hiveSession = HiveWarehouseSession.session(sparkSession).build()
  hiveSession.setDatabase(REDI_DATABASE)

  @transient lazy val csiActivityUpdateLog = LogManager.getLogger(getClass.getName)

  def process(): Unit = {

    csiActivityUpdateLog.debug(CSIDATAPROCESS_DEBUG + "Inside process method")

    val hwm = getHWMId(REDI_CSI_ACTIVITY_UPDATE_ACCESS_CONTROL_KEY)
    val hwmYYYYMMDD = dateYYYYMMDD(hwm)
    var csiAccessDF = hiveSession.executeQuery("select * from " + REDI_CSI_ACCESS_HIVE_TABLE + "")
      .filter($"AccessDateTime".gt(hwm) && $"accessdateyyyymmdd".gt(hwmYYYYMMDD) && $"AccessResult".equalTo("SUCCESS"))


    val csiNotesDF = hiveSession.executeQuery("Select * from " + REDI_CSI_NOTES_TABLE + "")
      .where("NoteDateTime > '" + getHWMId(REDI_CSI_ACTIVITY_UPDATE_NOTES_CONTROL_KEY) + "'")


    val csiUsersDF = hiveSession.executeQuery("Select * from " + REDI_CSI_USERS_TABLE + "").filter($"CASEMANAGERYN".equalTo("Y")).select("UserId")


    var activityDF = csiAccessDF.join(csiUsersDF, Seq("UserId"), "inner")


    activityDF = activityDF.select($"UserId",
      $"UserName",
      $"UserFullName",
      $"AccessDateTime".alias("ActionTime"),
      when($"AccessType" === lit("LOGOUT"), lit("Logout")).otherwise(lit("Login")).alias("UserAction"),
      when($"AccessType" === lit("LOGOUT"), lit("Successful Logout")).otherwise(lit("Successful Login")).alias("NoteText"),
      $"ClientId",
      substring($"Client12", 7, 6).alias("SubClientId"),
      $"Client12",
      $"WhenLoaded",
      lit("").alias("OID")
    ).withColumn("ActionYYYYMMDD", CSICommonMethods.dateYYYYMMDDWithoutTimePart($"ActionTime"))
      .withColumn("TransactionId", lit(""))


    var activityNotesDF = csiNotesDF.join(csiUsersDF, Seq("UserId"), "inner")

    activityNotesDF = activityNotesDF.select($"UserId",
      $"UserName",
      $"UserFullName",
      $"NoteDateTime".alias("ActionTime"),
      $"NoteAction".alias("UserAction"),
      $"NoteText",
      $"ClientId",
      $"SubClientId",
      concat($"ClientId", $"SubclientId").alias("Client12"),
      $"WhenLoaded",
      $"OID"
    ).withColumn("ActionYYYYMMDD", CSICommonMethods.dateYYYYMMDDWithoutTimePart($"ActionTime"))


    val csiCasesDF = gettheDataFromHive(sparkSession, REDI_CSI_CASES_TABLE).select($"TransactionId", $"OID")

    activityNotesDF = activityNotesDF.join(csiCasesDF, Seq("OID"), "inner")
    activityNotesDF = super.reorderSourceTableSchema(CSI_ACTIVITY_UPDATE_1_COL_ORDER, activityNotesDF)
    activityDF = super.reorderSourceTableSchema(CSI_ACTIVITY_UPDATE_1_COL_ORDER, activityDF)

    activityDF = activityDF.union(activityNotesDF)

    activityDF = activityDF.withColumn("InternalKey", monotonically_increasing_id())
      .withColumn("StartTime", lit(""))
      .withColumn("SecondsTaken", lit(""))


    activityDF = super.reorderSourceTableSchema(CSI_ACTIVITY_UPDATE_COL_ORDER, addAuditColumns(activityDF))


    activityDF.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE).save()

    var activityUpdatedDF = hiveSession.executeQuery("Select * from " + REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE + " Where Whenloaded  =  (Select Max(Whenloaded) from " + REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE + ")")

    activityUpdatedDF.createTempView("tmp_CSI_ACTIVITY")


    var activityRankDF = sparkSession.sql("Select UserId, InternalKey, UserAction , ActionTime, RANK() over(order by UserId asc,ActionTime asc,InternalKey asc) as ThisItem from tmp_CSI_ACTIVITY order by UserId asc,Actiontime asc,InternalKey asc")

    //activityRankDF.createTempView("TempWrk")

    var activityPrevItemDF = activityRankDF
      .withColumn("PrevItem", when($"UserAction" =!= "Login", $"ThisItem" - 1).otherwise(0))
    // activityPrevItemDF = activityPrevItemDF.withColumn("StartTime", col("ActionTime")).drop(col("ActionTime"))


    //activityPrevItemDF.createTempView("TempWrk1")


    var df2 = activityRankDF.join(activityPrevItemDF, activityRankDF.col("ThisItem") === activityPrevItemDF.col("PrevItem"))
      .filter(activityPrevItemDF.col("PrevItem").notEqual(lit(0)) && activityRankDF.col("userid") === activityPrevItemDF.col("userid"))
      .withColumn("StartTime", activityPrevItemDF.col("ActionTime"))
      .withColumn("StartTime", when(col("StartTime").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"StartTime", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))
      .drop(activityRankDF.col("UserId"))
      .drop(activityRankDF.col("InternalKey"))
      .drop(activityRankDF.col("UserAction"))
      .drop(activityRankDF.col("ThisItem"))
      .drop(activityPrevItemDF.col("UserId"))
      .drop(activityPrevItemDF.col("UserAction"))
      .drop(activityPrevItemDF.col("ActionTime"))


    df2 = df2.withColumn("SecondsTaken", CSICommonMethods.timeDifference($"ActionTime", $"StartTime"))
    df2 = df2.drop(col("UserId"))
      .drop(col("ActionTime"))
      .drop(col("UserAction"))
      .drop(col("ThisItem"))
      .drop(col("PrevItem"))



    // var df2 = sparkSession.sql("Select a.InternalKey, a.actionTime endtime, b.ActionTime Starttime  from TempWrk1 a,TempWrk b where a.PrevItem = b.ThisItem  and a.prevItem <> 0")


    var activityUpdatedDF1 = hiveSession.executeQuery("Select * from " + REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE + " Where Whenloaded  =  (Select Max(Whenloaded) from " + REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE + ")")

    activityUpdatedDF1 = activityUpdatedDF1.drop(col("secondstaken")).drop(col("starttime"))


    var activityUpdatedJoin = activityUpdatedDF1.join(df2, Seq("InternalKey"), "left_outer")


    activityUpdatedJoin = super.reorderSourceTableSchema(CSI_ACTIVITY_UPDATE_COL_ORDER, addAuditColumns(activityUpdatedJoin))



    activityUpdatedJoin.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", REDI_CSI_ACTIVITY_UPDATE_HIVE_TABLE).save()

    updateControlTables(csiAccessDF, "AccessDateTime", REDI_CSI_ACTIVITY_UPDATE_ACCESS_CONTROL_KEY)
    updateControlTables(csiNotesDF, "NoteDateTime", REDI_CSI_ACTIVITY_UPDATE_NOTES_CONTROL_KEY)

    hiveSession.executeUpdate("delete  from  " + REDI_CSI_ACTIVITY_UPDATE_HIVE_TEMP_TABLE + "")
    csiActivityUpdateLog.debug(CSIDATAPROCESS_DEBUG + "Compelete process method CSIACtivityUpdate")

  }


  def getHWMId(controlKey: String): String = {
    csiActivityUpdateLog.debug(CSIDATAPROCESS_DEBUG + "Inside getHWMId method")
    csiActivityLog.info(CSIDATAPROCESS_INFO + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    csiActivityLog.debug(CSIDATAPROCESS_DEBUG + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    var hwmDate = hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    csiActivityLog.info(CSIDATAPROCESS_INFO + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    csiActivityLog.debug(CSIDATAPROCESS_DEBUG + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    hwmDate
  }

  def updateControlTables(RawCSIDataDF: DataFrame, hwmColumn: String, controlKey: String): Unit = {
    /** Ingestion Process Step: 05
      * Reading the Dataframe for getting the MAXIMUM of HWM Column from the data Ingested from Oracle
      * This value is pushed into Hive Control Table.
      * Updating the Maximum HWM Column into Hive Control table and Marking the end of process */

    // Setting the End time of the CSI CBData
    csiActivityUpdateLog.debug(CSIDATAPROCESS_DEBUG + "Inside updateControlTabless method")
    val endTimeCSIDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(RawCSIDataDF, hwmColumn, controlKey, PROCESS_CONTROL_COMPLETED, "", endTimeCSIDataLoad.toString, "Completed", CSI_DATA_PROCESS)
  }
}

