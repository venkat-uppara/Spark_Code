/**
  * @author : Sudhakar
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */


package com.aciworldwide.ra.redi.csi.dao

import java.sql.ResultSet

import com.aciworldwide.ra.redi.csi.schemas._
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import com.aciworldwide.ra.redi.csi.schemas.UsersSchema
import org.apache.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.MutableList

class CSIDataDao(sc: SparkSession) extends DateUtils  with DatabaseServices with ReDiConstants with Serializable  {

  /**
    * setupConnections is used to instantiate the SetupConnections
    * This will be used across the methods for creating connections with the databases, so declaring this globally */
  val setupConnections = new SetupConnections

  @transient lazy val csiDaoLog = LogManager.getLogger(getClass.getName)

  /**
    *  This method is used read the connection parameters and connect to the Postgres Database and
    *  Read the HWM: High Water Mark data for CSIHWMData Data process from the Control table. */
  def fetchCSIHWMData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Starting to fetch HWM data for CSI Data process from Postgres Data. " + schemaname + "." + tablename)
    val CSIHWMDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Fetched HWM data for CSI Data process from Postgres Data. " + schemaname + "." + tablename)
    CSIHWMDF
  }

  /**
    * This method is used read the connection parameters and connect to the Oracle Database and
    * Read the data for CSI  Data Process. */
  def fetchCSIData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Starting to fetch new/updated data for CSI  process from Oracle. " + schemaname + "." + tablename)
    val CSIDataDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Fetched new/updated data for CSI   Data. " + schemaname + "." + tablename)
    CSIDataDF
  }

  /**
    * This method is used read the connection parameters and connect to the Oracle Database and
    * Read the maximum of the last_updated column in client. */

  def fetchLastUpdatedFromOracle(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): String = {
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Starting to fetch the Maximum value of the Last Updated data from Oracle. " + schemaname + "." + tablename)
    val CSILastUpdatedDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Fetched Last Updated data from Oracle. " + schemaname + "." + tablename)
    CSILastUpdatedDF.collectAsList().get(0).toString()
  }

  /**
    * This method is used read the connection parameters and connect to the Postgres Database and
    * Update the HWM (High Water Mark) with the latest max GROUP_ID in the Control table. */

  def updateCSIHWMData(NewCSIHWMGID:String): Unit = {
    val setupConnection = setupConnections.createScalaConnection(REDI_CONTROL_DATABASE, POSTGRES_CONN_TYPE)
    try {
      val sqlUpdateStatement = setupConnection.createStatement()
      csiDaoLog.debug(CSIDATAPROCESS_DEBUG +":Starting to Update the Postgres table with the latest HWM for Automated CB Data Process. ")
      val updateCSIHWM = "UPDATE " + REDI_CONTROL_TABLE + " SET processhighwatermark = " + "'" + NewCSIHWMGID + "'" + " WHERE " + REDI_CONTROL_TABLE + ".processname = '" + REDI_AUTOMATED_CB_CONTROL_KEY + "'"
      sqlUpdateStatement.executeUpdate(updateCSIHWM)
    } catch {
      case e: Exception => csiDaoLog.debug(CSIDATAPROCESS_ERROR +":Exception occurred in updating the HWM for Automated CB Data Process." + e)
    }
    finally {
      setupConnection.close()
    }
  }



  /* getting the CSI_SUBCLIENT_PTROFILES table data from Hive*/
  def getSubClientProfilesTable: DataFrame = {


//    val result = readDataIntoJdbcRDDFromHiveTable(REDI_CSI_SUBCLIENT_PROFILES)
//    val fetchedResponse = getSubclientProfileData(result)
//    sc.sparkContext.parallelize(fetchedResponse).toDF()

    sc.sql("set spark.sql.hive.convertMetastoreOrc=true")
    sc.sql("Select ClientId, SubClientId, Client12, ProfileId, " +
      " whenloaded from "+REDI_CSI_SUBCLIENT_PROFILES_VIEW )

  }

  /* getting the CSI_USERS table data from Hive*/
  def getUsersTable: DataFrame = {
    sc.sql("set spark.sql.hive.convertMetastoreOrc=true")
    sc.sql("Select ClientId, SubClientId, Client12, UserName, " +
      "UserFullName, UserId, whenloaded from redi.CSI_USERS ")

  }



  /*
   Read the Hive Transactional tables via HIVE JDBC
  */

  def getSubclientProfileData(resultSet: ResultSet): MutableList[SubclientProfileSchema] ={
    val fetchedResponse = MutableList[SubclientProfileSchema]()
    while(resultSet.next()){
      var rec = SubclientProfileSchema(
        resultSet.getString(0),
        resultSet.getString(1),
        resultSet.getTimestamp(2),
        resultSet.getString(3),
        resultSet.getTimestamp(4),
        resultSet.getInt(5),
        resultSet.getInt(6),
        resultSet.getString(7),
        resultSet.getString(8),
        resultSet.getString(9),
        resultSet.getString(10),
        resultSet.getString(11),
        resultSet.getString(12),
        resultSet.getInt(13),
        resultSet.getInt(14),
        resultSet.getString(15),
        resultSet.getString(16),
        resultSet.getString(17),
        resultSet.getInt(18),
        resultSet.getInt(19),
        resultSet.getInt(20),
        resultSet.getInt(21),
        resultSet.getInt(22),
        resultSet.getInt(23),
        resultSet.getInt(24),
        resultSet.getInt(25),
        resultSet.getString(26),
        resultSet.getString(27),
        resultSet.getString(28),
        resultSet.getString(29),
        resultSet.getInt(30),
        resultSet.getInt(31),
        resultSet.getString(32),
        resultSet.getString(33),
        resultSet.getString(34),
        resultSet.getString(35),
        resultSet.getInt(36),
        resultSet.getString(37),
        resultSet.getInt(38),
        resultSet.getString(39),
        resultSet.getString(40),
        resultSet.getString(41),
        resultSet.getString(42),
        resultSet.getString(43),
        resultSet.getString(44),
        resultSet.getString(45),
        resultSet.getString(46),
        resultSet.getString(47),
        resultSet.getString(48),
        resultSet.getInt(49),
        resultSet.getInt(50),
        resultSet.getTimestamp(51),
        resultSet.getString(52),
        resultSet.getTimestamp(53),
        resultSet.getString(54)
      )
      fetchedResponse += rec
    }
    fetchedResponse
  }

  def getUsersData(resultSet: ResultSet): MutableList[UsersSchema] ={
    val fetchedResponse = MutableList[UsersSchema]()
    while(resultSet.next()){
      var rec = UsersSchema(
        resultSet.getString(0),
        resultSet.getString(1),
        resultSet.getString(2),
        resultSet.getInt(3),
        resultSet.getString(4),
        resultSet.getString(5),
        resultSet.getString(6),
        resultSet.getString(7),
        resultSet.getString(8),
        resultSet.getString(9),
        resultSet.getString(10),
        resultSet.getString(11),
        resultSet.getString(12),
        resultSet.getTimestamp(13),
        resultSet.getString(14),
        resultSet.getTimestamp(15),
        resultSet.getTimestamp(16),
        resultSet.getString(17),
        resultSet.getString(18),
        resultSet.getString(19),
        resultSet.getInt(20),
        resultSet.getString(21),
        resultSet.getString(22),
        resultSet.getString(23),
        resultSet.getInt(24),
        resultSet.getTimestamp(25),
        resultSet.getString(26),
        resultSet.getTimestamp(27),
        resultSet.getString(28),
        resultSet.getString(29)

      )
      fetchedResponse += rec
    }
    fetchedResponse
  }

}
