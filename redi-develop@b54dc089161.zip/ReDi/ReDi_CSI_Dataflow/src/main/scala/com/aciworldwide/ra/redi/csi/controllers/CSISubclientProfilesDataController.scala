/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.SaveMode
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession._
import org.apache.log4j.LogManager
import org.apache.spark.sql.types.{IntegerType, StringType}

object CSISubclientProfilesDataController extends ReDiConstants with  Serializable {

  @transient lazy val csiSubClientProfileLog = LogManager.getLogger(getClass.getName)

  def remapClientIDsForIKEA(clientId: String, subClientId: String): String = {
    csiSubClientProfileLog.info(CSIDATAPROCESS_INFO +":inside remapClientIDsForIKEA" +clientId+":"+subClientId)
    var clientId_1 = clientId
    if (clientId != null &&  subClientId!=null && clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194")
    }
    csiSubClientProfileLog.info("completed remapClientIDsForIKEA:" +clientId_1)
    clientId_1
  }


  def remapClient12IDsForIKEA(client12: String, clientId: String, subClientId: String): String = {
    var clientId_1 = client12
    if (clientId != null &&  subClientId!=null &&clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194").concat(subClientId)
    }
    clientId_1
  }

}

class CSISubclientProfilesDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants
   with Serializable {

  import sparkSession.implicits._

  @transient lazy val csiSubClientProfileLogger = LogManager.getLogger(getClass.getName)


  override def getHiveTableName(): String = {
    REDI_CSI_SUBCLIENT_PROFILE_HIVE_TABLE

  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiSubClientProfileLogger.info(CSIDATAPROCESS_INFO + "Inside csiTransformation :" + this.getClass)
    val outputDataframe = inputDataFrame.select(
      $"ID".alias("profileid"),
      $"CREATED_DATE".alias("createddate"),
      $"CREATED_BY".alias("createdby"),
      $"MODIFIED_DATE".alias("modifieddate"),
      $"MODIFIED_BY".alias("modifiedby"),
      $"CANCEL_ORDER_SERVICE_ENABLED".alias("cancelorderserviceenabled"),
      $"CLIENT_ID".alias("clientid"),
      $"SUBCLIENT_ID".alias("subclientid"),
      $"CM_ENABLED".alias("cmenabled"),
      $"TIEBACK_URL".alias("tiebackurl"),
      $"TIEBACK_REQ_HEADER".alias("tiebackreqheader"),
      $"TIEBACK_REQ_BODY".alias("tiebackreqbody"),
      $"TIEBACK_RETRY_DELAY".alias("tiebackretrydelay"),
      $"TIEBACK_RETRY_COUNT".alias("tiebackretrycount"),
      $"TIEBACK_URL_1".alias("tiebackurl1"),
      $"TIEBACK_URL_2".alias("tiebackurl2"),
      $"TIEBACK_URL_3".alias("tiebackurl3"),
      $"TXN_HOLD_TIME".alias("txnholdtime"),
      $"TXN_NOTE_1".alias("txnnote1"),
      $"TXN_NOTE_2".alias("txnnote2"),
      $"TXN_NOTE_3".alias("txnnote3"),
      $"TXN_NOTE_4".alias("txnnote4"),
      $"NUM_RULES".alias("numrules"),
      $"NUM_QUEUES".alias("numqueues"),
      $"SUMMARY_CHALLENGE_PCT_ALERT".alias("summarychallengepctalert"),
      $"SUMMARY_DENY_PCT_ALERT".alias("summarydenypctalert"),
      $"CB_CHALLENGE_PCT_ALERT".alias("cbchallengepctalert"),
      $"CB_DENY_PCT_ALERT".alias("cbdenypctalert"),
      $"CB_ACCEPT_PCT_ALERT".alias("cbacceptpctalert"),
      $"REPORT_EMAIL".alias("reportemail"),
      $"LOGO_FILENAME".alias("logofilename"),
      $"OUTSORTED_RECOMMENDATIONS".alias("outsortedrecommendations"),
      $"CB_FIELDS".alias("cbfields"),
      $"PEND_TIME".alias("pendtime"),
      $"MAX_QUEUE_USERS".alias("maxqueueusers"),
      $"TXN_SEARCH_FIELDS".alias("txnsearchfields"),
      $"TXN_RESULT_FIELDS".alias("txnresultfields"),
      $"SELECTED_WIDGETS".alias("selectedwidgets"),
      $"TZ_CODE".alias("tzcode"),
      $"SESSION_TIMEOUT".alias("sessiontimeout"),
      $"LOGO_FILE".alias("logofile"),
      $"IS_VISIBLE_TO_PRIMARY".alias("isvisibletoprimary"),
      $"TXN_NOTE_5".alias("txnnote5"),
      $"TXN_NOTE_6".alias("txnnote6"),
      $"TXN_NOTE_7".alias("txnnote7"),
      $"TXN_NOTE_8".alias("txnnote8"),
      $"TXN_NOTE_9".alias("txnnote9"),
      $"TXN_NOTE_10".alias("txnnote10"),
      $"MAX_HEAT_MAP_SCORE".alias("maxheatmapscore"),
      $"VIEW_NON_PRIMARY_SYSTEM_QUEUE".alias("viewnonprimarysystemqueue"))
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("client12", CSICommonMethods.remapClient12IDsForIKEA(concat(col("CLIENTID"), col("SUBCLIENTID")), col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("cmenabled",when(col("cmenabled")===1,lit("Y")).otherwise("N"))


    csiSubClientProfileLogger.info(CSIDATAPROCESS_INFO + "Completed csiTransformation :" + this.getClass)
    reorderSourceTableSchema(CSI_SUBCLIENT_PROFILES_TABLE_COL_ORDER, addAuditColumns(outputDataframe))
  }

  def remapClientIDsForIKEACSI: UserDefinedFunction = udf((clientId: String, subClientId: String) => {
    CSISubclientProfilesDataController.remapClientIDsForIKEA(clientId, subClientId)
  })


  def remapClient12IDsForIKEACSI: UserDefinedFunction = udf((client12: String, clientId: String, subClientId: String) => {
    CSISubclientProfilesDataController.remapClient12IDsForIKEA(client12, clientId, subClientId)
  })

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_SUBCLIENT_PROFILE_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_SUBCLIENT_PROFILE_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_SUBCLIENT_PROFILE_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_SUBCLIENT_PROFILES_KEY
  }

  override def getODSWhereCondition(value: String): String = {
    csiSubClientProfileLogger.debug(CSIDATAPROCESS_DEBUG + " :Inside getODSWhereCondition SUbclientprofile" + value)
    " WHERE MODIFIED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and MODIFIED_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiSubClientProfileLogger.debug(CSIDATAPROCESS_DEBUG + ":Starting to push the data into Hive table " + getHiveTableName() + " " + this.getClass)
    hiveSession.executeUpdate("delete from REDI.CSI_SUBCLIENT_PROFILES_ON_WRITE")
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    hiveSession.executeUpdate("MERGE INTO REDI.CSI_SUBCLIENT_PROFILES AS D USING " +
      " (SELECT * FROM REDI.CSI_SUBCLIENT_PROFILES_ON_WRITE) AS S ON (D.PROFILEID=S.PROFILEID AND D.CLIENTID=S.CLIENTID AND D.SUBCLIENTID=S.SUBCLIENTID) WHEN MATCHED THEN " +
      "UPDATE SET CREATEDBY=S.CREATEDBY,CREATEDDATE=S.CREATEDDATE,MODIFIEDBY=S.MODIFIEDBY,MODIFIEDDATE=S.MODIFIEDDATE,CANCELORDERSERVICEENABLED=S.CANCELORDERSERVICEENABLED," +
      "CMENABLED=S.CMENABLED,CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,CLIENT12=S.CLIENT12,TIEBACKURL=S.TIEBACKURL,TIEBACKREQHEADER=S.TIEBACKREQHEADER," +
      "TIEBACKRETRYDELAY=S.TIEBACKRETRYDELAY,TIEBACKRETRYCOUNT=S.TIEBACKRETRYCOUNT,TIEBACKURL1=S.TIEBACKURL1,TIEBACKURL2=S.TIEBACKURL2,TIEBACKURL3=S.TIEBACKURL3," +
      "TXNHOLDTIME=S.TXNHOLDTIME,NUMRULES=S.NUMRULES,NUMQUEUES=S.NUMQUEUES,SUMMARYCHALLENGEPCTALERT=S.SUMMARYCHALLENGEPCTALERT,SUMMARYDENYPCTALERT=S.SUMMARYDENYPCTALERT," +
      "CBCHALLENGEPCTALERT=S.CBCHALLENGEPCTALERT,CBDENYPCTALERT=S.CBDENYPCTALERT,CBACCEPTPCTALERT=S.CBACCEPTPCTALERT,REPORTEMAIL=S.REPORTEMAIL,LOGOFILENAME=S.LOGOFILENAME," +
      "OUTSORTEDRECOMMENDATIONS=S.OUTSORTEDRECOMMENDATIONS,CBFIELDS=S.CBFIELDS,PENDTIME=S.PENDTIME,MAXQUEUEUSERS=S.MAXQUEUEUSERS,TXNSEARCHFIELDS=S.TXNSEARCHFIELDS," +
      "TXNRESULTFIELDS=S.TXNRESULTFIELDS,SELECTEDWIDGETS=S.SELECTEDWIDGETS,TZCODE=S.TZCODE,SESSIONTIMEOUT=S.SESSIONTIMEOUT,LOGOFILE=S.LOGOFILE,ISVISIBLETOPRIMARY=S.ISVISIBLETOPRIMARY," +
      "TXNNOTE1=S.TXNNOTE1,TXNNOTE2=S.TXNNOTE2,TXNNOTE3=S.TXNNOTE3,TXNNOTE4=S.TXNNOTE4,TXNNOTE5=S.TXNNOTE5,TXNNOTE6=S.TXNNOTE6,TXNNOTE7=S.TXNNOTE7,TXNNOTE8=S.TXNNOTE8," +
      "TXNNOTE9=S.TXNNOTE9,TXNNOTE10=S.TXNNOTE10,MAXHEATMAPSCORE=S.MAXHEATMAPSCORE,VIEWNONPRIMARYSYSTEMQUEUE=S.VIEWNONPRIMARYSYSTEMQUEUE," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.PROFILEID,S.CREATEDBY,S.CREATEDDATE,S.MODIFIEDBY,S.MODIFIEDDATE,S.CANCELORDERSERVICEENABLED,S.CMENABLED,S.CLIENTID,S.SUBCLIENTID," +
      "S.CLIENT12,S.TIEBACKURL,S.TIEBACKREQHEADER,S.TIEBACKREQBODY,S.TIEBACKRETRYDELAY,S.TIEBACKRETRYCOUNT,S.TIEBACKURL1,S.TIEBACKURL2,S.TIEBACKURL3,S.TXNHOLDTIME," +
      "S.NUMRULES,S.NUMQUEUES,S.SUMMARYCHALLENGEPCTALERT,S.SUMMARYDENYPCTALERT,S.CBCHALLENGEPCTALERT,S.CBDENYPCTALERT,S.CBACCEPTPCTALERT,S.REPORTEMAIL," +
      "S.LOGOFILENAME,S.OUTSORTEDRECOMMENDATIONS,S.CBFIELDS,S.PENDTIME,S.MAXQUEUEUSERS,S.TXNSEARCHFIELDS,S.TXNRESULTFIELDS,S.SELECTEDWIDGETS,S.TZCODE," +
      "S.SESSIONTIMEOUT,S.LOGOFILE,S.ISVISIBLETOPRIMARY,S.TXNNOTE1,S.TXNNOTE2,S.TXNNOTE3,S.TXNNOTE4,S.TXNNOTE5,S.TXNNOTE6,S.TXNNOTE7,S.TXNNOTE8,S.TXNNOTE9,S.TXNNOTE10," +
      "S.MAXHEATMAPSCORE,S.VIEWNONPRIMARYSYSTEMQUEUE,S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED)")
    csiSubClientProfileLogger.debug(CSIDATAPROCESS_DEBUG + ":Completed to push the data into Hive table " + getHiveTableName() + " " + this.getClass)
  }
}

