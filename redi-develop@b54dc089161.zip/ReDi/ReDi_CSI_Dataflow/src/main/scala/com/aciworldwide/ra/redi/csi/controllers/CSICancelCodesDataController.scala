/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSICancelCodesDataController.{CSIDATAPROCESS_DEBUG, csiCancelCodesLog}
import com.aciworldwide.ra.redi.csi.dao._
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object CSICancelCodesDataController extends ReDiConstants with Serializable {

  @transient lazy val csiCancelCodesLog = LogManager.getLogger(getClass.getName)

  def remapClientIDsForIKEA(clientId: String, subClientId: String): String = {
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside remapClientIDsForIKEA" + clientId + ":" + subClientId)
    var clientId_1 = clientId
    if (clientId != null && subClientId != null && clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194")
    }
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":completed remapClientIDsForIKEA:" + clientId_1)
    clientId_1
  }


  def cancelFraudYN(cancelDesc: String, clientId: String, cancelCode: String): String = {
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside cancelFraudYN" + clientId + ":" + cancelDesc + "" + cancelDesc + "" + cancelCode)
    var CancelFraudYN = "N"
    if (cancelDesc != null && cancelDesc.toUpperCase().contains("FRAUD")) {
      CancelFraudYN = "Y"
    }
    //set CancelFraudYN = 'Y' where ClientId = '000137' and CancelCode = '226';
    //set CancelFraudYN = 'Y' where ClientId = '000120' and CancelCode = '226';
    if (clientId != null && ("000137".equals(clientId) || "000120".equals(clientId)) && cancelCode != null && ("226".equals(cancelCode))) {
      CancelFraudYN = "Y"
    }
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside cancelFraudYN" + clientId + ":" + cancelDesc + "" + cancelDesc + "" + cancelCode)
    CancelFraudYN
  }

}

class CSICancelCodesDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants
   {

  import sparkSession.implicits._

  val cancelCodeAA = new CSICancelCodesAADataController(sparkSession, csiDataDao)

  override def getHiveTableName(): String = {
    REDI_CSI_CANCEL_CODES_HIVE_TABLE
  }


  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":inside csiTransformation method"+this.getClass)

    val subclientProfileDF = hiveSession.execute("SELECT * FROM REDI.CSI_SUBCLIENT_PROFILES").select(
      $"ClientId",
      $"SubClientId",
      $"Client12",
      $"profileid"
    )

    var outputDF = inputDataFrame.select(
      $"CODE".alias("cancelcode"),
      lower(substring($"DESCRIPTION", 0, 50)).alias("CancelDesc"),
      $"CREATED_DATE".alias("cancelcreated"),
      $"CREATED_BY".alias("cancelcreatedby"),
      $"MODIFIED_DATE".alias("cancelmodified"),
      $"MODIFIED_BY".alias("cancelmodifiedby"),
      $"DELETED",
      $"ID".alias("cancelcodeid"),
      $"PROFILE_ID".alias("ProfileId"),
      $"CancelSource"
    )
    outputDF = joinedDf(outputDF, subclientProfileDF)
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":completed csiTransformation")
    reorderSourceTableSchema(CSI_CANCEL_CODES_TABLE_COL_ORDER, addAuditColumns(outputDF))
  }

  def joinedDf(cancelCodeDf: DataFrame, subClientProfileDf: DataFrame): DataFrame = {
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":inside joinedDf method")
    val result = cancelCodeDf.join(subClientProfileDf, Seq("profileid"), "left_outer")
      .withColumn("cancelfraudyn", updateCancelFraudYN($"CancelDesc", $"ClientId", $"cancelcode"))
      .withColumn("clientid", remapClientIDsForIKEACSI(col("CLIENTID"), col("SUBCLIENTID")))
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":completed joinedDf method")
    result
  }


  def remapClientIDsForIKEACSI: UserDefinedFunction = udf((clientId: String, subClientId: String) => {
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside remapClientIDsForIKEACSI method" + clientId + "" + subClientId)
    CSICancelCodesDataController.remapClientIDsForIKEA(clientId, subClientId)
  })


  def updateCancelFraudYN: UserDefinedFunction = udf((cancelDesc: String, clientId: String, cancelCode: String) => {
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside updateCancelFraudYN method" + clientId + "" + cancelDesc + "" + cancelCode)
    CSICancelCodesDataController.cancelFraudYN(cancelDesc, clientId, cancelCode)
  })

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_CANCEL_CODES_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_CANCEL_CODES_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_CANCEL_CODES_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_CANCEL_CODES_CONTROL_KEY
  }

  def csiPretransformation(inputDataFrame: DataFrame): DataFrame = {
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":inside csiPretransformation method")
    val outputDF = inputDataFrame.withColumn("CancelSource", lit("CC"))
    outputDF


  }

  override def setRawDataframe(RawCSIDataDF: DataFrame): Unit = {
    csiCancelCodesLog.info(CSIDATAPROCESS_INFO + ":inside setRawDataframe method")
    cancelCodeAA.CSIDataPipeline()

    val cancelCodeAADF = cancelCodeAA.getRawDataframe()

    val cancelCodeDF = RawCSIDataDF.union(cancelCodeAADF)

    super.setRawDataframe(cancelCodeDF)
  }


  override def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    super.updateControlTables(RawCSIDataDF)

    cancelCodeAA.updateControlTables(cancelCodeAA.getRawDataframe())

  }

  override def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    var cancelCodeDF = super.fetchRawDataFromODS(CSIHWMID)

    cancelCodeDF = csiPretransformation(cancelCodeDF)

    cancelCodeDF
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE COALESCE(DELETED,0)<>1 AND CREATED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and  CREATED_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":inside storeInput2Hive method")
    hiveSession.executeUpdate("delete from REDI.CSI_CANCEL_CODES_ON_WRITE")
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    hiveSession.executeUpdate("MERGE INTO REDI.CSI_CANCEL_CODES AS D USING " +
      " (SELECT * FROM REDI.CSI_CANCEL_CODES_ON_WRITE) AS S ON (D.CANCELCODEID=S.CANCELCODEID) WHEN MATCHED THEN " +
      "UPDATE SET CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,CLIENT12=S.CLIENT12,CANCELCODE=S.CANCELCODE,CANCELDESC=S.CANCELDESC," +
      "CANCELSOURCE=S.CANCELSOURCE,CANCELFRAUDYN=S.CANCELFRAUDYN,CANCELCREATED=S.CANCELCREATED,CANCELCREATEDBY=S.CANCELCREATEDBY,CANCELMODIFIED=S.CANCELMODIFIED,CANCELMODIFIEDBY=S.CANCELMODIFIEDBY," +
      "CANCELCODEID=S.CANCELCODEID,PROFILEID=S.PROFILEID,DELETED=S.DELETED,WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.CLIENTID,S.SUBCLIENTID,S.CLIENT12,S.CANCELCODE,S.CANCELDESC,S.CANCELSOURCE,S.CANCELFRAUDYN,S.CANCELCREATED,S.CANCELCREATEDBY," +
      "S.CANCELMODIFIED,S.CANCELMODIFIEDBY,S.CANCELCODEID,S.PROFILEID,S.DELETED,S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED)")
    csiCancelCodesLog.debug(CSIDATAPROCESS_DEBUG + ":Completed  storeInput2Hive method")
  }
}

