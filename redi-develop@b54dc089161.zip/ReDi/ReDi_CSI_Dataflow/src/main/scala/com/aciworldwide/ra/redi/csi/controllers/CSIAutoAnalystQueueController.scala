/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

class CSIAutoAnalystQueueController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSISupplimentDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) {


  @transient lazy val csiQueueDataContorller = LogManager.getLogger(getClass.getName)

  private var CSIQUEUES_COLUMN_ORDER = "ID,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,CLIENT_ID,SUBCLIENT_ID,STATUS,QUEUE_TYPE,RANK_ORDER,NAME,DESCRIPTION,REFERRING_SITE,CRITERIA_DEFINITION,CRITERIA_EXPRESSION,CRITERIA_UI,IS_TRANSFERABLE,RECOMMENDATION,CRITERIA,PRISM_SCORE,EFALCON_SCORE,EBCARDTYPE,EBSHIPMETHOD,EBITEMSHIPMETHOD,VIRTBILLSHIP,BULK_CLICKBLOCK_SETTING,CANCEL_CODE,SCHEDULE_START,SCHEDULE_END,SCHEDULE_UI,NOTE,ORDER_TYPE,PEND_TIME,QueueCMType,ACTION"

  import sparkSession.implicits._

  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_AA_QUEUES_TABLE_HWM_COLUMN
  }

  def getODSTableName(): String = {
    REDI_CSI_AA_QUEUES_ODS_TABLE_NAME
  }

  def getControlKey(): String = {
    REDI_CSI_AA_QUEUES_CONTROL_KEY
  }


  def getODSWhereCondition(value: String): String = {
    " WHERE MODIFIED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  override def setRawDataframe(RawCSIDataDF: DataFrame) = {
    csiQueueDataContorller.info(CSIDATAPROCESS_INFO + ":Inside setRawDataframe method" + this.getClass)

    this.rawDataFrame =
      RawCSIDataDF.select(
        $"ID",
        $"CREATED_BY",
        $"CREATED_DATE",
        $"MODIFIED_BY",
        $"MODIFIED_DATE",
        $"CLIENT_ID",
        $"SUBCLIENT_ID",
        $"STATUS",
        $"ACTION",
        $"NAME",
        $"DESCRIPTION",
        $"CRITERIA_DEFINITION",
        $"CRITERIA_EXPRESSION",
        $"CANCEL_CODE",
        $"SCHEDULE_START",
        $"SCHEDULE_END",
        $"CRITERIA_UI",
        $"SCHEDULE_UI",
        $"NOTE",
        $"ORDER_TYPE",
        $"PEND_TIME"
      ).withColumn("RANK_ORDER", lit("9999"))
        .withColumn("QueueCMType", lit("A"))
        .withColumn("QUEUE_TYPE", lit("AUTO"))
        .withColumn("RECOMMENDATION", lit(""))
        .withColumn("CRITERIA", lit(""))
        .withColumn("PRISM_SCORE", lit(""))
        .withColumn("EFALCON_SCORE", lit(""))
        .withColumn("EBCARDTYPE", lit(""))
        .withColumn("EBSHIPMETHOD", lit(""))
        .withColumn("EBITEMSHIPMETHOD", lit(""))
        .withColumn("VIRTBILLSHIP", lit(""))
        .withColumn("BULK_CLICKBLOCK_SETTING", lit(""))
        .withColumn("REFERRING_SITE", lit(""))
        .withColumn("IS_TRANSFERABLE", lit(""))

    this.rawDataFrame = reorderSourceTableSchema(CSIQUEUES_COLUMN_ORDER, rawDataFrame)
  }

}

