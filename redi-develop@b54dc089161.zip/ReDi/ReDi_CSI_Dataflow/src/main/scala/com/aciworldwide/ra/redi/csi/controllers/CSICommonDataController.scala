/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.aciworldwide.ra.redi.csi.controllers.CSINotesDataController.getClass
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager

class CSICommonDataController extends DateUtils with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices {


  /** The Spark Master and Spark App Name that will be used when establishing a connection
    * These values will be used during this job session */
  val sparkMaster = ConfigFactory.load().getString("local.common.spark.master")
  val sparkAppName = ConfigFactory.load().getString("local.common.spark.app.name")


  /** sparkSession variable is used to build spark session */
  val sparkSession = sparkSessionBuilder(sparkMaster, sparkAppName)

  /** CSIDataDao is used to instantiate the CBIDataDao with the session builder parameter
    * This will be used across the methods for accessing the database access , so declaring this globally */
  val csiDataDao = new CSIDataDao(sparkSessionBuilder(sparkMaster, sparkAppName))

  @transient lazy val csiCommonDataController = LogManager.getLogger(getClass.getName)

  val csiOrderDispositionDataController = new CSIOrderDispositionDataController(sparkSession, csiDataDao)
  val csisbuClientProfiles = new CSISubclientProfilesDataController(sparkSession, csiDataDao)
  val cSICancelCodesDataController = new CSICancelCodesDataController(sparkSession, csiDataDao)
  val cSIUsersDataController = new CSIUsersDataController(sparkSession, csiDataDao)
  val cSIAccessDataController = new CSIAccessDataController(sparkSession, csiDataDao)
  val cSINotesDataController = new CSINotesDataController(sparkSession, csiDataDao)
  val csiQueuesController = new CSIQueuesController(sparkSession, csiDataDao)
  val csiProcessedOrderController = new CSI2ProcessedOrdersController(sparkSession, csiDataDao)
  val csiItemsController = new CSIItemAccessDataController(sparkSession, csiDataDao)
  val csiActivityUpdateController = new CSIActivityUpdateDataController(sparkSession, csiDataDao)


  def processAllCSITransactions(): Unit = {
    csiCommonDataController.info(CSIDATAPROCESS_INFO + ": Inside processAllCSITransactions method started running all CSI Jobs")
    csiOrderDispositionDataController.process()
    csisbuClientProfiles.process()
    cSICancelCodesDataController.process()
    cSIUsersDataController.process()
    cSIAccessDataController.process()
    cSINotesDataController.process()
    csiQueuesController.process()
    csiProcessedOrderController.process()
    csiItemsController.process()
    csiActivityUpdateController.process()
    csiCommonDataController.info(CSIDATAPROCESS_INFO + ": Completed running all CSI jobs, completed process processAllCSITransactions")
  }
}


