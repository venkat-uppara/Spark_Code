/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSICancelCodesDataController.csiCancelCodesLog
import com.aciworldwide.ra.redi.csi.controllers.CSIUsersDataController.{CSIDATAPROCESS_DEBUG, csiUsersDataContorller}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.{CSICommonMethods, CSIUtils}
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{col, _}


object CSIUsersDataController extends ReDiConstants with Serializable {

  def tranformUserFullName: UserDefinedFunction = udf((userLastName: String, userFirstName: String) => {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside tranformUserFullName UDF" + userLastName + "" + userFirstName)
    CSIUsersDataController.generateFullorShortName(userLastName, userFirstName, 40)
  })

  def tranformUserShortName: UserDefinedFunction = udf((userLastName: String, userFirstName: String) => {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside tranformUserShortName UDF" + userLastName + "" + userFirstName)
    CSIUsersDataController.generateFullorShortName(userLastName, userFirstName, 30)
  })

  def tranformUserMerchantYN: UserDefinedFunction = udf((clientId: String) => {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside tranformUserMerchantYN UDF:" + clientId)
    var merchantFlag = "Y"
    if (clientId == null || clientId.equals("999999")) {
      merchantFlag = "N"
    }
    merchantFlag
  })

  @transient lazy val csiUsersDataContorller = LogManager.getLogger(getClass.getName)

  def toCamelCase(noteAction: String): String = {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":Inside toCamelCase Method")

    var outputstring = noteAction

    if (noteAction != null && noteAction.length > 0) {
      outputstring = noteAction.substring(0, 1).toUpperCase() +
        noteAction.substring(1).toLowerCase()
    }
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":Completed toCamelCase Method")
    outputstring
  }

  def generateFullorShortName(userLastName: String, userFirstName: String, len: Int): String = {
    val camelCaseFirstName = toCamelCase(userFirstName)
    val camelCaseLastName = toCamelCase(userLastName)
    var result: String = null

    var len1 = 0
    if (camelCaseLastName != null && camelCaseLastName.length > len) {
      len1 = len
    }
    else if (userLastName != null) {
      len1 = userLastName.length
    }

    if (camelCaseFirstName != null && camelCaseLastName != null) {
      result = camelCaseFirstName.concat(", ").concat(camelCaseLastName.substring(0, len1))
    }
    else if (camelCaseFirstName != null && camelCaseLastName == null) {
      result = camelCaseFirstName
    }
    result
  }

  def ConvertTimeZoneforClient(inputdate: String, targetTimeZone: String): Timestamp = {

    val simpleformat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))

    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))

  }

  def addClientTimeZone(userLastAccess: String, timeZone: String): String = {
    var updDate: String = null
    if (!userLastAccess.isEmpty && userLastAccess != null) {
      val ClientDate =
        if (timeZone != null) {
          ConvertTimeZoneforClient(userLastAccess, timeZone)
        } else {
          ConvertTimeZoneforClient(userLastAccess, "EST")
        }
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
      val outputFormat = new SimpleDateFormat(CSICLIENTACCESSDATEFORMAT)
      updDate = outputFormat.format(inputFormat.parse(ClientDate.toString))
    }
    updDate
  }


}

class CSIUsersDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants {
  val usersInfoCSI1 = new CSIUsersInfoDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao)


  override def getHiveTableName(): String = {
    REDI_CSI_USERS_HIVE_TABLE
  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":inside csiTransformation method" + this.getClass)

    val outputDataFrame = usersTrans(inputDataFrame)
    val rbiRefClient = hiveSession.executeQuery("select * from " + REDI_RBI_REF_CLIENT + "").select("clientid", "SUBCLIENTID", "tzclient")

    val updOutputDataFrame = addClientDateTime(outputDataFrame, rbiRefClient)
    super.reorderSourceTableSchema(CSI_USERS_TABLE_COL_ORDER, addAuditColumns(updOutputDataFrame))
  }

  def usersTrans(userdDf: DataFrame): DataFrame = {
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":inside userdDf method")
    val output = userdDf.select(
      col("UserId"),
      col("CREATED_DATE").alias("CREATEDDATE"),
      col("CREATED_BY").alias("CREATEDBY"),
      col("MODIFIED_DATE").alias("usermodified"),
      col("MODIFIED_BY").alias("MODIFIEDBY"),
      col("DELETED").alias("deleted"),
      col("UserName"),
      col("STATUS").alias("userstatus"),
      col("SALUTATION_CODE"),
      col("FIRST_NAME").alias("userfirstname"),
      col("LAST_NAME").alias("userlastname"),
      col("MIDDLE_NAME").alias("usermiddlename"),
      col("PASSWORD").alias("password"),
      col("PASSWORD_STATE").alias("passwordstate"),
      col("LEGACY_USER_ID").alias("legacyuserid"),
      when(col("CLIENT_ID").isNotNull, col("CLIENT_ID")).otherwise(lit("000000")).alias("CLIENTID"),
      when(col("SUBCLIENT_ID").isNotNull, col("SUBCLIENT_ID")).otherwise(lit("000000")).alias("SUBCLIENTID"),
      col("SALT").alias("salt"),
      col("hashtypeflag"),
      col("UserType"),
      col("LAST_ACCESSED_DATE").alias("UserLastAccess")
    )
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("client12", CSICommonMethods.remapClient12IDsForIKEA(concat(col("CLIENTID"), col("SUBCLIENTID")), col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("UserMerchantYN", CSIUsersDataController.tranformUserMerchantYN(col("CLIENTID")))
      .withColumn("UserFullName", CSIUsersDataController.tranformUserFullName(col("UserLastName"), col("UserFirstName")))
      .withColumn("UserShortName", CSIUsersDataController.tranformUserShortName(col("UserLastName"), col("UserFirstName")))
      .withColumn("UserList", updUsrList(col("UserName"), col("UserFullName"), col("SUBCLIENTID")))
      .withColumn("casemanageryn", lit("N"))
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":completed userdDf method")
    output

  }

  def csiPreTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":inside csiPreTransformation method")
    val outputDataFrame =
      inputDataFrame.select(
        col("ID").alias("UserId"),
        col("CREATED_DATE"),
        col("CREATED_BY"),
        col("MODIFIED_DATE"),
        col("MODIFIED_BY"),
        col("DELETED"),
        col("USER_NAME").alias("UserName"),
        col("STATUS"),
        col("SALUTATION_CODE"),
        col("FIRST_NAME"),
        col("LAST_NAME"),
        col("MIDDLE_NAME"),
        col("PASSWORD"),
        col("PASSWORD_STATE"),
        col("LEGACY_USER_ID"),
        col("CLIENT_ID"),
        col("SUBCLIENT_ID"),
        col("SALT").alias("salt"),
        col("HASH_TYPE_FLAG").alias("hashtypeflag")
      ).withColumn("UserType", lit("2"))
        .withColumn("LAST_ACCESSED_DATE", lit(""))

    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":completed csiPreTransformation method")
    outputDataFrame
  }


  def updUsrList = udf((userName: String, userFullName: String, subClientID: String) => {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside updUsrList UDF:" + userName + "" + userFullName + "" + subClientID)
    var usrList: String = null
    if (userName != null && userFullName != null && subClientID != null && userFullName.length > 0) {
      usrList = userName.concat("-").concat(userFullName).concat("-").concat(subClientID)
    } else if (userName != null && subClientID != null) {
      usrList= userName.concat("-").concat(subClientID)
    }
    usrList
  })


  def addClientDateTime(inputDf: DataFrame, rbiRefClient: DataFrame): DataFrame = {

    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside addClientDateTime method")

    val joinedDf = inputDf.join(rbiRefClient, Seq("clientid", "SUBCLIENTID"), "left_outer")
    //val joinedDf = rbiRefClient.withColumn("CLIENTID",col("clientid")).join(inputDf,Seq("CLIENTID"))


    val addedClientDtDf = joinedDf.withColumn("AccessYYMMDDClient", when(col("UserLastAccess").isNotNull,
      addClientDt(col("UserLastAccess"), col("TZClient"))).otherwise(lit(null)))

    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":completed addClientDateTime method")
    addedClientDtDf
  }

  def addClientDt = udf((userLastAccess: String, timeZone: String) => {
    csiUsersDataContorller.debug(CSIDATAPROCESS_DEBUG + ":inside addClientDt UDF")
    CSIUsersDataController.addClientTimeZone(userLastAccess, timeZone)
  })

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_USERS_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_USERS_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_USERS_ODS_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_USERS_CONTROL_KEY
  }

  override def setRawDataframe(RawCSIDataDF: DataFrame): Unit = {

    usersInfoCSI1.CSIDataPipeline()

    val usersInfoCSI1DF = usersInfoCSI1.getRawDataframe()
    val usersDF =
      if (usersInfoCSI1DF != null) {
        RawCSIDataDF.union(usersInfoCSI1DF)
      } else {
        RawCSIDataDF
      }

    super.setRawDataframe(usersDF)
  }


  override def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    super.updateControlTables(RawCSIDataDF)

    usersInfoCSI1.updateControlTables(usersInfoCSI1.getRawDataframe())

  }

  override def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    var usersDF = super.fetchRawDataFromODS(CSIHWMID)

    usersDF = csiPreTransformation(usersDF)

    usersDF
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE MODIFIED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and MODIFIED_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":inside storeInput2Hive Method")
    hiveSession.executeUpdate("delete from REDI.CSI_USERS_ON_WRITE")
    csiUsersDataContorller.debug("Starting to push the data into Hive table " + getHiveTableName() + " " + this.getClass)
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    hiveSession.executeUpdate("MERGE INTO REDI.CSI_USERS AS D USING " +
      " (SELECT * FROM REDI.CSI_USERS_ON_WRITE) AS S ON (D.USERID=S.USERID) WHEN MATCHED THEN " +
      "UPDATE SET CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,CLIENT12=S.CLIENT12,USERID=S.USERID,LEGACYUSERID=S.LEGACYUSERID," +
      "SALUTATION_CODE=S.SALUTATION_CODE,USERNAME=S.USERNAME,USERFIRSTNAME=S.USERFIRSTNAME,USERMIDDLENAME=S.USERMIDDLENAME,USERLASTNAME=S.USERLASTNAME,USERFULLNAME=S.USERFULLNAME," +
      "USERSHORTNAME=S.USERSHORTNAME,USERMERCHANTYN=S.USERMERCHANTYN,MODIFIEDBY=S.MODIFIEDBY," +
      "CREATEDDATE=S.CREATEDDATE,CREATEDBY=S.CREATEDBY,USERMODIFIED=S.USERMODIFIED,USERLASTACCESS=S.USERLASTACCESS,USERSTATUS=S.USERSTATUS,USERLIST=S.USERLIST,CASEMANAGERYN=S.CASEMANAGERYN," +
      "DELETED=S.DELETED,PASSWORD=S.PASSWORD,PASSWORDSTATE=S.PASSWORDSTATE,SALT=S.SALT,HASHTYPEFLAG=S.HASHTYPEFLAG," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.CLIENTID,S.SUBCLIENTID,S.CLIENT12,S.USERID,S.LEGACYUSERID,S.SALUTATION_CODE,S.USERNAME,S.USERFIRSTNAME,S.USERMIDDLENAME," +
      "S.USERLASTNAME,S.USERFULLNAME,S.USERSHORTNAME,S.USERMERCHANTYN,S.MODIFIEDBY,S.CREATEDDATE,S.CREATEDBY,S.USERMODIFIED,S.USERLASTACCESS,S.USERSTATUS,S.USERLIST,S.CASEMANAGERYN," +
      "S.DELETED,S.PASSWORD,S.PASSWORDSTATE,S.SALT,S.HASHTYPEFLAG," +
      "S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED,S.USERTYPE)")
    csiUsersDataContorller.info(CSIDATAPROCESS_INFO + ":completed storeInput2Hive Method")
  }
}

