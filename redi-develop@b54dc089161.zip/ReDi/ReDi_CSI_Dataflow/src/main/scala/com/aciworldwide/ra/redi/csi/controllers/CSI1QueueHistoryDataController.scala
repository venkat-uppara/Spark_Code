/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.csi.controllers.CSI2ProcessedOrdersController.getClass
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

class CSI1QueueHistoryDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSISupplimentDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) {

  @transient lazy val csiQueuehistoryLog = LogManager.getLogger(getClass.getName)

  private var CSI1PROCESSED_ORDERS_COLUMN_ORDER =
    "ID,CREATED_BY,CREATED_DATE,MODIFIED_BY,MODIFIED_DATE,OID,QUEUE_ID,PROCESS_BY_TYPE,QUEUED_DATETIME,PROCESSED_DATETIME,RESULTING_ACTION,TRANSACTION_ID,CANCEL_CODE,PROCESS_BY_USER_ID,PROCESS_BY_AUTO_ANALYST_ID,OID_DATE,PROCESS_BY_USER,CLIENT_ID,SUBCLIENT_ID,RECOMMAND,EBCARDTYPE,EBSHIPMETHOD,VIRTBILLSHIP,EBTOF,EBREFERRING_SITE,EBTOTAL,PRISM_SCORE,EFALCON_SCORE,PEND_DATE,RESPONSE_STATUS,CMSource"


  import sparkSession.implicits._

  def getRawDataFrameHWMColumn(): String = {
    REDI_HIVE_QUEUE_HISTORY_TABLE_HWM_COLUMN
  }

  def getODSTableName(): String = {
    REDI_CSI_QUEUE_HISTORY_TABLE_NAME
  }

  def getControlKey(): String = {
    REDI_CSI_QUEUE_HISTORY_CONTROL_KEY
  }

  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  override def getStartRawDataFrameHWMColumn(): String = {
    REDI_ODS_QUEUE_HISTORY_TABLE_HWM_COLUMN
  }

  def getODSWhereCondition(value: String): String = {
    " WHERE INS_TIME > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF') " +
      " and  INS_TIME  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }


  override def setRawDataframe(RawCSIDataDF: DataFrame) = {
    csiQueuehistoryLog.debug(CSIDATAPROCESS_DEBUG + ":Inside setRawDataframe method")

    this.rawDataFrame =
      RawCSIDataDF.select(
        $"CLIENTID".alias("CLIENT_ID"),
        $"SUB_CLIENTID".alias("SUBCLIENT_ID"),
        $"OID",
        $"OID_DATE",
        $"TRANSID".alias("TRANSACTION_ID"),
        $"PRISM_SCORE",
        $"EFALCON_SCORE",
        $"RECOMMAND",
        $"LOAD_DATE_TIME".alias("QUEUED_DATETIME"),
        $"PEND_DATE",
        $"STATUS".alias("RESULTING_ACTION"),
        $"CANCEL_REASON".alias("CANCEL_CODE"),
        $"INS_TIME".alias("CREATED_DATE"),
        $"QID".alias("QUEUE_ID"),
        $"RESPONSE_STATUS",
        $"EBCARDTYPE",
        $"EBSHIPMETHOD",
        $"VIRTBILLSHIP",
        $"EBTOF",
        $"EBREFERRING_SITE",
        $"EBTOTAL"

      ).withColumn("ID", lit(""))
        .withColumn("CREATED_BY", lit(""))
        .withColumn("MODIFIED_BY", lit(""))
        .withColumn("MODIFIED_DATE", lit(""))
        .withColumn("PROCESS_BY_TYPE", lit(""))
        .withColumn("PROCESSED_DATETIME", lit(""))
        .withColumn("PROCESS_BY_USER_ID", lit(""))
        .withColumn("PROCESS_BY_AUTO_ANALYST_ID", lit(""))
        .withColumn("PROCESS_BY_USER", lit(""))
        .withColumn("CMSource", lit("C1"))


    this.rawDataFrame = reorderSourceTableSchema(CSI1PROCESSED_ORDERS_COLUMN_ORDER, rawDataFrame)
  }


}

