/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */


package com.aciworldwide.ra.redi.csi.schemas

import java.sql.Timestamp

case class SubclientProfileSchema(
                                   PROFILEID : String,
   CREATEDBY : String,
   CREATEDDATE               : Timestamp,
   MODIFIEDBY                : String,
   MODIFIEDDATE              : Timestamp,
   CANCELORDERSERVICEENABLED : Int,
   CMENABLED : Int,
   CLIENTID  : String,
   SUBCLIENTID               : String,
   CLIENT12  : String,
   TIEBACKURL                : String,
   TIEBACKREQHEADER          : String,
   TIEBACKREQBODY            : String,
   TIEBACKRETRYDELAY         : Int,
   TIEBACKRETRYCOUNT         : Int,
   TIEBACKURL1               : String,
   TIEBACKURL2               : String,
   TIEBACKURL3               : String,
   TXNHOLDTIME               : Int,
   NUMRULES  : Int,
   NUMQUEUES : Int,
   SUMMARYCHALLENGEPCTALERT  : Int,
   SUMMARYDENYPCTALERT       : Int,
   CBCHALLENGEPCTALERT       : Int,
   CBDENYPCTALERT            : Int,
   CBACCEPTPCTALERT          : Int,
   REPORTEMAIL               : String,
   LOGOFILENAME              : String,
   OUTSORTEDRECOMMENDATIONS  : String,
   CBFIELDS  : String,
   PENDTIME  : Int,
   MAXQUEUEUSERS             : Int,
   TXNSEARCHFIELDS           : String,
   TXNRESULTFIELDS           : String,
   SELECTEDWIDGETS           : String,
   TZCODE    : String,
   SESSIONTIMEOUT            : Int,
   LOGOFILE  : String,
   ISVISIBLETOPRIMARY        : Int,
   TXNNOTE1  : String,
   TXNNOTE2  : String,
   TXNNOTE3  : String,
   TXNNOTE4  : String,
   TXNNOTE5  : String,
   TXNNOTE6  : String,
   TXNNOTE7  : String,
   TXNNOTE8  : String,
   TXNNOTE9  : String,
   TXNNOTE10 : String,
   MAXHEATMAPSCORE           : Int,
   VIEWNONPRIMARYSYSTEMQUEUE : Int,
   WHENLOADED                : Timestamp,
   WHOLOADED : String,
   WHENUPDATED               : Timestamp,
   WHOUPDATED               : String
                 )
