/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */


package com.aciworldwide.ra.redi.csi.controllers

import java.text.{ParseException, SimpleDateFormat}

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.RollbackController
import com.aciworldwide.ra.redi.common.dao.ClientMasterDataDao
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


object CSIOrderDispositionDataController extends ReDiConstants {
  @transient lazy val csiOrderDispositionLog = LogManager.getLogger(getClass.getName)

  def dateYYYYMMDDWithoutTimePart = udf((notedate: String) => {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside dateYYYYMMDDWithoutTimePart Method")
    var date = ""
    if (notedate == null || notedate.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)

      try {
        date = outputFormat.format(inputFormat.parse(notedate))
      } catch {
        case ex: ParseException => csiOrderDispositionLog.error(CSIDATAPROCESS_ERROR + ":Unparseable date")
      }
    }
    date
  })

  def updateDecision: UserDefinedFunction = udf((orderStatus: String) => {
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateDecision UDF" + orderStatus)
    val decision =
      if (orderStatus != null && (orderStatus.equals("Approved") || orderStatus.equals("Released"))) {
        "A"
      } else {
        "R"
      }
    decision
  })

  def updateCurrentStatus: UserDefinedFunction = udf((currentStatus: String, orderStatus: String) => {
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateCurrentStatus UDF" + orderStatus)
    currentStatus match {
      case "Challenge" =>
        orderStatus match {
          case "Confirmed_Fraud" => "Challenge->RejFraud"
          case "Approved" => "Challenge->Approve"
          case "Released" => "Challenge->Approve"
          case _ => "Challenge->Reject"
        }
      case "Deny" =>
        orderStatus match {
          case "Confirmed_Fraud" => "Deny->RejFraud"
          case "Approved" => "Deny->Approve"
          case _ => "Deny->Reject"
        }
      case "NoScore" =>
        orderStatus match {
          case "Confirmed_Fraud" => "NoScore->RejFraud"
          case "Approved" => "NoScore->Approve"
          case _ => "NoScore->Reject"
        }
      case "Accept" =>
        orderStatus match {
          case "Confirmed_Fraud" => "Accept->Fraud"
          case _ => "Accept->Reject"
        }
      case _ => currentStatus
    }
  })

  def updateChallSource: UserDefinedFunction = udf((challSource: String) => {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateCurrentStatus UDF" + challSource)
    val updChallSource = if (challSource == null || challSource.isEmpty()) {
      "CSI"
    } else {
      challSource
    }
    updChallSource
  })

  def updateChallStatus: UserDefinedFunction = udf((currentStatus: String, challStatus: String, orderStatus: String) => {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateCurrentStatus UDF" + currentStatus + "" + challStatus + "" + orderStatus)
    currentStatus match {
      case "Challenge" =>
        orderStatus match {
          case "Confirmed_Fraud" => "RejFraud"
          case "Approved" => "Approve"
          case "Released" => "Approve"
          case _ => "RejOther"
        }
      case _ => challStatus
    }
  })

  def updateRealFraud: UserDefinedFunction = udf((realFraud: String, fraudynsrc: String) => {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateRealFraud UDF" + realFraud + "" + fraudynsrc)
    var returnValue = if (fraudynsrc.equals("Y") && (realFraud == null || realFraud.isEmpty || !realFraud.equals("Y"))) {
      "Y"

    } else {
      realFraud
    }
    returnValue
  })

}

class CSIOrderDispositionDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants {

  @transient lazy val csiOrderDispositionLog = LogManager.getLogger(getClass.getName)

  import sparkSession.implicits._

  private var transDetailDF: DataFrame = null
  private var rbiRefClientDF: DataFrame = null
  val clientMasterDataDao = new ClientMasterDataDao(sparkSession)

  override def getHiveTableName(): String = {
    REDI_CSI_ORDER_DISP_HIVE_TABLE
  }

  override def getDatabaseSchema(): String = {
    //CLIENT_DATA_DATABASE
    CSI_DATABASE
  }


  def updateClientMaster(inputDF: DataFrame): DataFrame = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateClientMaster Method")
    val rbiRefClient = hiveSession.executeQuery("select * from  redi.rbi_ref_client").where("RSActive= 'Y'")
    // .where("RSActive = 'Y' and CSIActive <> 'Y' and ChallActive <> 'Y' ")

    val srcDF = inputDF.select("clientid")

    var joinedDf = srcDF.join(rbiRefClient, Seq("clientid"), "inner")

    joinedDf = joinedDf
      .withColumn("CSIActive", lit("Y"))
      .withColumn("ChallActive", lit("Y"))

    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":completed updateClientMaster Method")
    reorderSourceTableSchema(CLIENT_MASTER_COL_ORDER, addAuditColumns(joinedDf))
  }


  def updateTransDetailCore(inputDF: DataFrame): Unit = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Started updateTransDetailCore OrderDisposition")
    val gg = inputDF.createOrReplaceTempView("csi_order_disp")

    var minDateDf = ""
    if (inputDF != null) {
      minDateDf = inputDF.groupBy().agg(min(inputDF("oiddateyyyymmdd"))).head()
        .getString(0)
    }


    //var trans_detail_sql = hiveSession.executeQuery("select * from redi.trans_master_core_csi   where oiddateyyyymmdd >=  '" + minDateDf + "'")

    var trans_detail_sql = hiveSession.executeQuery("select * from redi.bi_trans_master_core where oiddateyyyymmdd >=  '" + minDateDf + "'")

    val transDetail = trans_detail_sql

    val orderdisSrcDF = inputDF.select($"OID", $"orderstatus".as("orderstatussrc"),
      $"fraudyn".alias("fraudynSrc"),
      $"updateuser".alias("updateuserSrc"),
      $"lastupdated".alias("lastupdatedSrc"))


    var df = orderdisSrcDF.join(transDetail, Seq("OID"))


    df = df.withColumn("CSIOrderStatus", col("orderstatussrc"))
      .withColumn("CSIFraudYN", col("fraudynSrc"))
      .withColumn("CSIWhoUpdated", col("updateuserSrc"))
      .withColumn("CSIWhenUpdated", col("lastupdatedSrc"))
      .withColumn("Decision", CSIOrderDispositionDataController.updateDecision(col("orderstatussrc")))
      .withColumn("CurrentStatus", CSIOrderDispositionDataController.updateCurrentStatus(col("CurrentStatus"), col("orderstatussrc")))
      .withColumn("ChallSource", CSIOrderDispositionDataController.updateChallSource(col("ChallSource")))
      .withColumn("ChallStatus", CSIOrderDispositionDataController.updateChallStatus(col("CurrentStatus"), col("ChallStatus"), col("orderstatussrc")))
      .withColumn("CSIUSER", col("updateuserSrc"))
    //.withColumn("CurrentRealFraud", col("RealFraud"))


    df = updateRealFraudFields(df)
    df = setRealFraudValue(df)
    /*df = reorderSourceTableSchema("OID,OIDDATE,OIDDateYYYYMMDD,CSIORDERSTATUS,CSIFRAUDYN,CSIWHOUPDATED,CSIWHENUPDATED,DECISION,CURRENTSTATUS,CHALLSOURCE," +
      "CHALLSTATUS, REALFRAUDYYYYMMDD, REALFRAUDDATE, REALFRAUDTYPE, RELFRAUDYYYYMMDD,RELFRAUDTYPE, REALFRAUDDATEBAE", addAuditColumns(df))*/
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Completed updateTransDetailCore OrderDisposition")
    val oidLatest = Window.partitionBy("oid").orderBy(desc("lastupdatedSrc"))
    hiveSession.executeUpdate("delete from REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE")
    addAuditColumns(df).withColumn("oidlatest", row_number() over oidLatest).filter($"oidlatest" === 1).select("OID", "OIDDATE", "OIDDateYYYYMMDD", "CSIORDERSTATUS",
      "CSIFRAUDYN", "CSIWHOUPDATED", "CSIWHENUPDATED", "DECISION", "CURRENTSTATUS", "CHALLSOURCE",
      "CHALLSTATUS", "REALFRAUDYN", "RELFRAUDYN", "REALFRAUDYYYYMMDD", "REALFRAUDDATE", "REALFRAUDTYPE", "RELFRAUDYYYYMMDD",
      "RELFRAUDTYPE", "REALFRAUDDATEBAE", "CLIENTID", "SUBCLIENTID", "CSIUSER", "WHENLOADED", "WHOLOADED", "WHENUPDATED", "WHOUPDATED").write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE").save()

    val updateBiTransCore = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING " +
      "(SELECT * FROM REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE) AS S ON (D.oid=S.oid) WHEN MATCHED " +
      "THEN UPDATE SET CSIORDERSTATUS=S.CSIORDERSTATUS,CSIFRAUDYN =S.CSIFRAUDYN," +
      "CSIWHOUPDATED =S.CSIWHOUPDATED,CSIWHENUPDATED =S.CSIWHENUPDATED," +
      "DECISION =S.DECISION,CURRENTSTATUS =S.CURRENTSTATUS,REALFRAUDYN=S.REALFRAUDYN,RELFRAUDYN=S.RELFRAUDYN," +
      "CHALLSOURCE =S.CHALLSOURCE,CHALLSTATUS =S.CHALLSTATUS," +
      "REALFRAUDYYYYMMDD =S.REALFRAUDYYYYMMDD,REALFRAUDDATE =S.REALFRAUDDATE," +
      "REALFRAUDTYPE =S.REALFRAUDTYPE,RELFRAUDYYYYMMDD =S.RELFRAUDYYYYMMDD," +
      "RELFRAUDTYPE =S.RELFRAUDTYPE,REALFRAUDDATEBAE =S.REALFRAUDDATEBAE,CLIENTID =S.CLIENTID,SUBCLIENTID =S.SUBCLIENTID,CSIUSER=S.CSIUSER," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    val updateTransCore = hiveSession.executeUpdate("MERGE INTO REDI.TRANS_MASTER_CORE AS D USING " +
      "(SELECT * FROM REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE) AS S ON (D.oid=S.oid) WHEN MATCHED " +
      "THEN UPDATE SET RealFraudYN='Y',REALFRAUDTYPE = S.REALFRAUDTYPE," +
      "REALFRAUDDATE = CURRENT_TIMESTAMP,REALFRAUDDATEBAE = CURRENT_TIMESTAMP," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")
  }

  def setRealFraudValue(frame: DataFrame): DataFrame = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside setRealFraudValue method")
    frame.withColumn("RealFraudYN", CSIOrderDispositionDataController.updateRealFraud(frame.col("RealFraudYN"), frame.col("fraudynSrc")))
      .withColumn("relfraudyn", col("REALFRAUDYN"))
  }

  //  def updateRealFraudDate:UserDefinedFunction = udf((realFraud: String,  inputColumn: String)  => {
  //
  //    var returnValue = if (realFraud.equals("Y")) {
  //      getCurrentdateTimeStamp.toString
  //    } else {
  //      inputColumn
  //    }
  //    returnValue
  //  })
  //
  //  def updateRealFraudType:UserDefinedFunction = udf((currentRealFraud: String,  realFraud: String, inputColumn: String)  => {
  //
  //    logRegularMessage("currentRealFraud "  + currentRealFraud )
  //    logRegularMessage("realFraud "  + realFraud )
  //    logRegularMessage("inputColumn "  + inputColumn )
  //
  //    var returnValue = if ( realFraud.equals("Y") && (currentRealFraud == null || currentRealFraud.isEmpty || currentRealFraud.equals("N"))) {
  //      "CSI_ORDR"
  //    } else {
  //      inputColumn
  //    }
  //
  //    logRegularMessage("returnValue "  + returnValue )
  //
  //    returnValue
  //  })

  def updateRealFraudFields(dataFrame: DataFrame): DataFrame = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside updateRealFraudFields method")
    dataFrame.withColumn("realfraudyyyymmdd", when($"CSIFraudYN" === lit("Y"), CSICommonMethods.dateYYYYMMDDWithoutTimePart(lit(getCurrentdateTimeStamp.toString))).otherwise(col("realfraudyyyymmdd")))
      .withColumn("RealFraudDate", when($"CSIFraudYN" === lit("Y"), lit(getCurrentdateTimeStamp.toString)).otherwise(col("RealFraudDate")))
      .withColumn("RealFraudType", when($"CSIFraudYN" === lit("Y"), lit("CSI_ORDR")).otherwise(col("RealFraudType")))
      .withColumn("relfraudyyyymmdd", col("realfraudyyyymmdd"))
      .withColumn("RelFraudType", col("RealFraudType"))
      .withColumn("realfrauddateBAE", when($"CSIFraudYN" === lit("Y"), col("RealFraudDate")).otherwise(col("realfrauddateBAE")))
  }


  def callRollbackProcess(transDetailDF: DataFrame) = {

    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":PreRollBack process from CSI Started " + transDetailDF.count())


    val fraudRollback = transDetailDF.select(col("oid"))
      .where(col("REALFRAUDYN") === lit("Y")
        and col("RealFraudType") === lit("CSI_ORDR")
      )
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + "RollBack process from CSI Started. Count : " + fraudRollback.count())
    val rollback = new RollbackController(hiveSession)
    rollback.rollbackTransactions(fraudRollback)
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + "RollBack process from CSI Completed")
  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Started csiTransformation OrderDisposition")
    val outputDF = inputDataFrame.select(
      $"OID",
      $"OID_DATE".alias("oiddate"),
      $"ORDER_STATUS".alias("orderstatus"),
      $"UPDATE_USER_ID".alias("updateuser"),
      $"UPDATE_DATE".alias("lastupdated"),
      $"CLIENT_ID".alias("clientid"),
      $"SUBCLIENT_ID".alias("subclientid"))
      .withColumn("fraudyn", when(upper(col("orderstatus")).contains("FRAUD"), lit("Y")).when(upper(col("orderstatus")).contains("ACCOUNT_TAKE"), lit("Y")).otherwise(lit("N")))
      .withColumn("client12", concat($"clientid", $"subclientid"))
      .withColumn("lastupdatedyyyymmdd", CSIOrderDispositionDataController.dateYYYYMMDDWithoutTimePart($"lastupdated"))
      .withColumn("oiddateyyyymmdd", CSIOrderDispositionDataController.dateYYYYMMDDWithoutTimePart($"oiddate"))

    // transDetailDF = updateTransDetailCore(outputDF)
    updateTransDetailCore(outputDF)
    // rbiRefClientDF = updateClientMaster(outputDF)


    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Completed csiTransformation OrderDisposition")
    reorderSourceTableSchema(CSI_ORDER_DISPOSITION_TABLE_COL_ORDER, addAuditColumns(outputDF))
  }

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_ORDER_DISP_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_ORDER_DISP_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_ORDER_DISP_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_ORDER_DISPOSITION_CONTROL_KEY
  }

  /*def updateTransMasterCoreToHive(transMasterCore: DataFrame): Unit = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + "Started pushing the data into Hive tables " + REDI_TRAN_DETAIL_ON_WRITE_TABLE)
    hiveSession.executeUpdate("delete from REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE")
    addAuditColumns(transMasterCore).select("OID", "OIDDATE", "OIDDateYYYYMMDD", "CSIORDERSTATUS",
      "CSIFRAUDYN", "CSIWHOUPDATED", "CSIWHENUPDATED", "DECISION", "CURRENTSTATUS", "CHALLSOURCE",
      "CHALLSTATUS", "REALFRAUDYN", "RELFRAUDYN", "REALFRAUDYYYYMMDD", "REALFRAUDDATE", "REALFRAUDTYPE", "RELFRAUDYYYYMMDD",
      "RELFRAUDTYPE", "REALFRAUDDATEBAE", "CLIENTID", "SUBCLIENTID", "WHENLOADED", "WHOLOADED", "WHENUPDATED", "WHOUPDATED").write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE").save()

    val updateBiTransCore = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING " +
      "(SELECT * FROM REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE) AS S ON (D.oid=S.oid) WHEN MATCHED " +
      "THEN UPDATE SET CSIORDERSTATUS=S.CSIORDERSTATUS,CSIFRAUDYN =S.CSIFRAUDYN," +
      "CSIWHOUPDATED =S.CSIWHOUPDATED,CSIWHENUPDATED =S.CSIWHENUPDATED," +
      "DECISION =S.DECISION,CURRENTSTATUS =S.CURRENTSTATUS,REALFRAUDYN=S.REALFRAUDYN," +
      "CHALLSOURCE =S.CHALLSOURCE,CHALLSTATUS =S.CHALLSTATUS," +
      "REALFRAUDYYYYMMDD =S.REALFRAUDYYYYMMDD,REALFRAUDDATE =S.REALFRAUDDATE," +
      "REALFRAUDTYPE =S.REALFRAUDTYPE," +
      "REALFRAUDDATEBAE =S.REALFRAUDDATEBAE,CLIENTID =S.CLIENTID,SUBCLIENTID =S.SUBCLIENTID," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    val updateTransCore = hiveSession.executeUpdate("MERGE INTO REDI.TRANS_MASTER_CORE AS D USING " +
      "(SELECT * FROM REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES_ON_WRITE) AS S ON (D.oid=S.oid) WHEN MATCHED " +
      "THEN UPDATE SET RealFraudYN='Y',REALFRAUDTYPE = S.RELFRAUDTYPE," +
      "REALFRAUDDATE = CURRENT_TIMESTAMP,REALFRAUDDATEBAE = CURRENT_TIMESTAMP," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    if (updateBiTransCore == false) {
      throw new Exception("Merge Issue in CSIOrderDisposition updateBiTransCore")
    }
    if (updateTransCore == false) {
      throw new Exception("Merge Issue in CSIOrderDisposition updateTransCore")
    }
  }*/

  def updateRbiRefClient(): Unit = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + "Started updating  the data into Hive table RBI_REF_CLIENT")


    val updateTransCore = hiveSession.executeUpdate("MERGE INTO REDI.rbi_ref_client AS D USING " +
      "(SELECT clientid FROM REDI.CSI_ORDER_DISP_TRANS_MASTER_UPDATES group by clientid) AS S ON (D.clientid=S.clientid and D.rsactive='Y') WHEN MATCHED " +
      "THEN UPDATE SET CSIActive='Y',ChallActive='Y',WHENUPDATED=" + current_timestamp() + ",WHOUPDATED='REDISYSTEM'")
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Inside storeInput2Hive Method")
    super.storeInput2Hive(inputDataFrame)
    if (transDetailDF != null) {
      //updateTransMasterCoreToHive(transDetailDF)
      updateRbiRefClient()
      callRollbackProcess(transDetailDF)
    }
    csiOrderDispositionLog.debug(CSIDATAPROCESS_DEBUG + ":Completed storeInput2Hive Method")
  }

  override def getODSWhereCondition(value: String): String = {

    " WHERE " + getRawDataFrameHWMColumn() + " > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and " + getRawDataFrameHWMColumn() + "  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }
}
