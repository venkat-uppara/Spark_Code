/**
  * @author : Sudhakar
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp
import java.text.{ParseException, SimpleDateFormat}
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSI2ProcessedOrdersController.{CSIDATAPROCESS_DEBUG, csiProcessOrderLog}
import com.aciworldwide.ra.redi.csi.controllers.CSIAccessDataController.{getClass, _}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions.{lit, minute, when, _}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Row, SaveMode, SparkSession}
import org.apache.spark.util.sketch.IncompatibleMergeException


object CSI2ProcessedOrdersController extends ReDiConstants with Serializable {

  @transient lazy val csiProcessOrderLog = LogManager.getLogger(getClass.getName)

  val DATEFORMATYYMMDD = "yyMMdd"
  val DATEFORMATYYYY_MM_DD = "yyyy-MM-dd"

  def ConvertTimeZone(inputdate: String, targetTimeZone: String): Timestamp = {
    csiAccessDataController.debug(CSIDATAPROCESS_DEBUG + ":inside ConvertTimeZone UDF")
    val simpleformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone("EST"))
    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }

  def addClientDt = udf((userLastAccess: String, timeZone: String, inputFormat: String, outputFormat: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside addClientDt UDF")
    var updDate: String = null
    if (!userLastAccess.isEmpty && userLastAccess != null) {
      val ClientDate =
        if (timeZone != null) {
          ConvertTimeZone(userLastAccess, timeZone)
        } else {
          ConvertTimeZone(userLastAccess, "America/New_York")
        }
      val inputFormatSDF = new SimpleDateFormat(inputFormat)
      val outputFormatSDF = new SimpleDateFormat(outputFormat)
      updDate = outputFormatSDF.format(inputFormatSDF.parse(ClientDate.toString))
    }

    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete addClientDt UDF")
    updDate
  })

  def dateFormatforGraphLabel = udf((inputDate: String, outputfomat: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside dateFormatforGraphLabel UDF")
    var date = ""
    if (inputDate == null || inputDate.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD)
      val outputFormat = new SimpleDateFormat(outputfomat)

      try {
        date = outputFormat.format(inputFormat.parse(inputDate))
      } catch {
        case ex: ParseException => csiProcessOrderLog.debug(CSIDATAPROCESS_ERROR + ":Unparseable date")
      }
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete dateFormatforGraphLabel UDF")
    date
  })

  def deriveClientId: UserDefinedFunction = udf((ClientId: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside deriveClientId UDF")
    var result = 0
    try {
      result = 99000000 + Integer.parseInt(ClientId)
    } catch {
      case e: Exception => csiProcessOrderLog.error(CSIDATAPROCESS_ERROR + ":Parse exception ClientId" + ClientId)
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete deriveClientId UDF")
    result
  })

  def getDifference: UserDefinedFunction = udf((days1: String, days2: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside getDifference UDF")
    val timediff = if (days1 != null && days2 != null) {
      val d1 = Integer.parseInt(days1)
      val d2 = Integer.parseInt(days2)
      new Integer(d1 - d2)
    } else {
      new Integer(-1)
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete getDifference UDF")
    timediff

  })

  def getDateDifference: UserDefinedFunction = udf((date1: String, date2: String, outputformat: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside getDateDifference UDF")
    val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
    var timeinformat = 0.0
    try {
      timeinformat = if (date1 != null && date2 != null) {
        var caldate1 = inputFormat.parse(date1)
        var caldate2 = inputFormat.parse(date2)

        var timeinmillisec = caldate2.getTime() - caldate1.getTime()

        val result = if (outputformat.equals("HOUR")) {
          val minute = (timeinmillisec / 1000.0) / 60.0
          val minuteTemp = Math.floor(minute)
          if (minuteTemp <= 0) {
            0.toDouble
          } else if (minuteTemp > 60) {
            val minRem = minuteTemp % 60
            ((minuteTemp - minRem) / 60 + (minRem * .01))
          } else {
            minuteTemp / 60
          }
        } else {
          Math.floor(((timeinmillisec / 1000.0) / 60.0))
        }
        result
      } else {
        0.toDouble
      }
    } catch {
      case e: Exception => csiProcessOrderLog.error(CSIDATAPROCESS_ERROR + ":Parse exception date1" + date1 + " " + date2 + " " + outputformat)
        0.toDouble
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete getDateDifference UDF")
    timeinformat

  })

  def minToHourUdf: UserDefinedFunction = udf((minute: Double) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside minToHourUdf UDF")
    if (minute != 0) {
      val minuteTemp = Math.floor(minute)
      if (minuteTemp > 60) {
        val minRem = minuteTemp % 60
        ((minuteTemp - minRem) / 60 + (minRem * .01))
      } else {
        minuteTemp / 60
      }
    }
    else {
      0.toDouble
    }
  })

  def hoursToMinuteUdf: UserDefinedFunction = udf((hour: Double) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside hoursToMinuteUdf UDF")
    if (hour != 0) {
      val hourOnly = Math.floor(hour)
      val minuteOnly = (hour - hourOnly) * 100
      (hourOnly * 60) + minuteOnly
    }
    else {
      0.toDouble
    }
  })

  def updateHoursBandCode: UserDefinedFunction = udf((overallHours: Integer) => {
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside updateHoursBand UDF")
    var overallHoursVar = overallHours
    if (overallHours == null || overallHours.equals("")) {
      overallHoursVar = new Integer("-1")
    }


    var returnValue = if (overallHoursVar <= 1) {
      "HR0001"

    } else if (overallHoursVar <= 2) {
      "HR0002"
    } else if (overallHoursVar <= 3) {
      "HR0003"
    } else if (overallHoursVar <= 4) {
      "HR0004"
    } else if (overallHoursVar <= 6) {
      "HR0006"
    } else if (overallHoursVar <= 8) {
      "HR0008"
    } else if (overallHoursVar <= 12) {
      "HR0012"
    } else if (overallHoursVar <= 24) {
      "HR0024"
    } else if (overallHoursVar <= 48) {
      "HR0048"
    } else if (overallHoursVar <= 72) {
      "HR0072"
    } else if (overallHoursVar <= 120) {
      "HR0120"
    } else {
      "HR9999"
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete updateHoursBand UDF")
    returnValue
  })

  def updateHoursBand: UserDefinedFunction = udf((overallhours: Integer) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside  updateHoursBandCode UDF")
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    var overallHoursVar = overallhours
    if (overallhours == null || overallhours.equals("")) {
      overallHoursVar = new Integer("-1")
    }


    var returnValue = if (overallHoursVar <= 1) {
      "Under 1 Hour"

    } else if (overallHoursVar <= 2) {
      "1-2 Hours"
    } else if (overallHoursVar <= 3) {
      "2-3 Hours"
    } else if (overallHoursVar <= 4) {
      "3-4 Hours"
    } else if (overallHoursVar <= 6) {
      "4-6 Hours"
    } else if (overallHoursVar <= 8) {
      "6-8 Hours"
    } else if (overallHoursVar <= 12) {
      "8-12 Hours"
    } else if (overallHoursVar <= 24) {
      "12-24 Hours"
    } else if (overallHoursVar <= 48) {
      "24-48 Hours"
    } else if (overallHoursVar <= 72) {
      "48-72 Hours"
    } else if (overallHoursVar <= 120) {
      "72-120 Hours"
    } else {
      ">120 Hours"
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete  updateHoursBandCode UDF")
    returnValue
  })

  def dateYYYYMMDDForFraud(date: String): String = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside   dateYYYYMMDDForFraud Method")
    var result = ""
    if (date == null || date.isEmpty) {

      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
      try {
        result = outputFormat.format(inputFormat.parse(date))
      } catch {
        case ex: ParseException => csiProcessOrderLog.error(CSIDATAPROCESS_ERROR + ":Unparseable date")
      }
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete   dateYYYYMMDDForFraud Method")
    result
  }

  def realFraudYYYYMMDD: UserDefinedFunction = udf((realfraudcol: String, otherwisecolumn: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside   realFraudYYYYMMDD UDF")
    if (realfraudcol != null && !realfraudcol.isEmpty) {
      realfraudcol
    }
    else {
      dateYYYYMMDDForFraud(otherwisecolumn)
    }
  })

  def realFraudRelatedColumns: UserDefinedFunction = udf((realfraudcol: String, otherwisecolumn: String) => {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside   realFraudRelatedColumns UDF")

    if (realfraudcol != null && !realfraudcol.isEmpty) {
      realfraudcol
    }
    else {
      otherwisecolumn
    }
  })

  def updateMinutesQueueBandSort: UserDefinedFunction = udf((minuitesToQueue: Integer) => {
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside   updateMinutesQueueBandSort UDF")
    var minutesToQueueVar = minuitesToQueue
    if (minuitesToQueue == null || minuitesToQueue.equals("")) {
      minutesToQueueVar = new Integer("-1")
    }


    var returnValue = if (minutesToQueueVar <= 2) {
      2

    } else if (minutesToQueueVar <= 4) {
      4
    } else if (minutesToQueueVar <= 5) {
      5
    } else if (minutesToQueueVar <= 6) {
      6
    } else if (minutesToQueueVar <= 7) {
      7
    } else if (minutesToQueueVar <= 8) {
      8
    } else if (minutesToQueueVar <= 9) {
      9
    } else if (minutesToQueueVar <= 10) {
      10
    } else if (minutesToQueueVar <= 15) {
      15
    } else if (minutesToQueueVar <= 20) {
      20
    } else {
      99
    }

    returnValue
  })


}


class CSI2ProcessedOrdersController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) {
  val csi1QueueHistoryCSI1 = new CSI1QueueHistoryDataController(sparkSession, csiDataDao)

  val refdates = hiveSession.executeQuery("select * from redi.RBI_REF_DATES")
  val DATEFORMATYYMMDD = "yyMMdd"
  val DATEFORMATYYYY_MM_DD = "yyyy-MM-dd"

  import sparkSession.implicits._

  override def getHiveTableName(): String = {
    REDI_CSI_CASES_HIVE_TABLE
  }

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_CASES_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_CASES_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_PROCESSED_ORDERS_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_PROCESSED_ORDER_CONTROL_KEY
  }

  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  override def setRawDataframe(RawCSIDataDF: DataFrame): Unit = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside   setRawDataframe method")

    csi1QueueHistoryCSI1.process()

    val csi1QueueHistoryCSI1DF = csi1QueueHistoryCSI1.getRawDataframe()

    val updateRawDRF = RawCSIDataDF.select(
      $"ID",
      $"CREATED_BY",
      $"CREATED_DATE",
      $"MODIFIED_BY",
      $"MODIFIED_DATE",
      $"OID",
      $"QUEUE_ID",
      $"PROCESS_BY_TYPE",
      $"QUEUED_DATETIME",
      $"PROCESSED_DATETIME",
      $"RESULTING_ACTION",
      $"TRANSACTION_ID",
      $"CANCEL_CODE",
      $"PROCESS_BY_USER_ID",
      $"PROCESS_BY_AUTO_ANALYST_ID",
      $"OID_DATE",
      $"PROCESS_BY_USER",
      $"CLIENT_ID",
      $"SUBCLIENT_ID").withColumn("RECOMMAND", lit(""))
      .withColumn("EBCARDTYPE", lit(""))
      .withColumn("EBSHIPMETHOD", lit(""))
      .withColumn("VIRTBILLSHIP", lit(""))
      .withColumn("EBTOF", lit(""))
      .withColumn("EBREFERRING_SITE", lit(""))
      .withColumn("EBTOTAL", lit(""))
      .withColumn("PRISM_SCORE", lit(""))
      .withColumn("EFALCON_SCORE", lit(""))
      .withColumn("PEND_DATE", lit(""))
      .withColumn("RESPONSE_STATUS", lit(""))
      .withColumn("CMSource", lit("C2"))


    val rawDF = if (csi1QueueHistoryCSI1DF != null) {
      updateRawDRF.union(csi1QueueHistoryCSI1DF)
    } else {
      updateRawDRF
    }
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete   setRawDataframe method")
    super.setRawDataFrame(rawDF)
  }

  override def csiTransformation(inputDataFrame1: DataFrame): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside csiTransformation method")

    val inputDataFrame = inputDataFrame1

    csiProcessOrderLog.info(CSIDATAPROCESS_INFO + ":Started Csi Transformations Processed Orders")

    //    var minDateDf = inputDataFrame.groupBy().agg(min(inputDataFrame("OID_DATE"))).head()
    //      .getTimestamp(0)
    //
    //    var trans_detail_sql = REDI_TRAN_DETAIL_TABLE + " where oiddateyyyymmdd >=  '" + dateYYYYMMDD(minDateDf.toString) + "'"

    var transDetailDF = hiveSession.executeQuery("Select * from bi_trans_master_core")

    var df = joinedDfForTransDetail(inputDataFrame, transDetailDF)


    df.cache()

    val csiQueue = hiveSession.executeQuery("select * from  " + REDI_CSI_QUEUES_TABLE + "").select($"QueueId", $"QueueName".alias("QueueNameQueue"), $"QueueNumber".alias("QueueNumberQueue"))

    df = df.join(csiQueue, Seq("QueueId"), "left_outer")

    df = df
      .withColumn("QueueName", when($"QueueNameQueue".isNotNull, $"QueueNameQueue").otherwise($"QueueName"))
      .withColumn("QueueNumber", when($"QueueNumberQueue".isNotNull, $"QueueNumberQueue").otherwise($"QueueNumber"))
      .withColumn("CMActive", lit("Y"))
      .withColumn("CM2ActiveTemp", when($"CMType" === "C2" || $"CMType" === "AA", lit("Y")).otherwise(lit("")))

    var cmActive = df.groupBy("Client12").agg(max("CM2ActiveTemp").alias("CM2ActiveTemp"))
      .select(
        $"Client12", $"CM2ActiveTemp"
      ).withColumn("CMActiveTemp", lit("Y"))

    var csiNotesDF = hiveSession.executeQuery("select * from " + REDI_CSI_NOTES_TABLE + "").select("OID", "UserId", "notedatetime").where(
      "NoteText like '%SYSTEM%Trans%Release%' OR NoteText LIKE '%SYSTEM%Trans%Cancel%'"
    )

    csiNotesDF = csiNotesDF.groupBy("OID").agg(max("UserId").alias("NotesUserId"), max("notedatetime").alias("NotesCompleteDateTime"))
      .select(
        $"OID", $"NotesUserId", $"NotesCompleteDateTime"

      )

    df = df.join(csiNotesDF, Seq("OID"), "left_outer")


    df = df.withColumn("UserId", when($"NotesUserId".isNotNull, $"NotesUserId").otherwise($"UserId"))
      .withColumn("CompleteDateTime", when($"CMSource" === "C1", when($"NotesCompleteDateTime".isNotNull, $"NotesCompleteDateTime").otherwise($"CompleteDateTime")).otherwise($"CompleteDateTime"))

    var csiPendsDF = hiveSession.executeQuery("select * from " + REDI_CSI_PENDS + "").select("OID", "PendDateTime")

    csiPendsDF = csiPendsDF.groupBy("OID").agg(count("OID").alias("PendsHowManyPends"), max("PendDateTime").alias("PendsLastPend"))
      .select(
        $"OID", $"PendsHowManyPends", $"PendsLastPend"

      )

    df = df.join(csiPendsDF, Seq("OID"), "left_outer")

    df = df.withColumn("HowManyPends", when($"PendsHowManyPends".isNotNull, $"PendsHowManyPends").otherwise($"HowManyPends"))
      .withColumn("LastPend", when($"PendsLastPend".isNotNull, $"PendsLastPend").otherwise($"LastPend"))


    val rbiRefClient = hiveSession.executeQuery("select * from  " + REDI_RBI_REF_CLIENT + "")


    val rbiRefClient_ClientOnly = rbiRefClient.select($"clientid", $"SUBCLIENTID", $"ClientName".alias("RbiClientName"), $"SubClientName".alias("RbiSubClientName"), $"tzclient")

    df = df.join(rbiRefClient_ClientOnly, Seq("clientid", "SUBCLIENTID"), "left_outer")


    var rbiRefClient_CMUpdate = rbiRefClient.join(cmActive, Seq("Client12"), "inner")

    rbiRefClient_CMUpdate = rbiRefClient_CMUpdate
      .withColumn("CMActive", $"CMActiveTemp")
      .withColumn("CM2Active", $"CM2ActiveTemp")


    rbiRefClient_CMUpdate = super.reorderSourceTableSchema(CLIENT_MASTER_COL_ORDER, addAuditColumns(rbiRefClient_CMUpdate))

    hiveSession.executeUpdate("delete from REDI.CSI_PROCESS_ORDER_RBI_REF_CLIENT_ON_WRITE")
    rbiRefClient_CMUpdate.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_PROCESS_ORDER_RBI_REF_CLIENT_ON_WRITE").save()

    hiveSession.executeUpdate("MERGE INTO REDI.rbi_ref_client AS D USING " +
      "(SELECT clientid,CMActive,CM2Active FROM REDI.CSI_PROCESS_ORDER_RBI_REF_CLIENT_ON_WRITE group by clientid,CMActive,CM2Active) AS S ON (D.clientid=S.clientid) WHEN MATCHED " +
      "THEN UPDATE SET CMActive=S.CMActive,CM2Active=S.CM2Active,WHENUPDATED=" + current_timestamp() + ",WHOUPDATED='REDISYSTEM'")


    df = df.withColumn("ClientName", $"RbiClientName")
      .withColumn("SubClientName", $"RbiSubClientName")
      .withColumn("Client12", concat($"clientid", $"SUBCLIENTID"))

    df = addClientDateTime(df)

    df = df.join(refdates, df("CompleteClientYYMMDD") === refdates("DateYYMMDD"), "left_outer")
    /*
        df = df.withColumn("CompleteClientWeek", when($"WeekActual".isNotNull, $"WeekActual").otherwise($"CompleteClientWeek"))
          .withColumn("GraphLabelWeek", when($"WeekActual".isNotNull, dateFormat($"WeekActual", lit("ddMmmyy"))).otherwise($"GraphLabelWeek"))   .withColumn("GraphLabelWeek", when($"WeekActual".isNotNull, dateFormat($"WeekActual", lit("ddMmmyy"))).otherwise($"GraphLabelWeek"))
    */
    //Rakesh changes
    df = df.withColumn("CompleteClientWeek", when($"WeekActual".isNotNull, $"WeekActual").otherwise($"CompleteClientWeek"))
      .withColumn("GraphLabelWeek", CSI2ProcessedOrdersController.dateFormatforGraphLabel($"WeekActual", lit("ddMMMyy")))


    val csiUsersDF = hiveSession.executeQuery("select * from " + REDI_CSI_USERS_TABLE + "")

    val csiUsersDF_1 = csiUsersDF.select($"UserId".alias("UsersUserId"), $"username".alias("Usersusername"), $"userfullname".alias("Usersuserfullname"))

    df = df.join(csiUsersDF_1, df("UserId") === csiUsersDF_1("UsersUserId"), "left_outer")


    df = df.withColumn("UserName", when($"Usersusername".isNotNull, $"Usersusername").otherwise($"username"))
      .withColumn("userfullname", when($"Usersuserfullname".isNotNull && $"Usersusername".isNotNull, $"Usersuserfullname").otherwise($"userfullname"))

    df = df.withColumn("UserName", when($"ClientId" === "000228" && $"UserId" === "101272", lit("VSC CMU")).otherwise($"username"))
      .withColumn("userfullname", when($"ClientId" === "000228" && $"UserId" === "101272", lit("VSC CMU")).otherwise($"userfullname"))

    df = df.withColumn("UserName", when($"CMType" === "AA", lit("AutoAnalyst")).otherwise($"username"))
      .withColumn("userfullname", when($"CMType" === "AA", lit("Auto Analyst")).otherwise($"userfullname"))
      .withColumn("UserID", when($"CMType" === "AA", CSI2ProcessedOrdersController.deriveClientId($"ClientId")).otherwise($"UserID"))

    val csiCancelCodesDF = hiveSession.executeQuery("select * from " + REDI_CSI_CANCEL_CODES_TABLE + "")
      .select($"CancelCode", $"CancelDesc".alias("CCCancelDesc"), $"CancelFraudYN".alias("CCCancelFraudYN"),
        $"ClientId", $"SubClientId"
      )

    df = df.join(csiCancelCodesDF, Seq("ClientId", "SubClientId", "CancelCode"), "left_outer")

    df = df.withColumn("CancelDesc", when($"CCCancelDesc".isNotNull && $"Outcome" === "Cancel", ($"CCCancelDesc")).otherwise($"CancelDesc"))
      .withColumn("CancelFraudYN", when($"CCCancelFraudYN".isNotNull && $"Outcome" === "Cancel", ($"CCCancelFraudYN")).otherwise($"CancelFraudYN"))

    df = df.withColumn("CancelReason", when($"CancelFraudYN".isNotNull && $"CancelFraudYN" === "Y" && $"CancelCode".isNotNull && $"CancelCode" =!= "", concat(lit("F-"), $"CancelCode")).otherwise(
      when($"CancelCode".isNotNull && $"CancelCode" =!= "",
        concat(lit("O-"), $"CancelCode")).otherwise($"CancelReason")))

    //val refdates_B = refdates.select($"Days2000".alias("Days2000_B"), $"DateYYMMDD".alias("DateYYMMDD_B")) // not required HDP 3.1 changes below line 449

    val refdates_B = hiveSession.executeQuery("select * from redi.RBI_REF_DATES").select($"Days2000".alias("Days2000_B"), $"DateYYMMDD".alias("DateYYMMDD_B"))

    df = df.join(refdates_B, df("OIDCLientYYMMDD") === refdates_B("DateYYMMDD_B"), "left_outer")


    df = df.withColumn("DaysToRelease", CSI2ProcessedOrdersController.getDifference($"Days2000", $"Days2000_B"))
      .withColumn("MinutesToRelease", CSI2ProcessedOrdersController.getDateDifference($"QueueDateTime", $"CompleteDateTime", lit("MIN")))
      .withColumn("HoursToRelease", CSI2ProcessedOrdersController.minToHourUdf($"MinutesToRelease"))
      // .withColumn("HoursToRelease", when($"MinutesToRelease" =!= 0, $"MnutesToRelease" % 60).otherwise(0))
      .withColumn("OverallHours", CSI2ProcessedOrdersController.getDateDifference($"OIDDateTime", $"CompleteDateTime", lit("HOUR")))
      .withColumn("HoursToQueue", CSI2ProcessedOrdersController.getDateDifference($"OIDDateTime", $"QueueDateTime", lit("HOUR")))
      //.withColumn("MinutesToQueue", when($"HoursToQueue" =!= 0, $"HoursToQueue" * 60).otherwise(0))
      .withColumn("MinutesToQueue", CSI2ProcessedOrdersController.getDateDifference($"OIDDateTime", $"QueueDateTime", lit("MIN")))
      .withColumn("MinutesQueueBandSort", CSI2ProcessedOrdersController.updateMinutesQueueBandSort($"MinutesToQueue"))
      .withColumn("HoursBand", CSI2ProcessedOrdersController.updateHoursBand($"OverallHours"))
      .withColumn("HoursBandCode", CSI2ProcessedOrdersController.updateHoursBandCode($"OverallHours"))
      .withColumn("CaseManagerYNTmp", when($"UserId".isNotNull, lit("Y")).otherwise(lit("N")))

    df = updateDaysToReleaseTextFn(df, "DaysToReleaseText")
    df = updateDaysToReleaseSortFn(df, "DaysToReleaseSort")
    df = updateMinutesQueueBandFn(df, "MinutesQueueBand")


     processForCSIUsers(df, csiUsersDF, csiUsersDF_1)

    df = df
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("client12", CSICommonMethods.remapClient12IDsForIKEA(concat(col("CLIENTID"), col("SUBCLIENTID")), col("CLIENTID"), col("SUBCLIENTID")))


    processTransMasterUpdates(df)

    df = super.reorderSourceTableSchema(CSI_CASES_TABLE_COL_ORDER_1, (addAuditColumns(df)))
    df
  }


  def joinedDfForTransDetail(inputDataFrame: DataFrame, transDetailDF: DataFrame): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside joinedDfForTransDetails method")
    val transDetail = transDetailDF.select($"OID", $"RECOMMENDATION".alias("recommendtransdetail"))
    var df = inputDataFrame.join(transDetail, Seq("OID"), "left_outer")

    df = df.select(
      $"OID",
      $"CREATED_BY".alias("UserId"),
      $"CREATED_DATE".alias("CompleteDateTime"),
      $"QUEUED_DATETIME".alias("QueueDateTime"),
      $"OID_DATE".alias("OIDDateTime"),
      $"CMSource",
      $"PROCESS_BY_TYPE",
      when($"CMSource" === lit("C2"),
        when($"PROCESS_BY_TYPE" like "AUTO%", lit("AA"))
          .otherwise(lit("C2")))
        .otherwise(lit("C1")).alias("CMType"),
      $"CLIENT_ID",
      when($"CMSource" === ("C2"),
        substring($"OID", 0, 6)).otherwise($"CLIENT_ID").alias("ClientId"),

      when($"CMSource" === ("C2"),
        substring($"OID", 7, 6)).otherwise($"SUBCLIENT_ID").alias("SubClientId"),

      $"OID",
      when($"CMSource" === ("C2"),
        substring($"OID", 0, 12)).otherwise(concat($"CLIENT_ID", $"SUBCLIENT_ID")).alias("Client12"),

      $"QUEUE_ID",
      when($"CMSource" === "C1", concat($"CLIENT_ID", lit("_"), when($"QUEUE_ID".isNotNull, $"QUEUE_ID").otherwise(lit("")))).otherwise($"QUEUE_ID").alias("QueueID"),


      when($"CMSource" === ("C1"),
        lit("CM1")).otherwise($"PROCESS_BY_TYPE").alias("ProcessType"),

      when($"RESULTING_ACTION" === ("APPROVE"),
        lit("Approve")).
        otherwise(
          when($"RESULTING_ACTION" === ("CANCEL"),
            lit("Cancel")).
            otherwise($"RESULTING_ACTION")
        ).alias("Outcome"),

      $"CANCEL_CODE".alias("CancelCode"),
      $"TRANSACTION_ID".alias("TransactionId"),
      $"ID".alias("InternalId"),
      $"RECOMMAND",
      $"recommendtransdetail",

      when($"RECOMMAND" === ("CHALLENGE"),
        lit("Challenge"))
        .when($"RECOMMAND" === ("DENY"),
          lit("Deny"))
        .when($"RECOMMAND" like ("%APPROVE"),
          lit("Accept"))
        //.when(($"RECOMMAND".isNull || $"RECOMMAND" === "") && $"recommendtransdetail".isNotNull, $"recommendtransdetail")
        .when(($"RECOMMAND".isNull || $"RECOMMAND" === "") && $"recommendtransdetail".isNotNull, recommandTransDetail($"recommendtransdetail"))
        .otherwise($"RECOMMAND")
        .alias("Recommend"),
      when($"CMSource" === ("C2"),
        lit("")).otherwise(when($"QUEUE_ID".isNotNull, $"QUEUE_ID").otherwise(lit(""))).alias("QueueNumber"),
      $"QUEUE_ID",
      when($"CMSource" === ("C2"),
        lit("")).
        when($"QUEUE_ID".isNotNull && $"QUEUE_ID" =!= "",
          concat(lit("Queue "), $"QUEUE_ID"))
        .otherwise(lit("No Queue Info")).alias("QueueName"),

      $"EBCARDTYPE",
      $"EBSHIPMETHOD",
      $"VIRTBILLSHIP",
      $"EBTOF",
      $"EBREFERRING_SITE",
      $"EBTOTAL",
      $"PRISM_SCORE".alias("prismscore"),
      $"EFALCON_SCORE".alias("efalconscore"),
      $"PEND_DATE".alias("PendDate"),
      $"RESPONSE_STATUS".alias("responsestatus"),
      $"ID",
      $"ID".alias("QID"),
      $"MODIFIED_BY".alias("modifiedby"),
      $"MODIFIED_DATE".alias("modifieddate"),
      $"PROCESS_BY_TYPE".alias("processbytype"),
      $"PROCESSED_DATETIME".alias("processeddatetime"),
      $"RESULTING_ACTION".alias("resultingaction"),
      $"PROCESS_BY_USER_ID".alias("processbyuserid"),
      $"PROCESS_BY_AUTO_ANALYST_ID".alias("processbyautoanalystid"),
      $"PROCESS_BY_USER".alias("processbyuser"),
      $"CREATED_BY".alias("createdby")
    ).withColumn("username", lit(""))
      .withColumn("userfullname", lit(""))
      .withColumn("completedatetimeclient", lit(""))
      .withColumn("queuedatetimeclient", lit(""))
      .withColumn("oiddatetimeclient", lit(""))
      .withColumn("completeclientyymmdd", lit(""))
      .withColumn("queueclientyymmdd", lit(""))
      .withColumn("oidclientyymmdd", lit(""))
      .withColumn("deltaminutes", lit(""))
      .withColumn("clientname", lit(""))
      .withColumn("subclientname", lit(""))
      .withColumn("cancelreason", lit(""))
      .withColumn("cancelfraudyn", lit(""))
      .withColumn("canceldesc", lit(""))
      .withColumn("minutestorelease", lit(""))
      .withColumn("hourstorelease", lit(""))
      .withColumn("daystorelease", lit(""))
      .withColumn("hoursbandcode", lit(""))
      .withColumn("hoursband", lit(""))
      .withColumn("hourstoqueue", lit(""))
      .withColumn("overallhours", lit(""))
      .withColumn("howmanypends", lit(""))
      .withColumn("lastpend", lit(""))
      .withColumn("lastpendclient", lit(""))
      .withColumn("completeclientweek", lit(""))
      .withColumn("minutestoqueue", lit(""))
      .withColumn("minutesqueueband", lit(""))
      .withColumn("minutesqueuebandsort", lit(""))
      .withColumn("graphlabelday", lit(""))
      .withColumn("graphlabelmonth", lit(""))
      .withColumn("graphlabelhour", lit(""))
      .withColumn("graphlabelweek", lit(""))
      .withColumn("flag1", lit(""))
      .withColumn("flag2", lit(""))
      .withColumn("flag3", lit(""))
      .withColumn("flag4", lit(""))
      .withColumn("flag5", lit(""))
      .withColumn("flag6", lit(""))
      .withColumn("xnote", lit(""))
      .withColumn("xtext1", lit(""))
      .withColumn("xtext2", lit(""))
      .withColumn("xnum1", lit(""))
      .withColumn("xnum2", lit(""))
      .withColumn("daystoreleasesort", lit(""))
      .withColumn("chargebackyn", lit(""))
      .withColumn("chargebackfraud", lit(""))
      .withColumn("chargebackdate", lit(""))
      .withColumn("fraudyn", lit(""))
      .withColumn("fraudtype", lit(""))
      .withColumn("frauddate", lit(""))
      .withColumn("daystoreleasetext", lit(""))
      .withColumn("cbfraudtext", lit(""))
      .withColumn("oiddate", col("OIDDateTime"))
      .withColumn("transid", lit(""))
      .withColumn("loaddatetime", lit(""))
      .withColumn("status", lit(""))
      .withColumn("instime", lit(""))
    // .withColumn("accessdateyyyymmdd",lit(""))

    df
  }


  def processForCSIUsers(df: DataFrame, csiUsersDF: DataFrame, csiUsersDF_1: DataFrame): Unit = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside processForCSIUsers method")
    var dfTemp = df.where("CaseManagerYNTmp = 'Y'")

    dfTemp = dfTemp.drop("ClientId")
      .drop("SubClientId")
      .drop("Client12")
      .drop("USERNAME")
      .drop("UserFullName")
      .drop("ModifiedBy")
      .drop("CreatedBy").drop("whenloaded").drop("wholoaded").drop("whenupdated").drop("whoupdated")

    val csiUsers = hiveSession.executeQuery("select * from " + REDI_CSI_USERS_TABLE + "")


    var updatedUsersDF = csiUsers.join(dfTemp, Seq("UserId"), "inner")

    updatedUsersDF = updatedUsersDF.drop("CaseManagerYN").withColumnRenamed("CaseManagerYNTmp", "CaseManagerYN")


    updatedUsersDF = super.reorderSourceTableSchema(CSI_USERS_TABLE_COL_ORDER, addAuditColumns(updatedUsersDF))

    updatedUsersDF = updatedUsersDF.dropDuplicates("UserId")

    hiveSession.executeUpdate("delete from REDI.CSI_USERS_ON_WRITE")

    updatedUsersDF.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_USERS_ON_WRITE").save()

    hiveSession.executeUpdate("MERGE INTO REDI.CSI_USERS AS D USING " +
      " (SELECT * FROM REDI.CSI_USERS_ON_WRITE) AS S ON (D.USERID=S.USERID) WHEN MATCHED THEN " +
      "UPDATE SET CASEMANAGERYN=S.CASEMANAGERYN")

    var dfAA = reorderSourceTableSchema("UserId,ClientId,SubClientId,Client12,CMType,UserName,UserFullName", addAuditColumns(df))

    hiveSession.executeUpdate("delete from REDI.CSI_USERS_FOR_AA_ON_WRITE")

    dfAA.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_USERS_FOR_AA_ON_WRITE").save()

    val df1 = hiveSession.executeQuery("select UserId,ClientId,SubClientId,Client12,CMType,UserName,UserFullName from REDI.CSI_USERS_FOR_AA_ON_WRITE")

    var csiUsersAddDF = df1.where($"CMType" === "AA").groupBy("UserId").agg(max("ClientId").alias("ClientId_1"),
      max("SubClientId").alias("SubClientId_1"), max("Client12").alias("Client12_1"),
      $"UserId", max("UserName").alias("UserName_1"), max("UserFullName").alias("UserFullName_1")
    )
      .select(
        $"ClientId_1".alias("ClientId"),
        $"SubClientId_1".alias("SubClientId"),
        $"Client12_1".alias("Client12"),
        $"UserId",
        $"UserName_1".alias("UserName"),
        $"UserFullName_1".alias("UserFullName"),
        concat($"UserName_1", lit("-"), $"UserFullName_1", lit("-"), $"SubClientId_1").alias("UserList")
      ).withColumn("USERSHORTNAME", lit("AutoAnalyst"))
      .withColumn("USERSTATUS", lit("ENABLED"))
      .withColumn("CaseManagerYN", lit("Y"))
      .withColumn("USERTYPE", lit("A"))
      .withColumn("USERMERCHANTYN", lit("Y"))
      .withColumn("CREATEDDATE", current_timestamp())
      .withColumn("USERMODIFIED", current_timestamp())
      .withColumn("USERLASTACCESS", current_timestamp())
      .withColumn("LEGACYUSERID", lit(""))
      .withColumn("SALUTATION_CODE", lit(""))
      .withColumn("USERFIRSTNAME", lit(""))
      .withColumn("USERMIDDLENAME", lit(""))
      .withColumn("USERLASTNAME", lit(""))
      .withColumn("MODIFIEDBY", lit(""))
      .withColumn("CREATEDBY", lit(""))
      .withColumn("DELETED", lit(""))
      .withColumn("PASSWORD", lit(""))
      .withColumn("PASSWORDSTATE", lit(""))
      .withColumn("SALT", lit(""))
      .withColumn("HASHTYPEFLAG", lit(""))


    val csiUsersDF_11 = hiveSession.executeQuery("select UserId from " + REDI_CSI_USERS_TABLE + "")

    //csiUsersAddDF = csiUsersAddDF.join(csiUsersDF_1, df("UserId") === csiUsersDF_1("UsersUserId"), "left_outer") old code not required

    //csiUsersAddDF = csiUsersAddDF.join(csiUsersDF_11,csiUsersAddDF("UserId") =!= csiUsersDF_11("UsersUserId"),"inner") //old code
    var csiUsersAddDF1 = csiUsersAddDF.join(csiUsersDF_11, Seq("UserId"), "leftanti")


    csiUsersAddDF1 = super.reorderSourceTableSchema(CSI_USERS_TABLE_COL_ORDER, addAuditColumns(csiUsersAddDF1))

    val del = hiveSession.executeUpdate("delete from REDI.CSI_USERS_ON_WRITE")


    csiUsersAddDF1.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "REDI.CSI_USERS_ON_WRITE").save()

    val res = hiveSession.executeUpdate("MERGE INTO REDI.CSI_USERS AS D USING " +
      " (SELECT * FROM REDI.CSI_USERS_ON_WRITE) AS S ON (D.USERID=S.USERID) WHEN MATCHED THEN " +
      "UPDATE SET CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,CLIENT12=S.CLIENT12,USERID=S.USERID,LEGACYUSERID=S.LEGACYUSERID," +
      "SALUTATION_CODE=S.SALUTATION_CODE,USERNAME=S.USERNAME,USERFIRSTNAME=S.USERFIRSTNAME,USERMIDDLENAME=S.USERMIDDLENAME,USERLASTNAME=S.USERLASTNAME,USERFULLNAME=S.USERFULLNAME," +
      "USERSHORTNAME=S.USERSHORTNAME,USERMERCHANTYN=S.USERMERCHANTYN,MODIFIEDBY=S.MODIFIEDBY," +
      "CREATEDDATE=S.CREATEDDATE,CREATEDBY=S.CREATEDBY,USERMODIFIED=S.USERMODIFIED,USERLASTACCESS=S.USERLASTACCESS,USERSTATUS=S.USERSTATUS,USERLIST=S.USERLIST,CASEMANAGERYN=S.CASEMANAGERYN," +
      "DELETED=S.DELETED,PASSWORD=S.PASSWORD,PASSWORDSTATE=S.PASSWORDSTATE,SALT=S.SALT,HASHTYPEFLAG=S.HASHTYPEFLAG," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.CLIENTID,S.SUBCLIENTID,S.CLIENT12,S.USERID,S.LEGACYUSERID,S.SALUTATION_CODE,S.USERNAME,S.USERFIRSTNAME,S.USERMIDDLENAME," +
      "S.USERLASTNAME,S.USERFULLNAME,S.USERSHORTNAME,S.USERMERCHANTYN,S.MODIFIEDBY,S.CREATEDDATE,S.CREATEDBY,S.USERMODIFIED,S.USERLASTACCESS,S.USERSTATUS,S.USERLIST,S.CASEMANAGERYN," +
      "S.DELETED,S.PASSWORD,S.PASSWORDSTATE,S.SALT,S.HASHTYPEFLAG," +
      "S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED,S.USERTYPE)")

    if (res == false) {
      throw new Exception("Error While merging the data fro CSI_USERS for process orders")
    }

    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete processForCSIUsers method")
  }


  private def processTransMasterUpdates(df: DataFrame): Unit = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":inside processTransMasterUpdates method")
    var oidDateTime = ""
    if (df != null) {
      oidDateTime = df.groupBy().agg(min(df("OIDDateTime"))).head()
        .getTimestamp(0).toString
    }


    val oidFilter = dateYYYYMMDD(oidDateTime)
    hiveSession.executeQuery("select * from redi.bed_audit_data where oiddateyyyymmdd >= '" + oidFilter + "'").createOrReplaceTempView("bed_audit_data_tempview")
    val bedDF = sparkSession.sql("Select OID , dataprocdate MaxProcDate  from bed_audit_data_tempview")
    hiveSession.executeQuery("select * from redi.csi_order_disp_audit_data where oiddateyyyymmdd >= '" + oidFilter + "'").createOrReplaceTempView("csi_order_disp_audit_data_tempview")
    val csiOrderStatus = sparkSession.sql("Select OID , LastUpdated MaxProcDate  from  csi_order_disp_audit_data_tempview")
    val df2 = bedDF.union(csiOrderStatus)

    var df1 = df.join(df2, Seq("OID"), "leftanti")
      .withColumn("MaxProcDate", lit(""))

    val df3 = df.join(df2, Seq("OID"), "inner").where($"CompleteDateTIme" > $"MaxProcDate")

    df1 = df1.union(df3)

    val dfStageCM = df1.select(
      $"OID",
      $"CancelReason".alias("CMCancelReasonSrc"),
      $"CompleteDateTime".alias("CMUpdateSrc"),
      when($"QueueNumber".isNotNull, $"QueueNumber").otherwise("na").alias("CMQIDSrc"),
      $"CancelFraudYN".alias("CMFraudSrc"),
      when($"Outcome" === "Cancel", lit("R")).otherwise(lit("A")).alias("DecisionSrc"),
      when($"Outcome" === "Cancel" && $"CancelFraudYN".equals("Y"), lit("RejFraud")).otherwise(
        when($"Outcome" === "Cancel", lit("RejOther")).otherwise(lit("Approve"))
      ).alias("CurrentStatusSrc"),
      $"OutCome".alias("CMStatusSrc"),
      lit("CM").alias("ChallSourceSrc"),
      when($"Outcome" === "Cancel" && $"CancelFraudYN".equals("Y"), lit("RejFraud")).otherwise(
        when($"Outcome" === "Cancel", lit("RejOther")).otherwise(lit("Approve"))
      ).alias("ChallStatusSrc"),
      $"UserId".alias("CMUserIdSrc"),
      $"UserName".alias("CMUserNameSrc"),
      $"UserFullName".alias("CMUserFullNameSrc"),
      $"QueueName".alias("CMQueueNameSrc"),
      $"CompleteDateTimeClient".alias("CMClientUpdateTimeSrc"),
      $"MODIFIEDDATE",
      $"QUEUEDATETIME"
    )


    val dfStageCMFraud = df1.select(
      $"OID",
      $"CompleteDateTime",
      $"CancelFraudYN",
      $"MODIFIEDDATE",
      $"QUEUEDATETIME"
    ).where($"CancelFraudYN" === "Y")

    hiveSession.executeUpdate("delete from REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE")
    updateTransDetailCore(dfStageCM, oidFilter)
    updateTransDetailCoreForFraud(dfStageCMFraud, oidFilter)
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete processTransMasterUpdates method")
  }

  def updateTransDetailCoreForFraud(inputDF: DataFrame, oidFilter: String): Unit = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Started updateTransDetailCore Fraud")

    //var trans_detail_sql = REDI_TRANS_MASTER_DETAILS + " where oiddateyyyymmdd >=  '" + oidFilter + "'"

    //val transDetail = hiveSession.executeQuery("Select * from redi.bi_trans_master_core where oiddateyyyymmdd >= '" + oidFilter + "'")  // to be uncommented later
    val transDetail = hiveSession.executeQuery("Select * from redi.bi_trans_master_core where oiddateyyyymmdd >= '"+oidFilter+"'")

    var df = inputDF.join(transDetail, Seq("OID"), "inner")

    df = df.withColumn("realfraudyn", lit("Y"))
      .withColumn("RealFraudYYYYMMDD", CSI2ProcessedOrdersController.realFraudYYYYMMDD($"RealFraudYYYYMMDD", $"CompleteDateTime"))
      .withColumn("RealFraudDate", CSI2ProcessedOrdersController.realFraudRelatedColumns($"RealFraudDate", $"CompleteDateTime"))
      .withColumn("RealFraudType", lit("CASE_MGR"))
      .withColumn("RELFRAUDYN", lit("Y"))
      .withColumn("RelFraudYYYYMMDD", $"RealFraudYYYYMMDD")
      .withColumn("RelFraudType", $"RealFraudType")
      .withColumn("RealFraudDateTime", current_timestamp()) // not there in hive
      .withColumn("realfrauddatebae", current_timestamp())


    val col_reorder = "OID,OIDDATE,MODIFIEDDATE,QUEUEDATETIME,REALFRAUDYN,REALFRAUDYYYYMMDD,REALFRAUDDATE,REALFRAUDTYPE,RELFRAUDYN,RELFRAUDYYYYMMDD,RELFRAUDTYPE," +
      "REALFRAUDDATEBAE,CMStatus,CMCANCELREASON,CMUPDATE,CMQID,CMFRAUD,CMUSERID,CMUSERNAME,CMUSERFULLNAME,CMQUEUENAME,CMCLIENTUPDATETIME,DECISION,CURRENTSTATUS,CHALLSOURCE,CHALLSTATUS," +
      "WhenLoaded,WhoLoaded,WhenUpdated,WhoUpdated"

    df = reorderSourceTableSchema(col_reorder, addAuditColumns(df))

    hiveSession.executeUpdate("delete from REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE")

    df.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE").save()
    val result = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING" +
      " (SELECT * FROM (SELECT *,ROW_NUMBER() OVER(PARTITION BY OID  ORDER BY (MODIFIEDDATE,QUEUEDATETIME) DESC) AS NUM  FROM REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE) LATEST  WHERE NUM=1) AS S ON (D.OID=S.OID) " +
      " WHEN MATCHED THEN UPDATE SET REALFRAUDYN=S.REALFRAUDYN,REALFRAUDYYYYMMDD=S.REALFRAUDYYYYMMDD,REALFRAUDDATE=S.REALFRAUDDATE," +
      "REALFRAUDTYPE=S.REALFRAUDTYPE,RELFRAUDYN=S.RELFRAUDYN,RELFRAUDYYYYMMDD=S.RELFRAUDYYYYMMDD,RELFRAUDTYPE=S.RELFRAUDTYPE," +
      "REALFRAUDDATEBAE=S.REALFRAUDDATEBAE,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    val transMasterCore = hiveSession.executeUpdate("MERGE INTO REDI.TRANS_MASTER_CORE AS D USING" +
      " (SELECT * FROM (SELECT *,ROW_NUMBER() OVER(PARTITION BY OID  ORDER BY (MODIFIEDDATE,QUEUEDATETIME) DESC) AS NUM  FROM REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE) LATEST  WHERE NUM=1) AS S ON (D.OID=S.OID) " +
      " WHEN MATCHED THEN UPDATE SET REALFRAUDYN='Y',REALFRAUDDATE=CURRENT_TIMESTAMP," +
      "REALFRAUDTYPE=S.REALFRAUDTYPE," +
      "REALFRAUDDATEBAE=CURRENT_TIMESTAMP,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")


    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":completed updateTransDetailCore Fraud")
  }


  def updateDaysToReleaseTextFn(inputDF: DataFrame, columnName: String): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside  updateDaysToReleaseTextFn Method")
    inputDF.withColumn(columnName, when($"DaysToRelease" === 0, "Same Day")
      .otherwise(when($"DaysToRelease" === 1, "Next Day")
        .otherwise(when($"DaysToRelease" === 2, "2 Days")
          .otherwise(when($"DaysToRelease" === 3, "3 Days")
            .otherwise(when($"DaysToRelease" <= 5, "4-5 Days")
              .otherwise(when($"DaysToRelease" <= 7, "6-7 Days")
                .otherwise(when($"DaysToRelease" <= 14, "8-14 Days")
                  .otherwise(when($"DaysToRelease" <= 28, "15-28 Days")
                    .otherwise("29 Days +")
                  )
                )
              )
            )
          )
        )
      )
    )

  }

  def updateDaysToReleaseSortFn(inputDF: DataFrame, columnName: String): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside  updateDaysToReleaseSortFn Method")
    inputDF.withColumn(columnName, when($"DaysToRelease" <= 3, $"daysToRelease")
      .otherwise(when($"DaysToRelease" <= 5, 4)
        .otherwise(when($"DaysToRelease" <= 7, 6)
          .otherwise(when($"DaysToRelease" <= 14, 8)
            .otherwise(when($"DaysToRelease" <= 28, 15)
              .otherwise(29)
            )
          )
        )
      )
    )

  }

  def updateMinutesQueueBandFn(inputDF: DataFrame, columnName: String): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside  updateMinutesQueueBandFn Method")
    inputDF.withColumn(columnName, when($"MinutesToQueue" <= 2, "Up to 2 minutes")
      .otherwise(when($"MinutesToQueue" <= 4, "2-4 minutes")
        .otherwise(when($"MinutesToQueue" <= 5, "4-5 minutes")
          .otherwise(when($"MinutesToQueue" <= 6, "5-6 minutes")
            .otherwise(when($"MinutesToQueue" <= 7, "6-7 minutes")
              .otherwise(when($"MinutesToQueue" <= 8, "7-8 minutes")
                .otherwise(when($"MinutesToQueue" <= 9, "8-9 minutes")
                  .otherwise(when($"MinutesToQueue" <= 10, "9-10 minutes")
                    .otherwise(when($"MinutesToQueue" <= 15, "10-15 minutes")
                      .otherwise(when($"MinutesToQueue" <= 20, "15-20 minutes")
                        .otherwise("Over 20 minutes")
                      )
                    )
                  )
                )
              )
            )
          )
        )
      )
    )
  }


  def addClientDateTime(inputDf: DataFrame): DataFrame = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Inside  addClientDateTime Method")

    val addedClientDtDf = inputDf

      .withColumn("CompleteDateTimeClient", when(col("CompleteDateTime").isNotNull,
        CSI2ProcessedOrdersController.addClientDt(col("CompleteDateTime"), col("TZClient"),
          lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("CompleteDateTimeClient", when(col("CompleteDateTimeClient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"CompleteDateTimeClient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))


      .withColumn("QueueDateTimeClient", when(col("QueueDateTime").isNotNull,
        CSI2ProcessedOrdersController.addClientDt(col("QueueDateTime"), col("TZClient"), lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("QueueDateTimeClient", when(col("QueueDateTimeClient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"QueueDateTimeClient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("OIDDateTimeClient", when(col("OIDDateTime").isNotNull,
        CSI2ProcessedOrdersController.addClientDt(col("OIDDateTime"), col("TZClient"), lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("OIDDateTimeClient", when(col("OIDDateTimeClient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"OIDDateTimeClient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("LastPendClient", when(col("LastPend").isNotNull,
        CSI2ProcessedOrdersController.addClientDt(col("LastPend"), col("TZClient"), lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("LastPendClient", when(col("LastPendClient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"LastPendClient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

      .withColumn("OIDClientyymmdd", CSICommonMethods.dateFormat($"OIDDateTimeClient", lit(DATEFORMATYYMMDD)))
      .withColumn("QueueClientyymmdd", CSICommonMethods.dateFormat($"QueueDateTimeClient", lit(DATEFORMATYYMMDD)))
      .withColumn("CompleteClientyymmdd", CSICommonMethods.dateFormat($"CompleteDateTimeClient", lit(DATEFORMATYYMMDD)))
      //.withColumn("GraphLabelDay", dateFormat($"CompleteDatetimeClient", lit("ddMmm")))
      //.withColumn("GraphLabelMonth", dateFormat($"CompleteDatetimeClient", lit("Mmmyy")))
      .withColumn("GraphLabelDay", CSICommonMethods.dateFormat($"CompleteDatetimeClient", lit("ddMMM")))
      .withColumn("GraphLabelMonth", CSICommonMethods.dateFormat($"CompleteDatetimeClient", lit("MMMYY")))
      .withColumn("GraphLabelHour", concat(CSICommonMethods.dateFormat($"CompleteDateTimeClient", lit("HH")), lit("00")))
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":complete  addClientDateTime Method")
    addedClientDtDf
  }


  def updateTransDetailCore(inputDF: DataFrame, oidFilter: String): Unit = {
    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Started updateTransDetailCore Method")

    var trans_detail_sql = REDI_TRANS_MASTER_CORE + " where oiddateyyyymmdd >=  '" + oidFilter + "'"

    //val transDetail = gettheDataFromHive(sparkSession, trans_detail_sql)
    //val transDetail = hiveSession.executeQuery("Select * from redi.bi_trans_master_core where oiddateyyyymmdd >= '" + oidFilter + "'")
    val transDetail = hiveSession.executeQuery("Select * from redi.bi_trans_master_core")

    var df = inputDF.join(transDetail, Seq("OID"), "inner")

    df = df.withColumn("CMStatus", $"CMStatusSrc")
      .withColumn("CMCancelReason", $"CMCancelReasonSrc")
      .withColumn("CMUpdate", $"CMUpdateSrc")
      .withColumn("CMQID", $"CMQIDSrc")
      .withColumn("CMFraud", $"CMFraudSrc")
      .withColumn("CMUserId", $"CMUserIdSrc")
      .withColumn("CMUserName", $"CMUserNameSrc")
      .withColumn("CMUserFullName", $"CMUserFullNameSrc")
      .withColumn("CMQueueName", $"CMQueueNameSrc")
      .withColumn("CMClientUpdatetime", $"CMClientUpdateTimeSrc")
      .withColumn("Decision", $"DecisionSrc")
      .withColumn("CurrentStatus", concat($"RECOMMENDATION", lit("->"), $"CurrentStatusSrc"))
      .withColumn("ChallSource", $"ChallSourceSrc")
      .withColumn("ChallStatus", $"ChallStatusSrc")

    val col_reorder = "OID,OIDDATE,MODIFIEDDATE,QUEUEDATETIME,REALFRAUDYN,REALFRAUDYYYYMMDD,REALFRAUDDATE,REALFRAUDTYPE,RELFRAUDYN,RELFRAUDYYYYMMDD,RELFRAUDTYPE," +
      "REALFRAUDDATEBAE,CMStatus,CMCANCELREASON,CMUPDATE,CMQID,CMFRAUD,CMUSERID,CMUSERNAME,CMUSERFULLNAME,CMQUEUENAME,CMCLIENTUPDATETIME,DECISION,CURRENTSTATUS,CHALLSOURCE,CHALLSTATUS," +
      "WhenLoaded,WhoLoaded,WhenUpdated,WhoUpdated"
    df = reorderSourceTableSchema(col_reorder, addAuditColumns(df))

    hiveSession.executeUpdate("delete from REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE")

    df.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", "CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE").save()

    val result = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING" +
      " (SELECT * FROM (SELECT *,ROW_NUMBER() OVER(PARTITION BY OID  ORDER BY (MODIFIEDDATE,QUEUEDATETIME) DESC) AS NUM  FROM REDI.CSI_CASES_TRANS_MASTER_UPDATES_ON_WRITE) LATEST  WHERE NUM=1) AS S ON (D.OID=S.OID) " +
      " WHEN MATCHED THEN UPDATE SET CMSTATUS=S.CMSTATUS,CMCANCELREASON=S.CMCANCELREASON,CMUPDATE=S.CMUPDATE," +
      "CMQID=S.CMQID,CMFRAUD=S.CMFRAUD,CMUSERID=S.CMUSERID,CMUSERNAME=S.CMUSERNAME," +
      "CMUSERFULLNAME=S.CMUSERFULLNAME,CMQUEUENAME=S.CMQUEUENAME,CMCLIENTUPDATETIME=S.CMCLIENTUPDATETIME,DECISION=S.DECISION,CURRENTSTATUS=S.CURRENTSTATUS," +
      "CHALLSOURCE=S.CHALLSOURCE,CHALLSTATUS=S.CHALLSTATUS," +
      "WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    csiProcessOrderLog.debug(CSIDATAPROCESS_DEBUG + ":Completed updateTransDetailCore Method")

  }

  def updateMinutesQueueBand: UserDefinedFunction = udf((minutesToQueue: Integer) => {
    //Approved' then 'A' when 'Released' then 'A' else 'R' end,
    var minutesToQueueVar = minutesToQueue
    if (minutesToQueue == null || minutesToQueue.equals("")) {
      minutesToQueueVar = new Integer("-1")
    }


    var returnValue = if (minutesToQueueVar <= 2) {
      "Up to 2 minutes"

    } else if (minutesToQueueVar <= 4) {
      "2-4 minutes"
    } else if (minutesToQueueVar <= 5) {
      "4-5 minutes"
    } else if (minutesToQueueVar <= 6) {
      "5-6 minutes"
    } else if (minutesToQueueVar <= 7) {
      "6-7 minutes"
    } else if (minutesToQueueVar <= 8) {
      "7-8 minutes"
    } else if (minutesToQueueVar <= 9) {
      "8-9 minutes"
    } else if (minutesToQueueVar <= 10) {
      "9-10 minutes"
    } else if (minutesToQueueVar <= 15) {
      "10-15 minutes"
    } else if (minutesToQueueVar <= 20) {
      "15-20 minutes"
    } else {
      "Over 20 minutes"
    }
    returnValue
  })

  override def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    super.updateControlTables(RawCSIDataDF)

    csi1QueueHistoryCSI1.updateControlTables(csi1QueueHistoryCSI1.getRawDataframe())

  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE CREATED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and  CREATED_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }


  def recommandTransDetail: UserDefinedFunction = udf((recommend: String) => {
    var result = ""
    if (recommend != null && !recommend.isEmpty) {
      if (recommend.equalsIgnoreCase("Deny")) {
        result = "Deny"
      }
      if (recommend.equalsIgnoreCase("Approve")) {
        result = "Approve"
      }
      if (recommend.equalsIgnoreCase("CHALLENGE")) {
        result = "Challenge"
      }
    }
    else {
      result
    }
    result
  })

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    val latestforCmSourceC2 = Window.partitionBy("QID").orderBy(desc("modifieddate"))
    val latestforCmSourceC1 = Window.partitionBy("OID", "TRANSACTIONID").orderBy(desc("OIDDateTime"))


    val CmsourceC2Data = inputDataFrame.withColumn("qid_row_number_C2", row_number() over latestforCmSourceC2).filter(col("CMSOURCE") === "C2" && col("qid_row_number_C2") === "1")
    val CmsourceC1Data = inputDataFrame.withColumn("oid_row_number_C1", row_number() over latestforCmSourceC1).filter(col("CMSOURCE") === "C1" && col("oid_row_number_C1") === "1")

    hiveSession.executeUpdate("delete from REDI.CSI_CASES_ON_WRITE")

    super.reorderSourceTableSchema(CSI_CASES_TABLE_COL_ORDER_1, CmsourceC2Data).write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    super.reorderSourceTableSchema(CSI_CASES_TABLE_COL_ORDER_1, CmsourceC1Data).write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()

    val result = hiveSession.executeUpdate("MERGE INTO REDI.CSI_CASES AS D USING " +
      " (SELECT * FROM REDI.CSI_CASES_ON_WRITE) AS S ON ((D.QID=S.QID AND S.CMSOURCE='C2') OR (D.OID=S.OID AND D.TRANSACTIONID=S.TRANSACTIONID AND S.CMSOURCE='C1')) WHEN MATCHED THEN " +
      "UPDATE SET OID=S.OID,USERID=S.USERID,USERNAME=S.USERNAME,USERFULLNAME=S.USERFULLNAME,COMPLETEDATETIME=S.COMPLETEDATETIME," +
      "COMPLETEDATETIMECLIENT=S.COMPLETEDATETIMECLIENT,QUEUEDATETIME=S.QUEUEDATETIME,QUEUEDATETIMECLIENT=S.QUEUEDATETIMECLIENT,OIDDATETIME=S.OIDDATETIME,OIDDATETIMECLIENT=S.OIDDATETIMECLIENT,COMPLETECLIENTYYMMDD=S.COMPLETECLIENTYYMMDD," +
      "QUEUECLIENTYYMMDD=S.QUEUECLIENTYYMMDD,OIDCLIENTYYMMDD=S.OIDCLIENTYYMMDD,CMTYPE=S.CMTYPE,CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID," +
      "CLIENT12=S.CLIENT12,DELTAMINUTES=S.DELTAMINUTES,CLIENTNAME=S.CLIENTNAME,SUBCLIENTNAME=S.SUBCLIENTNAME,RECOMMEND=S.RECOMMEND," +
      "QUEUEID=S.QUEUEID,QUEUENUMBER=S.QUEUENUMBER,QUEUENAME=S.QUEUENAME,PROCESSTYPE=S.PROCESSTYPE,OUTCOME=S.OUTCOME," +
      "CANCELCODE=S.CANCELCODE,CANCELREASON=S.CANCELREASON,CANCELFRAUDYN=S.CANCELFRAUDYN,CANCELDESC=S.CANCELDESC,MINUTESTORELEASE=S.MINUTESTORELEASE," +
      "HOURSTORELEASE=S.HOURSTORELEASE,DAYSTORELEASE=S.DAYSTORELEASE,HOURSBANDCODE=S.HOURSBANDCODE,HOURSBAND=S.HOURSBAND,HOURSTOQUEUE=S.HOURSTOQUEUE,OVERALLHOURS=S.OVERALLHOURS," +
      "TRANSACTIONID=S.TRANSACTIONID,INTERNALID=S.INTERNALID,HOWMANYPENDS=S.HOWMANYPENDS,LASTPEND=S.LASTPEND,LASTPENDCLIENT=S.LASTPENDCLIENT,WHENLOADED=S.WHENLOADED,COMPLETECLIENTWEEK=S.COMPLETECLIENTWEEK,MINUTESTOQUEUE=S.MINUTESTOQUEUE," +
      "MINUTESQUEUEBAND=S.MINUTESQUEUEBAND,MINUTESQUEUEBANDSORT=S.MINUTESQUEUEBANDSORT,GRAPHLABELDAY=S.GRAPHLABELDAY,GRAPHLABELMONTH=S.GRAPHLABELMONTH,GRAPHLABELHOUR=S.GRAPHLABELHOUR," +
      "GRAPHLABELWEEK=S.GRAPHLABELWEEK,FLAG1=S.FLAG1,FLAG2=S.FLAG2,FLAG3=S.FLAG3,FLAG4=S.FLAG4,FLAG5=S.FLAG5,FLAG6=S.FLAG6,XNOTE=S.XNOTE,XTEXT1=S.XTEXT1,XTEXT2=S.XTEXT2,XNUM1=S.XNUM1,XNUM2=S.XNUM2," +
      "DAYSTORELEASESORT=S.DAYSTORELEASESORT,CHARGEBACKYN=S.CHARGEBACKYN,CHARGEBACKFRAUD=S.CHARGEBACKFRAUD,CHARGEBACKDATE=S.CHARGEBACKDATE,FRAUDYN=S.FRAUDYN,FRAUDTYPE=S.FRAUDTYPE," +
      "FRAUDDATE=S.FRAUDDATE,DAYSTORELEASETEXT=S.DAYSTORELEASETEXT,CBFRAUDTEXT=S.CBFRAUDTEXT,OIDDATE=S.OIDDATE,TRANSID=S.TRANSID,PRISMSCORE=S.PRISMSCORE,EFALCONSCORE=S.EFALCONSCORE," +
      "RECOMMAND=S.RECOMMAND,LOADDATETIME=S.LOADDATETIME,PENDDATE=S.PENDDATE,STATUS=S.STATUS,INSTIME=S.INSTIME,QID=S.QID,RESPONSESTATUS=S.RESPONSESTATUS,EBCARDTYPE=S.EBCARDTYPE," +
      "EBSHIPMETHOD=S.EBSHIPMETHOD,VIRTBILLSHIP=S.VIRTBILLSHIP,EBTOF=S.EBTOF,EBREFERRING_SITE=S.EBREFERRING_SITE,EBTOTAL=S.EBTOTAL,ID=S.ID," +
      "CREATEDBY=S.CREATEDBY,MODIFIEDBY=S.MODIFIEDBY,MODIFIEDDATE=S.MODIFIEDDATE,PROCESSBYTYPE=S.PROCESSBYTYPE,PROCESSEDDATETIME=S.PROCESSEDDATETIME,RESULTINGACTION=S.RESULTINGACTION," +
      "PROCESSBYUSERID=S.PROCESSBYUSERID,PROCESSBYAUTOANALYSTID=S.PROCESSBYAUTOANALYSTID,PROCESSBYUSER=S.PROCESSBYUSER,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED," +
      "WHOUPDATED=S.WHOUPDATED " +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.OID,S.USERID,S.USERNAME,S.USERFULLNAME,S.COMPLETEDATETIME,S.COMPLETEDATETIMECLIENT,S.QUEUEDATETIME,S.QUEUEDATETIMECLIENT,S.OIDDATETIME," +
      "S.OIDDATETIMECLIENT,S.COMPLETECLIENTYYMMDD,S.QUEUECLIENTYYMMDD,S.OIDCLIENTYYMMDD,S.CMTYPE,S.CLIENTID,S.SUBCLIENTID,S.CLIENT12,S.DELTAMINUTES,S.CLIENTNAME," +
      "S.SUBCLIENTNAME,S.RECOMMEND,S.QUEUEID,S.QUEUENUMBER,S.QUEUENAME,S.PROCESSTYPE,S.OUTCOME,S.CANCELCODE," +
      "S.CANCELREASON,S.CANCELFRAUDYN,S.CANCELDESC,S.MINUTESTORELEASE,S.HOURSTORELEASE,S.DAYSTORELEASE,S.HOURSBANDCODE,S.HOURSBAND,S.HOURSTOQUEUE," +
      "S.OVERALLHOURS,S.TRANSACTIONID,S.INTERNALID,S.HOWMANYPENDS,S.LASTPEND,S.LASTPENDCLIENT,S.WHENLOADED,S.COMPLETECLIENTWEEK,S.MINUTESTOQUEUE,S.MINUTESQUEUEBAND,S.MINUTESQUEUEBANDSORT,S.GRAPHLABELDAY,S.GRAPHLABELMONTH," +
      "S.GRAPHLABELHOUR,S.GRAPHLABELWEEK,S.FLAG1,S.FLAG2,S.FLAG3,S.FLAG4,S.FLAG5,S.FLAG6,S.XNOTE,S.XTEXT1,S.XTEXT2,S.XNUM1,S.XNUM2,S.DAYSTORELEASESORT,S.CHARGEBACKYN," +
      "S.CHARGEBACKFRAUD,S.CHARGEBACKDATE,S.FRAUDYN,S.FRAUDTYPE,S.FRAUDDATE,S.DAYSTORELEASETEXT,S.CBFRAUDTEXT,S.OIDDATE,S.TRANSID,S.PRISMSCORE,S.EFALCONSCORE,S.RECOMMAND,S.LOADDATETIME," +
      "S.PENDDATE,S.STATUS,S.INSTIME,S.QID,S.RESPONSESTATUS,S.EBCARDTYPE,S.EBSHIPMETHOD,S.VIRTBILLSHIP,S.EBTOF,S.EBREFERRING_SITE,S.EBTOTAL,S.ID,S.CREATEDBY," +
      "S.MODIFIEDBY,S.MODIFIEDDATE,S.PROCESSBYTYPE,S.PROCESSEDDATETIME,S.RESULTINGACTION,S.PROCESSBYUSERID,S.PROCESSBYAUTOANALYSTID,S.PROCESSBYUSER," +
      "S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED,S.CMSOURCE)")

    if (result == false) {
      throw new Exception("Merge Error in CSI_CASES")
    }
  }
}

