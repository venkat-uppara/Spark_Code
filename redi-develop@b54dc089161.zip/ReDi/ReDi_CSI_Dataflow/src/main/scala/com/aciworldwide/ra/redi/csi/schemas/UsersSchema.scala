/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */


package com.aciworldwide.ra.redi.csi.schemas

import java.sql.Timestamp

case class UsersSchema(
                        CLIENTID                 : String      ,
                        SUBCLIENTID              : String      ,
                        CLIENT12                 : String      ,
                        USERID                   : Int         ,
                        LEGACYUSERID             : String      ,
                        SALUTATION_CODE          : String      ,
                        USERFIRSTNAME            : String      ,
                        USERMIDDLENAME           : String      ,
                        USERLASTNAME             : String      ,
                        USERFULLNAME             : String      ,
                        USERSHORTNAME            : String      ,
                        USERMERCHANTYN           : String     ,
                        MODIFIEDBY               : String      ,
                        CREATEDDATE              : Timestamp   ,
                        CREATEDBY                : String      ,
                        USERMODIFIED             : Timestamp   ,
                        USERLASTACCESS           : Timestamp   ,
                        USERSTATUS               : String      ,
                        USERLIST                 : String      ,
                        CASEMANAGERYN            : String     ,
                        DELETED                  : Int         ,
                        PASSWORD                 : String      ,
                        PASSWORDSTATE            : String      ,
                        SALT                     : String      ,
                        HASHTYPEFLAG             : Int         ,
                        WHENLOADED               : Timestamp   ,
                        WHOLOADED                : String      ,
                        WHENUPDATED              : Timestamp   ,
                        WHOUPDATED               : String      ,
                        USERTYPE                 : String


)
