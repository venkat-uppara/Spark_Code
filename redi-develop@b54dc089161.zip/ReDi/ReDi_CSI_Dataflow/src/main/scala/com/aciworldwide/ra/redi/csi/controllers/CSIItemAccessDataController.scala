/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.actions.CSIDataProcess
import com.aciworldwide.ra.redi.csi.controllers.CSIAccessDataController.getClass
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SparkSession}

class CSIItemAccessDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) with ReDiConstants {

  @transient lazy val csiItemAccessLog = LogManager.getLogger(getClass.getName)

  import sparkSession.implicits._

  override def getHiveTableName(): String = {
    REDI_CSI_ITEM_ACCESS_HIVE_TABLE
  }

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_ITEM_ACCESS_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_ITEM_ACCESS_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_ITEM_ACCESS_ODS_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_ITEM_ACCESS_CONTROL_KEY
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE ACCESS_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF3')" +
      " and  ACCESS_DATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF3')"
  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiItemAccessLog.debug(CSIDATAPROCESS_DEBUG + "Inside csiTransformation method")
    val usersDF = hiveSession.executeQuery("select ClientId, SubClientId, Client12, UserName, UserFullName, UserId from REDI.CSI_USERS")

    val reorderdedinputDF =
      inputDataFrame.select(
        $"USER_ID".alias("UserId"),
        $"OID",
        $"ID".alias("ItemAccessId"),
        $"ACCESS_DATE".alias("ItemAccessDateTime"),
        $"IP_ADDRESS".alias("IPADDRESS")
      )

    var usersAccessDF = reorderdedinputDF.join(usersDF, Seq("UserId"))

    var transDetailDF = hiveSession.executeQuery("select OID,TransactionId from " + BI_TRANS_MASTER_CORE + "")
    //transDetailDF = transDetailDF.select($"OID", $"TransactionId")
    usersAccessDF = usersAccessDF.join(transDetailDF, Seq("OID"), "left_outer")
    usersAccessDF = usersAccessDF.select(
      $"clientid",
      $"subclientid",
      $"client12",
      $"UserId",
      $"username",
      $"userfullname",
      $"OID",
      $"ItemAccessDateTime",
      $"ItemAccessID",
      $"IPADDRESS",
      when($"TransactionId".isNotNull, $"TransactionId").otherwise(lit("")).alias("TransactionId")
    )
      .withColumn("ItemAccessYYYYMMDD", CSICommonMethods.dateYYYYMMDDWithoutTimePart($"ItemAccessDateTime"))
      .withColumn("clientid", CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
      .withColumn("client12", CSICommonMethods.remapClient12IDsForIKEA(concat(col("CLIENTID"), col("SUBCLIENTID")), col("CLIENTID"), col("SUBCLIENTID")))
    usersAccessDF = addClientDateTime(usersAccessDF)
    csiItemAccessLog.debug(CSIDATAPROCESS_DEBUG + "compelete csiTransformation method")
    reorderSourceTableSchema(CSI_ITEM_ACCESS_TABLE_COL_ORDER, addAuditColumns(usersAccessDF))
  }

  def addClientDateTime(inputDf: DataFrame): DataFrame = {
    csiItemAccessLog.debug(CSIDATAPROCESS_DEBUG + "inside  addClientDateTime method")
    val rbiRefClient = hiveSession.executeQuery("select * from redi.rbi_ref_client").select("clientid", "SUBCLIENTID", "tzclient")

    val joinedDf = inputDf.join(rbiRefClient, Seq("clientid", "SUBCLIENTID"), "left_outer")


    val addedClientDtDf = joinedDf.withColumn("ItemAccessDateTimeClient", when(col("ItemAccessDateTime").isNotNull,
      CSICommonMethods.addClientDt(col("ItemAccessDateTime"), col("TZClient"), lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))
      .withColumn("ItemAccessYYYYMMDDClient",CSICommonMethods.dateYYYYMMDDWithoutTimePart(col("ItemAccessDateTimeClient")))

      .withColumn("ItemAccessDateTimeClient", when(col("ItemAccessDateTimeClient").isNotNull,
        CSICommonMethods.ConvertToTimestamp($"ItemAccessDateTimeClient", lit(DATEFORMATYYYY_MM_DD_HHMMSS), lit(DATEFORMATYYYY_MM_DD_HHMMSS))).otherwise(lit(null)))

    addedClientDtDf
  }


}

