package com.aciworldwide.ra.redi.csi.utils

import java.sql.Timestamp
import java.text.{ParseException, SimpleDateFormat}
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers.CSISubclientProfilesDataController.{csiSubClientProfileLog, getClass}
import com.aciworldwide.ra.redi.csi.controllers.CSIUsersDataController.{DATEFORMATYYYYMMDDHHMMSS, SERVER_TIMEZONE, TARGDATEFORMAT}
import org.apache.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object CSICommonMethods extends ReDiConstants with Serializable {

  @transient lazy val csiCommonLogs = LogManager.getLogger(getClass.getName)

  def dateFormat = udf((inputDate: String, outputfomat: String) => {
    csiCommonLogs.debug(CSIDATAPROCESS_DEBUG + ":inside dateFormat" + inputDate + ":" + outputfomat)
    var date = ""
    if (inputDate == null || inputDate.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(outputfomat)

      try {
        date = outputFormat.format(inputFormat.parse(inputDate))
      } catch {
        case ex: ParseException => csiCommonLogs.error(CSIDATAPROCESS_ERROR + ":Unparseable date")
      }
    }
    date
  })

  def remapClientIDsForIKEA = udf((clientId: String, subClientId: String) => {
    csiCommonLogs.debug(CSIDATAPROCESS_DEBUG + ":inside remapClientIDsForIKEA" + clientId + ":" + subClientId)
    var clientId_1 = clientId
    if (clientId != null && subClientId != null && clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194")
    }
    csiCommonLogs.debug(CSIDATAPROCESS_DEBUG + ":completed remapClientIDsForIKEA:" + clientId_1)
    clientId_1
  })


  def remapClient12IDsForIKEA = udf((client12: String, clientId: String, subClientId: String) => {
    csiCommonLogs.debug(CSIDATAPROCESS_DEBUG + ":inside remapClient12IDsForIKEA" + clientId + ":" + subClientId)
    var clientId_1 = client12
    if (clientId != null && subClientId != null && clientId.equals("000194")) {
      clientId_1 = "9".concat(subClientId.substring(1, 3)).concat("194").concat(subClientId)
    }
    csiCommonLogs.debug(CSIDATAPROCESS_DEBUG + ":inside remapClient12IDsForIKEA" + clientId + ":" + subClientId)
    clientId_1
  })

  def ConvertTimeZone(inputdate: String, targetTimeZone: String): Timestamp = {

    val simpleformat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone("EST"))

    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))

    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))

  }

  def clientSubclientDateZone = udf((OIDDate: String, TZValue: String) => {

    var returnDate = ""
    var inputTimeZone = TZValue
    if (inputTimeZone == null || inputTimeZone.isEmpty) {
      inputTimeZone = "America/New_York"
    }

    val simpleformat = new SimpleDateFormat(DATEFORMATEPOCH)
    simpleformat.setTimeZone(TimeZone.getTimeZone("EST"))

    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(inputTimeZone))

    returnDate = java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(OIDDate))).toString
    //    val returnDate = ConvertTimeZone(OIDDate, inputTimeZone)


    returnDate

  })

  def addClientDt = udf((userLastAccess: String, timeZone: String, inputFormat: String, outputFormat: String) => {

    var updDate: String = null
    if (!userLastAccess.isEmpty && userLastAccess != null) {
     // val timeutc=ConvertTimeZone(userLastAccess, "UTC").toString

      val ClientDate =
        if (timeZone != null) {
          ConvertTimeZone(userLastAccess, timeZone)
        } else {
          ConvertTimeZone(userLastAccess, "America/New_York")
        }
      val inputFormatSDF = new SimpleDateFormat(inputFormat)
      val outputFormatSDF = new SimpleDateFormat(outputFormat)
      updDate = outputFormatSDF.format(inputFormatSDF.parse(ClientDate.toString))
    }
    updDate
  })

  def dateYYYYMMDDWithoutTimePart = udf((notedate: String) => {
    csiCommonLogs.info(CSIDATAPROCESS_INFO + ":Inside dateYYYYMMDDWithoutTimePart UDF")
    var date = ""
    if (notedate == null || notedate.isEmpty) {
      ""
    } else {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)

      try {
        date = outputFormat.format(inputFormat.parse(notedate))
      } catch {
        case ex: ParseException => csiCommonLogs.error(CSIDATAPROCESS_ERROR + ":Unparseable date in dateYYYYMMDDWithoutTimePart")
      }
    }
    date
  })

  def timeDifference: UserDefinedFunction = udf((starttime: String, endtime: String) => {

    var result = 0L
    val inputFormat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)

    var startDate = inputFormat.parse(starttime)
    var endDate = inputFormat.parse(endtime)

    result = (startDate.getTime() - endDate.getTime) / 1000

    result
  })

  def convertedtzFromEstToUtc = udf((OIDDate: String) => {

    var returnDate = ""

    if(OIDDate!=null && !OIDDate.trim.isEmpty) {
      val simpleformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      simpleformat.setTimeZone(TimeZone.getTimeZone(OID_SOURCE_TZ))

      val targetformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      targetformat.setTimeZone(TimeZone.getTimeZone(OID_TARGET_TZ))

      returnDate = java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(OIDDate))).toString
      //    val returnDate = ConvertTimeZone(OIDDate, inputTimeZone)
    }

    returnDate

  })

  def getTZConvertedDate = udf((OIDDate: String, TZValue: String) => {

    var returnDate = ""

    if(OIDDate!=null && !OIDDate.trim.isEmpty) {
      var inputTimeZone = TZValue
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }

      val simpleformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      simpleformat.setTimeZone(TimeZone.getTimeZone("EST"))

      val targetformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
      targetformat.setTimeZone(TimeZone.getTimeZone(inputTimeZone))

      returnDate = java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(OIDDate))).toString
      //    val returnDate = ConvertTimeZone(OIDDate, inputTimeZone)
    }

    returnDate

  })

  def ConvertToTimestamp: UserDefinedFunction = udf((inputdate: String, sourceformat: String, targetformat: String) => {
    val sourceformatObj = new SimpleDateFormat(sourceformat)
    val targetformatObj = new SimpleDateFormat(targetformat)
    java.sql.Timestamp.valueOf(targetformatObj.format(sourceformatObj.parse(inputdate)))
  })


}
