/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.TimeZone

import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.spark.sql.functions.{lit, max}




abstract class CSIBaseDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends DateUtils with CSIUtils with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices
   {


  @transient lazy val csiBaseDataController = LogManager.getLogger(getClass.getName)
  val serialversionUID = 129348938L
  var rawDataFrame: DataFrame = null
  val hiveSession= HiveWarehouseSession.session(sparkSession).build()
  hiveSession.setDatabase(REDI_DATABASE)

  def getHiveTableName(): String

  def getControlKey(): String

  def getODSTableName(): String

  def getODSWhereCondition(value: String): String

  def csiTransformation(inputDataFrame: DataFrame): DataFrame

  def getLocalHDFSStorageValue(): String

  def getRawDataFrameHWMColumn(): String

  def getStartRawDataFrameHWMColumn(): String = {
    getRawDataFrameHWMColumn()
  }

  // Schema the ODS Table beleongs to
  def getDatabaseSchema(): String = {
    CSI_DATABASE
  }

  def isProcessController(): Boolean = {
    true
  }

  // Uitility method for setting the raw dataframe in case more than 1 table is involved
  def setRawDataFrame(inputDataFrame: DataFrame): Unit = {
    rawDataFrame = inputDataFrame
  }

  /*Store to Hive */
  def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    csiBaseDataController.debug("Starting to push the data into Hive table " + getHiveTableName()+ " "+this.getClass)
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    csiBaseDataController.debug("Completed to push the data into Hive table " + getHiveTableName()+ " "+this.getClass)
  }

  ////
  ////  /** ****************************************************************************************************************************************************
  ////    * This is the method which is invoked by the action
  ////    * This will be used to ingest and process the CSI Data from Source into Destination
  ////    * ***************************************************************************************************************************************************/


  def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    val CSI_MASTER_QUERY = "(SELECT * FROM " + getDatabaseSchema() + "." + getODSTableName() + getODSWhereCondition(CSIHWMID) + ") CSI_Data"

    val RawCSIDataDF = fetchCSIData(csiDataDao, CSI_MASTER_QUERY, ORACLE_CONN_TYPE, getDatabaseSchema())
    csiBaseDataController.info("Fetched CSI Data into processing layer " + getDatabaseSchema() + "." + getODSTableName())
    csiBaseDataController.info("QUERY: " +CSI_MASTER_QUERY)

    /** Caching the Dataframe, so that the data presists in memory and can be easy to push into HDFS */
    RawCSIDataDF.cache()

    RawCSIDataDF

  }


  def getHWMId(): String = {
    csiBaseDataController.info(CSIDATAPROCESS_INFO + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    var hwmDate = hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + getControlKey() + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    csiBaseDataController.info(CSIDATAPROCESS_INFO + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    hwmDate
  }

  def setRawDataframe(RawCSIDataDF: DataFrame) = {
    this.rawDataFrame = RawCSIDataDF
  }

  def getRawDataframe(): DataFrame = {
    this.rawDataFrame
  }


  def process(): Unit = {
    csiBaseDataController.info(CSIDATAPROCESS_INFO + ": Inside process method CSIBaseDataContoller")
    val CSIHWMID = getHWMId

    /** Ingestion Process Step: 01
      * Get the High Water Mark for CSI Data from Hive control table
      * The value returned will be stored in the CSIHWMGID variable. */

    /** Ingestion Process Step: 02
      * 1. Check whether the HWM for CSI CB process (GROUP_ID) is null.
      * If null then throw an error that on the oracle date converted and exit.
      * 2. If the HWM for CSI CB process is not null then read incremental data from Oracle (only new data which has come after High water mark date)
      */


    if (CSIHWMID == null) {
      csiBaseDataController.info(CSIDATAPROCESS_INFO + ":There is a error in the " + getControlKey() + " value stored in Hive" + CSIHWMID)
      csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + ":There is a error in the " + getControlKey() + " value stored in Hive" + CSIHWMID)
    }
    else {
      /** Ingestion Process Step: 02(A)
        * Creating the Query that will be executed in Oracle to get data for Respective Table Name. */

      csiBaseDataController.info(CSIDATAPROCESS_INFO + " :Before Fetch : " + getCurrentdateTimeStamp + " " + getControlKey())
      csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + " :Before Fetch : " + getCurrentdateTimeStamp + " " + getControlKey())
      val RawCSIDataDF = fetchRawDataFromODS(CSIHWMID)
      csiBaseDataController.info(CSIDATAPROCESS_INFO + " :After Fetch : " + getCurrentdateTimeStamp + " " + getControlKey())
      csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + " :After Fetch : " + getCurrentdateTimeStamp + " " + getControlKey())

      /** Reading the Dataframe for getting the total count of records that was Ingested from Oracle
        * This value is pushed into the variable CSIDataCount. */

      // logRegularMessage("Raw data Count: " + RawCSIDataDF.count())
      /** Ingestion Process Step: 03
        * Updating the Process Status in the into Hive Control table */

      // Setting the Start time of the CSI CBData
      csiBaseDataController.info(CSIDATAPROCESS_INFO +":Before Control Table Process : " + getCurrentdateTimeStamp + " "+getControlKey())
      csiBaseDataController.debug(CSIDATAPROCESS_DEBUG +":Before Control Table Process : " + getCurrentdateTimeStamp + " "+getControlKey())
      val startTimeCSIDataLoad = getCurrentdateTimeStamp
      controlTableDataProcess(RawCSIDataDF, getStartRawDataFrameHWMColumn(), getControlKey(), PROCESS_CONTROL_STARTED, startTimeCSIDataLoad.toString, "", "Starting to Fetch the CSI from ODS into HDFS",CSI_DATA_PROCESS)

      csiBaseDataController.info(CSIDATAPROCESS_INFO + " : After Control Table Process : " + getCurrentdateTimeStamp+" "+getControlKey())
      csiBaseDataController.debug(CSIDATAPROCESS_DEBUG +": After Control Table Process : " + getCurrentdateTimeStamp + " "+getControlKey())


      setRawDataframe(RawCSIDataDF)

      /** Transformation Process Step:01 */

      if (isProcessController) {
        csiBaseDataController.info(CSIDATAPROCESS_INFO +":Before Transformation Process : " + getCurrentdateTimeStamp+ " "+getControlKey())

        val TransformCSIDataDF = csiTransformation(this.rawDataFrame)

        csiBaseDataController.debug(CSIDATAPROCESS_DEBUG +":After Transformation Process : " + getCurrentdateTimeStamp+ " "+getControlKey())


        csiBaseDataController.info(CSIDATAPROCESS_INFO+ ": Before storeInput2Hive Process : " + getCurrentdateTimeStamp+ " "+ this.getClass)

        storeInput2Hive(TransformCSIDataDF)

        csiBaseDataController.info(CSIDATAPROCESS_INFO+ ":After storeInput2Hive Process : " + getCurrentdateTimeStamp + " "+ this.getClass)
        csiBaseDataController.info(CSIDATAPROCESS_INFO+ ":Before updateControlTables Final Process : " + getCurrentdateTimeStamp + " "+ this.getClass)
        updateControlTables(RawCSIDataDF)

        csiBaseDataController.info(CSIDATAPROCESS_INFO+ " :After updateControlTables Final Process : " + getCurrentdateTimeStamp + " "+ this.getClass)

        /** Ingestion Process Step: 04
          * Pushing the Data from Dataframe into HDFS */
        csiBaseDataController.info(CSIDATAPROCESS_INFO+ "Before saveCSIDatatoHDFS Process : " + getCurrentdateTimeStamp+ " "+ this.getClass)
        saveCSIDatatoHDFS(this.rawDataFrame)
        csiBaseDataController.info(CSIDATAPROCESS_INFO+ "After saveCSIDatatoHDFS Process : " + getCurrentdateTimeStamp+ " "+ this.getClass)

        /**
          * Final message of how many records were ingested and stored in HDFS as part of CSI CB Process
          */
        //logRegularMessage("Total of " + RawCSIDataDF.count() + " records ingested to ReDi File storage "+ getHiveTableName() )
      }

    }
  }

  def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    /** Ingestion Process Step: 05
      * Reading the Dataframe for getting the MAXIMUM of HWM Column from the data Ingested from Oracle
      * This value is pushed into Hive Control Table.
      * Updating the Maximum HWM Column into Hive Control table and Marking the end of process */

    // Setting the End time of the CSI CBData
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG+ "Inside updateControlTables method " + getCurrentdateTimeStamp+ " "+ this.getClass)
    val endTimeCSIDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(RawCSIDataDF, getRawDataFrameHWMColumn(), getControlKey(), PROCESS_CONTROL_COMPLETED,"",endTimeCSIDataLoad.toString, "Completed the CSI data Fetch from ODS into HDFS",CSI_DATA_PROCESS)
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG+ "Inside updateControlTables method " + getCurrentdateTimeStamp+ " "+ this.getClass)
  }


  ////  /**
  ////    * This method is used to store the data from source into HDFS. */
  def saveCSIDatatoHDFS(inputDataFrame: DataFrame): Unit = {
    csiBaseDataController.info(CSIDATAPROCESS_INFO+ " :Starting to load data into HDFS location :" + this.getClass)
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG + "Starting to load data into HDFS location :" + this.getClass)

    csiDataDao.saveDataintoHDFS(inputDataFrame, "orc", ConfigFactory.load().getString(getLocalHDFSStorageValue()), HDFS_STORAGE_DATE_EXT)

    csiBaseDataController.info(CSIDATAPROCESS_INFO+ "Finished loading the data into HDFS location :" + this.getClass)
    csiBaseDataController.debug(CSIDATAPROCESS_DEBUG+ "Finished loading the data into HDFS location :" + this.getClass)
  }

  override def ConvertTimeZone(inputdate: String, targetTimeZone: String): Timestamp = {
    val simpleformat = new SimpleDateFormat(DATEFORMATYYYY_MM_DD_HHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))
    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }

  /** This udf was created by @author: Krishnaprasad Ramkumar [KP]
    * This udf is created to add description to the CardTypeDesc Column */
  /**
    * def funcAddTransformedColumns: UserDefinedFunction = udf((inputValue: String, inputColumn: String, returnInput: Boolean ) => {
    * var outputString: String = null
    * var df: DataFrame = null
    * *
    *
    * if (inputValue != null && !inputValue.isEmpty) {
    * df = dfTrnsMetadataBC.value.select($"TransformValue").where($"sourceColumn" === inputColumn && $"Key" === inputValue)
    * }
    * if (df != null && df.count() > 0) {
    * outputString = df.head().getString(0)
    * }
    * else if(inputValue == null) {
    * outputString = null
    * }  else if(inputValue != null && returnInput) {
    * outputString = inputValue.trim
    * } else {
    * outputString = "Unknown "+inputColumn+" "+inputValue
    * }
    * println( "outputString :" + outputString)
    * *
    * outputString
    * })
    **/
}

