/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp

import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class CSI1QueueNotesDataController(sparkSession: SparkSession, csiDataDao: CSIDataDao) extends DateUtils with CSIUtils {

  private var rawDataFrame: DataFrame = null
  val hiveSession = HiveWarehouseSession.session(sparkSession).build()
  hiveSession.setDatabase(REDI_DATABASE)
  private var CSITXNNOTES_COLUMN_ORDER = "ID,OID,CREATED_DATE,CREATED_BY,MODIFIED_DATE,MODIFIED_BY,NOTE,ORDER_STATUS,NOTE_SOURCE,USER_ACTION,NOTETYPE,clientid,subclientid"
  @transient lazy val csiQueueNoteDataController = LogManager.getLogger(getClass.getName)


  import sparkSession.implicits._

  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_QUEUE_NOTES_TABLE_HWM_COLUMN
  }

  def getODSTableName(): String = {
    REDI_CSI_QUEUE_NOTES_TABLE_NAME
  }

  def getControlKey(): String = {
    REDI_CSI_TXN_NOTES_CS1_CONTROL_KEY
  }

  def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  def getODSWhereCondition(value: String): String = {

    " WHERE NOTEDATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and  NOTEDATE  <= to_timestamp('" + addoffset() + "' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }


  def getHWMId(): String = {
    csiQueueNoteDataController.info(CSIDATAPROCESS_INFO + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    csiQueueNoteDataController.debug(CSIDATAPROCESS_DEBUG + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    var hwmDate = hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + getControlKey() + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    csiQueueNoteDataController.info(CSIDATAPROCESS_INFO + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    csiQueueNoteDataController.debug(CSIDATAPROCESS_DEBUG + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    hwmDate
  }

  def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    val CSI_MASTER_QUERY = "(SELECT * FROM " + getDatabaseSchema() + "." + getODSTableName() + getODSWhereCondition(CSIHWMID) + ") CSI_Data"

    val RawCSIDataDF = fetchCSIData(csiDataDao, CSI_MASTER_QUERY, ORACLE_CONN_TYPE, getDatabaseSchema())
    csiQueueNoteDataController.debug(CSIDATAPROCESS_DEBUG+":Fetched CSI Data into processing layer " + getDatabaseSchema() + "." + getODSTableName())
    csiQueueNoteDataController.info("Fetched CSI Data into processing layer " + getDatabaseSchema() + "." + getODSTableName())
    csiQueueNoteDataController.info("QUERY: " +CSI_MASTER_QUERY)

    /** Caching the Dataframe, so that the data presists in memory and can be easy to push into HDFS */
    RawCSIDataDF.cache()

    RawCSIDataDF

  }

  def CSIDataPipeline(): Unit = {
    csiQueueNoteDataController.info(CSIDATAPROCESS_INFO+":Inside CSIDataPipeline Method ")
    // Do nothing
    val CSIHWMID = getHWMId

    /** Ingestion Process Step: 01
      * Get the High Water Mark for CSI Data from Hive control table
      * The value returned will be stored in the CSIHWMGID variable. */

    /** Ingestion Process Step: 02
      * 1. Check whether the HWM for CSI CB process (GROUP_ID) is null.
      * If null then throw an error that on the oracle date converted and exit.
      * 2. If the HWM for CSI CB process is not null then read incremental data from Oracle (only new data which has come after High water mark date)
      */

    if (CSIHWMID == null) {
      csiQueueNoteDataController.info(CSIDATAPROCESS_INFO+":There is a error in the " + getControlKey() + " value stored in Hive" + CSIHWMID)
    }
    else {
      /** Ingestion Process Step: 02(A)
        * Creating the Query that will be executed in Oracle to get data for Respective Table Name. */

      val RawCSIDataDF = fetchRawDataFromODS(CSIHWMID)


      /** Ingestion Process Step: 03
        * Updating the Process Status in the into Hive Control table */

      // Setting the Start time of the CSI CBData
      val startTimeCSIDataLoad = getCurrentdateTimeStamp
      controlTableDataProcess(RawCSIDataDF, getRawDataFrameHWMColumn(), getControlKey(), PROCESS_CONTROL_STARTED, startTimeCSIDataLoad.toString, "", "Starting to Fetch the CSI from ODS into HDFS/HIVE", CSI_DATA_PROCESS)

      /** Reading the Dataframe for getting the total count of records that was Ingested from Oracle
        * This value is pushed into the variable CSIDataCount. */

      setRawDataframe(RawCSIDataDF)
    }
  }

  def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    /** Ingestion Process Step: 05
      * Reading the Dataframe for getting the MAXIMUM of HWM Column from the data Ingested from Oracle
      * This value is pushed into Hive Control Table.
      * Updating the Maximum HWM Column into Hive Control table and Marking the end of process */

    // Setting the End time of the CSI CBData
    val endTimeCSIDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(RawCSIDataDF, "CREATED_DATE", getControlKey(), PROCESS_CONTROL_COMPLETED, "", endTimeCSIDataLoad.toString, "Completed the  Fetch the CSI from ODS into HDFS/HIVE", CSI_DATA_PROCESS)
  }

  def setRawDataframe(RawCSIDataDF: DataFrame) = {
    csiQueueNoteDataController.info(CSIDATAPROCESS_INFO+":Inside setRawDataframe Method ")
    this.rawDataFrame =
      RawCSIDataDF.select(
        $"OID",
        substring($"NOTE", 0, 255).alias("NOTE"),
        $"USERID".alias("CREATED_BY"),
        $"NOTEDATE".alias("CREATED_DATE"),
        concat($"ClientId", lit("-"), $"NoteId").alias("ID"),
        $"clientid",
        $"sub_clientid".alias("subclientid")
      ).withColumn("NoteType", lit("CM"))
        .withColumn("Note_Source", lit("Q1"))
        .withColumn("MODIFIED_DATE", lit(""))
        .withColumn("MODIFIED_BY", lit(""))
        .withColumn("ORDER_STATUS", lit(""))
        .withColumn("USER_ACTION", lit(""))


    this.rawDataFrame = reorderSourceTableSchema(CSITXNNOTES_COLUMN_ORDER, rawDataFrame)
    rawDataFrame
  }

  def getRawDataframe(): DataFrame = {
    this.rawDataFrame
  }
}

