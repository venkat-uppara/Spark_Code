/**
  * @author : Sudhakar
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSICommonMethods
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}


class CSIQueuesController (sparkSession: SparkSession, csiDataDao: CSIDataDao )  extends CSIBaseDataController (sparkSession: SparkSession, csiDataDao: CSIDataDao )  with ReDiConstants
   {

  @transient lazy val csiQueueDataContorller = LogManager.getLogger(getClass.getName)
  val csi1Queue=  new CSI1QueueController(sparkSession, csiDataDao)
  val csiAAQueue=  new CSIAutoAnalystQueueController(sparkSession, csiDataDao)

  import sparkSession.implicits._


  override def getStartRawDataFrameHWMColumn() : String = {
    REDI_ODS_QUEUES_TABLE_HWM_COLUMN
  }
  override def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  override def getHiveTableName(): String = {
    REDI_CSI_QUEUES_HIVE_TABLE
  }

  override def getLocalHDFSStorageValue(): String = {
    REDI_CSI_QUEUES_HDFS_LOCATION
  }

  override def getRawDataFrameHWMColumn(): String = {
    REDI_HIVE_QUEUES_TABLE_HWM_COLUMN
  }

  override def getODSTableName(): String = {
    REDI_CSI_QUEUES_ODS_TABLE_NAME
  }

  override def getControlKey(): String = {
    REDI_CSI_QUEUES_CONTROL_KEY
  }

  override def getODSWhereCondition(value: String): String = {
    " WHERE MODIFIED_DATE > to_timestamp('" + value +"' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }


  override def setRawDataframe(RawCSIDataDF: DataFrame): Unit = {

    csi1Queue.process()

    val csi1QueueDF = csi1Queue.getRawDataframe()

    csiAAQueue.process()

    val csiAAQueueDF = csiAAQueue.getRawDataframe()

    val csiQueueDF= RawCSIDataDF
      .withColumn("RECOMMENDATION",lit(""))
      .withColumn("CRITERIA",lit(""))
      .withColumn("PRISM_SCORE",lit(""))
      .withColumn("EFALCON_SCORE",lit(""))
      .withColumn("EBCARDTYPE",lit(""))
      .withColumn("EBSHIPMETHOD",lit(""))
      .withColumn("EBITEMSHIPMETHOD",lit(""))
      .withColumn("VIRTBILLSHIP",lit(""))
      .withColumn("BULK_CLICKBLOCK_SETTING",lit(""))
      .withColumn("CANCEL_CODE",lit(""))
      .withColumn("SCHEDULE_START",lit(""))
      .withColumn("SCHEDULE_END",lit(""))
      .withColumn("SCHEDULE_UI",lit(""))
      .withColumn("NOTE",lit(""))
      .withColumn("ORDER_TYPE",lit(""))
      .withColumn("PEND_TIME",lit(""))
      .withColumn("QueueCMType", lit("2"))
      .withColumn("ACTION", lit(""))



    val combinedDF=  csiQueueDF.union(csi1QueueDF).union(csiAAQueueDF)


    super.setRawDataFrame(combinedDF)
  }


  override def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    super.updateControlTables(RawCSIDataDF)
    csi1Queue.updateControlTables(csi1Queue.getRawDataframe())
    csiAAQueue.updateControlTables(csiAAQueue.getRawDataframe())

  }

  override def csiTransformation(inputDataFrame: DataFrame): DataFrame = {
    csiQueueDataContorller.info("Inside csiTransformation"+this.getClass)
    //super.reorderSourceTableSchema(CSI_QUEUES_TABLE_COL_ORDER,inputDataFrame)
   var transformedDF=  inputDataFrame.select(
      $"NAME".alias("QueueName"),
      $"DESCRIPTION".alias("QueueFullName"),
      $"CLIENT_ID".alias("ClientId"),
      $"SUBCLIENT_ID".alias("SubClientid"),
      $"RANK_ORDER".alias("QueueSort"),
      $"QueueCMType",
      $"CREATED_DATE".alias("QueueCreated"),
      $"MODIFIED_DATE".alias("QueueModified"),
      $"QUEUE_TYPE".alias("QueueType"),
      $"ACTION".alias("QueueAction"),
     $"ID",
      when($"QueueCMType" === "1" , concat($"CLIENT_ID",lit("_"),$"ID")).otherwise($"ID").alias("QueueID"),
      when($"QueueCMType" =!= "1" ,  lit("0")).otherwise($"ID").alias("QueueNumber"),
      $"STATUS",
      when($"QueueCMType" =!= "1" ,
        when($"STATUS" === "ACTIVE", lit("Y")).otherwise(lit("N")))
        .otherwise("Y").alias("QueueActiveYN"),
      $"RECOMMENDATION" ,
        $"CRITERIA" ,
        $"PRISM_SCORE" ,
        $"EFALCON_SCORE" ,
        $"EBCARDTYPE" ,
        $"EBSHIPMETHOD" ,
        $"EBITEMSHIPMETHOD" ,
        $"VIRTBILLSHIP" ,
        $"BULK_CLICKBLOCK_SETTING" ,
        $"CREATED_BY" ,
        $"MODIFIED_BY" ,
        $"REFERRING_SITE",
        $"CRITERIA_DEFINITION" ,
        $"CRITERIA_EXPRESSION" ,
        $"CRITERIA_UI" ,
        $"IS_TRANSFERABLE",
        $"CANCEL_CODE",
        $"SCHEDULE_START",
        $"SCHEDULE_END" ,
        $"SCHEDULE_UI" ,
        $"NOTE" ,
        $"ORDER_TYPE" ,
        $"RANK_ORDER" ,
        $"PEND_TIME"
    ).withColumn("ClientId",CSICommonMethods.remapClientIDsForIKEA(col("CLIENTID"), col("SUBCLIENTID")))
    transformedDF =  reorderSourceTableSchema(CSI_QUEUES_TABLE_COL_ORDER, addAuditColumns(transformedDF))
    csiQueueDataContorller.info("Completed csiTransformation")
    transformedDF
  }

  override def storeInput2Hive(inputDataFrame: DataFrame): Unit = {
    hiveSession.executeUpdate("delete from REDI.CSI_QUEUES_ON_WRITE")
    csiQueueDataContorller.debug("Starting to push the data into Hive table " + getHiveTableName()+ " "+this.getClass)
    inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", getHiveTableName()).save()
    hiveSession.executeUpdate("MERGE INTO REDI.CSI_QUEUES AS D USING " +
      " (SELECT * FROM REDI.CSI_QUEUES_ON_WRITE) AS S ON (D.QUEUEID=S.QUEUEID AND D.CLIENTID=S.CLIENTID AND D.SUBCLIENTID=S.SUBCLIENTID) WHEN MATCHED THEN " +
      "UPDATE SET QUEUEID=S.QUEUEID,QUEUENUMBER=S.QUEUENUMBER,QUEUENAME=S.QUEUENAME,QUEUEFULLNAME=S.QUEUEFULLNAME,CLIENTID=S.CLIENTID," +
      "SUBCLIENTID=S.SUBCLIENTID,QUEUESORT=S.QUEUESORT,QUEUECREATED=S.QUEUECREATED,QUEUEMODIFIED=S.QUEUEMODIFIED,QUEUETYPE=S.QUEUETYPE,QUEUEACTIVEYN=S.QUEUEACTIVEYN," +
      "QUEUEACTION=S.QUEUEACTION,RECOMMENDATION=S.RECOMMENDATION,CRITERIA=S.CRITERIA,PRISM_SCORE=S.PRISM_SCORE,EFALCON_SCORE=S.EFALCON_SCORE," +
      "EBCARDTYPE=S.EBCARDTYPE,EBSHIPMETHOD=S.EBSHIPMETHOD,EBITEMSHIPMETHOD=S.EBITEMSHIPMETHOD,VIRTBILLSHIP=S.VIRTBILLSHIP,BULK_CLICKBLOCK_SETTING=S.BULK_CLICKBLOCK_SETTING," +
      "CREATED_BY=S.CREATED_BY,MODIFIED_BY=S.MODIFIED_BY,REFERRING_SITE=S.REFERRING_SITE,CRITERIA_DEFINITION=S.CRITERIA_DEFINITION,CRITERIA_EXPRESSION=S.CRITERIA_EXPRESSION," +
      "CRITERIA_UI=S.CRITERIA_UI,IS_TRANSFERABLE=S.IS_TRANSFERABLE,CANCEL_CODE=S.CANCEL_CODE,SCHEDULE_START=S.SCHEDULE_START,SCHEDULE_END=S.SCHEDULE_END,SCHEDULE_UI=S.SCHEDULE_UI," +
      "NOTE=S.NOTE,ORDER_TYPE=S.ORDER_TYPE,RANK_ORDER=S.RANK_ORDER,PEND_TIME=S.PEND_TIME," +
      "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
      " WHEN NOT MATCHED THEN INSERT VALUES(S.QUEUEID,S.QUEUENUMBER,S.QUEUENAME,S.QUEUEFULLNAME,S.CLIENTID,S.SUBCLIENTID,S.QUEUESORT,S.QUEUECREATED,S.QUEUEMODIFIED,"+
      "S.QUEUETYPE,S.QUEUEACTIVEYN,S.QUEUEACTION,S.RECOMMENDATION,S.CRITERIA,S.PRISM_SCORE,S.EFALCON_SCORE,S.EBCARDTYPE,S.EBSHIPMETHOD,S.EBITEMSHIPMETHOD,"+
      "S.VIRTBILLSHIP,S.BULK_CLICKBLOCK_SETTING,S.CREATED_BY,S.MODIFIED_BY,S.REFERRING_SITE,S.CRITERIA_DEFINITION,S.CRITERIA_EXPRESSION,S.CRITERIA_UI,"+
      "S.IS_TRANSFERABLE,S.CANCEL_CODE,S.SCHEDULE_START,S.SCHEDULE_END,S.SCHEDULE_UI,S.NOTE,S.ORDER_TYPE,S.RANK_ORDER,S.PEND_TIME,"+
      "S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED,S.QUEUECMTYPE)")
  }
    csiQueueDataContorller.debug("Completed to push the data into Hive table " + getHiveTableName()+ " "+this.getClass)
}

