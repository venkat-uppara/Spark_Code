/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.actions

import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.csi.controllers._
import org.apache.log4j.LogManager

object CSIDataProcess extends CSICommonDataController with Serializable  {
  /**
    * This invokes the process that addresses the CSI Data
    */
  @transient lazy val csiDataProcess = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    csiDataProcess.info(CSIDATAPROCESS_INFO+":Start of Incremental Load for CSI Related Data from ODS")
    try{
      processAllCSITransactions()
     } catch {
      case e: Exception => csiDataProcess.error(CSIDATAPROCESS_ERROR+":We have an error in the Incremental Load for CSI Data Flow" + e.printStackTrace())
        System.exit(1)
    } finally {
      csiDataProcess.info(CSIDATAPROCESS_INFO+":End of Incremental Load for CSI Related Data Controller Data from ODS")
    }
  }
}