/**
  * @author : Sudhakar R
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8679
  * @note :
  */

package com.aciworldwide.ra.redi.csi.controllers

import java.sql.Timestamp

import com.aciworldwide.ra.redi.common.utils.DateUtils
import com.aciworldwide.ra.redi.csi.dao.CSIDataDao
import com.aciworldwide.ra.redi.csi.utils.CSIUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.log4j.LogManager
import org.apache.spark.sql.functions.{lit, max}
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class CSICancelCodesAADataController (sparkSession: SparkSession, csiDataDao: CSIDataDao )  extends DateUtils with CSIUtils {

  @transient lazy val csiCancelCodesAA = LogManager.getLogger(getClass.getName)

  private var rawDataFrame: DataFrame = null

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()
  hiveSession.setDatabase(REDI_DATABASE)

  def getDatabaseSchema(): String = {
    SDB_QUEUE_DATABASE
  }

  def getHWMId(): String = {
    csiCancelCodesAA.info(CSIDATAPROCESS_INFO + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    csiCancelCodesAA.debug(CSIDATAPROCESS_DEBUG + ": get the HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass)
    var hwmDate = hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + getControlKey() + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    csiCancelCodesAA.info(CSIDATAPROCESS_INFO + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    csiCancelCodesAA.debug(CSIDATAPROCESS_DEBUG + ":  HIGHWATERMARK Column from REDI_PROCESS_CONTROL table " + this.getClass + ":hwmDate")
    hwmDate
  }

  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_CANCEL_CODES_AA_TABLE_HWM_COLUMN
  }

  def getODSTableName(): String = {
    REDI_CSI_CANCEL_CODES_AA_TABLE_NAME
  }

  def getControlKey(): String = {
    REDI_CSI_CANCEL_CODES_AA_CONTROL_KEY
  }

  def getODSWhereCondition(value: String): String = {
    " WHERE COALESCE(DELETED,0)<>1 AND CREATED_DATE > to_timestamp('" + value + "' , 'YYYY-MM-DD HH24:MI:SS.FF')" +
      " and  CREATED_DATE  <= to_timestamp('" + addoffset() +"' , 'YYYY-MM-DD HH24:MI:SS.FF')"
  }

  def fetchRawDataFromODS(CSIHWMID: String): DataFrame = {
    csiCancelCodesAA.info(CSIDATAPROCESS_INFO + ": staring fetching from ODS  " + this.getClass)
    val CSI_MASTER_QUERY = "(SELECT * FROM " + getDatabaseSchema() + "." + getODSTableName() + getODSWhereCondition(CSIHWMID) + ") CSI_Data"

    val RawCSIDataDF = fetchCSIData(csiDataDao,CSI_MASTER_QUERY, ORACLE_CONN_TYPE, getDatabaseSchema())
    csiCancelCodesAA.info(CSIDATAPROCESS_INFO+":Fetched CSI Data into processing layer " + getDatabaseSchema() + "." + getODSTableName())

    /** Caching the Dataframe, so that the data presists in memory and can be easy to push into HDFS */
    RawCSIDataDF.cache()

    RawCSIDataDF

  }

  override def  StorethedataintoHive(tablename: String, format:String, inputdataset: DataFrame): Unit ={
    inputdataset.write.format(HIVE_WAREHOUSE_CONNECTOR).option("","").mode(SaveMode.Append).option("table",tablename).save()
  }

  def CSIDataPipeline(): Unit = {
    // Do nothing
    val CSIHWMID = getHWMId

    /** Ingestion Process Step: 01
      * Get the High Water Mark for CSI Data from Hive control table
      * The value returned will be stored in the CSIHWMGID variable. */

    /** Ingestion Process Step: 02
      * 1. Check whether the HWM for CSI CB process (GROUP_ID) is null.
      * If null then throw an error that on the oracle date converted and exit.
      * 2. If the HWM for CSI CB process is not null then read incremental data from Oracle (only new data which has come after High water mark date)
      */

    
    if (CSIHWMID == null) {
      csiCancelCodesAA.info(CSIDATAPROCESS_INFO+":There is a error in the " + getControlKey() + " value stored in Hive" + CSIHWMID)
    }
    else {
      /** Ingestion Process Step: 02(A)
        * Creating the Query that will be executed in Oracle to get data for Respective Table Name. */

      val RawCSIDataDF = fetchRawDataFromODS(CSIHWMID)


      /** Ingestion Process Step: 03
        * Updating the Process Status in the into Hive Control table */

      // Setting the Start time of the CSI CBData
      val startTimeCSIDataLoad = getCurrentdateTimeStamp
      controlTableDataProcess(RawCSIDataDF, getRawDataFrameHWMColumn(), getControlKey(), PROCESS_CONTROL_STARTED, startTimeCSIDataLoad.toString, "", "Starting to Fetch the CSI from ODS into HDFS",CSI_DATA_PROCESS)

      /** Reading the Dataframe for getting the total count of records that was Ingested from Oracle
        * This value is pushed into the variable CSIDataCount. */
      val CSIDataCount = RawCSIDataDF.count()


      setRawDataframe(RawCSIDataDF)

    }
  }

  def updateControlTables(RawCSIDataDF: DataFrame): Unit = {
    /** Ingestion Process Step: 05
      * Reading the Dataframe for getting the MAXIMUM of HWM Column from the data Ingested from Oracle
      * This value is pushed into Hive Control Table.
      * Updating the Maximum HWM Column into Hive Control table and Marking the end of process */

    // Setting the End time of the CSI CBData

    val endTimeCSIDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(RawCSIDataDF, getRawDataFrameHWMColumn(), getControlKey(), PROCESS_CONTROL_COMPLETED, "", endTimeCSIDataLoad.toString, "Completed the  Fetch from ODS into HDFS",CSI_DATA_PROCESS)
  }

  def setRawDataframe(RawCSIDataDF: DataFrame) = {
    this.rawDataFrame = RawCSIDataDF.select(
      "ID", "CODE", "DESCRIPTION", "COLOR_CODE", "CREATED_DATE",
      "CREATED_BY", "MODIFIED_DATE", "MODIFIED_BY", "DELETED", "PROFILE_ID")
      .withColumn("CancelSource", lit("AA"))
  }

  def getRawDataframe(): DataFrame = {
    this.rawDataFrame
  }

}

