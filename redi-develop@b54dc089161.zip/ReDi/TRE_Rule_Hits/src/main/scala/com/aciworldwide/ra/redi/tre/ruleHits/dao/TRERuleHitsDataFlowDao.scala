package com.aciworldwide.ra.redi.tre.ruleHits.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, SparkSession}
import za.co.absa.abris.avro.read.confluent.SchemaManager
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY
import za.co.absa.abris.avro.AvroSerDe._

class TRERuleHitsDataFlowDao(sc: SparkSession) extends Serializable
  with ReDiConstants with CommonUtils with DatabaseServices with EstablishConnections {

  val schemaRegistryConfs = Map(
    SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> ConfigFactory.load().getString("local.common.tre_rule_hits.schemaRegistryURL"),
    SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> ConfigFactory.load().getString("local.common.tre_rule_hits.trerulehitskafkatopic"),
    SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME, // choose a subject name strategy
    SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest" // set to "latest" if you want the latest schema version to used
  )

  @transient lazy val treRuleHitsProcess = LogManager.getLogger(getClass.getName)
  def WriteTRERuleHitsData(df: DataFrame) = {

    treRuleHitsProcess.info(TRE_RULE_HITS_INFO+" : TRERuleHitsProcess::WriteTRERuleHitsData::START")

    df
      .writeStream
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .trigger(Trigger.ProcessingTime(ConfigFactory.load().getString("local.common.tre_rule_hits.processingTime")))
      .option(DATABASE, MAINFLOW_DATABASE)
      .option(TABLE, ConfigFactory.load().getString("local.common.tre_rule_hits.HiveSinkTable"))
      .option(METASTOREURI, ConfigFactory.load().getString("local.common.kafka.metastoreUri"))
      .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.tre_rule_hits.trerulehitstopicCheckpointlocation"))
      .start()
      .awaitTermination()
  }

  def readTRERuleHitsFromKafka(): DataFrame = {
    treRuleHitsProcess.info(TRE_RULE_HITS_INFO+" : TRERuleHitsProcess::WriteTRERuleHitsData::START")
    sc.readStream
      .format(KAFKA_SOURCE)
      .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.tre_rule_hits.bootstrapservers"))
      .option(SUBSCRIBE, ConfigFactory.load().getString("local.common.tre_rule_hits.trerulehitskafkatopic"))
      .option("startingOffsets", "latest")
      .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.tre_rule_hits.maxOffsetsPerTrigger"))
      .option(KAFKASECURITYPROTOCOL, SASL_SSL)
      .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
      .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
      .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
      .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
      .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
      .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
      .option(KAFKASASLMECHANISM, GSSAPI)
      .option("failOnDataLoss", false)
      .load()
      //.fromConfluentAvro("value", None, Some(schemaRegistryConfs))(RETAIN_SELECTED_COLUMN_ONLY) // invoke the library passing over parameters to access the Schema Registry
  }
}
