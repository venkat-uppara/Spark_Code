package com.aciworldwide.ra.redi.tre.ruleHits.controllers

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.tre.ruleHits.dao.TRERuleHitsDataFlowDao
import com.databricks.spark.avro.SchemaConverters
import com.typesafe.config.ConfigFactory
import io.confluent.kafka.schemaregistry.client.rest.{RestService, entities}
import io.confluent.kafka.serializers.KafkaAvroDeserializer
import org.apache.avro.Schema
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.{from_json, udf, _}
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.JavaConverters._


object InformationOfHits {
  val schemaRegistryURL = ConfigFactory.load().getString("local.common.tre_rule_hits.schemaRegistryURL")

  val topicName = ConfigFactory.load().getString("local.common.tre_rule_hits.trerulehitskafkatopic")
  val subjectValueName = topicName + "-value"

  //create RestService object
  val restService = new RestService(schemaRegistryURL)

  //gets latest version of type entities.Schema object.
  val valueRestResponseSchema: entities.Schema = restService.getLatestVersion(subjectValueName)


  //Use Avro parsing classes to get Avro Schema
  val parser = new Schema.Parser
  val topicValueAvroSchema: Schema = parser.parse(valueRestResponseSchema.getSchema)

  val props = Map("schema.registry.url" -> schemaRegistryURL)
  val structure: StructType = SchemaConverters.toSqlType(topicValueAvroSchema).dataType.asInstanceOf[StructType]

  //Declare SerDe vars before using Spark structured streaming map. Avoids non serializable class exception.
  var keyDeserializer: StringDeserializer = null
  var valueDeserializer: KafkaAvroDeserializer = null

  def deserValue(key: String, value: Array[Byte]): String = {
    //    var valueDeserializer: KafkaAvroDeserializer = null
    if (valueDeserializer == null) {
      valueDeserializer = new KafkaAvroDeserializer
      valueDeserializer.configure(props.asJava, false) //isKey = false
    }
    val deserializedValueJsonString = valueDeserializer.deserialize(topicName, value, topicValueAvroSchema).toString
    deserializedValueJsonString
  }

}



class TRERuleHitsController(sparkSession: SparkSession) extends ReDiConstants {

  @transient lazy val treRuleHitsProcess = LogManager.getLogger(getClass.getName)

  import sparkSession.implicits._

  val treRuleDetailDataFlowDao = new TRERuleHitsDataFlowDao(sparkSession)

  def udfGetCurrTime: UserDefinedFunction = udf(() => {
    val date: LocalDateTime = java.time.LocalDateTime.now()
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").format(date)
  })

  def transformTRERuleHitsData(df: DataFrame): DataFrame = {
    treRuleHitsProcess.info(TRE_RULE_HITS_INFO + " : TRERuleHitsProcess::transformTRERuleHitsData::START")

    df
            .select($"key".as[String], $"value".as[Array[Byte]])
            .map(
              row => {
                InformationOfHits.deserValue(row._1, row._2)
              }
            ).select(from_json($"value", InformationOfHits.structure).as("data")).select("data.*")
      .select($"oid", $"oiddate", $"metadataVersion", to_json($"audits").as("audits"), to_json($"results").as("results"))
      .withColumn("Whenloaded", udfGetCurrTime())
      .withColumn("OIDDATEYYYYMMDD", expr("substring(oiddate, 1, 8)").cast("int"))

  }

  def treRuleHitsPipeline(): Unit = {
    treRuleHitsProcess.info(TRE_RULE_HITS_INFO + " : TRERuleHitsProcess::treRuleHitsPipeline::START")
    treRuleDetailDataFlowDao.WriteTRERuleHitsData(transformTRERuleHitsData(treRuleDetailDataFlowDao.readTRERuleHitsFromKafka()))
    treRuleHitsProcess.info(TRE_RULE_HITS_INFO + " : TRERuleHitsProcess::treRuleHitsPipeline::START")
  }

}
