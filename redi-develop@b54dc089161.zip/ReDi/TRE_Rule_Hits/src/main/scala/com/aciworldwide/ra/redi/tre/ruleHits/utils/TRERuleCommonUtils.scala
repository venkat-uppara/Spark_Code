package com.aciworldwide.ra.redi.tre.ruleHits.utils

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}

trait TRERuleCommonUtils extends Serializable with EstablishConnections with Loggers with ReDiConstants {

}
