package com.aciworldwide.ra.redi.tre.ruleHits.actions

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.tre.ruleHits.controllers.TRERuleHitsController
import org.apache.logging.log4j.LogManager


object TRERuleHitsProcess extends BaseController with Loggers with Serializable with  ReDiConstants{


  /**
    * Single process which invokes the process that addresses the Tre Rule Details
    */
  @transient lazy val treRuleHitsProcess = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    treRuleHitsProcess.info(TRE_RULE_HITS_INFO+" : TRERuleHitsProcess::main::START")
    try {

      val sparkSession = createSparkSession(RSTRANSFLOWTRANSAPP)
      val TRERuleHitsDataFlowDao = new TRERuleHitsController(sparkSession)
      TRERuleHitsDataFlowDao.treRuleHitsPipeline()

    } catch {
      case e: Exception => treRuleHitsProcess.error(TRE_RULE_HITS_ERROR+" : We have an error in the Tre Rule details  flow from  TRE Kafka " + e)
    } finally {
      treRuleHitsProcess.info(TRE_RULE_HITS_INFO+" : TRERuleHitsProcess::main::END::Ingestion of Tre Rule details  flow from  TRE Kafka Is completed ")
    }
  }
}
