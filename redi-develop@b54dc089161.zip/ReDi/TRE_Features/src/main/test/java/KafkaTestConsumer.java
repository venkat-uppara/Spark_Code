import com.aciworldwide.ra.model.FeatureSet;
import com.typesafe.config.ConfigFactory;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.Arrays;
import java.util.Properties;
import java.util.UUID;

public class KafkaTestConsumer {
    public static void main(String args[]) {
        final Properties props = new Properties();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,"cov3lddbsgem04.ose.am.tsacorp.com:9093,cov3lddbsgem05.ose.am.tsacorp.com:9093,cov3lddbsgem06.ose.am.tsacorp.com:9093");
        props.put(ConsumerConfig.GROUP_ID_CONFIG, UUID.randomUUID().toString());
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class.getName());
        props.put("schema.registry.url", "http://cov3lddbsgem03.ose.am.tsacorp.com:8081");
        // Use Specific Record or else you get Avro GenericRecord.
        props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true");

        //props.put("security.protocol", "SASL_SSL");
        props.put("maxOffsetsPerTrigger", ConfigFactory.load().getString("local.common.kafka.maxOffsetsPerTrigger"));
        props.put("security.protocol", ConfigFactory.load().getString("local.common.kafka.securityProtocol"));
        props.put("schema.registry.url", ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"));
        props.put("max.block.ms", ConfigFactory.load().getString("local.common.kafka.maxBlockMs"));

        /*  props.put("acks", "all")
          props.put("retries", "0")
          props.put("batch.size", "16635")
          props.put("linger.ms", "0")
          props.put("buffer.memory", "33554432")
        */

        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"));
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"));
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"));
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"));

        props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"));
        props.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, ConfigFactory.load().getString("local.common.kafka.saslKerberosServiceName"));
        props.put(SaslConfigs.SASL_MECHANISM, ConfigFactory.load().getString("local.common.kafka.saslMechanism"));

        final KafkaConsumer<String, FeatureSet> consumer = new KafkaConsumer<>(props);
        consumer.subscribe(Arrays.asList("nor-tre-features"));

        while (true) {
            final ConsumerRecords<String, FeatureSet> consumerRecords =
                    consumer.poll(1000);
            System.out.println("FOUND: " + consumerRecords.count());
            consumerRecords.forEach(record -> {
                FeatureSet update = record.value();
                //System.out.printf("OID: %s, OIDATE: %s ATTRIBUTES: %s\n", update.getOID(), update.getOIDDATE(), update.getAttributes());
                System.out.printf("OID: %s, OIDATE: %s ATTRIBUTES: %s\n", update.getOid(), update.getOiddate(), update.getFeatures());

            });
            consumer.commitAsync();
        }
    }
}
