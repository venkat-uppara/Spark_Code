package com.aciworldwide.ra

import java.util
import java.util.{Properties, UUID}

import com.aciworldwide.ra.model.FeatureSet
import io.confluent.kafka.serializers.{KafkaAvroDeserializer, KafkaAvroDeserializerConfig}
import org.apache.kafka.clients.consumer.{ConsumerConfig, KafkaConsumer}
import org.apache.kafka.common.config.{SaslConfigs, SslConfigs}
import org.apache.kafka.common.serialization.StringDeserializer


object KafkaSampleConsumer {

  def main(args: Array[String]): Unit = {

    val props = new Properties
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "cov3lddbsgem04.ose.am.tsacorp.com:9093,cov3lddbsgem05.ose.am.tsacorp.com:9093,cov3lddbsgem06.ose.am.tsacorp.com:9093")
    props.put(ConsumerConfig.GROUP_ID_CONFIG, UUID.randomUUID.toString)
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, classOf[StringDeserializer].getName)
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, classOf[KafkaAvroDeserializer].getName)
    props.put("schema.registry.url", "http://cov3lddbsgem03.ose.am.tsacorp.com:8081")
    // Use Specific Record or else you get Avro GenericRecord.
    props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, "true")
    props.put("security.protocol", "SASL_SSL")
    props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "C:\\security\\cov3lcep14vm.am.tsacorp.com.keystore.jks")
    props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "hadoop")
    props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "C:\\security\\cov3lcep14vm.am.tsacorp.com.truststore.jks")
    props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "hadoop")
    props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "hadoop")
    props.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, "kafka")
    props.put(SaslConfigs.SASL_MECHANISM, "GSSAPI")
    val consumer = new KafkaConsumer[String, FeatureSet](props)
    consumer.subscribe(util.Arrays.asList("nor_tre_features"))

/*    while (true) {
      val consumerRecords = consumer.poll(1000)
      System.out.println("FOUND: " + consumerRecords.count)

      consumerRecords.forEach(record => {
          val update = record.value()
          //System.out.printf("OID: %s, OIDATE: %s ATTRIBUTES: %s\n", update.getOID(), update.getOIDDATE(), update.getAttributes());
          println("OID: %s, OIDATE: %s ATTRIBUTES: %s\n", update.getOid, update.getOiddate, update.getFeatures)
      })
      consumer.commitAsync()
    }*/

  }
}
