/*
 *  Copyright (c) 2018 by ACI Worldwide Inc.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of ACI
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such
 *  Confidential Information and shall use it only in accordance with the
 *  terms of the license agreement you entered with ACI Worldwide Inc.
 */

package com.aciworldwide.ra.kafka

import java.util.Properties

import com.aciworldwide.ra.model.FeatureSet
import com.typesafe.config.ConfigFactory
import org.apache.kafka.common.config.{SaslConfigs, SslConfigs}

object FeatureKafka {

  import org.apache.kafka.clients.producer._

  val props = new Properties
  props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
  props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.keySerializerClassConfig"))
  props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.valueSerializerClassConfig"))

  props.put("maxOffsetsPerTrigger", ConfigFactory.load().getString("local.common.kafka.maxOffsetsPerTrigger"))
  props.put("security.protocol", ConfigFactory.load().getString("local.common.kafka.securityProtocol"))
  props.put("schema.registry.url", ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"))
  props.put("max.block.ms", ConfigFactory.load().getString("local.common.kafka.maxBlockMs"))

  /*  props.put("acks", "all")
    props.put("retries", "0")
    props.put("batch.size", "16635")
    props.put("linger.ms", "0")
    props.put("buffer.memory", "33554432")
  */

  props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
  props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
  props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
  props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))

  props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
  props.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, ConfigFactory.load().getString("local.common.kafka.saslKerberosServiceName"))
  props.put(SaslConfigs.SASL_MECHANISM, ConfigFactory.load().getString("local.common.kafka.saslMechanism"))


  /*    .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
      .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.tremaxOffsetsPerTrigger"))
      .option(KAFKASECURITYPROTOCOL, ConfigFactory.load().getString("local.common.kafka.securityProtocol"))
      .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
      .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
      .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
      .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
      .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
      .option(KAFKASASLKERBEROSSERVICENAME, ConfigFactory.load().getString("local.common.kafka.saslKerberosServiceName"))
      .option(KAFKASASLMECHANISM, ConfigFactory.load().getString("local.common.kafka.saslMechanism"))
      .load()

    val properties = new Properties()
    properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.keySerializerClassConfig"))
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.valueSerializerClassConfig"))
    properties.put("schema.registry.url", ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"))
    properties.put("security.protocol", ConfigFactory.load().getString("local.common.kafka.securityProtocol"))
    properties.put("max.block.ms", ConfigFactory.load().getString("local.common.kafka.maxBlockMs"))

    properties.put("acks", "all")
    properties.put("retries", "0")
    properties.put("batch.size", "16635")
    properties.put("linger.ms", "0")
    properties.put("buffer.memory", "33554432")

    properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
    properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
    properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
    properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))

    properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
    properties.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, ConfigFactory.load().getString("local.common.kafka.saslKerberosServiceName"))
    properties.put(SaslConfigs.SASL_MECHANISM, ConfigFactory.load().getString("local.common.kafka.saslMechanism"))*/

  val producer = new KafkaProducer[String, FeatureSet](props)

  def sendAsync(value: FeatureSet): Unit = {
    //val record = new ProducerRecord[String, FeatureSet]("nor_tre_features", value)
    val record = new ProducerRecord("cit-tre-features", value.getOid.toString, value)
   //val p = Promise[(RecordMetadata, Exception)]()

    producer.send(record, new Callback {

      override def onCompletion(metadata: RecordMetadata,
                                exception: Exception): Unit = {
        if(exception != null) {
          println("Error in FeatureKafka:: " + exception)
        } else {
          //p.success((metadata, exception))
          println("No error in FeatureKafka, msg sent to Kafka topic")
        }

      } // def onCompletion ends here

    }) //producer.send ends here

  }
}
