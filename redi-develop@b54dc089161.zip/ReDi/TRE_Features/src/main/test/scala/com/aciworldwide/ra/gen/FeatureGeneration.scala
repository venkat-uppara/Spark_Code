/*
 *  Copyright (c) 2018 by ACI Worldwide Inc.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of ACI
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such
 *  Confidential Information and shall use it only in accordance with the
 *  terms of the license agreement you entered with ACI Worldwide Inc.
 */

package com.aciworldwide.ra.gen

import java.util
import java.util.{Calendar, UUID}

import com.aciworldwide.ra.model.FeatureSet

import scala.collection.JavaConverters.mapAsJavaMapConverter
import scala.util.Random

object FeatureGeneration {
  val calendar: Calendar = Calendar.getInstance()

  val featureNames = Seq("complexFeatureSingle",
    "MINDEVCLDEVEMAIL30",
    "MAXDEVCLDEVEMAIL7",
    "AVGDEVCLDEVEMAIL30")

/*  def feature(name: String): util.Map[String, String] = {
    mapAsJavaMapConverter[String, String](
      Map(
        "featureid" -> ("id_" + name),
        "featurename" -> s"name_$name",
        "featurevalue" -> Random.nextInt(1000).toString,
        "featurealias" -> ("alias_" + Random.alphanumeric.take(10).mkString)
      )).asJava
  }*/

  def feature(name: String): util.Map[CharSequence, CharSequence] = {
    mapAsJavaMapConverter[CharSequence, CharSequence](
      Map(
        "featureid" -> ("id_" + name),
        "featurename" -> s"name_$name",
        "featurevalue" -> Random.nextInt(100).toString,
        "featurealias" -> ("alias_" + Random.alphanumeric.take(10).mkString)
      )).asJava
  }

  def features(): FeatureSet = {
    //val list: util.List[util.Map[String, String]] = new util.ArrayList[util.Map[String, String]]()

    val list: util.List[util.Map[CharSequence, CharSequence]] = new util.ArrayList[util.Map[CharSequence, CharSequence]]()

    for (name <- featureNames) {
      list.add(feature(name))
    }

    println("List is --> " + list)

    FeatureSet
      .newBuilder()
      .setFeatures(list)
      .setOid(UUID.randomUUID().toString)
      .setOiddate(
        Calendar
          .getInstance()
          .getTimeInMillis / 100)
      .build()

  }
}
