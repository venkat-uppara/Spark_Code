package com.aciworldwide.ra

import java.util.concurrent.atomic.AtomicLong

import com.aciworldwide.ra.gen.FeatureGeneration
import com.aciworldwide.ra.kafka.FeatureKafka
import com.aciworldwide.ra.model.FeatureSet

object FeatureProducer {
  val atomicLong = new AtomicLong(0)

  def main(args: Array[String]): Unit = {
    for (i <- 0 until 2) {
      for (a <- 0 until 2) {
        val fSet: FeatureSet = FeatureGeneration.features()
        println("FeatureSet" + i + "" + a + ":" + s"$fSet")
        FeatureKafka.sendAsync(fSet)
      }
      FeatureKafka.producer.flush()
      //FeatureKafka.producer.close()
      //Thread.sleep(750)
      println(atomicLong.getAndIncrement())
    }
  }
}