package test.schemas



case class TRE_DATA_SCHEMA_1(oid: String,oiddate: String,id: String,name: String,alias: String,value: String,clientid: String,subclientid: String,client12: String,whenloaded: String,wholoaded: String,whenupdated: String,whoupdated: String)


