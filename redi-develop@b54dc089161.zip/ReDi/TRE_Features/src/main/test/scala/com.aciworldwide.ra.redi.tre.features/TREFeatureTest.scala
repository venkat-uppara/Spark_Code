package com.aciworldwide.ra.redi.tre.features

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.redshield.core.ods.executive.ReDShieldTransaction
import com.databricks.spark.avro.SchemaConverters
import com.typesafe.config.ConfigFactory
import org.apache.avro.Schema
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfter, FunSuite}


class TREFeatureTest extends FunSuite with  Serializable with CommonUtils {


  import org.apache.spark.sql.streaming.OutputMode


  test("basicAssertionForTREfeature") {

    val session = SparkSession.builder()
      .config("spark.sql.caseSensitive", "false")
      .config("spark.default.parallelism", "2")
      .config("spark.sql.shuffle.partitions", "2")
      .config("spark.testing.memory", "4718592000")
      .appName("TREFeatureTest")
      .master("local[*]")
      .getOrCreate()

    import session.implicits._
    val dataFrame = Seq(("999999999999ZZZ00000000000000000", "2019-02-07 05:19:09.954","12345","tre","xyz"))
      .toDF("oid", "oiddate", "id", "name","alias")

    val treFeature = new com.aciworldwide.ra.redi.tre.features.transformations.TREFeatures(session)

    val df = treFeature.generateAdditionalColumns(dataFrame)

    assert(df.select($"oid").head().mkString == "999999999999ZZZ00000000000000000", "Basic validation of oid data.")
    assert(df.select($"clientid").head().mkString == "999999", "Basic validation of clientid data.")
    assert(df.select($"client12").head().mkString == "999999999999", "Basic validation of client12 data.")
    assert(df.select($"subclientid").head().mkString == "999999", "Basic validation of subclientid data.")
    assert(df.select($"type").head().mkString == "sae", "Basic validation of type data.")

  }

  test("basicAssertionForTREfeature_1") {

    val session = SparkSession.builder()
      .config("spark.sql.caseSensitive", "false")
      .config("spark.default.parallelism", "1")
      .config("spark.sql.shuffle.partitions", "1")
      .config("spark.testing.memory", "471859200")
      .appName("TREFeatureTest")
      .master("local[*]")
      .getOrCreate()

    import session.implicits._
    val dataFrame = Seq(("999999999999ZZZ00000000000000000", "2019-02-07 05:19:09.954","12345","tre","xyz"))
      .toDF("oid", "oiddate", "id", "name","alias")


    val treFeature = new com.aciworldwide.ra.redi.tre.features.transformations.TREFeatures(session)

    val df = treFeature.generateAdditionalColumns(dataFrame)

    assert(df.select($"oid").head().mkString == "999999999999ZZZ00000000000000000", "Basic validation of oid data.")
    assert(df.select($"clientid").head().mkString == "999999", "Basic validation of clientid data.")
    assert(df.select($"client12").head().mkString == "999999999999", "Basic validation of client12 data.")
    assert(df.select($"subclientid").head().mkString == "999999", "Basic validation of subclientid data.")
    assert(df.select($"type").head().mkString == "sae", "Basic validation of type data.")


  }
/*
  test("basicAssertionForTREfeature_2") {

    val session = SparkSession.builder()
      .config("spark.sql.caseSensitive", "false")
      .config("spark.default.parallelism", "1")
      .config("spark.sql.shuffle.partitions", "1")
      .config("spark.testing.memory", "471859200")
      .appName("TREFeatureTest")
      .master("local[*]")
      .getOrCreate()

    import session.implicits._
    val dataFrame = Seq(("999999999999ZZZ00000000000000000", "2019-02-07T05:19:09.954","name | alias | id | value | printtableRingBuffer"))
      .toDF("oid", "oiddate", "feature")


    val treFeature = new com.aciworldwide.ra.redi.tre.features.transformations.TREFeatures(session)

    val df = treFeature.mapCellsToColumns(dataFrame)

    assert(df.select($"oid").head().mkString == "999999999999ZZZ00000000000000000", "Basic validation of oid data.")
    assert(df.select($"oiddate").head().mkString == "2019-02-07T05:19:09.954", "Basic validation of oiddate data.")
    assert(df.select($"id").head().mkString == "12345", "Basic validation of id data.")
    assert(df.select($"name").head().mkString == "tre", "Basic validation of subclientid data.")

*/

  }




}