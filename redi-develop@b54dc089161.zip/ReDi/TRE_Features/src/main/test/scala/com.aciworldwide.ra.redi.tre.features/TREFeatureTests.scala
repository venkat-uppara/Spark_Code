package test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.tre.features.transformations.TREFeatures
import org.apache.spark.sql.DataFrame
import org.junit.Test
import org.junit.runners.Suite.SuiteClasses
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import test.schemas.TRE_DATA_SCHEMA_1



class TREDataTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiConstants {

  private val TRE_DATA = Array(
    TRE_DATA_SCHEMA_1("999999999999ZZZ00000000000000000", "11111", "999999", "999999", "xyz", "7", "TEST_CLINT", "TEST_CLINT", "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT"),
    TRE_DATA_SCHEMA_1("999999999999ZZZ00000000000000000", "999999", "999999", "999999", "xyz", "7", "TEST_CLINT", "TEST_CLINT", "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT")
  )

  private var treFeatures: TREFeatures = _

  private var tre_df: DataFrame = _

/*
  override def beforeAll(): Unit = {
   // super.beforeAll()
    val _sqlc = sc

    //tre_df = _sqlc.sparkContext.parallelize(TRE_DATA).toDF()
    treFeatures = new TREFeatures(_sqlc)

  }

  "This test will test if we are able to get the rows from tre features. This " should "display the schema of the dataframe " in {
    val tre_size = treFeatures.transform(tre_df, false).take(2)
    tre_size should have size 2
  }
  "This test will test the tre data. this" should "Display the transformed tre data " in {
    val tre_data = treFeatures.mapCellsToColumns(tre_df).collect()
    tre_data should have size 2
  }

  "This test will test the final transformed tre data. this" should "Display the transformed tre Data " in {
    val tre_data = treFeatures.generateAdditionalColumns(tre_df)
    val transform = tre_data.filter(tre_data("oid") === "11111").collect().map(col => col.getString(2)).mkString(" ")
    transform should be === "20181206"

    "This test will test the final transformed tre data. this" should "Display the transformed tre Data " in {
      val tre_data = treFeatures.generateAdditionalColumns(tre_df)
      val transform = tre_data.filter(tre_data("oid") === "11111").collect().map(col => col.getString(2)).mkString(" ")
      transform should be === "20181206"
    }

    "This test will test the final transformed tre data. this" should "Display the transformed tre Data " in {
      val tre_data = treFeatures.generateAdditionalColumns(tre_df)
      val transform = tre_data.filter(tre_data("oid") === "11111").collect().map(col => col.getString(2)).mkString(" ")
      transform should be === "20181206"
    }

  */
}


