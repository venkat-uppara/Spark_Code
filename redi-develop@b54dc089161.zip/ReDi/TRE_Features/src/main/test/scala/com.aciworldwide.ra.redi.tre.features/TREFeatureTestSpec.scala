package com.aciworldwide.ra.redi.tre.features

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.redshield.core.ods.executive.ReDShieldTransaction
import com.databricks.spark.avro.SchemaConverters
import com.typesafe.config.ConfigFactory
import org.apache.avro.Schema
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfter, FunSuite}
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}

/*
trait TREFeatureTestSpec extends BeforeAndAfterAll with EstablishConnections {
  this: Suite =>
  private var _sc: SparkSession = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    lazy val spark: SparkSession = {
      getSparkSession
    }
    sparkConfig.foreach { case (k, v) => spark.sparkContext.getConf.setIfMissing(k, v) }

    _sc = getSparkSession
  }

  def sparkConfig: Map[String, String] = Map.empty

  def getSparkSession: SparkSession = {

    val sparkSession = sparkSessionBuilder(ConfigFactory.load().getString("local.common.spark.master"), ConfigFactory.load().getString("local.common.spark.app.name"))

    sparkSession
  }

  override def afterAll(): Unit = {
    if (_sc != null) {
      _sc.stop()
      _sc = null
    }
    super.afterAll()
  }

  def sc: SparkSession = _sc
}*/
