package com.aciworldwide.ra.redi.tre.features.transformations

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.tre.features.utils.Utils
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Class involving below methods
  * (a) Transformation
  * (b) Deserialize
  * (c) explodeFeatures from incoming Kafka msg
  * (d) mapCellsToColumns of incoming Kafka msg
  * (e) generateAdditionalColumns to incoming Kafka msg
  *
  * Also a separate object InformationTREFeatures is created that will contain objects of the type FeatureSet.
  * This object is what will be serialized and stored in HDFS as ORC Files
  */

//object InformationTREFeatures {
//
//  val schemaRegistryURL = ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL")
//  val topicName = ConfigFactory.load().getString("local.common.kafka.treFeatureskafkatopic")
//  val props = Map("schema.registry.url" -> schemaRegistryURL)
//
//  val currentuser=System.getProperty("user.name")
//  val wholoaded=currentuser+"_tre-features"
//
//
//  val fs = new FeatureSet()
//  val featuresSchema: Schema = fs.getSchema()
//
//  val structure: StructType = SchemaConverters.toSqlType(featuresSchema).dataType.asInstanceOf[StructType]
//
//  //Declare SerDe vars before using Spark structured streaming map. Avoids non serializable class exception.
//  var keyDeserializer: StringDeserializer = null
//  var valueDeserializer: KafkaAvroDeserializer = null
//
//}

class TREFeatures(trefeaturesSession: SparkSession) extends BaseController
  with TransformerFactory
  with Loggers
  with ReDiConstants
  with CommonUtils
  with Serializable {

  @transient lazy val treFeatures = LogManager.getLogger(getClass.getName)
  val wholoaded=System.getProperty("user.name")+"_tre-features"
  //  val props = Map("schema.registry.url" -> InformationTREFeatures.schemaRegistryURL)

  val bcFeatureMap: Broadcast[Map[String, String]] = {

    trefeaturesSession.sparkContext.broadcast(
      Utils.configToMap(ConfigFactory.parseResources("feature.properties")))
  }

  //  private val structure: StructType = {
  //
  //    SchemaConverters
  //      .toSqlType(FeatureSet.SCHEMA$)
  //      .dataType
  //      .asInstanceOf[StructType]
  //  }

  private lazy val bcColumns = trefeaturesSession.sparkContext.broadcast(
    tableColumns(DYNAMIC_FEATURE_DATA))

  import org.apache.spark.sql.functions._
  import sparkSession.implicits._



  def transform(dataFrame: DataFrame,
                testRuntime: Boolean = false): DataFrame = {

    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::transform::START")

    val deserializedDF = transformDeserializeData(dataFrame)
    val explodedDF = explodeFeatures(deserializedDF)
    val columnedDF = mapCellsToColumns(explodedDF)
    val withAdditionalColumnsDF = generateAdditionalColumns(columnedDF)

    if (!testRuntime) {
      withAdditionalColumnsDF.select(bcColumns.value.head,
        bcColumns.value.tail: _*)
    } else {
      withAdditionalColumnsDF
    }
  }

  def transformDeserializeData(df: DataFrame): DataFrame = {
    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::transformDeserializeData::START")

    //    df.select($"key".as[String], $"value".as[Array[Byte]])
    //      .map(
    //        row => {
    //          deservalue(row._1, row._2)
    //        }
    //      ).select(from_json($"value", structure).as("data")).select("*")
    df
  }

  //  private def deservalue(key: String, value: Array[Byte]): String = {
  //    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::deservalue::START")
  //
  //    if (InformationTREFeatures.valueDeserializer == null) {
  //      try {
  //        InformationTREFeatures.valueDeserializer = new KafkaAvroDeserializer
  //        InformationTREFeatures.valueDeserializer.configure(props.asJava, false) //isKey = false
  //      }
  //      catch {
  //        case e: Exception => treFeatures.error(TRE_RULE_FEATURES_ERROR+" : TREFeatures::deserialize::Serialization error: " + e)
  //      }
  //      finally {
  //        treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::deserialize::END::Deserialize method ended")
  //      }
  //
  //    }
  //
  //    val deserializedJsonString = InformationTREFeatures.valueDeserializer.deserialize(InformationTREFeatures.topicName, value, InformationTREFeatures.featuresSchema).toString
  //    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::deservalue::END")
  //    deserializedJsonString
  //  }

  def explodeFeatures(dataFrame: DataFrame) = {
    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::explodeFeatures::START")

    dataFrame.select($"oid",
      $"oiddate",
      explode_outer($"features").as("feature"))
  }

  def mapCellsToColumns(dataFrame: DataFrame) = {
    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::mapCellsToColumns::START")

    dataFrame.select(
      $"oid" +: $"oiddate" +: bcFeatureMap.value.keySet.toSeq
        .map(
          k =>
            $"feature"
              .getItem(k)
              .as(k)
              .cast(bcFeatureMap.value.getOrElse(k, "string"))): _*)
  }

  def generateAdditionalColumns(dataFrame: DataFrame) = {
    treFeatures.info(TRE_RULE_FEATURES_INFO+" : TREFeatures::generateAdditionalColumns::START::generateAdditionalColumns method called")

    dataFrame
      .withColumn("clientid", when($"oid".isNotNull, substring($"oid", 1, 6)).otherwise($"oid"))
      .withColumn("subclientid", when($"oid".isNotNull, substring($"oid", 7, 6)).otherwise($"oid"))
      .withColumn("client12", when($"oid".isNotNull, substring($"oid", 1, 12)).otherwise($"oid"))

      .withColumn("OIDDATEYYYYMMDD", oIdDateWithoutTimePart($"oiddate").cast("int"))

      // Need to decide whether it has to be sae or dynamic
      .withColumn("type", lit("dynamic"))

      .withColumn("whenloaded", current_time_utc().cast("string"))
      .withColumn("wholoaded", lit(wholoaded))

      .withColumn("whenupdated", lit(""))
      .withColumn("whoupdated", lit(""))

  }

}
