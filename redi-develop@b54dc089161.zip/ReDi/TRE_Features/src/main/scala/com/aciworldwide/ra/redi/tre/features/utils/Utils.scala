/*
 *  Copyright (c) 2018 by ACI Worldwide Inc.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of ACI
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such
 *  Confidential Information and shall use it only in accordance with the
 *  terms of the license agreement you entered with ACI Worldwide Inc.
 */

package com.aciworldwide.ra.redi.tre.features.utils

import java.util.Properties

import com.aciworldwide.ra.redi.common.services.Loggers
import com.typesafe.config.Config
import org.apache.log4j.LogManager
import org.apache.spark.sql.SparkSession

import com.aciworldwide.ra.redi.common.constants.ReDiConstants

/**
  * Object involving
  * (a) Retrieving SparkSession
  * (b) Converting incoming config to map
  */

object Utils extends Loggers {

  @transient lazy val utils = LogManager.getLogger(getClass.getName)


  val sparkSession: SparkSession = {

    val sparkSession =
      SparkSession.getActiveSession.orElse(SparkSession.getDefaultSession)
    require(sparkSession.isDefined)
    sparkSession.get
  }

  def configToMap(config: Config): Map[String, String] = {
    //utils.info(TRE_RULE_FEATURES_INFO+" : Utils::configToMap::START::configToMap instantiated")

    import scala.collection.JavaConverters.{
      asScalaSetConverter,
      propertiesAsScalaMapConverter
    }
    val props = new Properties()
    asScalaSetConverter(config.entrySet()).asScala.foreach(e =>
      props.setProperty(e.getKey, config.getString(e.getKey)))
    propertiesAsScalaMapConverter(props).asScala.toMap
  }

}
