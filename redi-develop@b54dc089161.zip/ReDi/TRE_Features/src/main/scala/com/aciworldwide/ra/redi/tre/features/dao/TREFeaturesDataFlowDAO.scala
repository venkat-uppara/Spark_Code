package com.aciworldwide.ra.redi.tre.features.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.log4j.LogManager
import org.apache.spark.sql.streaming.{OutputMode, Trigger}
import org.apache.spark.sql.{DataFrame, SparkSession}
import za.co.absa.abris.avro.read.confluent.SchemaManager
import za.co.absa.abris.avro.schemas.policy.SchemaRetentionPolicies.RETAIN_SELECTED_COLUMN_ONLY
import za.co.absa.abris.avro.AvroSerDe._

/**
  * Data Access Class involving
  * (a) Reading Kafka stream as a Dataframe
  * (b) Writing transformed dataframe into hive
  */

class TREFeaturesDataFlowDAO(sc: SparkSession) extends Serializable
  with ReDiConstants with CommonUtils with DatabaseServices with EstablishConnections with Loggers {

  val schemaRegistryConfs = Map(
    SchemaManager.PARAM_SCHEMA_REGISTRY_URL -> ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"),
    SchemaManager.PARAM_SCHEMA_REGISTRY_TOPIC -> ConfigFactory.load().getString("local.common.kafka.treFeatureskafkatopic"),
    SchemaManager.PARAM_VALUE_SCHEMA_NAMING_STRATEGY -> SchemaManager.SchemaStorageNamingStrategies.TOPIC_NAME, // choose a subject name strategy
    SchemaManager.PARAM_VALUE_SCHEMA_ID -> "latest" // set to "latest" if you want the latest schema version to used
  )

  var topicName: String = ConfigFactory.load().getString("local.common.kafka.treFeatureskafkatopic")
  var orcFilePath: String = ConfigFactory.load().getString("local.common.tre_features.trefeaturesorcfilepath")
  var ingestionORCFilePath: String = ConfigFactory.load().getString("local.common.tre_features.trefeaturesIngestionfilepath")
  var topicCheckpointLocation: String = ConfigFactory.load().getString("local.common.tre_features.trefeaturesCheckpointlocation")
  var hiveSinkTable: String = ConfigFactory.load().getString("local.common.tre_features.hiveSinkTable")
  var metaStoreURI: String = ConfigFactory.load().getString("local.common.tre_features.metaStoreUri")

  @transient lazy val treFeaturesDataFlowDAO = LogManager.getLogger(getClass.getName)


  def readTREFeaturesFromKafka(): DataFrame = {
    treFeaturesDataFlowDAO.info(TRE_RULE_FEATURES_INFO+" : ReDiKafkaController::readStreamFromKafka::START")

    sc.readStream
      .format(KAFKA_SOURCE)
      .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
      .option(SUBSCRIBE, topicName)
      .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.tremaxOffsetsPerTrigger"))
      .option(KAFKASECURITYPROTOCOL, SASL_SSL)
      //.option(SCHEMAREGISTRYCLIENT, ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"))
      .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
      .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
      .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
      .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
      .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
      .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
      .option(KAFKASASLMECHANISM, GSSAPI)
      .option("startingOffsets","latest")
      .option("failOnDataLoss", false)
      .load()
      .fromConfluentAvro("value", None, Some(schemaRegistryConfs))(RETAIN_SELECTED_COLUMN_ONLY) // invoke the library passing over parameters to access the Schema Registry
  }


  def writeToHive(df: DataFrame) = {
    treFeaturesDataFlowDAO.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesDataFlowDAO::writeToHive::START")
    df
      .writeStream
      .outputMode(OutputMode.Append())
      .format(HiveWarehouseSession.STREAM_TO_STREAM)
      .trigger(Trigger.ProcessingTime(ConfigFactory.load().getString("local.common.tre_features.processingTime")))
      .option("database", REDI_CONTROL_DATABASE)
      .option("table", hiveSinkTable)
      .option("metastoreUri", metaStoreURI)
      .option(KAFKA_CHECKPOINT_LOCATION, topicCheckpointLocation)
      .queryName(KAFKA_WRITE_QUERYNAME)
      .start()
      .awaitTermination()

    treFeaturesDataFlowDAO.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesDataFlowDAO::writeToHive::END")
  }
}
