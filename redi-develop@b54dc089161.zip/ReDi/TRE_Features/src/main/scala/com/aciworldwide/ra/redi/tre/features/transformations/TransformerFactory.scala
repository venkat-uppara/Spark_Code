/*
 *  Copyright (c) 2018 by ACI Worldwide Inc.
 *  All rights reserved.
 *
 *  This software is the confidential and proprietary information of ACI
 *  Worldwide Inc ("Confidential Information"). You shall not disclose such
 *  Confidential Information and shall use it only in accordance with the
 *  terms of the license agreement you entered with ACI Worldwide Inc.
 */

package com.aciworldwide.ra.redi.tre.features.transformations

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.tre.features.utils.Utils
import org.apache.spark.sql.{DataFrame, SparkSession}
/**
  * Trait involving
  * (a) Transform method
  * (b) Getting list of columns present in a table
  * (c) UDF giving Timestamp
  */

trait TransformerFactory extends Loggers with ReDiConstants  {

  val sparkSession: SparkSession = Utils.sparkSession

  /**
    * This method should implement a full cycle of data transformation.
    * @param dataFrame Raw DataFrame which taken from the Kafka queue
    * @param testRuntime Required for Tests.
    * @return DataFrame completely transformed and ready to be written to the Hive table
    */
  def transform(dataFrame: DataFrame, testRuntime: Boolean = false): DataFrame

  /**
    * Getting list of columns present in a table.
    * @param tableName Name of table which we will use as data source.
    * @return List of columns
    */
  def tableColumns(tableName: String): Array[String] = {

    import org.apache.spark.sql.functions.collect_list

    import scala.collection.mutable

    import com.hortonworks.hwc.HiveWarehouseSession

    val hive = HiveWarehouseSession.session(sparkSession).build()

    val arr = hive
      .execute(s"SHOW COLUMNS IN $tableName")
      .agg(collect_list("field"))
      .first()
      .getAs[mutable.WrappedArray[String]](0)
      .array

    arr
  }

}

