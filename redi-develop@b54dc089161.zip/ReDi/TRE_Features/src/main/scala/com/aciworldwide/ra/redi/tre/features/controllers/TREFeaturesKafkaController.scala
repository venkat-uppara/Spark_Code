package com.aciworldwide.ra.redi.tre.features.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.tre.features.actions.TREFeaturesKafkaConsumer.{TRE_RULE_FEATURES_INFO, getClass}
import com.aciworldwide.ra.redi.tre.features.dao.TREFeaturesDataFlowDAO
import com.aciworldwide.ra.redi.tre.features.transformations.TREFeatures
import org.apache.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Controller which invokes the process that addresses the Tre features involving
  * (a) Read Kafka stream
  * (b) Store the stream to hive
  */

class TREFeaturesKafkaController extends BaseController with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with Loggers {

  @transient lazy val treFeaturesKafkaController = LogManager.getLogger(getClass.getName)

  val kafkaSparkSession = createSparkSession(TREFEATURESKAFKAAPP)

  val treFeaturesKafkaDao = new TREFeaturesDataFlowDAO(kafkaSparkSession)



  def TreFeaturesPipeline(): Unit = {
    treFeaturesKafkaController.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaController::TreFeaturesPipeline::START")

    val streamDF: DataFrame = treFeaturesKafkaDao.readTREFeaturesFromKafka()

    val transformedDF: DataFrame = transformTREFeaturesData(streamDF, kafkaSparkSession)

    val reorderedTransformedDF: DataFrame = reorderSourceTableSchema(TRE_FEATURES_COL_ORDER, transformedDF)
    treFeaturesKafkaDao.writeToHive(reorderedTransformedDF)

    treFeaturesKafkaController.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaController::TreFeaturesPipeline::END")
  }

  def transformTREFeaturesData(df: DataFrame, transformTRESession: SparkSession): DataFrame = {
    treFeaturesKafkaController.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaController::transformTREFeaturesData::START")

    val tre = new TREFeatures(transformTRESession)
    val df_ret = tre.transform(df)

    treFeaturesKafkaController.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaController::transformTREFeaturesData::END")
    df_ret
  }


}