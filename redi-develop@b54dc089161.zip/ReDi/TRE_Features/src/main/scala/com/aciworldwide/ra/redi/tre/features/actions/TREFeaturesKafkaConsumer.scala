package com.aciworldwide.ra.redi.tre.features.actions

import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.tre.features.controllers.TREFeaturesKafkaController
import org.apache.log4j.LogManager

/**
  * Single process which invokes the process that addresses the Tre features
  * (a) Read Kafka stream
  * (b) Store as ORC Files in HDFS
  */

object TREFeaturesKafkaConsumer extends TREFeaturesKafkaController with Loggers with Serializable {

  @transient lazy val treFeaturesKafkaConsumer = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    treFeaturesKafkaConsumer.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaConsumer::Main::START")
    try {
      TreFeaturesPipeline()
    } catch {
      case e: Exception => treFeaturesKafkaConsumer.error(TRE_RULE_FEATURES_ERROR+" : TREFeaturesKafkaConsumer::Main::ERROR::We have an error in the TREFeaturesController::TreFeaturesPipeline::" + e)
    } finally {
      treFeaturesKafkaConsumer.info(TRE_RULE_FEATURES_INFO+" : TREFeaturesKafkaConsumer::Main::END")
    }
  }
}
