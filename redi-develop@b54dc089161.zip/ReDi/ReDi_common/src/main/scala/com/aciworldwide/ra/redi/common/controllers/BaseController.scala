package com.aciworldwide.ra.redi.common.controllers

/**
  * Base controller which contains methods that have to be called across all the controllers
  * HPA Initial Draft 08/22/2018
  * @note :
  */

import com.aciworldwide.ra.redi.common.services.EstablishConnections
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession

class BaseController extends EstablishConnections{

  def createSparkSession(appname: String): SparkSession = {
    val sparkmaster = ConfigFactory.load().getString("local.common.spark.master")
    sparkSessionBuilder(sparkmaster, appname)
  }

}
