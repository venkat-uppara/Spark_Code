package com.aciworldwide.ra.redi.common.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.common.utils.ShellscriptCall
import com.databricks.spark.avro.SchemaConverters
import com.typesafe.config.ConfigFactory
import io.confluent.kafka.schemaregistry.client.rest.{RestService, entities}
import io.confluent.kafka.serializers.KafkaAvroDeserializer
import org.apache.avro.Schema
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{col, from_json}
import org.apache.spark.sql.types.StructType

import scala.collection.JavaConverters._

object InformationSchema {

  val schemaRegistryURL = ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL")

  val topicName = ConfigFactory.load().getString("local.common.kafka_scheduler.schedulerkafkatopic")
  val subjectValueName = topicName + "-value"

  //create RestService object
  val restService = new RestService(schemaRegistryURL)

  //gets latest version of type entities.Schema object.
  val valueRestResponseSchema: entities.Schema = restService.getLatestVersion(subjectValueName)


  //Use Avro parsing classes to get Avro Schema
  val parser = new Schema.Parser
  val topicValueAvroSchema: Schema = parser.parse(valueRestResponseSchema.getSchema)

  val props = Map("schema.registry.url" -> schemaRegistryURL)
  val structure: StructType = SchemaConverters.toSqlType(topicValueAvroSchema).dataType.asInstanceOf[StructType]

  //Declare SerDe vars before using Spark structured streaming map. Avoids non serializable class exception.
  var keyDeserializer: StringDeserializer = null
  var valueDeserializer: KafkaAvroDeserializer = null

  def deserValue(key: String, value: Array[Byte]): String = {
    if (valueDeserializer == null) {
      valueDeserializer = new KafkaAvroDeserializer
      valueDeserializer.configure(props.asJava, false) //isKey = false
    }
    val deserializedValueJsonString = valueDeserializer.deserialize(topicName, value, topicValueAvroSchema).toString
    deserializedValueJsonString
  }
}

class ReDiSchedulerDao extends BaseController with Serializable  with Loggers with ReDiConstants {

  @transient lazy val ReDiJobSchedulerlogger = LogManager.getLogger(getClass.getName)


  def SchedulerDataPipeline(): Unit = {

    /**
      * Read Transaction from Kafka
      *
      * @return
      */

    ReDiJobSchedulerlogger.info(ReDiJobScheduler_INFO +"ReDiScheduler  pipeline processing starts " )

    ReDiJobSchedulerlogger.info(ReDiJobScheduler_INFO +"Starting to Fetch Jobnames  into processing layer ")

    val baseController = new BaseController()

    val sparkSession = baseController.createSparkSession(REDISCHEDULERAPP)

    System.setProperty(ConfigFactory.load().getString("local.common.kerberos.configkafka"), ConfigFactory.load().getString("local.common.kerberos.jassconfigkafka"))

    import sparkSession.implicits._

    val Schedulerdf =
      sparkSession
        .readStream
        .format(KAFKA_SOURCE)
        .option("latestOffsets", "latest")
        .option("failOnDataLoss", "false")
        .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
        .option(SUBSCRIBE, ConfigFactory.load().getString("local.common.kafka_scheduler.schedulerkafkatopic"))
        .option(KAFKASECURITYPROTOCOL, SASL_SSL)
        .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
        .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
        .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
        .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
        .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
        .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
        .option(KAFKASASLMECHANISM, GSSAPI)
        .load()

    /* calling the shellscript from Foreach writer*/

    ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Spark Job Trigger Process Starts" )
    val writer = new ForeachWriter[Row] {
      override def open(partitionId: Long, version: Long) = true

      override def process(value: Row): Unit = {
        val jobname = value.mkString("")

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Foreachwriter fetching the Jobtype from Scheduler Topic" + jobname)


        val shell = new ShellscriptCall().Triggeringjobs(jobname)


      }

      override def close(errorOrNull: Throwable): Unit = {}
    }

    val deserializedTopicMessageDS: Dataset[Row] = Schedulerdf.select(col("key").as[String], col("value").as[Array[Byte]])
      .map(
        row => {
          InformationSchema.deserValue(row._1, row._2)
        }
      ).select(from_json(col("value"), InformationSchema.structure).as("data")).select("data.*")


    val jobtype = deserializedTopicMessageDS.select("type").where(col("type").isNotNull)

    /* Writting streaming data to HDFS Location */

    jobtype.writeStream
      .format("orc")
      .option("path",ConfigFactory.load().getString("local.common.kafka_scheduler.schedulerorcfile"))
      .queryName(KAFKA_SCHEDULER_WRITE_QUERYNAME)
      .foreach(writer)
      .outputMode("append")
      .option(KAFKA_CHECKPOINT_LOCATION, ConfigFactory.load().getString("local.common.kafka_scheduler.schedulertopicCheckpointlocation"))
      .start()
      .awaitTermination()

  }

}