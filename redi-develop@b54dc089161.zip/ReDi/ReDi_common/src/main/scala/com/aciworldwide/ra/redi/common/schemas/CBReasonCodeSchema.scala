package com.aciworldwide.ra.redi.common.schemas

case class CBReasonCodeSchema(RSN_CD: String, CARD_TYPE: String, FRAUD_FLAG: String, DESCRIPTION:String, SDS_FLAG: String,CB_PROCESSOR: String)
