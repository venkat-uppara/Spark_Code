package com.aciworldwide.ra.redi.common.controllers

import java.util.Properties

import com.aciworldwide.ra.model.{Attribute, TxUpdate}
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.typesafe.config.ConfigFactory
import org.apache.kafka.clients.producer._
import org.apache.kafka.common.config.{SaslConfigs, SslConfigs}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession._

import scala.collection.mutable.ListBuffer

class RollbackController(hiveSession: HiveWarehouseSession) extends BaseController with EstablishConnections with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with Loggers {
  //val session = createSparkSession(ConfigFactory.load().getString("local.common.spark.app.name"))
  //val session = createSparkSession(ConfigFactory.load().getString("local.common.spark.app.name"))
  val session= hiveSession.session()
  val rollback_txn_producer_log_view = hiveSession.executeQuery("Select * From " + REDI_ROLLBACK_TXN_PRODUCER_LOG_VIEW)
  val transMaster = hiveSession.executeQuery("Select OID,OIDDATE,ABA,ACCTTYPE,ACHRESPONSE,AUTHAMT,AUTHDT,AUTHRESP,AUTHTM," +
    "BILLADDRESS2,BILLAPT,BILLCITY,BILLCOUNTRY,BILLSTATE,BILLSTREET,BILLZIPCD," +
    "CARDEXPDT,CARDSEQNUM,CARDTYPE,CARRIER,CINPRESENT,CLIENTID,CMPLTRCK2DATA," +
    "CREDDEBIND,CURRCD,CUSTEMAIL,CUSTFIRSTNAME,CUSTHOMEPHONE,CUSTIP,CUSTLASTNAME,CUSTMIDNAME," +
    "CUSTTRANDT,CUSTWORKPHONE,CVV2DATA,ECOMMFLAG,EMVCARDVRFYRSLTS,EMVTERMTYPE,EMVTRMNLVRFYRSLT," +
    "EMVUSRFLR,GIFTCARDTYPE,GIFTMSG,HANDLING,MERCHANTCOUNTRY,MERCHANTID,MERCHANTNM,MERCHANTSIC," +
    "MERCHANTZIPCD,ORDERDT,ORDERTM,ORDERTZ,PAYMETHOD,PININDX,POSCONDCODE,POSENTRYMOD,PRENOTE,PREVIOUSCUST," +
    "PRODIND,RETURNALLOWED,RTLRSICCODE,SERVICE,SETTLEMENTCURRCD,SHIPADDRESS2,SHIPAPT,SHIPCITY,SHIPCOMMENTS," +
    "SHIPCOUNTRY,SHIPEMAIL,SHIPFIRSTNAME,SHIPLASTNAME,SHIPMIDNAME,SHIPSTATE,SHIPSTREET,SHIPZIPCD,SUBCLIENTID," +
    "SUBTOTAL,TAX,TERMCITY,TERMCNTR,TERMID,TERMNAMELOC,TERMPSTLCODE,TERMST,TOTAL,TRANAMT1,TRANAMT5,TRANAUTHSRC,TRANCATEGORY," +
    "TRANCODE,TRANRSNCODE,TRANSACTIONID,TRANTYPE,USERDATA02,USERDATA03,USERDATA04,USERDATA05,USERDATA06,USERDATA07,USERDATA08," +
    "USERDATA09,USERDATA11,USERDATA19,USERDATA20,USERDATA21,USERDATA25,VIRTBILLSHIP,VIRTBILLZIPMATCH,VIRTBIN,VIRTCARDBIN," +
    "VIRTCARDCLASS,VIRTCUSTEMAILDOMAIN,VIRTCUSTEMAILMATCH,VIRTEXPIRED,VIRTFUZBILLSCORE,VIRTFUZRSP,VIRTFUZSHIPSCORE,VIRTIOVRSP," +
    "VIRTMOD10FAIL,VIRTRECIPEMAILMATCH,VIRTRECIPZIPMATCH,VIRTSHIPEMAILMATCH,VIRTSHIPZIPMATCH,VIRTUTF8,WEBSITE,VIRTSAERSP," +
    "CARDNO,REALFRAUDYN,REALFRAUDDATEBAE,REALFRAUDYYYYMMDD " +
    " From " + BI_TRANS_MASTER_CORE)

  val refclient  = hiveSession.executeQuery("Select * From " + REDI_RBI_REF_CLIENT)

  def rollbackTransactions(oids: DataFrame): Unit = {
    import session.sqlContext.implicits._

    val oid = oids
      .withColumnRenamed("OID", "REFERENCE_OID")
      .select($"REFERENCE_OID")
      .union((rollback_txn_producer_log_view)
        .withColumnRenamed("OID", "REFERENCE_OID")
        .select($"REFERENCE_OID"))
      .where($"REFERENCE_OID".isNotNull)
      .distinct()
    // .show(false)

    val core = transMaster
      .withColumnRenamed("OID", "MASTER_REFERENCE_OID")
      .withColumnRenamed("CLIENTID", "REF_CLIENT_ID")
      .withColumnRenamed("SUBCLIENTID", "REF_SUBCLIENT_ID")
      .select($"MASTER_REFERENCE_OID",
        $"OIDDATE",
        $"ABA",
        $"ACCTTYPE",
        $"ACHRESPONSE",
        $"AUTHAMT",
        $"AUTHDT",
        $"AUTHRESP",
        $"AUTHTM",
        $"BILLADDRESS2",
        $"BILLAPT",
        $"BILLCITY",
        $"BILLCOUNTRY",
        $"BILLSTATE",
        $"BILLSTREET",
        $"BILLZIPCD",
        $"CARDEXPDT",
        $"CARDSEQNUM",
        $"CARDTYPE",
        $"CARRIER",
        $"CINPRESENT",
        $"REF_CLIENT_ID",
        $"CMPLTRCK2DATA",
        $"CREDDEBIND",
        $"CURRCD",
        $"CUSTEMAIL",
        $"CUSTFIRSTNAME",
        $"CUSTHOMEPHONE",
        $"CUSTIP",
        $"CUSTLASTNAME",
        $"CUSTMIDNAME",
        $"CUSTTRANDT",
        $"CUSTWORKPHONE",
        $"CVV2DATA",
        $"ECOMMFLAG",
        $"EMVCARDVRFYRSLTS",
        $"EMVTERMTYPE",
        $"EMVTRMNLVRFYRSLT",
        $"EMVUSRFLR",
        $"GIFTCARDTYPE",
        $"GIFTMSG",
        $"HANDLING",
        $"MERCHANTCOUNTRY",
        $"MERCHANTID",
        $"MERCHANTNM",
        $"MERCHANTSIC",
        $"MERCHANTZIPCD",
        $"ORDERDT",
        $"ORDERTM",
        $"ORDERTZ",
        $"PAYMETHOD",
        $"PININDX",
        $"POSCONDCODE",
        $"POSENTRYMOD",
        $"PRENOTE",
        $"PREVIOUSCUST",
        $"PRODIND",
        $"RETURNALLOWED",
        $"RTLRSICCODE",
        $"SERVICE",
        $"SETTLEMENTCURRCD",
        $"SHIPADDRESS2",
        $"SHIPAPT",
        $"SHIPCITY",
        $"SHIPCOMMENTS",
        $"SHIPCOUNTRY",
        $"SHIPEMAIL",
        $"SHIPFIRSTNAME",
        $"SHIPLASTNAME",
        $"SHIPMIDNAME",
        $"SHIPSTATE",
        $"SHIPSTREET",
        $"SHIPZIPCD",
        $"REF_SUBCLIENT_ID",
        $"SUBTOTAL",
        $"TAX",
        $"TERMCITY",
        $"TERMCNTR",
        $"TERMID",
        $"TERMNAMELOC",
        $"TERMPSTLCODE",
        $"TERMST",
        $"TOTAL",
        $"TRANAMT1",
        $"TRANAMT5",
        $"TRANAUTHSRC",
        $"TRANCATEGORY",
        $"TRANCODE",
        $"TRANRSNCODE",
        $"TRANSACTIONID",
        $"TRANTYPE",
        $"USERDATA02",
        $"USERDATA03",
        $"USERDATA04",
        $"USERDATA05",
        $"USERDATA06",
        $"USERDATA07",
        $"USERDATA08",
        $"USERDATA09",
        $"USERDATA11",
        $"USERDATA19",
        $"USERDATA20",
        $"USERDATA21",
        $"USERDATA25",
        $"VIRTBILLSHIP",
        $"VIRTBILLZIPMATCH",
        $"VIRTBIN",
        $"VIRTCARDBIN",
        $"VIRTCARDCLASS",
        $"VIRTCUSTEMAILDOMAIN",
        $"VIRTCUSTEMAILMATCH",
        $"VIRTEXPIRED",
        $"VIRTFUZBILLSCORE",
        $"VIRTFUZRSP",
        $"VIRTFUZSHIPSCORE",
        $"VIRTIOVRSP",
        $"VIRTMOD10FAIL",
        $"VIRTRECIPEMAILMATCH",
        $"VIRTRECIPZIPMATCH",
        $"VIRTSHIPEMAILMATCH",
        $"VIRTSHIPZIPMATCH",
        $"VIRTUTF8",
        $"WEBSITE",
        $"VIRTSAERSP",
        $"CARDNO",
        $"REALFRAUDYN",
        $"REALFRAUDDATEBAE",
        $"REALFRAUDYYYYMMDD"
      )
      .join(oid, oid.col("REFERENCE_OID") === $"MASTER_REFERENCE_OID")
      .where ($"REALFRAUDYN" === lit("Y") && $"MASTER_REFERENCE_OID".isNotNull && $"OIDDATE".isNotNull)


    val details = refclient
      .select($"CLIENTID", $"SUBCLIENTID", $"FLAGTRE")
      .join(core, $"CLIENTID" === core.col("REF_CLIENT_ID")
        && $"SUBCLIENTID" === core.col("REF_SUBCLIENT_ID")
        && $"FLAGTRE" === lit("T"))
      .groupBy($"MASTER_REFERENCE_OID") // TODO: This is extremely slow, needs to be improved, cannot do group by
      .agg(first($"MASTER_REFERENCE_OID").as("OID"),
      first(core("OIDDATE")).cast("String").as("OIDDATE"),
      max($"REALFRAUDDATEBAE").as("REALFRAUDDATEBAE"),
      max($"REALFRAUDYYYYMMDD").as("REALFRAUDYYYYMMDD"),
      first($"REALFRAUDYN").as("REALFRAUDYN"),
      first($"ABA").as("ABA"),
      first($"ACCTTYPE").as("ACCTTYPE"),
      first($"ACHRESPONSE").as("ACHRESPONSE"),
      first($"AUTHAMT").as("AUTHAMT"),
      first($"AUTHDT").as("AUTHDT"),
      first($"AUTHRESP").as("AUTHRESP"),
      first($"AUTHTM").as("AUTHTM"),
      first($"BILLADDRESS2").as("BILLADDRESS2"),
      first($"BILLAPT").as("BILLAPT"),
      first($"BILLCITY").as("BILLCITY"),
      first($"BILLCOUNTRY").as("BILLCOUNTRY"),
      first($"BILLSTATE").as("BILLSTATE"),
      first($"BILLSTREET").as("BILLSTREET"),
      first($"BILLZIPCD").as("BILLZIPCD"),
      first($"CARDEXPDT").as("CARDEXPDT"),
      first($"CARDSEQNUM").as("CARDSEQNUM"),
      first($"CARDTYPE").as("CARDTYPE"),
      first($"CARRIER").as("CARRIER"),
      first($"CINPRESENT").as("CINPRESENT"),
      first($"CMPLTRCK2DATA").as("CMPLTRCK2DATA"),
      first($"CREDDEBIND").as("CREDDEBIND"),
      first($"CURRCD").as("CURRCD"),
      first($"CUSTEMAIL").as("CUSTEMAIL"),
      first($"CUSTFIRSTNAME").as("CUSTFIRSTNAME"),
      first($"CUSTHOMEPHONE").as("CUSTHOMEPHONE"),
      first($"CUSTIP").as("CUSTIP"),
      first($"CUSTLASTNAME").as("CUSTLASTNAME"),
      first($"CUSTMIDNAME").as("CUSTMIDNAME"),
      first($"CUSTTRANDT").as("CUSTTRANDT"),
      first($"CUSTWORKPHONE").as("CUSTWORKPHONE"),
      first($"CVV2DATA").as("CVV2DATA"),
      first($"ECOMMFLAG").as("ECOMMFLAG"),
      first($"EMVCARDVRFYRSLTS").as("EMVCARDVRFYRSLTS"),
      first($"EMVTERMTYPE").as("EMVTERMTYPE"),
      first($"EMVTRMNLVRFYRSLT").as("EMVTRMNLVRFYRSLT"),
      first($"EMVUSRFLR").as("EMVUSRFLR"),
      first($"GIFTCARDTYPE").as("GIFTCARDTYPE"),
      first($"GIFTMSG").as("GIFTMSG"),
      first($"HANDLING").as("HANDLING"),
      first($"MERCHANTCOUNTRY").as("MERCHANTCOUNTRY"),
      first($"MERCHANTID").as("MERCHANTID"),
      first($"MERCHANTNM").as("MERCHANTNM"),
      first($"MERCHANTSIC").as("MERCHANTSIC"),
      first($"MERCHANTZIPCD").as("MERCHANTZIPCD"),
      first($"ORDERDT").as("ORDERDT"),
      first($"ORDERTM").as("ORDERTM"),
      first($"ORDERTZ").as("ORDERTZ"),
      first($"PAYMETHOD").as("PAYMETHOD"),
      first($"PININDX").as("PININDX"),
      first($"POSCONDCODE").as("POSCONDCODE"),
      first($"POSENTRYMOD").as("POSENTRYMOD"),
      first($"PRENOTE").as("PRENOTE"),
      first($"PREVIOUSCUST").as("PREVIOUSCUST"),
      first($"PRODIND").as("PRODIND"),
      first($"RETURNALLOWED").as("RETURNALLOWED"),
      first($"RTLRSICCODE").as("RTLRSICCODE"),
      first($"SERVICE").as("SERVICE"),
      first($"SETTLEMENTCURRCD").as("SETTLEMENTCURRCD"),
      first($"SHIPADDRESS2").as("SHIPADDRESS2"),
      first($"SHIPAPT").as("SHIPAPT"),
      first($"SHIPCITY").as("SHIPCITY"),
      first($"SHIPCOMMENTS").as("SHIPCOMMENTS"),
      first($"SHIPCOUNTRY").as("SHIPCOUNTRY"),
      first($"SHIPEMAIL").as("SHIPEMAIL"),
      first($"SHIPFIRSTNAME").as("SHIPFIRSTNAME"),
      first($"SHIPLASTNAME").as("SHIPLASTNAME"),
      first($"SHIPMIDNAME").as("SHIPMIDNAME"),
      first($"SHIPSTATE").as("SHIPSTATE"),
      first($"SHIPSTREET").as("SHIPSTREET"),
      first($"SHIPZIPCD").as("SHIPZIPCD"),
      first($"SUBTOTAL").as("SUBTOTAL"),
      first($"TAX").as("TAX"),
      first($"TERMCITY").as("TERMCITY"),
      first($"TERMCNTR").as("TERMCNTR"),
      first($"TERMID").as("TERMID"),
      first($"TERMNAMELOC").as("TERMNAMELOC"),
      first($"TERMPSTLCODE").as("TERMPSTLCODE"),
      first($"TERMST").as("TERMST"),
      first($"TOTAL").as("TOTAL"),
      first($"TRANAMT1").as("TRANAMT1"),
      first($"TRANAMT5").as("TRANAMT5"),
      first($"TRANAUTHSRC").as("TRANAUTHSRC"),
      first($"TRANCATEGORY").as("TRANCATEGORY"),
      first($"TRANCODE").as("TRANCODE"),
      first($"TRANRSNCODE").as("TRANRSNCODE"),
      first($"TRANSACTIONID").as("TRANSACTIONID"),
      first($"TRANTYPE").as("TRANTYPE"),
      first($"USERDATA02").as("USERDATA02"),
      first($"USERDATA03").as("USERDATA03"),
      first($"USERDATA04").as("USERDATA04"),
      first($"USERDATA05").as("USERDATA05"),
      first($"USERDATA06").as("USERDATA06"),
      first($"USERDATA07").as("USERDATA07"),
      first($"USERDATA08").as("USERDATA08"),
      first($"USERDATA09").as("USERDATA09"),
      first($"USERDATA11").as("USERDATA11"),
      first($"USERDATA19").as("USERDATA19"),
      first($"USERDATA20").as("USERDATA20"),
      first($"USERDATA21").as("USERDATA21"),
      first($"USERDATA25").as("USERDATA25"),
      first($"VIRTBILLSHIP").as("VIRTBILLSHIP"),
      first($"VIRTBILLZIPMATCH").as("VIRTBILLZIPMATCH"),
      first($"VIRTBIN").as("VIRTBIN"),
      first($"VIRTCARDBIN").as("VIRTCARDBIN"),
      first($"VIRTCARDCLASS").as("VIRTCARDCLASS"),
      first($"VIRTCUSTEMAILDOMAIN").as("VIRTCUSTEMAILDOMAIN"),
      first($"VIRTCUSTEMAILMATCH").as("VIRTCUSTEMAILMATCH"),
      first($"VIRTEXPIRED").as("VIRTEXPIRED"),
      first($"VIRTFUZBILLSCORE").as("VIRTFUZBILLSCORE"),
      first($"VIRTFUZRSP").as("VIRTFUZRSP"),
      first($"VIRTFUZSHIPSCORE").as("VIRTFUZSHIPSCORE"),
      first($"VIRTIOVRSP").as("VIRTIOVRSP"),
      first($"VIRTMOD10FAIL").as("VIRTMOD10FAIL"),
      first($"VIRTRECIPEMAILMATCH").as("VIRTRECIPEMAILMATCH"),
      first($"VIRTRECIPZIPMATCH").as("VIRTRECIPZIPMATCH"),
      first($"VIRTSHIPEMAILMATCH").as("VIRTSHIPEMAILMATCH"),
      first($"VIRTSHIPZIPMATCH").as("VIRTSHIPZIPMATCH"),
      first($"VIRTUTF8").as("VIRTUTF8"),
      first($"WEBSITE").as("WEBSITE"),
      first($"VIRTSAERSP").as("VIRTSAERSP"),
      first($"CARDNO").as("CARDNO"))

    val producer = new KafkaProducer[String, TxUpdate](getProperties)

    sys.addShutdownHook(() => {
      producer.close()
    })

    // TODO: Improve efficiency...
    details.collect().foreach(row => {
      //val executorSession = createSparkSession(ConfigFactory.load().getString("local.common.spark.app.name"))
      import scala.collection.JavaConversions._
      val transaction = TxUpdate.newBuilder().setOID(row.getAs("OID").toString)
        .setOIDDATE(row.getAs("OIDDATE").toString)
        .setAttributes(ListBuffer(
          Attribute.newBuilder.setKey("REALFRAUDYN").setValue(if (row.getAs("REALFRAUDYN") != null) row.getAs("REALFRAUDYN").toString else null).build(),
          Attribute.newBuilder.setKey("REALFRAUDDATEBAE").setValue(if (row.getAs("REALFRAUDDATEBAE") != null) if (row.getAs("REALFRAUDDATEBAE") != null) row.getAs("REALFRAUDDATEBAE").toString else null else null).build(),
          Attribute.newBuilder.setKey("REALFRAUDYYYYMMDD").setValue(if (row.getAs("REALFRAUDYYYYMMDD") != null) row.getAs("REALFRAUDYYYYMMDD").toString else null).build(),
          Attribute.newBuilder.setKey("ABA").setValue(if (row.getAs("ABA") != null) row.getAs("ABA").toString else null).build(),
          Attribute.newBuilder.setKey("ACCTTYPE").setValue(if (row.getAs("ACCTTYPE") != null) row.getAs("ACCTTYPE").toString else null).build(),
          Attribute.newBuilder.setKey("ACHRESPONSE").setValue(if (row.getAs("ACHRESPONSE") != null) row.getAs("ACHRESPONSE").toString else null).build(),
          Attribute.newBuilder.setKey("AUTHAMT").setValue(if (row.getAs("AUTHAMT") != null) row.getAs("AUTHAMT").toString else null).build(),
          Attribute.newBuilder.setKey("AUTHDT").setValue(if (row.getAs("AUTHDT") != null) row.getAs("AUTHDT").toString else null).build(),
          Attribute.newBuilder.setKey("AUTHRESP").setValue(if (row.getAs("AUTHRESP") != null) row.getAs("AUTHRESP").toString else null).build(),
          Attribute.newBuilder.setKey("AUTHTM").setValue(if (row.getAs("AUTHTM") != null) row.getAs("AUTHTM").toString else null).build(),
          Attribute.newBuilder.setKey("BILLADDRESS2").setValue(if (row.getAs("BILLADDRESS2") != null) row.getAs("BILLADDRESS2").toString else null).build(),
          Attribute.newBuilder.setKey("BILLAPT").setValue(if (row.getAs("BILLAPT") != null) row.getAs("BILLAPT").toString else null).build(),
          Attribute.newBuilder.setKey("BILLCITY").setValue(if (row.getAs("BILLCITY") != null) row.getAs("BILLCITY").toString else null).build(),
          Attribute.newBuilder.setKey("BILLCOUNTRY").setValue(if (row.getAs("BILLCOUNTRY") != null) row.getAs("BILLCOUNTRY").toString else null).build(),
          Attribute.newBuilder.setKey("BILLSTATE").setValue(if (row.getAs("BILLSTATE") != null) row.getAs("BILLSTATE").toString else null).build(),
          Attribute.newBuilder.setKey("BILLSTREET").setValue(if (row.getAs("BILLSTREET") != null) row.getAs("BILLSTREET").toString else null).build(),
          Attribute.newBuilder.setKey("BILLZIPCD").setValue(if (row.getAs("BILLZIPCD") != null) row.getAs("BILLZIPCD").toString else null).build(),
          Attribute.newBuilder.setKey("CARDEXPDT").setValue(if (row.getAs("CARDEXPDT") != null) row.getAs("CARDEXPDT").toString else null).build(),
          Attribute.newBuilder.setKey("CARDSEQNUM").setValue(if (row.getAs("CARDSEQNUM") != null) row.getAs("CARDSEQNUM").toString else null).build(),
          Attribute.newBuilder.setKey("CARDTYPE").setValue(if (row.getAs("CARDTYPE") != null) row.getAs("CARDTYPE").toString else null).build(),
          Attribute.newBuilder.setKey("CARRIER").setValue(if (row.getAs("CARRIER") != null) row.getAs("CARRIER").toString else null).build(),
          Attribute.newBuilder.setKey("CINPRESENT").setValue(if (row.getAs("CINPRESENT") != null) row.getAs("CINPRESENT").toString else null).build(),
          Attribute.newBuilder.setKey("CMPLTRCK2DATA").setValue(if (row.getAs("CMPLTRCK2DATA") != null) row.getAs("CMPLTRCK2DATA").toString else null).build(),
          Attribute.newBuilder.setKey("CREDDEBIND").setValue(if (row.getAs("CREDDEBIND") != null) row.getAs("CREDDEBIND").toString else null).build(),
          Attribute.newBuilder.setKey("CURRCD").setValue(if (row.getAs("CURRCD") != null) row.getAs("CURRCD").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTEMAIL").setValue(if (row.getAs("CUSTEMAIL") != null) row.getAs("CUSTEMAIL").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTFIRSTNAME").setValue(if (row.getAs("CUSTFIRSTNAME") != null) row.getAs("CUSTFIRSTNAME").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTHOMEPHONE").setValue(if (row.getAs("CUSTHOMEPHONE") != null) row.getAs("CUSTHOMEPHONE").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTIP").setValue(if (row.getAs("CUSTIP") != null) row.getAs("CUSTIP").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTLASTNAME").setValue(if (row.getAs("CUSTLASTNAME") != null) row.getAs("CUSTLASTNAME").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTMIDNAME").setValue(if (row.getAs("CUSTMIDNAME") != null) row.getAs("CUSTMIDNAME").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTTRANDT").setValue(if (row.getAs("CUSTTRANDT") != null) row.getAs("CUSTTRANDT").toString else null).build(),
          Attribute.newBuilder.setKey("CUSTWORKPHONE").setValue(if (row.getAs("CUSTWORKPHONE") != null) row.getAs("CUSTWORKPHONE").toString else null).build(),
          Attribute.newBuilder.setKey("CVV2DATA").setValue(if (row.getAs("CVV2DATA") != null) row.getAs("CVV2DATA").toString else null).build(),
          Attribute.newBuilder.setKey("ECOMMFLAG").setValue(if (row.getAs("ECOMMFLAG") != null) row.getAs("ECOMMFLAG").toString else null).build(),
          Attribute.newBuilder.setKey("EMVCARDVRFYRSLTS").setValue(if (row.getAs("EMVCARDVRFYRSLTS") != null) row.getAs("EMVCARDVRFYRSLTS").toString else null).build(),
          Attribute.newBuilder.setKey("EMVTERMTYPE").setValue(if (row.getAs("EMVTERMTYPE") != null) row.getAs("EMVTERMTYPE").toString else null).build(),
          Attribute.newBuilder.setKey("EMVTRMNLVRFYRSLT").setValue(if (row.getAs("EMVTRMNLVRFYRSLT") != null) row.getAs("EMVTRMNLVRFYRSLT").toString else null).build(),
          Attribute.newBuilder.setKey("EMVUSRFLR").setValue(if (row.getAs("EMVUSRFLR") != null) row.getAs("EMVUSRFLR").toString else null).build(),
          Attribute.newBuilder.setKey("GIFTCARDTYPE").setValue(if (row.getAs("GIFTCARDTYPE") != null) row.getAs("GIFTCARDTYPE").toString else null).build(),
          Attribute.newBuilder.setKey("GIFTMSG").setValue(if (row.getAs("GIFTMSG") != null) row.getAs("GIFTMSG").toString else null).build(),
          Attribute.newBuilder.setKey("HANDLING").setValue(if (row.getAs("HANDLING") != null) row.getAs("HANDLING").toString else null).build(),
          Attribute.newBuilder.setKey("MERCHANTCOUNTRY").setValue(if (row.getAs("MERCHANTCOUNTRY") != null) row.getAs("MERCHANTCOUNTRY").toString else null).build(),
          Attribute.newBuilder.setKey("MERCHANTID").setValue(if (row.getAs("MERCHANTID") != null) row.getAs("MERCHANTID").toString else null).build(),
          Attribute.newBuilder.setKey("MERCHANTNM").setValue(if (row.getAs("MERCHANTNM") != null) row.getAs("MERCHANTNM").toString else null).build(),
          Attribute.newBuilder.setKey("MERCHANTSIC").setValue(if (row.getAs("MERCHANTSIC") != null) row.getAs("MERCHANTSIC").toString else null).build(),
          Attribute.newBuilder.setKey("MERCHANTZIPCD").setValue(if (row.getAs("MERCHANTZIPCD") != null) row.getAs("MERCHANTZIPCD").toString else null).build(),
          Attribute.newBuilder.setKey("ORDERDT").setValue(if (row.getAs("ORDERDT") != null) row.getAs("ORDERDT").toString else null).build(),
          Attribute.newBuilder.setKey("ORDERTM").setValue(if (row.getAs("ORDERTM") != null) row.getAs("ORDERTM").toString else null).build(),
          Attribute.newBuilder.setKey("ORDERTZ").setValue(if (row.getAs("ORDERTZ") != null) row.getAs("ORDERTZ").toString else null).build(),
          Attribute.newBuilder.setKey("PAYMETHOD").setValue(if (row.getAs("PAYMETHOD") != null) row.getAs("PAYMETHOD").toString else null).build(),
          Attribute.newBuilder.setKey("PININDX").setValue(if (row.getAs("PININDX") != null) row.getAs("PININDX").toString else null).build(),
          Attribute.newBuilder.setKey("POSCONDCODE").setValue(if (row.getAs("POSCONDCODE") != null) row.getAs("POSCONDCODE").toString else null).build(),
          Attribute.newBuilder.setKey("POSENTRYMOD").setValue(if (row.getAs("POSENTRYMOD") != null) row.getAs("POSENTRYMOD").toString else null).build(),
          Attribute.newBuilder.setKey("PRENOTE").setValue(if (row.getAs("PRENOTE") != null) row.getAs("PRENOTE").toString else null).build(),
          Attribute.newBuilder.setKey("PREVIOUSCUST").setValue(if (row.getAs("PREVIOUSCUST") != null) row.getAs("PREVIOUSCUST").toString else null).build(),
          Attribute.newBuilder.setKey("PRODIND").setValue(if (row.getAs("PRODIND") != null) row.getAs("PRODIND").toString else null).build(),
          Attribute.newBuilder.setKey("RETURNALLOWED").setValue(if (row.getAs("RETURNALLOWED") != null) row.getAs("RETURNALLOWED").toString else null).build(),
          Attribute.newBuilder.setKey("RTLRSICCODE").setValue(if (row.getAs("RTLRSICCODE") != null) row.getAs("RTLRSICCODE").toString else null).build(),
          Attribute.newBuilder.setKey("SERVICE").setValue(if (row.getAs("SERVICE") != null) row.getAs("SERVICE").toString else null).build(),
          Attribute.newBuilder.setKey("SETTLEMENTCURRCD").setValue(if (row.getAs("SETTLEMENTCURRCD") != null) row.getAs("SETTLEMENTCURRCD").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPADDRESS2").setValue(if (row.getAs("SHIPADDRESS2") != null) row.getAs("SHIPADDRESS2").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPAPT").setValue(if (row.getAs("SHIPAPT") != null) row.getAs("SHIPAPT").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPCITY").setValue(if (row.getAs("SHIPCITY") != null) row.getAs("SHIPCITY").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPCOMMENTS").setValue(if (row.getAs("SHIPCOMMENTS") != null) row.getAs("SHIPCOMMENTS").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPCOUNTRY").setValue(if (row.getAs("SHIPCOUNTRY") != null) row.getAs("SHIPCOUNTRY").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPEMAIL").setValue(if (row.getAs("SHIPEMAIL") != null) row.getAs("SHIPEMAIL").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPFIRSTNAME").setValue(if (row.getAs("SHIPFIRSTNAME") != null) row.getAs("SHIPFIRSTNAME").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPLASTNAME").setValue(if (row.getAs("SHIPLASTNAME") != null) row.getAs("SHIPLASTNAME").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPMIDNAME").setValue(if (row.getAs("SHIPMIDNAME") != null) row.getAs("SHIPMIDNAME").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPSTATE").setValue(if (row.getAs("SHIPSTATE") != null) row.getAs("SHIPSTATE").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPSTREET").setValue(if (row.getAs("SHIPSTREET") != null) row.getAs("SHIPSTREET").toString else null).build(),
          Attribute.newBuilder.setKey("SHIPZIPCD").setValue(if (row.getAs("SHIPZIPCD") != null) row.getAs("SHIPZIPCD").toString else null).build(),
          Attribute.newBuilder.setKey("SUBTOTAL").setValue(if (row.getAs("SUBTOTAL") != null) row.getAs("SUBTOTAL").toString else null).build(),
          Attribute.newBuilder.setKey("TAX").setValue(if (row.getAs("TAX") != null) row.getAs("TAX").toString else null).build(),
          Attribute.newBuilder.setKey("TERMCITY").setValue(if (row.getAs("TERMCITY") != null) row.getAs("TERMCITY").toString else null).build(),
          Attribute.newBuilder.setKey("TERMCNTR").setValue(if (row.getAs("TERMCNTR") != null) row.getAs("TERMCNTR").toString else null).build(),
          Attribute.newBuilder.setKey("TERMID").setValue(if (row.getAs("TERMID") != null) row.getAs("TERMID").toString else null).build(),
          Attribute.newBuilder.setKey("TERMNAMELOC").setValue(if (row.getAs("TERMNAMELOC") != null) row.getAs("TERMNAMELOC").toString else null).build(),
          Attribute.newBuilder.setKey("TERMPSTLCODE").setValue(if (row.getAs("TERMPSTLCODE") != null) row.getAs("TERMPSTLCODE").toString else null).build(),
          Attribute.newBuilder.setKey("TERMST").setValue(if (row.getAs("TERMST") != null) row.getAs("TERMST").toString else null).build(),
          Attribute.newBuilder.setKey("TOTAL").setValue(if (row.getAs("TOTAL") != null) row.getAs("TOTAL").toString else null).build(),
          Attribute.newBuilder.setKey("TRANAMT1").setValue(if (row.getAs("TRANAMT1") != null) row.getAs("TRANAMT1").toString else null).build(),
          Attribute.newBuilder.setKey("TRANAMT5").setValue(if (row.getAs("TRANAMT5") != null) row.getAs("TRANAMT5").toString else null).build(),
          Attribute.newBuilder.setKey("TRANAUTHSRC").setValue(if (row.getAs("TRANAUTHSRC") != null) row.getAs("TRANAUTHSRC").toString else null).build(),
          Attribute.newBuilder.setKey("TRANCATEGORY").setValue(if (row.getAs("TRANCATEGORY") != null) row.getAs("TRANCATEGORY").toString else null).build(),
          Attribute.newBuilder.setKey("TRANCODE").setValue(if (row.getAs("TRANCODE") != null) row.getAs("TRANCODE").toString else null).build(),
          Attribute.newBuilder.setKey("TRANRSNCODE").setValue(if (row.getAs("TRANRSNCODE") != null) row.getAs("TRANRSNCODE").toString else null).build(),
          Attribute.newBuilder.setKey("TRANSACTIONID").setValue(if (row.getAs("TRANSACTIONID") != null) row.getAs("TRANSACTIONID").toString else null).build(),
          Attribute.newBuilder.setKey("TRANTYPE").setValue(if (row.getAs("TRANTYPE") != null) row.getAs("TRANTYPE").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA02").setValue(if (row.getAs("USERDATA02") != null) row.getAs("USERDATA02").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA03").setValue(if (row.getAs("USERDATA03") != null) row.getAs("USERDATA03").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA04").setValue(if (row.getAs("USERDATA04") != null) row.getAs("USERDATA04").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA05").setValue(if (row.getAs("USERDATA05") != null) row.getAs("USERDATA05").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA06").setValue(if (row.getAs("USERDATA06") != null) row.getAs("USERDATA06").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA07").setValue(if (row.getAs("USERDATA07") != null) row.getAs("USERDATA07").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA08").setValue(if (row.getAs("USERDATA08") != null) row.getAs("USERDATA08").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA09").setValue(if (row.getAs("USERDATA09") != null) row.getAs("USERDATA09").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA11").setValue(if (row.getAs("USERDATA11") != null) row.getAs("USERDATA11").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA19").setValue(if (row.getAs("USERDATA19") != null) row.getAs("USERDATA19").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA20").setValue(if (row.getAs("USERDATA20") != null) row.getAs("USERDATA20").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA21").setValue(if (row.getAs("USERDATA21") != null) row.getAs("USERDATA21").toString else null).build(),
          Attribute.newBuilder.setKey("USERDATA25").setValue(if (row.getAs("USERDATA25") != null) row.getAs("USERDATA25").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTBILLSHIP").setValue(if (row.getAs("VIRTBILLSHIP") != null) row.getAs("VIRTBILLSHIP").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTBILLZIPMATCH").setValue(if (row.getAs("VIRTBILLZIPMATCH") != null) row.getAs("VIRTBILLZIPMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTBIN").setValue(if (row.getAs("VIRTBIN") != null) row.getAs("VIRTBIN").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTCARDBIN").setValue(if (row.getAs("VIRTCARDBIN") != null) row.getAs("VIRTCARDBIN").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTCARDCLASS").setValue(if (row.getAs("VIRTCARDCLASS") != null) row.getAs("VIRTCARDCLASS").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTCUSTEMAILDOMAIN").setValue(if (row.getAs("VIRTCUSTEMAILDOMAIN") != null) row.getAs("VIRTCUSTEMAILDOMAIN").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTCUSTEMAILMATCH").setValue(if (row.getAs("VIRTCUSTEMAILMATCH") != null) row.getAs("VIRTCUSTEMAILMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTEXPIRED").setValue(if (row.getAs("VIRTEXPIRED") != null) row.getAs("VIRTEXPIRED").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTFUZBILLSCORE").setValue(if (row.getAs("VIRTFUZBILLSCORE") != null) row.getAs("VIRTFUZBILLSCORE").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTFUZRSP").setValue(if (row.getAs("VIRTFUZRSP") != null) row.getAs("VIRTFUZRSP").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTFUZSHIPSCORE").setValue(if (row.getAs("VIRTFUZSHIPSCORE") != null) row.getAs("VIRTFUZSHIPSCORE").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTIOVRSP").setValue(if (row.getAs("VIRTIOVRSP") != null) row.getAs("VIRTIOVRSP").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTMOD10FAIL").setValue(if (row.getAs("VIRTMOD10FAIL") != null) row.getAs("VIRTMOD10FAIL").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTRECIPEMAILMATCH").setValue(if (row.getAs("VIRTRECIPEMAILMATCH") != null) row.getAs("VIRTRECIPEMAILMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTRECIPZIPMATCH").setValue(if (row.getAs("VIRTRECIPZIPMATCH") != null) row.getAs("VIRTRECIPZIPMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTSHIPEMAILMATCH").setValue(if (row.getAs("VIRTSHIPEMAILMATCH") != null) row.getAs("VIRTSHIPEMAILMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTSHIPZIPMATCH").setValue(if (row.getAs("VIRTSHIPZIPMATCH") != null) row.getAs("VIRTSHIPZIPMATCH").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTUTF8").setValue(if (row.getAs("VIRTUTF8") != null) row.getAs("VIRTUTF8").toString else null).build(),
          Attribute.newBuilder.setKey("WEBSITE").setValue(if (row.getAs("WEBSITE") != null) row.getAs("WEBSITE").toString else null).build(),
          Attribute.newBuilder.setKey("VIRTSAERSP").setValue(if (row.getAs("VIRTSAERSP") != null) row.getAs("VIRTSAERSP").toString else null).build(),
          Attribute.newBuilder.setKey("CARDNO").setValue(if (row.getAs("CARDNO") != null) row.getAs("CARDNO").toString else null).build()))
        .build()

      val record = new ProducerRecord(ConfigFactory.load().getString("local.common.kafka.rollbackKafkaTopicName"), transaction.getOID.toString, transaction)
      producer.send(record, new Callback() {
        override def onCompletion(recordMetadata: RecordMetadata, e: Exception): Unit = {
          if (e != null) {
            logger.error(e.getMessage())
          }
          if (recordMetadata == null) {

            Seq(transaction.getOID.toString)
              .toDF("oid")
              .withColumn("whenloaded", current_timestamp())
              .withColumn("status", lit("F")).toDF()
              .write.format(HIVE_WAREHOUSE_CONNECTOR)
              .mode(APPEND_MODE)
              .option("table", REDI_ROLLBACK_TXN_PRODUCER_LOG)
              .save()
          } else {
            Seq(transaction.getOID.toString)
              .toDF("oid")
              .withColumn("whenloaded", current_timestamp())
              .withColumn("status", lit("S")).toDF()
              .write.format(HIVE_WAREHOUSE_CONNECTOR)
              .mode(APPEND_MODE)
              .option("table", REDI_ROLLBACK_TXN_PRODUCER_LOG)
              .save()
          }
        }
      })
    })
    producer.flush()
    producer.close()
  }

  def getProperties(): Properties = {

    val properties = new Properties()
    properties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
    properties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.keySerializerClassConfig"))
    properties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, ConfigFactory.load().getString("local.common.kafka.valueSerializerClassConfig"))
    properties.put("schema.registry.url", ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"))
    properties.put("security.protocol", ConfigFactory.load().getString("local.common.kafka.securityProtocol"))
    properties.put("max.block.ms", ConfigFactory.load().getString("local.common.kafka.maxBlockMs"))

    properties.put("acks", "all")
    properties.put("retries", "0")
    properties.put("batch.size", "16635")
    properties.put("linger.ms", "0")
    properties.put("buffer.memory", "33554432")

    properties.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
    properties.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
    properties.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
    properties.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))

    properties.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
    properties.put(SaslConfigs.SASL_KERBEROS_SERVICE_NAME, ConfigFactory.load().getString("local.common.kafka.saslKerberosServiceName"))
    properties.put(SaslConfigs.SASL_MECHANISM, ConfigFactory.load().getString("local.common.kafka.saslMechanism"))

    properties

  }
}