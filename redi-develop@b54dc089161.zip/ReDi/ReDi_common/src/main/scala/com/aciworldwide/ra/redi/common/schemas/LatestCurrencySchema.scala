package com.aciworldwide.ra.redi.common.schemas

case class LatestCurrencySchema(currencydate: String, currencyCode: String,
                                rate: String, RSLastUpdatedtime: String) {

}
