package com.aciworldwide.ra.redi.common.actions

import com.aciworldwide.ra.redi.common.services.{EstablishConnections}
import org.apache.logging.log4j.LogManager
import com.aciworldwide.ra.redi.common.controllers.CurrencyRatesHistoricalDataController

object CurrencyRatesHistoricalDataProcess extends CurrencyRatesHistoricalDataController with EstablishConnections with Serializable{

  @transient lazy val currencyRatesDatalogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    currencyRatesDatalogger.info(CURRENCY_RATES_HIST_DATA_PROCESS_INFO +" : Start of Currency Historical data  load process")
    try{
      CurrencyRatesHistoricalDataPipeLine()
    } catch{
      case exce: Exception => currencyRatesDatalogger.error(CURRENCY_RATES_HIST_DATA_PROCESS_ERROR + " : We have an error in the Currency Historical data  processing " +  exce)
        System.exit(1)
    } finally {
      currencyRatesDatalogger.info(CURRENCY_RATES_HIST_DATA_PROCESS_INFO +" : End of Currency Historical data  load process")
    }
  }
}
