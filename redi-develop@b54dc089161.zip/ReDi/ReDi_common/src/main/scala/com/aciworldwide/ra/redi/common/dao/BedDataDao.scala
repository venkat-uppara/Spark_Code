package com.aciworldwide.ra.redi.common.dao

import java.sql.ResultSet

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.{DataFrame, SparkSession}




class BedDataDao(sc: SparkSession) extends DateUtils with Loggers with DatabaseServices with ReDiConstants with Serializable {


  /**
    * setupConnections is used to instantiate the SetupConnections
    * This will be used across the methods for creating connections with the databases, so declaring this globally */

  @transient lazy val BEDDataTransformationLogger = LogManager.getLogger(getClass.getName)
  val hivesession= HiveWarehouseSession.session(sc).build()

  val setupConnections = new SetupConnections

  def fetchBedData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int):DataFrame={
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Starting to fetch new/updated data for BED  process from Oracle. " + schemaname + "." + tablename)
    val bedDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Fetched new/updated data for BED   Data. " + schemaname + "." + tablename)
    bedDF
  }

  def getDataFromHive(tableName:String):DataFrame={
    hivesession.executeQuery("select * from tablename")
  }

  def StoredataintoHive(tablename: String, format:String, inputdataset: DataFrame ): Unit ={
    inputdataset
      .write
      .format(HIVE_WAREHOUSE_CONNECTOR)
      .option("database",REDI_DATABASE)
      .mode(APPEND_MODE)
      .option("table",tablename)
      .save()
  }

}
