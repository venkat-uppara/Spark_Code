package com.aciworldwide.ra.redi.common.services

import java.sql.{Connection, DriverManager}
import java.util.Properties

import com.aciworldwide.ra.redi.common.security.EncryptSensitiveData
import org.apache.spark.sql.SparkSession



trait EstablishConnections extends Serializable with Loggers{


  //System.setProperty("java.security.krb5.conf",ConfigFactory.load().getString("local.common.kerberos.conffile"))
/*  System.setProperty("sun.security.krb5.debug","true")
  System.setProperty("com.ibm.security.krb5.Krb5Debug","all");
  System.setProperty("com.ibm.security.jgss.debug","all");*/

  /*
  This method will help us establish speak session when starting a spark job
   */

  def sparkSessionBuilder(masterinput: String, applicationname: String): SparkSession ={

    logRegularMessage("Starting Spark session building.")
   // UserGroupInformation.loginUserFromKeytab(ConfigFactory.load().getString("local.common.kerberos.userkeyTab"),ConfigFactory.load().getString("local.common.kerberos.servicekeytab"))

    lazy val sc: SparkSession = {
      SparkSession
        .builder()
       // .master(masterinput)
        .appName(applicationname)
        .config("spark.sql.warehouse.dir", "/apps/hive/warehouse")
        .config("spark.testing.memory","471859200")
        .config("hive.exec.dynamic.partition", "true")
        .config("hive.exec.dynamic.partition.mode", "nonstrict")
        .config("hive.exec.max.dynamic.partitions","400")
        .config("hive.exec.max.dynamic.partitions.pernode","400")
        .config("hive.enforce.bucketing","true")
        .config("optimize.sort.dynamic.partitioning","true")
        .config("hive.vectorized.execution.enabled","true")
        .config("hive.enforce.sorting","true")
        .config("spark.sql.orc.impl","native")
        .config("spark.sql.orc.enabled", "true")
        .config("spark.sql.orc.filterPushdown", "true")
        .config("spark.sql.orc.char.enabled", "true")
        .config("spark.sql.cbo.enabled","true")
        .config("spark.sql.cbo.JoinReorder.enabled","true")
        .config("spark.sql.hive.metastorePartitionPruning","true")
        .config("spark.streaming.stopGracefullyOnShutdown", "true")
        .enableHiveSupport()
        .getOrCreate()
    }

    logRegularMessage("Obtained the sparksession.")
    sc
  }

  /*
    This method will establish required jdbc connections to the source databases
   */
  val encryptSensitiveData = new EncryptSensitiveData

  def databaseConnection(username: String, password: String, driverclass: String, key: String) : Properties = {
    logRegularMessage("Started preparing the database connection properties for jdbc to " + driverclass)
    val connectionproperties = new Properties()

    connectionproperties.setProperty("user",username)
    connectionproperties.setProperty("password",encryptSensitiveData.decrypt(key, password))
    connectionproperties.setProperty("Driver",driverclass)
    logRegularMessage("Finished preparing the database connection properties for jdbc to " + driverclass)
    connectionproperties
  }

  def decryptPassword(encryptPassword: String, key: String): String = {
    val decryptedpassword = encryptSensitiveData.decrypt(key, encryptPassword)

    decryptedpassword
  }

  def createScalaJdbcConnection(driver: String, username: String, password: String, url: String): Connection  ={
    var connection: Connection = null
    Class.forName(driver)
    connection = DriverManager.getConnection(url,username,password)
    connection
  }



}
