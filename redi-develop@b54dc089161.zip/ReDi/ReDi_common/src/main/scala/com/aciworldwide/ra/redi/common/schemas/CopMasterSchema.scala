package com.aciworldwide.ra.redi.common.schemas
import java.sql.Timestamp

case class CopMasterSchema(EBIT_CLIENT_ID:String, EBIT_SUB_CLIENT_ID:String, CLIENT_NAME:String, SUBCLIENT_NAME:String, RED_AFFILIATE:String, ACTIVE_STATUS:String, sector:String,
FlagSAE:String,FlagTRE:String,FlagDVE:String,FlagTSW:String,LAST_UPDATED:Timestamp, LAST_UPDATEDBY:String)
