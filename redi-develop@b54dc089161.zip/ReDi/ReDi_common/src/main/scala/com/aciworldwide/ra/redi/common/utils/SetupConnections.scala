package com.aciworldwide.ra.redi.common.utils

import java.sql.Connection

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.EstablishConnections
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.Map

class SetupConnections extends EstablishConnections with ReDiConstants{

  val key = ConfigFactory.load().getString("local.common.SecurityKey.value")
  def setupConnectionDetails(sourcedatabase: String, connectionType: String): Map[String,String] ={

    var map = Map[String, String]()

    if(sourcedatabase == CBDATA_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.cbusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.cbpassword")
    }else if(sourcedatabase == CSI_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.csiusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.csipassword")
    }else if(sourcedatabase == SDB_QUEUE_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.sdbqueueusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.sdbqueuepassword")
    }else if(sourcedatabase == SDBREP_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.sdbrepusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.sdbreppassword")
    }else if(sourcedatabase == RISKMGT_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.riskmgmtusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.riskmgmtpassword")
    }else if(sourcedatabase == REDI_CONTROL_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.postgres.postgresusername")
      map("password") = ConfigFactory.load().getString("local.common.postgres.postgrespassword")
    }
    else if(sourcedatabase == CLIENT_DATA_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.sdbusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.sdbpassword")
    }else if (sourcedatabase == BEDATA_DATABASE){
      map("username") = ConfigFactory.load().getString("local.common.ods.bedusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.bedpassword")
    }
    else if(sourcedatabase == MODSREP_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.modsrepusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.modsrepspassword")
    }
    else if(sourcedatabase == RULEMGR_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.rulemgrusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.rulemgrpassword")
    }
    else if(sourcedatabase == APSFUSERDATA_DATABASE){
      map ("username")= ConfigFactory.load().getString("local.common.ods.apsfusername")
      map("password") = ConfigFactory.load().getString("local.common.ods.apsfpassword")
    }

    if(connectionType == ORACLE_CONN_TYPE) {
      map ("driverclass") = ConfigFactory.load().getString("local.common.ods.driver")
      map("jdbcurl") = ConfigFactory.load().getString("local.common.ods.url")
      map("jdbcurlapsf") = ConfigFactory.load().getString("local.common.ods.urlapsf")
    }else if(connectionType == POSTGRES_CONN_TYPE){
      map("driverclass") = ConfigFactory.load().getString("local.common.postgres.driver")
      map("jdbcurl") = ConfigFactory.load().getString("local.common.postgres.url")
    }else if(connectionType == ClUSTER_CONN_TYPE) {
      map("username") = ConfigFactory.load().getString("local.common.cluster.userid")
      map("password") = ConfigFactory.load().getString("local.common.cluster.clusterpassword")
    }

    map
  }

  def readDataIntoDataframe(sc: SparkSession, table: String, connectionType: String, sourcedatabase: String,numPartitions: Int): DataFrame = {

    val map = setupConnectionDetails(sourcedatabase,connectionType)

    val username = map("username")
    val password = map("password")
    val driverclass = map("driverclass")
    var jdbcurl = map("jdbcurl")

    if(username==APSFUSERDATA_DATABASE)
    {
      jdbcurl=map("jdbcurlapsf")
    }

    val df = sc.read.format("jdbc")
      .option("url", jdbcurl)
      .option("dbtable", table)
      .option("user", username)
      .option("password",decryptPassword(password,key))
      .option("driver",driverclass)
      .option("numPartitions", numPartitions)
      .load()
    df
  }

  def createScalaConnection(sourcedatabase: String, connectionType: String): Connection ={

    val map = setupConnectionDetails(sourcedatabase,connectionType)

    val username = map("username")
    val password = map("password")
    val driverclass = map("driverclass")
    val jdbcurl = map("jdbcurl")
    createScalaJdbcConnection(driverclass,username,decryptPassword(password,key),jdbcurl)
  }


}
