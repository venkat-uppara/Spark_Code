package com.aciworldwide.ra.redi.common.actions

import com.aciworldwide.ra.redi.common.dao.ReDiSchedulerDao
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import org.apache.logging.log4j.LogManager

object ReDiJobScheduler extends ReDiSchedulerDao with EstablishConnections with Serializable with Loggers{

  def main(args: Array[String]): Unit = {

    @transient lazy val ReDiJobSchedulerlogger = LogManager.getLogger(getClass.getName)
    ReDiJobSchedulerlogger.info(ReDiJobScheduler_INFO +"Start of ReDi job Scheduling process" )

    try{
      SchedulerDataPipeline()
    } catch{
      case exce: Exception => ReDiJobSchedulerlogger.info(ReDiJobScheduler_INFO +"We have an error in the ReDi job Scheduling process " +  exce)

        System.exit(1)
    } finally {

      ReDiJobSchedulerlogger.info(ReDiJobScheduler_INFO +"End of ReDi job Scheduling process " )

    }


  }

}
