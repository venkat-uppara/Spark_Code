package com.aciworldwide.ra.redi.common.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils, SetupConnections}
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import com.hortonworks.spark.sql.hive.llap.HiveWarehouseSessionImpl
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

class APSFUserDataController extends Loggers with ReDiConstants with Serializable with CommonUtils {
  @transient lazy val APSFUserDataProcessLogger = LogManager.getLogger(getClass.getName)

  /** Creating the base controller object from the BaseController Class */
  val baseController = new BaseController()
  /** Building Spark Session using the createSparkSession in Base Controller.
    * Using the value in APSFUSERDATAPROCESSAPP for APP Name. */
  val spark: SparkSession = baseController.createSparkSession(APSFUSERDATAPROCESSAPP)
  /** Building the Hive Warehouse Session with the Spark Session */
  val hiveSession: HiveWarehouseSessionImpl = HiveWarehouseSession.session(spark).build()
  /** Setting the Database Schema for Hive */
  hiveSession.setDatabase(REDI_DATABASE)

  val dateutils = new DateUtils

  /** Importing spark implicits */

  import spark.implicits._

  val setupConnections = new SetupConnections

  def fetchUserData(tableName: String, connectionType: String, schemaName: String): DataFrame = {
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + ":Starting to Fetch APSF User Data into processing layer " + schemaName + "." + tableName)
    val apsfDf = fetchDataFromOds(tableName, connectionType, schemaName, 10)
    APSFUserDataProcessLogger.debug(CLIENTMASTERDATAPROCESS_DEBUG + ":Fetched Client Master data  from  " + schemaName + "." + tableName)
    apsfDf
  }

  def fetchDataFromOds(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + "Starting to fetch new/updated data for APSF process from Oracle. " + schemaname + "." + tablename)
    val apsfData = setupConnections.readDataIntoDataframe(spark, tablename, connectiontype, schemaname, numpartitions)
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + "Fetched new/updated data for APSF  Data. " + schemaname + "." + tablename)
    apsfData
  }

  def storeDataToHive(finalCoreDF: DataFrame, hiveTable: String): Unit = {
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + "Starting to push the data into Hive table " + USER_PROFILE_TABLE)
    finalCoreDF.write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_DATABASE).mode(SaveMode.Append).option("table", hiveTable).save()
  }


  def ApsfDatafromOracleToHive(): Unit = {
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + ": Inside  ApsfDatafromOracleToHive Method ")

    val maxHighWaterMarkForAPSFUSERDATA_ENT_USER_HWM = hiveSession.executeQuery("SELECT MAX(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + APSFUSERDATA_ENT_USER_HWM + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    val maxHighWaterMarkForAPSFUSERDATA_RMS_ORGANIZATION_HWM = hiveSession.executeQuery("SELECT MAX(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + APSFUSERDATA_RMS_ORGANIZATION_HWM + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + ": The Maximum of the HighWaterMark for the APSF User Data Process is " + maxHighWaterMarkForAPSFUSERDATA_ENT_USER_HWM)

    if (maxHighWaterMarkForAPSFUSERDATA_ENT_USER_HWM == null && maxHighWaterMarkForAPSFUSERDATA_RMS_ORGANIZATION_HWM == null) {
      APSFUserDataProcessLogger.debug(APSFUSERDATAPROCESS_DEBUG + ": The Oracle format of HighWaterMark in APSFData process has null value. Please investigate")
    } else {

      val ent_user = "(SELECT T1.RID,T1.ORGANIZATIONAL_UNIT_ID as ORGUNITID ,T1.LOGIN AS USERID, (T1.FAMILY_NM || ' ' || T1.MIDDLE_NM || ' ' || T1.FIRST_NM) AS USERNAME, T1.UPDATED_DT as ENT_USER_UPDATED_DT," +
        "T3.ORGANIZATION_ACRONYM " +
        " FROM " + ENT_USER + " T1 JOIN " + RMS_ORGANIZATION + " T2 " +
        "ON T1.ORGANIZATIONAL_UNIT_ID = T2.RID JOIN ENT_ORG_UNIT  T3 ON T2.ORGANIZATION_RID = T3.RID  WHERE T2.UNIQUE_CLIENT_ID LIKE '%REDSHIELD@%' " +
        "AND coalesce(T1.CREATED_DT,T1.UPDATED_DT) >= to_timestamp('" + maxHighWaterMarkForAPSFUSERDATA_ENT_USER_HWM + "', 'YYYY-MM-DD HH24:MI:SS.FF'))  ENT_USER"

      APSFUserDataProcessLogger.info(APSFUSERDATAPROCESS_INFO + ": Query for APSF :" + ent_user)
      var entUserDf = fetchUserData(ent_user, ORACLE_CONN_TYPE, APSFUSERDATA_DATABASE)

      entUserDf = entUserDf.withColumn("fetch_row_limit", lit(0))
        .withColumn("rsupdateddate", col("ENT_USER_UPDATED_DT"))
        .withColumn("isactive", lit("Y"))
        .withColumn("USERID", upper(concat(col("ORGANIZATION_ACRONYM"), lit("-"), col("USERID"))))
        .withColumn("REDIUSERID", col("USERID"))


      val rms_organization = "(select T2.UPDATED_DT as RMS_ORGANIZATION_UPDATED_DT,T2.RID,SUBSTR(T2.UNIQUE_CLIENT_ID,11,6) AS CLIENTID, SUBSTR(T2.UNIQUE_CLIENT_ID,17,6) AS SUBCLIENTID from  " + RMS_ORGANIZATION + " T2 " + " WHERE T2.UNIQUE_CLIENT_ID LIKE '%REDSHIELD@%' and T2.UPDATED_DT  > to_timestamp('" + maxHighWaterMarkForAPSFUSERDATA_RMS_ORGANIZATION_HWM + "', 'YYYY-MM-DD HH24:MI:SS.FF')) RMS_ORGANIZATION"
      var rmsUserDf = fetchUserData(rms_organization, ORACLE_CONN_TYPE, APSFUSERDATA_DATABASE)


      hiveSession.executeUpdate("delete from " + USER_PROFILE_TABLE_ON_WRITE + "")

      val res1 = entUserDf.join(rmsUserDf, entUserDf.col("ORGUNITID") === rmsUserDf.col("RID"), "left_outer")
        .drop(rmsUserDf("RID"))
        .withColumn("clientid", when($"clientid".isNotNull, col("clientid")).otherwise("REDSHIELD"))
        .withColumn("subclientid", when($"subclientid".isNotNull, col("subclientid")).when($"clientid" === "REDSHIELD", lit(null)).otherwise("000001"))
        .withColumn("client12", when($"subclientid".isNotNull, concat(col("clientid"), col("subclientid"))).otherwise(col("clientid")))

      controlTableDataProcess(res1, "ENT_USER_UPDATED_DT", APSFUSERDATA_ENT_USER_HWM, PROCESS_CONTROL_STARTED, getCurrentdateTimeStamp.toString, "", " Records getting fetched from APSF", APSFUSERDATAPROCESS)
      controlTableDataProcess(rmsUserDf, "RMS_ORGANIZATION_UPDATED_DT", APSFUSERDATA_RMS_ORGANIZATION_HWM, PROCESS_CONTROL_STARTED, getCurrentdateTimeStamp.toString, "", "Records getting fetched from APSF ", APSFUSERDATAPROCESS)


      storeDataToHive(reorderSourceTableSchema(APSF_COL_REORDER, addAuditColumns(res1)), USER_PROFILE_TABLE_ON_WRITE)


      val res = hiveSession.executeUpdate("MERGE INTO " + USER_PROFILE_TABLE + " AS D USING " +
        " (SELECT * FROM " + USER_PROFILE_TABLE_ON_WRITE + ") AS S ON (D.RID=S.RID) WHEN MATCHED THEN " +
        "UPDATE SET USERID=S.USERID,USERNAME=S.USERNAME,CLIENTID=S.CLIENTID,SUBCLIENTID=S.SUBCLIENTID,CLIENT12=S.CLIENT12," +
        "ISACTIVE=S.ISACTIVE,FETCH_ROW_LIMIT=S.FETCH_ROW_LIMIT,RSUPDATEDDATE=S.RSUPDATEDDATE,ORGUNITID=S.ORGUNITID,ORGANIZATION_ACRONYM=S.ORGANIZATION_ACRONYM,REDIUSERID=S.REDIUSERID," +
        "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED" +
        " WHEN NOT MATCHED THEN INSERT VALUES(S.RID,S.USERID,S.USERNAME,S.CLIENTID,S.SUBCLIENTID,S.CLIENT12,S.ISACTIVE,S.FETCH_ROW_LIMIT,S.RSUPDATEDDATE,S.ORGUNITID,S.ORGANIZATION_ACRONYM,S.REDIUSERID," +
        "S.WHENLOADED,S.WHOLOADED,S.WHENUPDATED,S.WHOUPDATED)")

      if (res == false) {
        throw new Exception("Mering into USER_PROFILE table error")
      }

      saveDataintoHDFS(entUserDf, "ORC", ConfigFactory.load().getString("local.common.hdfs.APSF_DATA_FILES_HDFS"), HDFS_STORAGE_DATE_EXT)
      controlTableDataProcess(res1, "ENT_USER_UPDATED_DT", APSFUSERDATA_ENT_USER_HWM, PROCESS_CONTROL_COMPLETED, "", getCurrentdateTimeStamp.toString, "Completed APSF fetching and stored the data in hive", APSFUSERDATAPROCESS)
      controlTableDataProcess(rmsUserDf, "RMS_ORGANIZATION_UPDATED_DT", APSFUSERDATA_RMS_ORGANIZATION_HWM, PROCESS_CONTROL_COMPLETED, "", getCurrentdateTimeStamp.toString, "Completed APSF fetching and stored the data in hive", APSFUSERDATAPROCESS)
    }
    APSFUserDataProcessLogger.info(APSFUSERDATAPROCESS_INFO + ":Completed ApsfDatafromOracleToHive")
  }

  def apsfDataPipeLine(): Unit = {
    APSFUserDataProcessLogger.info(APSFUSERDATAPROCESS_INFO + ": Start of APSF User Data Pipeline Processing")
    ApsfDatafromOracleToHive()
    APSFUserDataProcessLogger.info(APSFUSERDATAPROCESS_INFO + ": Completed of APSF User Data Pipeline Processing")
  }
}









