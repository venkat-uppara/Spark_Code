package com.aciworldwide.ra.redi.common.dao


import java.sql.ResultSet
import org.apache.logging.log4j.LogManager

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.CBReasonCodeSchema
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

import scala.collection.mutable.MutableList
import com.hortonworks.hwc.HiveWarehouseSession._


class CBReasonCodesDao(sc:SparkSession) extends DateUtils with DatabaseServices
  with ReDiConstants with Serializable with EstablishConnections with Loggers{

  @transient lazy val CBReasonCodeProcesslogger = LogManager.getLogger(getClass.getName)

  val hivesession= HiveWarehouseSession.session(sc).build()
  import sc.implicits._

  /*
  This is the method to fetch the CBReason Codes from database
   */
  val setupConnections = new SetupConnections

  def fetchCBReasonCodes(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int) : DataFrame ={

    CBReasonCodeProcesslogger.debug(CBREASONCODEPROCESS_DEBUG +":Starting to Fetch CB Reason Codes " + schemaname+"." + tablename)

    val cbrsncodefromodsdf = setupConnections.readDataIntoDataframe(sc,tablename, connectiontype, schemaname, numpartitions)

    val cbreasoncodesdf=cbrsncodefromodsdf.select($"CB_PROCESSOR".as("cbprocessor"),
      $"RSN_CD".as("reasoncode"),
      $"CARD_TYPE".as("cardtype"),
      $"FRAUD_FLAG".as("fraudflag"),
      $"DESCRIPTION".as("description"),
      $"SDS_FLAG".as("sdsflag"))

    CBReasonCodeProcesslogger.debug(CBREASONCODEPROCESS_DEBUG +":CB Reason Codes are fetched " + schemaname+"." + tablename)

    cbreasoncodesdf

  }


  def getCBReasonCodesTable():DataFrame= {

    //gettheDataFromHive(sc,REDI_CB_REASONCODES)
    hivesession.executeQuery("select * from"+ REDI_DATABASE+"."+ REDI_CB_REASON_CODE_TABLE)
  }

  /*
    Read the Hive Transactional tables via HIVE JDBC
   */

  def getCBResonCodesData(resultSet: ResultSet): MutableList[CBReasonCodeSchema] ={
    val fetchedResponse = MutableList[CBReasonCodeSchema]()
    while(resultSet.next()){
      var rec = CBReasonCodeSchema(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6))
      fetchedResponse += rec
    }
    fetchedResponse
  }

}
