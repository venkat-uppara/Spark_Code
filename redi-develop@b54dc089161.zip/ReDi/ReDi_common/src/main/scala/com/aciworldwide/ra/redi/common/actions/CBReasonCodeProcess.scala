/**
  * @author: Hariprasad Allaka
  * @usecase: Chareback reason codes loading into ReDi from RS
  * @version : 1.0 intial Draft
  */
package com.aciworldwide.ra.redi.common.actions

import com.aciworldwide.ra.redi.common.controllers.CBReasonCodesController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import org.apache.logging.log4j.LogManager


object CBReasonCodeProcess extends CBReasonCodesController with EstablishConnections with Serializable with Loggers{

  def main(args: Array[String]): Unit = {

    @transient lazy val CBReasonCodeProcesslogger = LogManager.getLogger(getClass.getName)
    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Start of CBReasonCode load process")

    try{
      CBReasonCodesDataPipeline()
    } catch{

      case exce: Exception => CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"We have an error in the CBProcess reason code processing " +  exce)
        System.exit(1)
    } finally {

      CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"End of CBReasonCode load process")

    }




  }


}
