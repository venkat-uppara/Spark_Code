package com.aciworldwide.ra.redi.common.utils

import com.jcraft.jsch._
import java.io._

import com.aciworldwide.ra.redi.common.constants.ReDiConstants

import scala.util.control.Breaks._
import com.aciworldwide.ra.redi.common.services.Loggers
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager


class ShellscriptCall extends Serializable with Loggers with ReDiConstants {

  @transient lazy val ReDiJobSchedulerlogger = LogManager.getLogger(getClass.getName)

  def Triggeringjobs(valuees:String): Unit = {
    val setupConnections = new SetupConnections
    val map =  setupConnections.setupConnectionDetails("","cluster")
    val username = map("username")

    ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"ReDiScheduler calling Spark jobs from Shellscripts  " )


    val jsch = new JSch
    val host = ""
    var command =""
    if (host != null) {
      // var host = VMHOST; // enter username and ipaddress for machine you need to connect
      var host = username
      val user: String = host.substring(0, host.indexOf('@'))
      host = host.substring(host.indexOf('@') + 1)
      val session:Session = jsch.getSession(user, host,VMPORT)
      // username and password will be given via UserInfo interface.
      val ui:UserInfo = new MyUserInfo
      session.setUserInfo(ui)
      session.connect()

      if(valuees.equalsIgnoreCase(CLIENTMASTERMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.clientmasterjob")

      }
      else if (valuees.equalsIgnoreCase(CBREASONCODEMSG)) {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.cbreasoncodejob")
      }
      else if(valuees.equalsIgnoreCase(CURRENCYRATEMSG))
      {
        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.currencyratejob")
      }
      else if(valuees.equalsIgnoreCase(CSIEVENTMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.csieventjob")
      }
      else if(valuees.equalsIgnoreCase(AUTOMATEDCBMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )


        command = ConfigFactory.load().getString("local.common.Redi_Job.automatedcbjob")
      }
      else if (valuees.equalsIgnoreCase(BEDMASTERMSG)) {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.bedmasterjob")
      }
      else if(valuees.equalsIgnoreCase(BEDCBMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.bedcbjob")
      }
      else if(valuees.equalsIgnoreCase(VELLIMHISTMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )

        command = ConfigFactory.load().getString("local.common.Redi_Job.vellimhistjob")
      }
      else if(valuees.equalsIgnoreCase(RULEDETAILMSG))
      {

        ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Job Getting Triggered is:" + valuees )


        command = ConfigFactory.load().getString("local.common.Redi_Job.ruledetailsjob")
      }


      else {
        logRegularMessage("no input has been received")
      }

      val channel: Channel = session.openChannel("exec")
      (channel.asInstanceOf[ChannelExec]).setCommand(command)
      channel.setInputStream(null)

      channel.asInstanceOf[ChannelExec].setErrStream(System.err)

      val in = channel.getInputStream

      channel.connect()
      val tmp = new Array[Byte](ARRAYBYTE)
      while (false) {
        if (in.available() > 0) {
          val i = in.read(tmp, 0, ARRAYBYTE)
          if (i < 0) {
            break

            ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"Out of shellscript recurring loop")
          }
          if (channel.isClosed) {
            ReDiJobSchedulerlogger.debug(ReDiJobScheduler_DEBUG +"exit-status:" + channel.getExitStatus)

            break
          }
        }
      }
      channel.disconnect()
      session.disconnect()
      return
    }
  }
}