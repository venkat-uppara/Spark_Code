package com.aciworldwide.ra.redi.common.utils

import java.text.SimpleDateFormat
import java.util.{Calendar, Date}

import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}

class DateUtils extends Serializable with Loggers {

  /*
  format a current Date into desired format
   */

  def formatCurrentDateString(outputfomat: String): String = {

      val now = Calendar.getInstance().getTime()
      val simpleDateFormat = new SimpleDateFormat(outputfomat)
      val currentdateString = simpleDateFormat.format(now)
      currentdateString
  }


  def formatDateString(inputDate:  Long, outputfomat: String): String = {

    val now = Calendar.getInstance().getTime()
    val simpleDateFormat = new SimpleDateFormat(outputfomat)
    val dateString = simpleDateFormat.format(inputDate)
    dateString
  }

  def convertToOracleDateFormat(oracleDate: String): String = {
    val dateInputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:Ss")
    val dateOutputFormat = new SimpleDateFormat("dd-MMM-yy ")

    var HWM_ClientMaster  = ""
    if(oracleDate != null){
      HWM_ClientMaster = dateOutputFormat.format(dateInputFormat.parse(oracleDate))
    }else{
      logRegularMessage("There is a error on Oracle DateFormat Converted   " +HWM_ClientMaster)
    }
    HWM_ClientMaster
  }

  def convertToPostGresDateFormat(oracleDate: String): String = {
    val date: Date  = new SimpleDateFormat("yyyy-MM-dd HH:mm:Ss").parse(oracleDate.substring(1,20))
    logRegularMessage("Input  Date in Format YY-MM-DD = " + date)
    new SimpleDateFormat("MM-dd-yyyy HH:mm:Ss").format(date)
   }

  def convertWhenloadedToPostGresDateFormat(whenloaded: String): String = {
    val date: Date  = new SimpleDateFormat("yyyy-MM-dd HH:mm:Ss").parse(whenloaded.substring(0,20))
    new SimpleDateFormat("YYYY-MM-dd HH:mm:Ss").format(date)
  }

  def convertPostGresToWhenloadedFormat(whenloaded: String): String = {
    val date: Date  = new SimpleDateFormat("yyyy-MM-dd HH:mm:Ss").parse(whenloaded.substring(1,20))
    new SimpleDateFormat("YYYY-MM-dd HH:mm:Ss").format(date)
  }

  def convertDateFormat(inputdate: String, inputDateFormat: String, targetDateFormat: String): String = {
    val simpleformat = new SimpleDateFormat(inputDateFormat)
    val targetformat = new SimpleDateFormat(targetDateFormat)
    String.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }
}
