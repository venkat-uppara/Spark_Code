/**
  * @version : 1.0 Initial Draft
  * @usecase - MERF-8357
  * @note : This class contains all the details that are needs to fetch the currency details from Rest API to ReDi
  */
package com.aciworldwide.ra.redi.common.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, SetupConnections}
import org.apache.spark.sql.functions.{lit, max}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.typesafe.config.ConfigFactory

class CurrencyDataDao(sc:SparkSession) extends Serializable
  with ReDiConstants with CommonUtils with DatabaseServices with EstablishConnections with ReDiTableSchemas{

  /**
    * Get the data from hive
    * This is temporary method which will be used till REST API is up and running to get the data
   */

  val setupConnections = new SetupConnections

    def getDatafromcurrenyService() ={
      getCurrencyData(sc,ConfigFactory.load().getString("local.common.currency.curr_microservice_api"),CURRENCY_API_CONN_TIMEOUT,CURRENCY_API_READ_TIMEOUT,CURRENCY_API_REQ_METHOD)
    }
}


