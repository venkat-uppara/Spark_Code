package com.aciworldwide.ra.redi.common.controllers
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.dao.CBReasonCodesDao
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, FileUtils}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{current_timestamp, lit}
import com.hortonworks.hwc.HiveWarehouseSession._
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager

class CBReasonCodesController extends BaseController with Serializable with ReDiConstants with CommonUtils
  with ReDiTableSchemas with Loggers{
  @transient lazy val CBReasonCodeProcesslogger = LogManager.getLogger(getClass.getName)

  val baseController = new BaseController()

  val sparkSession =baseController.createSparkSession(CLIENTMASTERDATAPROCESSAPP)


  val ReasonCodesDao = new CBReasonCodesDao(createSparkSession(CBREASONCODEPROCESSAPP))
  val hivesession= HiveWarehouseSession.session(sparkSession).build()
  hivesession.setDatabase(REDI_DATABASE)

  /*
  Fetch the CB Reason codes from the oracle database CBData
   */

  def createCBReasonCodesDataSet(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {

    CBReasonCodeProcesslogger.debug(CBREASONCODEPROCESS_DEBUG +":Starting to Fetch CB Reason Code set into processing layer" + schemaname+"." + tablename)

    ReasonCodesDao.fetchCBReasonCodes(tablename, connectiontype, schemaname,numpartitions)

  }

  /*
  Transformation will be applied on the reason codes
   */
  def processCBReasonCodes(cbreasoncodesdf: DataFrame): DataFrame = {

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Starting to add new columns to result data frame." )

    reorderSourceTableSchema(CB_REASON_CODE_COL_ORDER,
      addAuditColumns(cbreasoncodesdf).withColumn(STATUS_COL,lit(STATUS_ACTIVE_INDICATOR))
        .withColumn(RS_UPDATED,current_timestamp()))

  }

  /*
  Store the CBReasonCodes to Hive
   */
  def StoreCBReasonCodestoHive (inputdataset: DataFrame): Unit ={


    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Starting to push the data into Hive tables " + REDI_CB_REASON_CODE_TABLE)
    // ReasonCodesDao.StorethedataintoHive(REDI_CB_REASON_CODE_TABLE,OVERWRITE_MODE,inputdataset)

    inputdataset.write.format(HIVE_WAREHOUSE_CONNECTOR)
      .option("database",REDI_DATABASE)
      .mode(OVERWRITE_MODE)
      .option("table", REDI_CB_REASON_CODE_TABLE)
      .save()

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"CBreasoncode data is stored successfully  into Hive " + REDI_CB_REASON_CODE_TABLE)

  }

  /*
  Store the CB Reason Codes to HDFS
   */

  def saveCBReasonCodestoHDFS(cbreasoncodesdf: DataFrame): Unit = {
    logRegularMessage("Starting to load the data into HDFS location")
    ReasonCodesDao.saveDataintoHDFS(cbreasoncodesdf, JDBC_TO_AVRO_FORMAT,
      ConfigFactory.load().getString("local.common.hdfs.CB_REASON_CODES_HDFS") ,HDFS_STORAGE_DATE_EXT)
    logRegularMessage("Finished to load the data into HDFS location")
  }
  /*
  All the methods that requires spark session
   */

  def CBReasonCodesDataPipeline(): Unit = {

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"CBreasoncode data pipeline processing starts " )

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Starting to Fetch CBReason code  into processing layer "+ CBDATA_DATABASE +"."+ RS_CB_REASONCODES )


    val result = createCBReasonCodesDataSet(RS_CB_REASONCODES, ORACLE_CONN_TYPE, CBDATA_DATABASE,CB_REASON_CODE_PARTS.toInt)

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Ending of Fetch process of  CBReason code  into processing layer "+ CBDATA_DATABASE +"."+ RS_CB_REASONCODES )

    result.cache()
    val resultCount = result.count()
    StoreCBReasonCodestoHive(processCBReasonCodes(result))

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Finished storing the data into Hive")

     saveCBReasonCodestoHDFS(result)

    CBReasonCodeProcesslogger.info(CBREASONCODEPROCESS_INFO +"Total of " + resultCount + " records got processed by CBReasonCodesProcessor from source "+
      CBDATA_DATABASE + "." + RS_CB_REASONCODES + "to destination" + REDI_CB_REASON_CODE_TABLE)
  }

}
