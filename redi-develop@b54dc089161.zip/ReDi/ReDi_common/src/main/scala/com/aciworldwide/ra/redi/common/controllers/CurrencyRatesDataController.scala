package com.aciworldwide.ra.redi.common.controllers

import java.text.SimpleDateFormat
import java.util.Calendar

import com.aciworldwide.ra.redi.common.actions.CurrencyRatesDataProcess.{CURRENCYRATESDATAPROCESS_INFO, getClass}
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.dao.CurrencyDataDao
import com.aciworldwide.ra.redi.common.schemas.{CurrencyResponseSchema, ReDiTableSchemas}
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.{DataFrame, Dataset}
import org.apache.spark.sql.types.{DoubleType, StructField, StructType}
import org.apache.spark.sql.functions._

class CurrencyRatesDataController extends BaseController  with  Serializable with ReDiConstants with CommonUtils   with ReDiTableSchemas with DatabaseServices{

  @transient lazy val CurrencyDataControllerLogger = LogManager.getLogger(getClass.getName)

  val startTime= getCurrentdateTimeStamp

  val inputformat = new SimpleDateFormat("dd-MMM-yyyy")
  val outputFormat = new SimpleDateFormat("dd-MMM-yy")

  val sparkSession = createSparkSession(CURRENCYCONVRATEAPP)

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()

  hiveSession.setDatabase(REDI_DATABASE)

  val currencyDao = new CurrencyDataDao(sparkSession)

  /*
  Get the data from rest api for the currecies
   */
  def getCurrencyRates(): Dataset[CurrencyResponseSchema] = {
    CurrencyDataControllerLogger.info(CURRENCYRATESDATAPROCESS_INFO+:"Starting to get the data from currency API")
    val currency= currencyDao.getDatafromcurrenyService()
    CurrencyDataControllerLogger.info(CURRENCYRATESDATAPROCESS_INFO+:"fetched data from currency API Successfully ")
    currency
  }

  /**
    *  convert Date To OracleDateFormat
    * @param oracleDate
    * @return
    */
  def convertToOracleDateFormat(oracleDate: String): String = {
    val dateInputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:Ss")
    val dateOutputFormat = new SimpleDateFormat("dd-MMM-yy ")

    var HWMforCurrencyData  = ""
    if(oracleDate != null){
      HWMforCurrencyData = dateOutputFormat.format(dateInputFormat.parse(oracleDate))
    }else{
      CurrencyDataControllerLogger.error(CURRENCYRATESDATAPROCESS_ERROR+"There is a error on Oracle DateFormat Converted " +HWMforCurrencyData)
    }
    HWMforCurrencyData
  }
  /*
   Get the High water mark from postgres
    */

  def getcurrencyHWMDate(): String = {
    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG +": Starting to get the HighWatermark from postgres control table")
    val HWMforCurrencyData = sparkSession.sql("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL +" WHERE PROCESSNAME = " + "'" + REDI_CURRDATA_CONTROL_KEY + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED  + "'" ).head().getString(0)
    convertToOracleDateFormat(HWMforCurrencyData)
  }
  /*
  Add the audit columns that helps us store the data into Hive
   */
  def processCurrencyData(currencyDataFrame : DataFrame) : DataFrame = {
    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+"Starting to process the currency rates to match hive table")
    addAuditColumns(currencyDataFrame)
      .withColumn(CURR_PARTITION_COL,year(col("CurrencyDate")))
  }
  /*
    Get the latest currencies from API
   */
  def getLatestCurrencyRates(currencydata: Dataset[CurrencyResponseSchema]): DataFrame = {
    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+"Starting to to get latest currency rates from API")
    currencydata.createOrReplaceTempView("currencydata")
    hiveSession.session().sql("select max(to_date(lastUpdateTime)) as currencydate, currencyCode, " +
      "rate, current_timestamp() as RSLastUpdatedtime from currencydata group by currencyCode, rate")
      .select(col("currencydate").alias("CurrencyDate"),
        col("currencyCode").alias("DestCurrencyCode"),
        col("rate").cast(DoubleType).alias("ConversionRate"),
        col("RSLastUpdatedtime").alias("RSLastUpdated"))

  }

  /*
    Store the currency data to Hive once in a day
   */

  def storeCurrencyDataHive(currencyData: DataFrame): Unit ={

    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+" latest currency rates from API to Storing into hive table  ")

    controlTableDataProcess(currencyData,"RSLastUpdated",REDI_CURRDATA_CONTROL_KEY,PROCESS_CONTROL_INPROGRESS,startTime.toString,"","Fetched records from Currency micro service API Call and storing into Hive Table  ",CURRENCY_RATES_DATA_PROCESS)

    //  val currency= setNullableStateForAllColumns(currencyData,true)

    currencyDao.storeDataIntoHive(CURR_CONV_TABLE,APPEND_MODE,currencyData,"currencydateyyyy")
  }
  def UpdateHWMforCurrencyData(currencyData: DataFrame): Unit ={

    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+" Updating HighWaterMark for latest currency rates from API ")

    val endTime= getCurrentdateTimeStamp

    controlTableDataProcess(currencyData,"RSLastUpdated",REDI_CURRDATA_CONTROL_KEY,PROCESS_CONTROL_COMPLETED,startTime.toString,endTime.toString,"Fetched records from Currency micro service API Call and Stored  into Hive Table ",CURRENCY_RATES_DATA_PROCESS)

    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+" Updated HighWaterMark for latest currency rates from API ")

  }

  def currencyRatesPipeline(): Unit = {

    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+" Started currency Rates data Pipeline  ")

    val processCurrencyCode= processCurrencyData(getLatestCurrencyRates(getCurrencyRates()))

    startControlTableDataProcess(processCurrencyCode, "RSLastUpdated", REDI_CURRDATA_CONTROL_KEY, PROCESS_CONTROL_STARTED, startTime.toString, "", "Fetched records from Currency micro service API Call ",CURRENCY_RATES_DATA_PROCESS)

    storeCurrencyDataHive(processCurrencyCode)

    UpdateHWMforCurrencyData(processCurrencyCode)

    CurrencyDataControllerLogger.debug(CURRENCYRATESDATAPROCESS_DEBUG+" Completed currency Rates data Pipeline  ")
  }

}
