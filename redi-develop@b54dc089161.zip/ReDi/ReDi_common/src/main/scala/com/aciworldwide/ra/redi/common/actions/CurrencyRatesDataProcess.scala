package com.aciworldwide.ra.redi.common.actions



import com.aciworldwide.ra.redi.common.controllers.CurrencyRatesDataController
import org.apache.logging.log4j.LogManager

object CurrencyRatesDataProcess extends CurrencyRatesDataController with Serializable {
  @transient lazy val CurrencyDataProcessLogger = LogManager.getLogger(getClass.getName)
  def main(args: Array[String]): Unit = {
    CurrencyDataProcessLogger.info(CURRENCYRATESDATAPROCESS_INFO+": Start of Currency Data  load process")
    try{
      currencyRatesPipeline()
    } catch{
      case exce: Exception => CurrencyDataProcessLogger.error(CURRENCYRATESDATAPROCESS_ERROR+" : We have an error in the Currency Data processing " +  exce.printStackTrace())
        System.exit(1)
    } finally {
      CurrencyDataProcessLogger.info(CURRENCYRATESDATAPROCESS_INFO+" : End of Currency Data load process")
    }
  }

}

