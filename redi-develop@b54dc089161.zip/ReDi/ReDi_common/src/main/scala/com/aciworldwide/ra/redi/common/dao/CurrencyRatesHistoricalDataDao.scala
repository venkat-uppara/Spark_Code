package com.aciworldwide.ra.redi.common.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import org.apache.spark.sql.{DataFrame, SparkSession}

class CurrencyRatesHistoricalDataDao(sc:SparkSession) extends DateUtils with DatabaseServices   with ReDiConstants with Serializable with EstablishConnections {
  /*
  This is the method to fetch the CBReason Codes from database
   */
  val setupConnections = new SetupConnections

  def fetchCurrencyHistRates(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int) : DataFrame ={
    logRegularMessage("Starting to fetch Currency Rates Historical Data . " + schemaname+"." + tablename)
    val currencyHistRates = setupConnections.readDataIntoDataframe(sc,tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Obtained to fetch Currency Rates Historical Data . " + schemaname +"."+ tablename)
    currencyHistRates
  }

}
