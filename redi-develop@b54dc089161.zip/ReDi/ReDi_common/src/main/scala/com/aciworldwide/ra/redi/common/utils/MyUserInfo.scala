package com.aciworldwide.ra.redi.common.utils

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.EstablishConnections
import com.jcraft.jsch.UserInfo
import com.typesafe.config.ConfigFactory

class MyUserInfo  extends UserInfo with  EstablishConnections with ReDiConstants{

 val setupConnections = new SetupConnections
 // val key = ConfigFactory.load().getString("local.common.SecurityKey.value")
 val map =  setupConnections.setupConnectionDetails("","cluster")
 val password = map("password")
 override def getPassword: String = decryptPassword(password, ConfigFactory.load().getString("local.common.SecurityKey.value"))



 override def promptYesNo( str: String): Boolean = {
  true
 }

 private[utils] var passwd = null

 override def getPassphrase: String = null

 override def promptPassphrase(message: String) = true

 override def promptPassword(message: String): Boolean = {
  // passwd = "*******" // enter the password for the machine you want to connect.
  true
 }

 override def showMessage(message: String): Unit = {
 }

}
