package com.aciworldwide.ra.redi.common.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, EstablishConnections, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Kafka Controller with methods to read, write from topics
  */

class ReDiKafkaController(sc: SparkSession) extends Loggers with Serializable
  with ReDiConstants with CommonUtils with DatabaseServices with EstablishConnections {

  def readStreamFromKafka(kafkaTopic: String): DataFrame = {

    logger.info("ReDiKafkaController::readStreamFromKafka::START::Read stream from Kafka for a particular topic")

    sc.readStream
      .format(KAFKA_SOURCE)
      .option("startingOffsets","latest")
      .option(KAFKA_BOOTSTRAP_SERVERS, ConfigFactory.load().getString("local.common.kafka.bootstrapservers"))
      .option(SUBSCRIBE, kafkaTopic)
      .option(MAXOFFSETSPERTRIGGER, ConfigFactory.load().getString("local.common.kafka.tremaxOffsetsPerTrigger"))
      .option(KAFKASECURITYPROTOCOL, SASL_SSL)
      //.option(SCHEMAREGISTRYCLIENT, ConfigFactory.load().getString("local.common.kafka.schemaRegistryURL"))
      .option(KAFKASSLKEYSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.Kafkasslkeystorelocation"))
      .option(KAFKASSLKEYSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeystorepassword"))
      .option(KAFKASSLTRUSTSTORELOCATION, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorelocation"))
      .option(KAFKASSLTRUSTSTOREPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkassltruststorepassword"))
      .option(KAFKASSLKEYPASSWORD, ConfigFactory.load().getString("local.common.kerberos.kafkasslkeypassword"))
      .option(KAFKASASLKERBEROSSERVICENAME, KAFKA)
      .option(KAFKASASLMECHANISM, GSSAPI)
      .load()
  }

}
