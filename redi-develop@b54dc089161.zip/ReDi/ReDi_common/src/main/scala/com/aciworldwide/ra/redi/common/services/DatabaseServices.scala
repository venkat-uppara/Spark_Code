package com.aciworldwide.ra.redi.common.services

import java.net.{HttpURLConnection, URL}
import java.sql.{Connection, DriverManager, ResultSet}

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.CurrencyResponseSchema
import com.aciworldwide.ra.redi.common.utils.FileUtils
import com.typesafe.config.ConfigFactory
import org.apache.hadoop.conf.Configuration
import org.apache.hadoop.security.UserGroupInformation
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.json4s.jackson.JsonMethods.parse
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import org.apache.logging.log4j.LogManager

import scala.io.Source.fromInputStream

trait DatabaseServices extends Serializable with Loggers with EstablishConnections with ReDiConstants{

  @transient lazy val databaseServiceslogger = LogManager.getLogger(getClass.getName)
  var connection:Connection = _

  def StorethedataintoHive(tablename: String, format:String, inputdataset: DataFrame ): Unit ={
    inputdataset.write.mode(format).insertInto(tablename)
  }

  def StorethedataintoHive(sc: SparkSession, tablename: String,partitionColumn:String,
                           inputdataset: DataFrame): Unit ={
    val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sc).build()
    inputdataset.createOrReplaceTempView("storetable")
    //inputdataset.write.format(format).mode(insertmode).insertInto(tablename)
    hiveSession.execute(s"insert into $tablename partition($partitionColumn) select * from storetable")
  }

  /**
    * Write into Hive ACID Table
    * @param tableName
    * @param inputDataFrame
    */
  def storeDataIntoHive(tableName: String, saveMode:String, inputDataFrame: DataFrame,partitionColumn:String ): Boolean ={
    var isHiveStore :Boolean = false;
    databaseServiceslogger.info(DATABASESERVICES_INFO +":Starting to push the data into Hive tables " + tableName)
    try {
      inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR)
        .mode(saveMode)
        .option("table", tableName)
        .option("partition", partitionColumn)
        .save()
      isHiveStore = true
    }catch{
      case exp: Exception =>  databaseServiceslogger.error(DATABASESERVICES_ERROR+": We have an error on storing data into Hive" + exp.printStackTrace())
        System.exit(1)

    } finally {
      databaseServiceslogger.debug(DATABASESERVICES_DEBUG +":End of Storing "+ tableName+ "data into Hive")
      isHiveStore
    }
    databaseServiceslogger.debug(DATABASESERVICES_DEBUG +":successfully stored data into Hive table :"+ tableName)
    isHiveStore
  }

  // Arrayindexoutofbounds issue KP moved from executeQuey to execute
  def gettheDataFromHive(sc:SparkSession, tablename: String): DataFrame ={
    val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sc).build()
    hiveSession.executeQuery(s"select * from $tablename")
  }

  def gettheDataFromHiveForRef(sc:SparkSession, tablename: String): DataFrame ={
    val hiveSession: HiveWarehouseSession = HiveWarehouseSession.session(sc).build()
    hiveSession.executeQuery(s"select clientId,subclientId,Region,clientSet,ClientName, SubclientName, TZclient,TzSubClient,ClientGroup, PSP_Group,Clientcurr,SubclientCurr from $tablename")
  }

  def saveDataintoHDFS(inputdataset: DataFrame, format: String, hdfspath: String, dateext: String): Unit = {
    val fileUtils = new FileUtils()
    inputdataset.write.format(format)
      .save(fileUtils.formatFilename(hdfspath,dateext))
  }



  /**
    * @author : Hariprasad Allaka
    * MERF-8357 : Get the data from RestAPI. Can be used across when we have something to pull from Rest API
    */

  @throws(classOf[java.io.IOException])
  @throws(classOf[java.net.SocketTimeoutException])
  def getCurrencyData(sc:SparkSession, url: String, connectTimeout: Int, readTimeout: Int, requestMethod: String) =
  {
    implicit val formats = org.json4s.DefaultFormats
    import sc.implicits._
    val connection = (new URL(url)).openConnection.asInstanceOf[HttpURLConnection]
    connection.setConnectTimeout(connectTimeout)
    connection.setReadTimeout(readTimeout)
    connection.setRequestMethod(requestMethod)
    val inputStream = connection.getInputStream
    val content = parse(fromInputStream(inputStream).mkString).extract[Array[CurrencyResponseSchema]]
    if (inputStream != null) inputStream.close
    sc.createDataset(content)
    // content
  }

  /**
    * Method is used to update the data into hive using Hive keytab
    *
    */
  def UpdateDataIntoHive(whenloaded:String ): Boolean ={

    var bool:Boolean = false;
    val conf = new Configuration()
    conf.set("hadoop.security.authentication", "Kerberos")
    UserGroupInformation.setConfiguration(conf)
    UserGroupInformation.loginUserFromKeytab(ConfigFactory.load().getString("local.common.hive.principal"),
      ConfigFactory.load().getString("local.common.hive.keytab"))
    try{
      Class.forName(ConfigFactory.load().getString("local.common.hive.driver"))
      connection = DriverManager.getConnection(ConfigFactory.load().getString("local.common.hive.url"))
      val stmt = connection.createStatement()
       val result = stmt.execute("MERGE INTO REDI.RBI_REF_CLIENT AS D USING (Select * from redi.RBI_REF_CLIENT_ON_WRITE where whenloaded >= UNIX_TIMESTAMP( "+ "'" + whenloaded + "'" + " )) AS S ON (D.CLIENTID=S.CLIENTID and D.subclientid = S.subclientid) WHEN MATCHED THEN UPDATE SET clientname=S.clientname,subclientname=S.subclientname,client12=S.client12,clientgroup =S.ClientGroup,subclientgroup=S.SubClientGroup,rsactive=S.RSActive,clientcurr=S.ClientCurr,subclientcurr=S.SubClientCurr,affiliate=S.affiliate,sectorgroup=S.sectorgroup,sector=S.sector,psp_group=S.psp_group,rslastupdatedby=S.rslastupdatedby,rslastupdated=S.rslastupdated,WhenUpdated =S.WhenUpdated ,WhoUpdated=S.WhoUpdated  WHEN NOT MATCHED THEN  INSERT VALUES(S.ClientID,S.SubClientID,S.ClientName,S.SubClientName,S.Client12,S.ClientGroup,S.SubClientGroup,S.RSActive,S.ClientCurr, S.SubClientCurr,S.CMActive,S.CSIActive,S.BEDActive,S.ChallActive,S.CBActive,S.Affiliate,S.SectorGroup,S.Sector,S.RiskManager,S.AccManager, S.xMerchantIds,S.ClubRFX,S.CM2Active,S.LocalKPIs,S.SilentRules,S.Alerts,S.TZClient,S.TZSubClient,S.PSP_GROUP,S.Region,S.ClientSet,ClientSet12, S.RSLastUpdatedBy,S.RSLastUpdated,S.WhenLoaded,S.WhoLoaded,S.WhenUpdated,S.WhoUpdated,S.DummyBucketCol)")

      bool = true
      } catch {
      case exce: ClassNotFoundException => logRegularMessage("ClassNotFoundException occurred" + exce)
      case oth: Exception => logRegularMessage("General Exception occurred" + oth)
       bool = false
    }finally{
      connection.close()}
    bool
  }


  def UpdateDataIntoHiveQuery(inputsql : String): Unit ={
    val conf = new Configuration()
    conf.set("hadoop.security.authentication", "Kerberos")
    UserGroupInformation.setConfiguration(conf)
    UserGroupInformation.loginUserFromKeytab(ConfigFactory.load().getString("local.common.hive.principal"),
      ConfigFactory.load().getString("local.common.hive.keytab"))
    try{
      Class.forName(ConfigFactory.load().getString("local.common.hive.url"))
      connection = DriverManager.getConnection(ConfigFactory.load().getString("local.common.hive.url"))
      val stmt = connection.createStatement()
      val result = stmt.executeQuery(inputsql)
    } catch {
      case exce: ClassNotFoundException => println("ClassNotFoundException occurred" + exce)
      case oth: Exception => println("General Exception occurred" + oth)
    }finally{
      connection.close()
    }
  }

  def readDataIntoJdbcRDDFromHiveTable(tablename: String): ResultSet ={
    val conf = new Configuration()
    conf.set("hadoop.security.authentication", "Kerberos")
    UserGroupInformation.setConfiguration(conf)
    UserGroupInformation.loginUserFromKeytab(ConfigFactory.load().getString("local.common.hive.principal"),
      ConfigFactory.load().getString("local.common.hive.keytab"))
    try{
      Class.forName(ConfigFactory.load().getString("local.common.hive.driver"))
    } catch {
      case classexception: ClassNotFoundException => logRegularMessage("Exception occurred while conencting Hive Jdbc" + classexception)
    }
    val connection =DriverManager.getConnection(ConfigFactory.load().getString("local.common.hive.url"))
    val stmt = connection.createStatement()
    val result = stmt.executeQuery("select * from " + tablename)
    result
  }

}
