package com.aciworldwide.ra.redi.common.schemas

case class SerializedKafkaRecord(key: Array[Byte], value: Array[Byte]) extends Serializable
