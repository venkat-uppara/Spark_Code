package com.aciworldwide.ra.redi.common.utils

class FileUtils extends DateUtils with Serializable {

  /*
  Method to format any type of file names with proper extentions
   */
  def formatFilename(filepath: String, suffix: String): String = {
    val rsncodeavrofilename =  filepath + "_" + formatCurrentDateString(suffix)

    rsncodeavrofilename
  }
}
