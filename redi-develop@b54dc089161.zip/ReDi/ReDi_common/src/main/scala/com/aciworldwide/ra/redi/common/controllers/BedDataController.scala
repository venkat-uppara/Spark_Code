package com.aciworldwide.ra.redi.common.controllers

import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.dao.BedDataDao
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.{DataFrame, SaveMode}
import org.apache.spark.sql.functions.{current_timestamp, lit, _}
import org.apache.logging.log4j.LogManager
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
//import com.aciworldwide.ra.redi.common.services.DatabaseServices

class BedDataController extends DateUtils with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with ReDiTableSchemas with Loggers{

  @transient lazy val BEDDataTransformationLogger = LogManager.getLogger(getClass.getName)

  val baseController = new BaseController()

  val sparkSession =baseController.createSparkSession(BEDDATAPROCESSAPP)

  val bedDataDao = new BedDataDao(sparkSession)

  val hivesession= HiveWarehouseSession.session(sparkSession).build()
  hivesession.setDatabase(REDI_DATABASE)

  import sparkSession.implicits._


  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_BEDS_DATA_TABLE_HWM_COLUMN
  }

  def getChallDataTableName(): String = {
    REDI_ODS_CHALLANGE_DATA_TABL
  }


  def getOverDataTableName(): String = {
    REDI_ODS_OVERRIDE_DATA_TABL
  }


  def getDatabaseSchema(): String = {
    BEDATA_DATABASE
  }


  /* This method has been implemented to fetch HWM from control table where clause
     */

  def getHWMId(controlKey:String): String = {
    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + " :Starting to fetch HWM Value")
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + " :Process Control Table Name:- " + REDI_PROCESS_CONTROL)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + " Process Control Key  Name:- " + controlKey)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + " :Process Status  :- " + PROCESS_CONTROL_COMPLETED)
    var hwmDate =  hivesession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL +" WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'"
      + PROCESS_CONTROL_COMPLETED  + "'" ).head().getString(0)

    //val HWMBED = convertToOracleDateFormat(hwmDate)
    hwmDate
  }

  /* This method has been implemented to create where clause
   */

  def getODSWhereCondition(value: String): String = {
    " WHERE " +  getRawDataFrameHWMColumn + "> to_timestamp('" + value + "','YYYY-MM-DD HH24:MI:SS.FF')"

  }
  /* This method has been implemented to fetch data from Oracle
     */

  def fetchRawDataFrmBeds(BEDHWM:String,tableName:String): DataFrame ={
    val tmpTable = tableName.substring(5,10)
    val challQuery = "( SELECT * FROM" +
      " " + getDatabaseSchema + "." + tableName + getODSWhereCondition(BEDHWM) + ") BED_"+ tmpTable +"_DATA"

    val challTableDF = bedDataDao.fetchBedData(challQuery,ORACLE_CONN_TYPE,getDatabaseSchema,BED_DATA_CODE_PARTS)
    challTableDF
  }

  /* This Wrapper  has been implemented to save data in hive  */

  def storeDataToHDFS(df: DataFrame): Unit = {
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"Starting to load data into HDFS location")
    saveDataintoHDFS(df, "ORC", ConfigFactory.load().getString("local.common.hdfs.BED_DATA_FILES_DATA"), HDFS_STORAGE_DATE_EXT)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"Finished loading the data into HDFS location")

  }
  def updateControlTables(bedDf: DataFrame, maxcolumn: String, processName: String,startTime:String): Unit = {

    val endTimeBEDDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(bedDf, maxcolumn, processName, PROCESS_CONTROL_COMPLETED, startTime, endTimeBEDDataLoad.toString, "Completed the  Fetch from ODS into HDFS",BED_DATA_PROCESS)
  }

  def dateFormatyymdd = udf((oidDate: String) => {
    //val testdate="2017-10-25 00:00:00"
    val inputFormat = new SimpleDateFormat(BED_IP_DATE_FORMAT)
    val outputFormat = new SimpleDateFormat(BED_OP_DATE_FORMAT)
    val date = outputFormat.format(inputFormat.parse(oidDate))
    date
  })

  /* This method has been implemented to do the transformation present in
       MODS.BED_001_Prepare - Date format conversion,Source(O/C) for Override DF
   */

  def ChallDfTranformations(df:DataFrame):DataFrame={

    var challDf:DataFrame = null

    challDf = df.select($"CHALL_OID".as("OID"),$"CHALL_REF_ID".as("ReferenceId"),$"CHALL_TRANSID".as("TransactionId"),
      $"CHALL_PROCESS_DATE".as("ProcessDate"),$"CHALL_DISPOSITION".as("Disposition"),
      $"CHALL_CLNT_REASON_CODE".as("ClientReasonCode"),$"CHALL_CLIENT_DESC".as("ClientDesc"),
      $"DATA_PROC_DATE".as("DataProcDate"),$"CLIENT_ID".as("ClientId"),$"OTHER_INFO1".as("OtherInfo1"),
      $"OTHER_INFO2".as("OtherInfo2"),$"OTHER_COUNT1".as("OtherCount1"),$"OTHER_COUNT2".as("OtherCount2"),
      $"REMARKS".as("Remarks"),$"LINE_NUM".as("LineNumber"),$"SUB_CLIENT_ID".as("SubClientId"),$"DATA_FILE_NAME".as("DataFileName"))
      .withColumn("ProcessYYMMDD",dateFormatyymdd($"ProcessDate"))
      .withColumn("DataProcYYMMDD",dateFormatyymdd($"DataProcDate"))
      .withColumn("Source",lit("C"))

    challDf
  }

  /* This method has been implemented to do the transformation present in
       MODS.BED_001_Prepare - Date format conversion,Source(O/C) for Override DF
   */

  def OverrDfTransformations(df:DataFrame):DataFrame = {

    var overrDf:DataFrame = null
    overrDf = df.select($"OVER_OID".as("OID"),$"OVER_REF_ID".as("ReferenceId"),$"OVER_TRANSID".as("TransactionId"),
      $"OVER_PROCESS_DATE".as("ProcessDate"),$"OVER_DISPOSITION".as("Disposition"),
      $"OVER_CLNT_REASON_CODE".as("ClientReasonCode"),$"OVER_CLIENT_DESC".as("ClientDesc"),
      $"DATA_PROC_DATE".as("DataProcDate"),$"CLIENT_ID".as("ClientId"),$"OTHER_INFO1".as("OtherInfo1"),
      $"OTHER_INFO2".as("OtherInfo2"),$"OTHER_COUNT1".as("OtherCount1"),$"OTHER_COUNT2".as("OtherCount2"),
      $"REMARKS".as("Remarks"),$"LINE_NUM".as("LineNumber"),
      $"SUB_CLIENT_ID".as("SubClientId"),$"DATA_FILE_NAME".as("DataFileName")).withColumn("ProcessYYMMDD",dateFormatyymdd($"ProcessDate"))
      .withColumn("DataProcYYMMDD",dateFormatyymdd($"DataProcDate"))
      .withColumn("Source",lit("O"))
    overrDf
  }
  def setDisposition = udf ((disposition: String)=>{
    val despo = disposition.take(12)
    val transDesposition= despo match {
      case "REJECT_OTHER" => "Reject Other"
      case "REJECT_FRAUD" => "Reject Fraud"
      case "ACCEPT" => "Accept"
      case "reject_other" => "Reject Other"
      case "reject_fraud" => "Reject Fraud"
      case "accept" => "Accept"
      case "REJECT_UNABL" => "Reject Other"
      case _ => despo
    }
    transDesposition
  })

  def setFraud = udf((disposition: String) => {
    val despPattern1 = """.*FRAUD.*""".r
    val despPattern2 = """.*fraud.*""".r
    val FraudYN = disposition.take(12) match  {

      case despPattern1()|despPattern2() => "Y"
      case _ => "N"

    }
    FraudYN
  })

  def updateMacysTransId = udf( (transId:String) =>{

    val tmpTransId = "000000000"
    var mTransId:String = null
    if (transId.trim.length < 9){
      mTransId = tmpTransId.take(9 - transId.trim.length)
    }else{
      mTransId = transId
    }
    mTransId
  })

  def updateCurrentStatus=udf ((recom:String,dispostion:String,currentstat:String)=>{
    var currentStat:String=""

    if (recom=="Challenge"||recom=="CHALLENGE"){
      currentStat=dispostion match  {
        case "Accept"=>recom.concat("->Accept")
        case "Reject Fraud"=>recom.concat("->RejFraud")
        case "Reject Other"=>recom.concat("->Reject")
        case _=> currentstat
      }

    }else if (recom=="Deny"||recom=="DENY") {
      currentStat=dispostion match  {
        case "Accept"=>recom.concat("->Accept")
        case "Reject Fraud"=>recom.concat("->RejFraud")
        case "Reject Other"=>recom.concat("->Reject")
        case _=> currentstat
      }

    }else if (recom=="Accept"||recom=="ACCEPT") {
      currentStat=dispostion match  {
        case "Reject Fraud"=>recom.concat("->RejFraud")
        case "Reject Other"=>recom.concat("->Reject")
        case _=> currentstat
      }
    }else if (recom=="NoScore"||recom=="NOSCORE") {
      currentStat=dispostion match {
        case "Reject Fraud" => recom.concat("->RejFraud")
        case "Reject Other" => recom.concat("->Reject")
        case _ => currentstat
      }
    }else{
      currentStat=currentstat
    }

    currentStat
  })
  def updateDecision=udf((recom:String,dispostion:String,decision:String)=>{
    var decision:String=""
    if (recom=="Accept"||recom=="Challenge"||recom=="Deny"||recom=="NoScore"||recom=="ACCEPT"||recom=="CHALLENGE"||recom=="DENY"||recom=="NOSCORE"){
      decision =dispostion match {
        case "Reject Fraud"=>"R"
        case "Reject Other"=>"R"
        case "Accept"=>"A"
        case "RejectUnable"=>"R"
        case _=>decision
      }
    }
    decision
  })
  def updateChallStatus = udf ((recom:String,dispostion:String,challStat:String)=>{
    var challStat:String=""
    if (recom=="Challenge"||recom=="CHALLENGE") {
      challStat = dispostion match {
        case "Accept" => "Approve"
        case "Reject Fraud" => "RejFraud"
        case "Reject Other" => "RejOther"
        case _ => challStat
      }
    }
    challStat

  })

  /* This method has been implemented to do the transformation present in
       MODS.BED_001_Prepare
   */

  def transformChallOverrDf(df:DataFrame):DataFrame = {
    var unionedDF:DataFrame = null
    BEDDataTransformationLogger.info("Inside transformChallOverrDf ")

    unionedDF = df.select($"OID".as("BOID"),$"ReferenceId".as("BEDReferenceId"),$"TransactionId".as("BEDTransactionId"),
      $"ProcessDate".as("BEDprocessdate"),$"Disposition".as("BEDDisposition"),$"ClientReasonCode".as("BEDClientReasonCode")
      ,$"ClientDesc".as("BEDClientDesc"),$"DataProcDate".as("BEDDataProcDate"),$"ClientId".as("BEDClientId"),$"SubClientId".as("BEDSubclientId"),
      $"DataFileName".as("BEDDataFileName"),$"ProcessYYMMDD".as("BEDProcessYYYYMMDD"),$"OtherInfo1".as("BEDOtherInfo1"),$"OtherInfo2".as("BEDOtherInfo2")
      ,$"OtherCount1".as("BEDOtherCount1"),$"OtherCount2".as("BEDOtherCount2"),$"Remarks".as("BEDRemarks"),$"LineNumber".as("BEDLineNumber"),
      $"Source".as("BEDsource"),
      $"DataProcYYMMDD".as("BEDDataProcYYYYMMDD"))
      .withColumn("BEDFraudYN",setFraud($"BEDDisposition"))
      .withColumn("TransactionIdReDi",when(col("BEDClientId") === "000050",updateMacysTransId($"BEDTransactionId"))
        .otherwise(col("BEDTransactionId")))
      .withColumn("BClient12",concat(when(col("BEDClientId").isNotNull,col("BEDClientId")).otherwise(lit(null)),
        when(col("BEDSubclientId").isNotNull,col("BEDSubclientId")).otherwise(lit(null))))
      .withColumn("BEDDispostionReDi",setDisposition($"BEDDisposition"))


    val tranDetailsDF = getTransDetail()


    //logRegularMessage("Inside transformChallOverrDf=====Count before Join --BED ="+unionedDF.count() )

    //logRegularMessage("Inside transformChallOverrDf=====Count before Join --trans_detail ="+tranDetailsDF.where($"OID" === "8888899999EEETT0133452565659" ).count() )


    //val joinedDF = unionedDF.join(tranDetailsDF,(unionedDF.col("BOID") === tranDetailsDF.col("oid") || unionedDF.col("BEDTransactionId") === tranDetailsDF.col("transactionid")))
    val joinedDF = unionedDF.join(tranDetailsDF, ((unionedDF.col("BOID") === tranDetailsDF.col("oid") && unionedDF.col("BEDClientId") === tranDetailsDF.col("clientid")) || (unionedDF.col("BEDTransactionId") === tranDetailsDF.col("transactionid") && unionedDF.col("BEDClientId") === tranDetailsDF.col("clientid"))), "left_outer")

    //logRegularMessage("Inside transformChallOverrDf=====Count After Join="+joinedDF.count() )


    val bedAuditDf = joinedDF.select($"BOID", $"oid", $"OIDDate",
      unionedDF.col("BEDTransactionId").as("TransactionIdBed"),
      $"TransactionIdReDi",$"BEDprocessdate".as("ProcessDate"),
      $"BEDDisposition".as("Disposition"),$"BEDDispostionReDi".as("DispostionReDi"),$"BEDClientReasonCode".as("ClientReasonCode"),$"BEDClientDesc".as("ClientDesc")
      ,$"BEDDataProcDate".as("DataProcDate"),$"BEDClientId".as("ClientID"),
      $"BEDSubclientId".as("SubClientId"),$"BClient12".as("Client12"),$"BEDDataFileName".as("DataFileName"),$"BEDOtherInfo1".as("OtherInfo1"),$"BEDOtherInfo2".as("OtherInfo2")
      ,$"BEDOtherInfo1".as("OtherCount1"),$"BEDOtherInfo2".as("OtherCount2"),$"BEDRemarks".as("Remarks"),$"BEDLineNumber".as("LineNumber"),
      $"BEDsource".as("Source"),$"BEDFraudYN".as("FraudYN"),$"BEDProcessYYYYMMDD".as("ProcessYYMMDD"),$"BEDDataProcYYYYMMDD".as("DataProcYYMMDD"),$"OIDDateYYYYMMDD",
      $"BEDReferenceId".as("ReferenceId"),$"realfraudtype",$"realfraudyyyymmdd",$"realfrauddatebae",$"realfrauddate",$"REALFRAUDYN")
      .withColumn("OID", when($"BOID".isNull, $"oid").otherwise($"BOID")).drop("BOID")


    val finalJoinedDF=joinedDF.drop("BOID").drop("TransactionIdReDi")


    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + " :Before bedUpdateTransformations  ")

    //finalJoinedDF.show()

    bedUpdateTransformations(finalJoinedDF)



    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + " :Exiting transformChallOverrDf ")
    bedAuditDf
  }

  /* API to get the trans_detail data from Hive */

  def getTransDetail(): DataFrame = {
    //gettheDataFromHive(sparkSession, REDI_TRAN_DETAIL_TABLE)
    //bedDataDao.getDataFromHive(REDI_TRAN_DETAIL_TABLE)
    hivesession.executeQuery("select OID,OIDDATE, OIDDateYYYYMMDD,RECOMMENDATION,currentstatus,decision,challstatus,transactionid,clientid,REALFRAUDYN" +
      ",realfraudtype,realfraudyyyymmdd,realfrauddatebae,realfrauddate from BI_TRANS_MASTER_CORE")
  }

  /** ****************************************************************************************************************************************************
    * TODO:This is the method implements MODS.BED_002_Update. For now this has been commented out
    *
    * ***************************************************************************************************************************************************/

  def bedUpdateTransformations(df1:DataFrame):Unit ={

    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"Inside bedUpdateTransformations ")
    var oidNotNullDf:DataFrame = null
    var challOidNullDf:DataFrame = null
    var OverrOidNullDf:DataFrame = null
    var unionDf:DataFrame = null
    var joinedAuditDf:DataFrame = null
    var joinedAuditDf1:DataFrame = null
    var joinedAuditDf2:DataFrame = null
    var csiCasesDF:DataFrame = null
    var csiOrdrStatus:DataFrame = null


    df1.createOrReplaceTempView("bedSourceData")

    //logRegularMessage("Inside bedUpdateTransformations ----000")


    /*Check if the latest record is present in CSI_CASES*/

    csiCasesDF = gettheDataFromHive(sparkSession, BED_CSI_CASES)
    csiCasesDF.createOrReplaceTempView("csiCasesView")

    val maxCSICasesComplDTDf =sparkSession.sql("select A.OID,A.clientid,MAX(A.completedatetime) as MaxCompleteDateTime " +
      "from csiCasesView A join bedSourceData B ON A.OID = B.OID AND A.clientid = B.clientid group by A.OID,A.clientid")

    maxCSICasesComplDTDf.createOrReplaceTempView("maxCSICasesView")
    // maxCSICasesComplDTDf.printSchema()
    //logRegularMessage("Inside bedUpdateTransformations ----111 ")

    val csiCasesOldRecords = sparkSession.sql("select A.OID,A.clientid " +
      "from bedSourceData A join maxCSICasesView C on  A.OID = C.OID and A.clientid = C.clientid   where " +
      "A.BEDDataProcDate < C.MaxCompleteDateTime ")

    //Check if the latest record is present in CSI_ORDER_STATUS
    csiOrdrStatus=gettheDataFromHive(sparkSession, BED_CSI_ORDER_STATUS)
    csiOrdrStatus.createOrReplaceTempView("csiOrdrStatusView")

    val maxCSIOrdrStatusDf = sparkSession.sql("select A.OID,A.clientid,MAX(A.LastUpdated)MaxLastUpdated " +
      "from csiOrdrStatusView A join bedSourceData B ON A.OID = B.OID AND A.clientid = B.clientid group by A.OID,A.clientid")

    maxCSIOrdrStatusDf.createOrReplaceTempView("maxCSIordrStatusView")

    val csiOrdrStatusOldRecords = sparkSession.sql("select A.OID,A.ClientId " +
      "from bedSourceData as A join maxCSIordrStatusView as C on A.OID = C.OID and A.clientid = C.clientid where " +
      "A.BEDDataProcDate < C.MaxLastUpdated")



    val csiDF=csiCasesOldRecords.union(csiOrdrStatusOldRecords).select($"OID".as("CSIOID"))
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"Inside bedUpdateTransformations ----333")

    hivesession.executeUpdate("delete from REDI.BED_CSI_TEMP_TABLE")
    addAuditColumns(csiDF).select("CSIOID", "WHENUPDATED", "WHOUPDATED","whenloaded")
      .write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_CONTROL_DATABASE).mode(SaveMode.Append).option("table", "REDI.BED_CSI_TEMP_TABLE").save()

    val tmp = hivesession.executeQuery("select * from  REDI.BED_CSI_TEMP_TABLE")

    //val tmp = csiDF//.select("CSIOID")

    //val latestBedRecords =df1.join(csiDF,df1.col("OID")===csiDF.col("CSIOID"),"left_outer").where(csiDF.col("CSIOID") isNull)
    val latestBedRecords =df1.join(tmp,df1.col("OID")===tmp.col("CSIOID"),"left_outer").where(tmp.col("CSIOID") isNull)
      .withColumn("BEDWhenLoaded", current_timestamp())
      .withColumn("BEDWhoLoaded", lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn("BEDWhenUpdated", current_timestamp())
      .withColumn("BEDWhoUpdated", lit(WHO_LOADED_UPDATED_INSERT))
      .drop("CSIOID")


    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Inside bedUpdateTransformations ----444")

    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Inside bedUpdateTransformations ----count=" + latestBedRecords.count())
    val transformedDf = finalBedtransformations(latestBedRecords)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Started pushing the data into Hive tables " + BI_TRANS_MASTER_CORE)
    updateDataTransDetailInHive(transformedDf)
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG + "Number of rows updated in " + BI_TRANS_MASTER_CORE + " table is : " + transformedDf.count)
    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + " :Exiting bedUpdateTransformations")
    //transformedDf
  }
  def finalBedtransformations(bedDF:DataFrame): DataFrame ={
    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + "Inside finalBedtransformations")

    val finalDF = bedDF
      .withColumn("ChallSource",lit("BEDS"))
      .withColumn("currentstatus", updateCurrentStatus($"RECOMMENDATION",$"beddispostionredi",$"currentstatus"))
      .withColumn("decision",updateDecision($"RECOMMENDATION",$"beddispostionredi",$"decision"))
      .withColumn("challstatus",updateChallStatus($"RECOMMENDATION",$"beddispostionredi",$"challstatus"))
      .withColumn("Override", $"beddispostionredi")
      .withColumn("OverrideType", $"bedsource")
      .withColumn("OverrideFraudYN", $"bedfraudyn")
      .withColumn("overrideyyyymmdd", $"BEDDataProcYYYYMMDD")
      .withColumn("OverrideUpdatedYYYYMMDD", date_format(current_date(), "yyyyMMdd"))
      .withColumn("REALFRAUDYN", when( $"bedfraudyn" === lit("Y"), lit("Y")).otherwise(lit("N")))
      .withColumn("realfraudtype",when($"bedsource" === lit("O")
        && $"bedfraudyn" === lit("Y"),lit("BEDOVROV"))
        .when($"bedsource" === lit("C")
          && $"bedfraudyn" === lit("Y") ,lit("BEDOVRCH"))
        .otherwise($"realfraudtype"))
      .withColumn("realfraudyyyymmdd", when($"bedfraudyn" === lit("Y"),$"overrideyyyymmdd")
        .otherwise($"realfraudyyyymmdd"))
      .withColumn("realfrauddatebae", when($"bedfraudyn" === lit("Y"),current_timestamp())
        .otherwise($"realfrauddatebae"))
      .withColumn("realfrauddate",when( $"bedfraudyn" === lit("Y"), $"BEDDataProcDate")
        .otherwise($"realfrauddate"))



    /*logRegularMessage("Started pushing the data into Hive tables " + REDI_TRAN_DETAIL_ON_WRITE_TABLE)
    storeTransDetailtoHive(reorderSourceTableSchema(REDI_TRANS_DETAIL_COL_ORDER,finalDF))
    logRegularMessage("Number of rows updated in " + REDI_TRAN_DETAIL_ON_WRITE_TABLE + " table is : " + finalDF.count)*/

    finalDF


  }

  /*Store bed_audit_table to Hive*/

  def storeDataToHive(finalCoreDF: DataFrame): Unit = {
    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + "Starting to push the data into Hive table " + REDI_BED_AUDIT_TABLE)
    bedDataDao.StoredataintoHive(REDI_BED_AUDIT_TABLE, APPEND_MODE, finalCoreDF)
    BEDDataTransformationLogger.info(BEDDataIngestionProcess_INFO + "Number of rows inserted in  BED_AUDIT_DATA: " + finalCoreDF.count)
  }

  /*Store Trans Detail to Hive*/

  /*def storeTransDetailtoHive(inputDataFrame: DataFrame): Unit = {
    logRegularMessage("Starting to push the data into Hive table " + REDI_TRAN_DETAIL_ON_WRITE_TABLE)
    StorethedataintoHive(REDI_TRAN_DETAIL_ON_WRITE_TABLE, APPEND_MODE, inputDataFrame)
  }*/
  def updateDataTransDetailInHive(inputDataFrame: DataFrame): Unit ={
    BEDDataTransformationLogger.info("Starting to push the data into Hive table " + BI_TRANS_MASTER_CORE)
    hivesession.executeUpdate("delete from REDI.BED_TRANS_MASTER_CORE_UPDATE_TABLE")

    BEDDataTransformationLogger.info("Finish deleting data from  Hive table " + BED_TRANS_MASTER_CORE_UPDATE_TABLE)

    addAuditColumns(inputDataFrame).select("OID", "OIDDATE", "OIDDateYYYYMMDD","bedtransactionid","bedprocessdate","beddisposition","beddispostionredi","bedclientreasoncode",
      "bedclientdesc","bedclientid","bedsubclientid","beddatafilename","bedotherinfo1","bedotherinfo2","bedothercount1","bedothercount2","bedremarks","bedreferenceid","bedlinenumber",
      "bedsource","bedfraudyn","bedprocessyyyymmdd","beddataprocyyyymmdd","bedwhenloaded","bedwholoaded","bedwhenupdated","bedwhoupdated","decision","currentstatus",
      "challsource","challstatus","realfraudyn","realfraudyyyymmdd","realfrauddate","realfraudtype","realfrauddatebae",
      "overridetype","override","overridefraudyn","overrideyyyymmdd","overrideupdatedyyyymmdd","WHOLOADED", "WHENUPDATED", "WHOUPDATED","whenloaded")
      .write.format(HIVE_WAREHOUSE_CONNECTOR).option("database", REDI_CONTROL_DATABASE).mode(SaveMode.Append).option("table", "REDI.BED_TRANS_MASTER_CORE_UPDATE_TABLE").save()

    val updateBITransCore = hivesession.executeUpdate("MERGE INTO REDI.bi_trans_master_core AS D USING" +
      "(SELECT * from (select *,row_number() over(partition by oid  order by (bedprocessdate) desc) as num from  REDI.BED_TRANS_MASTER_CORE_UPDATE_TABLE)latest  where num=1) AS S ON (D.OID=S.OID) WHEN MATCHED " +
      "THEN UPDATE SET  bedtransactionid=S.bedtransactionid,bedprocessdate=S.bedprocessdate,beddisposition=S.beddisposition," +
      "beddispostionredi=S.beddispostionredi,bedclientreasoncode=S.bedclientreasoncode,bedclientdesc=S.bedclientdesc," +
      "bedclientid=S.bedclientid,bedsubclientid=S.bedsubclientid,beddatafilename=S.beddatafilename,bedotherinfo1=S.bedotherinfo1,bedotherinfo2=S.bedotherinfo2," +
      "bedothercount1=S.bedothercount1,bedothercount2=S.bedothercount2,bedremarks=S.bedremarks,bedreferenceid=S.bedreferenceid," +
      "bedlinenumber=S.bedlinenumber,bedsource=S.bedsource,bedfraudyn=S.bedfraudyn,bedprocessyyyymmdd=S.bedprocessyyyymmdd," +
      "beddataprocyyyymmdd=S.beddataprocyyyymmdd,bedwhenloaded=S.bedwhenloaded,bedwholoaded=S.bedwholoaded,bedwhenupdated=S.bedwhenupdated" +
      ",bedwhoupdated=S.bedwhoupdated,decision=S.decision,currentstatus=S.currentstatus,challsource=S.challsource,challstatus=S.challstatus,realfraudyn=S.realfraudyn" +
      ",realfraudyyyymmdd=S.realfraudyyyymmdd,realfrauddate=S.realfrauddate,realfraudtype=S.realfraudtype," +
      "realfrauddatebae=S.realfrauddatebae,overridetype=S.overridetype,override=S.override,overridefraudyn=S.overridefraudyn,overrideyyyymmdd=S.overrideyyyymmdd," +
      "overrideupdatedyyyymmdd=S.overrideupdatedyyyymmdd,WHOLOADED=S.WHOLOADED,WHENLOADED=S.WHENLOADED, WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

    val updateTransCore = hivesession.executeUpdate("Merge INTO redi.TRANS_MASTER_CORE AS ingtransdata " +
      "USING (SELECT * from (select *,row_number() over(partition by oid  order by (bedprocessdate) desc) as num from  REDI.BED_TRANS_MASTER_CORE_UPDATE_TABLE)latest  where num=1) AS frauddata " +
      "on (frauddata.oid = ingtransdata.oid  and ingtransdata.realfraudyn = 'N' ) " +
      "When matched Then Update " +
      "SET RealFraudYN = 'Y'," +
      "realfraudtype=frauddata.realfraudtype," +
      "RealFraudDate = current_timestamp," +
      "realfrauddatebae = current_timestamp," +
      "WHOLOADED=frauddata.WHOLOADED,WHENLOADED=frauddata.WHENLOADED, WHENUPDATED=frauddata.WHENUPDATED,WHOUPDATED=frauddata.WHOUPDATED")

  }



  /** ****************************************************************************************************************************************************
    * This is the method which is invoked by the action
    * This will be used to ingest and process the Automated BED Data from Source into Destination
    * ***************************************************************************************************************************************************/

  def bedDataPipeline(): Unit ={

    val BEDCHALLHWM = getHWMId(REDI_BEDS_CHALL_CONTROL_KEY)
    val BEDOVERRHWM = getHWMId(REDI_BEDS_OVERR_CONTROL_KEY)
    val startTimeBEDDATA = getCurrentdateTimeStamp
    var rawChallDF:DataFrame = null
    var rawOverrDF:DataFrame = null
    var rawBedDataFrame:DataFrame = null
    var transChallDf:DataFrame = null
    var transOverrDf:DataFrame = null
    var transChallOverrDf:DataFrame = null
    var finalDF1:DataFrame = null
    var finalDF2:DataFrame = null

    if (BEDCHALLHWM == null) {
      BEDDataTransformationLogger.info("There is a error in the " + REDI_BEDS_CHALL_CONTROL_KEY + " value stored in Hive" + BEDCHALLHWM)
    }
    else{
      rawChallDF= fetchRawDataFrmBeds(BEDCHALLHWM,REDI_ODS_CHALLANGE_DATA_TABL)

      BEDDataTransformationLogger.info("Total Count is for "+REDI_ODS_CHALLANGE_DATA_TABL+ "=" + rawChallDF.count())

      transChallDf = ChallDfTranformations(rawChallDF)

    }
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG+":Insert data into  REDI_PROCESS_CONTROL table for BED CB  data process job"+ REDI_BEDS_CHALL_CONTROL_KEY + " Status Is :" + PROCESS_CONTROL_STARTED)
    startControlTableDataProcess(rawChallDF, getRawDataFrameHWMColumn, REDI_BEDS_CHALL_CONTROL_KEY, PROCESS_CONTROL_STARTED, startTimeBEDDATA.toString, "", "Fetched records from ODS BED2_CB_DATA_FILES_DATA  table",BED_DATA_PROCESS)

    if (BEDOVERRHWM == null){
      BEDDataTransformationLogger.info("There is a error in the " + REDI_BEDS_OVERR_CONTROL_KEY + " value stored in Hive" + BEDOVERRHWM)
    }else{
      rawOverrDF= fetchRawDataFrmBeds(BEDOVERRHWM,REDI_ODS_OVERRIDE_DATA_TABL)
      BEDDataTransformationLogger.info("Total Count is for "+REDI_ODS_OVERRIDE_DATA_TABL+ "=" + rawOverrDF.count())
      transOverrDf = OverrDfTransformations(rawOverrDF)
      BEDDataTransformationLogger.info("Ending the Process  ")
    }
    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG+":Insert data into  REDI_PROCESS_CONTROL table for BED CB  data process job"+ REDI_BEDS_OVERR_CONTROL_KEY + " Status Is :" + PROCESS_CONTROL_STARTED)
    startControlTableDataProcess(rawOverrDF, getRawDataFrameHWMColumn, REDI_BEDS_OVERR_CONTROL_KEY, PROCESS_CONTROL_STARTED, startTimeBEDDATA.toString, "", "Fetched records from ODS BED2_CB_DATA_FILES_DATA  table",BED_DATA_PROCESS)

    if (transOverrDf !=null && transChallDf !=null ){
      transChallOverrDf=transChallDf.union(transOverrDf)
    }else if (transChallDf !=null){
      transChallOverrDf=transChallDf
    }else if (transOverrDf !=null){
      transChallOverrDf=transOverrDf
    }
    startControlTableDataProcess(rawChallDF,getRawDataFrameHWMColumn,REDI_BEDS_CHALL_CONTROL_KEY,PROCESS_CONTROL_INPROGRESS,startTimeBEDDATA.toString,"","processing to store fetched records  from ODS BED2_CB_DATA_FILES_DATA into Hive ",BED_DATA_PROCESS)
    startControlTableDataProcess(rawOverrDF,getRawDataFrameHWMColumn,REDI_BEDS_OVERR_CONTROL_KEY,PROCESS_CONTROL_INPROGRESS,startTimeBEDDATA.toString,"","processing to store fetched records  from ODS BED2_CB_DATA_FILES_DATA into Hive ",BED_DATA_PROCESS)
    finalDF1=transformChallOverrDf(transChallOverrDf)
    if (finalDF1!=null){
      BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"Started pushing the data into Hive tables " + REDI_BED_AUDIT_TABLE)
      storeDataToHive(reorderSourceTableSchema(BED_AUDIT_TABLE_COL_ORDER, addAuditColumns(finalDF1)))
    }
    val rawBedDF = transChallOverrDf.drop("ProcessYYMMDD").drop("DataProcYYMMDD")
    storeDataToHDFS(rawBedDF)


    if (rawOverrDF.count()>0){
      updateControlTables(rawOverrDF,getRawDataFrameHWMColumn ,REDI_BEDS_OVERR_CONTROL_KEY,startTimeBEDDATA.toString )
    }
    if (rawChallDF.count()>0){
      updateControlTables(rawChallDF,getRawDataFrameHWMColumn , REDI_BEDS_CHALL_CONTROL_KEY,startTimeBEDDATA.toString)
    }



    BEDDataTransformationLogger.debug(BEDDataIngestionProcess_DEBUG +"End of bedDataPipeline ")


  }
}
