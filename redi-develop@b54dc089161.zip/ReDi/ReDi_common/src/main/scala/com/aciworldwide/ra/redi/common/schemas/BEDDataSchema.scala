package com.aciworldwide.ra.redi.common.schemas

import java.sql.Timestamp

case class BEDDataSchemas (oid:String, bedprocessdate:String, beddispostionredi:String, bedclientreasoncode:String, bedclientdesc:String, dataprocdate:String,
                           bedclientid:String, bedsource:String, recommendation:String, currentstatus:String, decision:String, challstatus:String, bedfraudyn:String
                           , BEDDataProcYYYYMMDD:String, REALFRAUDYN:String, BEDDataProcDate:String, realfraudtype:String, realfraudyyyymmdd:Timestamp, realfrauddatebae:String
                           , realfrauddate:String)/*
                          ,beddatafilename:String,bedotherinfo1:String,bedotherinfo2:String,bedothercount1:String,bedothercount2:String,bedremarks:String
                          ,bedreferenceid:String,bedlinenumber:String)*/
