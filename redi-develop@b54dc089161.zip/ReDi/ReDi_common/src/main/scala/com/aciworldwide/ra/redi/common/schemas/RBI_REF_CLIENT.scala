package com.aciworldwide.ra.redi.common.schemas
import java.sql.Timestamp
import scala.Array
case class RBI_REF_CLIENT (ClientID :String,
                           SubClientID :String,
                           ClientName :String,
                           SubClientName :String,
                           Affiliate :String ,
                           RSActive :String,
                           Sector :String,
                           SectorGroup :String,
                           Client12 :String,
                           RSLastUpdatedBy :String,
                           RSLastUpdated : Timestamp,
                           ClientSet :Array[String],
                           PSP_GROUP :String,
                           ClientCurr :String,
                           SubClientCurr :String)
