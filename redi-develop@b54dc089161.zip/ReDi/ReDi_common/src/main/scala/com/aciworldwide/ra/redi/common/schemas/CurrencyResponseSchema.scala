package com.aciworldwide.ra.redi.common.schemas

case class CurrencyResponseSchema(rate: String, beginRateTime: String,
                                  endRateTime: String, currencyCode: String, lastUpdateTime: String) {

}
