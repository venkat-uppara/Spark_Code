package com.aciworldwide.ra.redi.common.actions
import com.aciworldwide.ra.redi.common.actions.CurrencyRatesHistoricalDataProcess.{CURRENCY_RATES_HIST_DATA_PROCESS_ERROR, CURRENCY_RATES_HIST_DATA_PROCESS_INFO, CurrencyRatesHistoricalDataPipeLine}
import com.aciworldwide.ra.redi.common.controllers.CurrencyRatesHistoricalDataController
import com.aciworldwide.ra.redi.common.services.EstablishConnections
import org.apache.logging.log4j.LogManager

object CurrencyRatesHistoricalDataProcessFile extends CurrencyRatesHistoricalDataController with EstablishConnections with Serializable{

  @transient lazy val currencyRatesDatalogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    currencyRatesDatalogger.info(CURRENCY_RATES_HIST_DATA_PROCESS_INFO +" : Start of Currency Historical data from CSV file process")
    try{
      CurrencyRatesHistoricalDataFromCSVPipeLine()
    } catch{
      case exce: Exception => currencyRatesDatalogger.error(CURRENCY_RATES_HIST_DATA_PROCESS_ERROR + " : We have an error in the Currency Historical data from CSV file processing " +  exce)
        System.exit(1)
    } finally {
      currencyRatesDatalogger.info(CURRENCY_RATES_HIST_DATA_PROCESS_INFO +" : End of Currency Historical data from CSV file  process")
    }
  }
}