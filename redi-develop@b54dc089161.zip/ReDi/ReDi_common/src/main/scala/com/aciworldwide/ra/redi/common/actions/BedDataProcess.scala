package com.aciworldwide.ra.redi.common.actions


import com.aciworldwide.ra.redi.common.controllers.BedDataController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import org.apache.logging.log4j.LogManager

object BedDataProcess extends BedDataController with EstablishConnections with Serializable with Loggers{

  def main(args: Array[String]): Unit = {
    @transient lazy val BEDDataIngestionlogger = LogManager.getLogger(getClass.getName)
    try{
      bedDataPipeline()
    } catch{
      case e: Exception => BEDDataIngestionlogger.error(BEDDataIngestionProcess_ERROR + ":We have an error in the BED Data Process " + e.printStackTrace())
        System.exit(1)
    } finally {
      BEDDataIngestionlogger.debug(BEDDataIngestionProcess_DEBUG + " :End of BED Update process")
    }




  }

}
