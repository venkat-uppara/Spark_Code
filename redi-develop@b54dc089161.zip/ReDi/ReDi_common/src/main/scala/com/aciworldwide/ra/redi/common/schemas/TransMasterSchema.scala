package com.aciworldwide.ra.redi.common.schemas
import java.sql.Timestamp
case class TransMasterSchema(OID:String, OIDDATE:Timestamp, CLIENTID:String, SUBCLIENTID: String, CURRCD :String)

