package com.aciworldwide.ra.redi.common.dao
import java.text.SimpleDateFormat

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.aciworldwide.ra.redi.common.utils.SetupConnections
import com.aciworldwide.ra.redi.common.utils.DateUtils
import java.sql.{Connection, DriverManager, ResultSet}
import java.util.Calendar

import com.aciworldwide.ra.redi.common.schemas.{ClientMasterSchema, TransMasterSchema}

import scala.collection.mutable.MutableList
class ClientMasterDataDao(sc:SparkSession) extends DateUtils with DatabaseServices
  with ReDiConstants with Serializable with Loggers {

 import sc.implicits._
  /*
  This is the method to fetch the postgres data  from database
   */
  val setupConnections = new SetupConnections
  def fetchClientMasterHWMData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to fetch Postgres Data. " + schemaname + "." + tablename)
    val clientMasterHWMdf1 = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Obtained to fetch postgres Data. " + schemaname + "." + tablename)
        clientMasterHWMdf1
  }


  /*
   This is the method to fetch the client  data  from oracle database
    */
  def fetchClientMasterData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    //val setupConnections = new SetupConnections
    logRegularMessage("Starting to fetch Client Master Data. " + schemaname + "." + tablename)
    val clientMasterDatadf = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Obtained to fetch Client Master Data. " + schemaname + "." + tablename)
        clientMasterDatadf

  }

  /* getting the TransMaster table data from Hive */
  def getTransMasterTable():DataFrame={
    //val result = readDataIntoJdbcRDDFromHiveTable(REDI_TRANS_MASTER_CORE)

    val dateformat = "YYYYMMdd"
    val calendar = Calendar.getInstance()
    calendar.roll(Calendar.DAY_OF_YEAR, TRANSACTION_DAYS )
    val currentdate = calendar.getTime()
    val format = new SimpleDateFormat(dateformat)
    val inputdate = format.format(currentdate)

    sc.sql("set spark.sql.hive.convertMetastoreOrc=true")
    sc.sql("select clientId, SubClientId, currcd, max(OIDDateYYYYMMDD) AS  OIDDateYYYYMMDD from " +
      s"redi.trans_master_core where OIDDateYYYYMMDD >=$inputdate  group by  clientId, SubClientId, currcd")
  }



  /* getting the RBI_REF_CLIEN table data from Hive*/
  def getRBIRefClientTable():DataFrame= {
    sc.sql("select * from redi.RBI_REF_CLIENT")
  }

  /*
   This is the method to fetch the max of last_updated column in client  data  from oracle database
    */
  def fetchmaxdatefromClientMasterData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to fetch max date. " + schemaname + "." + tablename)
    val clientMasterDatadf = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Obtained  Client max last updated date. " + schemaname + "." + tablename)
    clientMasterDatadf

  }

  /*
  Update the High water mark on the currency data
   */

  def UpdateHWMforClientData(Cop_Master_maxdate_conv: String,processName : String ): Unit = {
    val connection = setupConnections.createScalaConnection(REDI_CONTROL_DATABASE, POSTGRES_CONN_TYPE)
    try {
      val statement = connection.createStatement()
      val update_currency_HWM = "UPDATE  " + REDI_CONTROL_TABLE + " SET processhighwatermark = " + "'" + Cop_Master_maxdate_conv + "'" + "  WHERE " + REDI_CONTROL_TABLE + ".processname = " + "'" + processName + "'"

      print(update_currency_HWM)
      statement.executeUpdate(update_currency_HWM)
    } catch {
      case e: Exception => logRegularMessage("Exception occured in storing the currency High water mark" + e)
    } finally {
      connection.close()
    }

  }
  /*
    Read the Hive Transactional tables via HIVE JDBC
   */

  def getClientMasterData(resultSet: ResultSet): MutableList[ClientMasterSchema] ={
    val fetchedResponse = MutableList[ClientMasterSchema]()
    while(resultSet.next()){
      var rec = ClientMasterSchema(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5), resultSet.getString(6),
        resultSet.getString(7), resultSet.getString(8), resultSet.getString(9), resultSet.getString(10),
        resultSet.getString(11), resultSet.getString(12), resultSet.getString(13), resultSet.getString(14),
        resultSet.getString(15), resultSet.getString(16), resultSet.getString(17), resultSet.getString(18),
        resultSet.getString(19), resultSet.getString(20), resultSet.getString(21), resultSet.getString(22),
        resultSet.getString(23), resultSet.getString(24), resultSet.getString(25), resultSet.getString(26),
        resultSet.getString(27), resultSet.getString(28), resultSet.getString(29), resultSet.getString(30),
        Array(resultSet.getString(31)), Array(resultSet.getString(32)), resultSet.getString(33), resultSet.getTimestamp(34))
      fetchedResponse += rec
    }
    fetchedResponse
  }

  def getTranMasterData(resultSet: ResultSet): MutableList[TransMasterSchema] ={
    val fetchedResponse = MutableList[TransMasterSchema]()
    while(resultSet.next()){
      var rec = TransMasterSchema(resultSet.getString(1), resultSet.getTimestamp(2), resultSet.getString(3), resultSet.getString(4), resultSet.getString(5))
      fetchedResponse += rec
    }
    fetchedResponse
  }



}
