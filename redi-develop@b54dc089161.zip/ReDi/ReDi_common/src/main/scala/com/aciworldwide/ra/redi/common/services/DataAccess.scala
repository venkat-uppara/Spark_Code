package com.aciworldwide.ra.redi.common.services

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import org.apache.spark.sql.{DataFrame, SparkSession}

trait DataAccess extends ReDiConstants with Serializable with Loggers {
  def createSession(master: String, name: String): SparkSession

  def readHiveData(spark: SparkSession, table: String): DataFrame

  def writeHiveData(table: String, format: String, dataframe: DataFrame): Unit

  def readKafkaData(spark: SparkSession, topic: String): DataFrame

  def writeKafkaData(dataframe: DataFrame): Unit
}
