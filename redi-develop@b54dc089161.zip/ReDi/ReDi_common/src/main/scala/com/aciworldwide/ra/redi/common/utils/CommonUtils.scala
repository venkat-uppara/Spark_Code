package com.aciworldwide.ra.redi.common.utils

import java.text.SimpleDateFormat
import java.util.{Calendar, TimeZone}
import java.sql.Timestamp
import java.time.{LocalDateTime, ZoneId}
import java.time.format.DateTimeFormatter

import com.aciworldwide.ra.encryptor.Encryptor
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.Loggers
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.DatabaseServices
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.joda.time.{DateTime, DateTimeZone}
import org.joda.time.format.DateTimeFormat

import scala.util.control.Breaks.{break, breakable}


case class Result(
                   recipientState: String,
                   recipientCity: String,
                   recipientZipCd: String
                 )

trait CommonUtils extends Serializable with ReDiTableSchemas with DatabaseServices with ReDiConstants {

  @transient lazy val commonUtilslogger = LogManager.getLogger(getClass.getName)

  val saltcc: String = ConfigFactory.load().getString("local.common.saltcc.value")
  val encrpt = new Encryptor()

  def addAuditColumns(inputdataFrame: DataFrame): DataFrame ={
    val outputDataFrame = inputdataFrame.withColumn(WHENLOADED, current_timestamp())
      .withColumn(WHOLOADED,lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn(WHENUPDATED, current_timestamp() )
      .withColumn(WHOUPDATED, lit(WHO_LOADED_UPDATED_INSERT))
    outputDataFrame
  }

  def concatArrayValue = udf((array: Seq[String],newvalue : String)=>
    if( array.isEmpty && array.length > 0) array :+ newvalue  else null)

  /**
    *
    * @param inputdate in String
    * @param targetTimeZone
    * @return java.sql.Timestamp
    * @author HPA
    * @version 1.0 Intial draft 17/08/2018
    * @version 1.1 Removed the servertimezone setting of EST
    * This method converts a string input to a provided timezone
    */
  def ConvertTimeZone(inputdate: String, targetTimeZone: String): Timestamp ={

    val simpleformat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

    val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))

    java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(inputdate)))

  }

  /**
    *
    * @param inputdate in Long Value
    * @param targetTimeZone
    * @return java.sql.Timestamp
    * @author HPA
    * @version 1.0 Intial draft 17/08/2018
    * @version 1.1 Removed the servertimezone setting of EST
    * This method converts a epoch time long value to a Timestamp based on target time zone.(Ex: targetTimeZone: America/New_York)
    */

  def ConvertTimeZone(inputdate: Long, targetTimeZone: String): Timestamp ={

    val input = new java.util.Date(inputdate)

    val simpleformat = new SimpleDateFormat(TARGDATEFORMAT)
    simpleformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))
    java.sql.Timestamp.valueOf(simpleformat.format(input))

  }

  def split_string_array = udf((oldString: String,newString : String) => {
    val newValue = newString.substring(0, newString.length - 1).split(",").map(_.trim).mkString("[\'","\',\'","\']")
    if( oldString != null && !oldString.isEmpty && !oldString.substring(1, oldString.length - 1).split(",").map(_.trim).toList.contains ("'FDSDSDENY'")){
      oldString.replace("]",",\'FDSDSDENY\' ]")
    } else if (oldString != null && !oldString.isEmpty && oldString.substring(1, oldString.length - 1).split(",").map(_.trim).toList.contains ("'FDSDSDENY'")){
      oldString
    } else{
      newValue
    }
  })


  /**
    * Write into Hive ACID Table
    * @param tableName
    * @param inputDataFrame
    */
  def storeDataIntoHive(tableName: String, saveMode:String, inputDataFrame: DataFrame ): Boolean ={
    var isHiveStore :Boolean = false;
    commonUtilslogger.info(COMMONDATAPROCESS_INFO +":Starting to push the data into Hive tables " + tableName)
    try {
      inputDataFrame.write.format(HIVE_WAREHOUSE_CONNECTOR)
        .mode(saveMode)
        .option("table", tableName)
        .save()
      isHiveStore = true
    }catch{
      case exp: Exception =>  commonUtilslogger.error(COMMONDATAPROCESS_ERROR+": We have an error on storing data into REDI.RBI_REF_CLIENT" + exp.printStackTrace())
    } finally {
      commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":End of Storing "+ tableName+ "data into Hive")
      isHiveStore
    }
    commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":successfully stored data into Hive table :"+ tableName)
    isHiveStore
  }
  /**
    * Store Controll Table
    *
    * @param inputdataset
    * @return
    */
  def storeHighWaterMarktoHive(inputDataSet: DataFrame): Boolean = {
    var isHighWaterMarktoHive: Boolean = false;
    commonUtilslogger.info(COMMONDATAPROCESS_INFO +":Starting to push the data into Hive tables " + REDI_PROCESS_CONTROL)
    try {
      storeDataIntoHive(REDI_PROCESS_CONTROL, APPEND_MODE, inputDataSet)
      isHighWaterMarktoHive = true;
    } catch {
      case exce: Exception => commonUtilslogger.error(COMMONDATAPROCESS_ERROR+":We have an error on storing HighWaterMark data into Hive" + exce.printStackTrace())
        isHighWaterMarktoHive
    } finally {
      commonUtilslogger.info(COMMONDATAPROCESS_INFO +":End of Storing HighWaterMark data into Hive")
      isHighWaterMarktoHive
    }
    isHighWaterMarktoHive
  }

  def getCurrentdateTimeStamp: Timestamp ={
    val today:java.util.Date = Calendar.getInstance.getTime
    val timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
    val now:String = timeFormat.format(today)
    val re = java.sql.Timestamp.valueOf(now)
    re
  }
  def controlTableDataProcess(inputDataFrame: DataFrame, maxDate: String, processName: String, ProcessCurrentStatus: String, startTime: String, endTime: String, description: String, ProcessGroup: String): Unit = {

    commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":Starting to enter controlTableDataProcess " + processName)

    val finalDataFrame = inputDataFrame.groupBy().agg(max(maxDate).alias("HIGHWATERMARK"))
      .withColumn("PROCESSNAME", lit(processName)).withColumn("NUMRECORDS", lit(inputDataFrame.count()))
      .withColumn("PROCESSCURRENTSTATUS", lit(ProcessCurrentStatus))
      .withColumn("StartTime", lit(startTime))
      .withColumn("endTime", lit(endTime))
      .withColumn("DESCRIPTION", lit(description))
      .withColumn("PROCESSGROUP", lit(ProcessGroup))
    storeHighWaterMarktoHive(reorderSourceTableSchema(CONTROL_TABLE_COL_ORDER, finalDataFrame))
    commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":completed to enter controlTableDataProcess" + processName)
  }


  def startControlTableDataProcess(inputDataFrame: DataFrame, HWXTime: String, processName: String, ProcessCurrentStatus: String, startTime: String, endTime: String, description: String, jobGroupName: String): Unit = {

    commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":Starting to enter startControlTableDataProcess " + processName)

    val finalDataFrame = inputDataFrame.groupBy().agg(min(HWXTime).alias("HIGHWATERMARK"))
      .withColumn("PROCESSNAME", lit(processName)).withColumn("NUMRECORDS", lit(inputDataFrame.count()))
      .withColumn("PROCESSCURRENTSTATUS", lit(ProcessCurrentStatus))
      .withColumn("StartTime", lit(startTime))
      .withColumn("endTime", lit(endTime))
      .withColumn("DESCRIPTION", lit(description))
      .withColumn("PROCESSGROUP", lit(jobGroupName))
    storeHighWaterMarktoHive(reorderSourceTableSchema(CONTROL_TABLE_COL_ORDER, finalDataFrame))
    commonUtilslogger.debug(COMMONDATAPROCESS_DEBUG +":Starting to enter startControlTableDataProcess " + processName)
  }

  def funcMaskCardNo: UserDefinedFunction = udf((cardNo: String) => {
    var finalcc =""
    if (cardNo != null && !cardNo.isEmpty) {
    // decrypting the Card No before masking.
//      var dcardNo = cardNo
    var dcardNo =   encrpt.decryptBase64EncodedString(cardNo)
    var trimlen = dcardNo.trim.length
    //var maskchar = '*'.toString().*((if (trimlen > 20) 20 else trimlen) - 10)
    var maskchar = '*'.toString().*(trimlen - 10)
      finalcc = dcardNo.trim.substring(0, 6) + maskchar + dcardNo.trim.takeRight(4)
    }
    finalcc
  })

  /** encrpting cardno **/

  def encryptCardNo: UserDefinedFunction = udf((inputString: String) => {
    var finalcc = ""

    if(inputString != null && inputString.matches("\\d+")) {
      finalcc = encrpt.encryptAndBase64Encode(inputString)
    }
    else {
      finalcc =  inputString
    }
    finalcc
  })

/** Hash Card No Function **/
 /**
    * @author : Mayank M
    * @version : Initial Draft 1.1 18/02/2019
    * @note : Few additional checks have been added to handle Junks values,etc
    *
    */
 def funcHashCardNo: UserDefinedFunction = udf((inputString: String) => {
   var finalcc = ""

   if(inputString != null && inputString.matches("\\d+")) {
     val inputStrTrim = inputString.trim.concat(saltcc)
     val md = java.security.MessageDigest.getInstance("SHA-1")
     finalcc =  md.digest(inputStrTrim.getBytes("UTF-8")).map("%02x".format(_)).mkString
   }
   else if(inputString != null && !inputString.matches("\\d+")){
     val decValue = encrpt.decryptBase64EncodedString(inputString)
     val inputStrTrim = decValue.trim.concat(saltcc)
     val md = java.security.MessageDigest.getInstance("SHA-1")
     finalcc =  md.digest(inputStrTrim.getBytes("UTF-8")).map("%02x".format(_)).mkString
   }
   finalcc
 })
  
  /* @author KP MERF-9082 30/08/2018 Function used for ClientDateYYYYMMDD calculation
*/
  def ConvertTimeZoneYYYYMMDD(inputdate: String, targetTimeZone: String): String ={

    val simpleformat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSS)
    simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

    val targetformat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
    targetformat.setTimeZone(TimeZone.getTimeZone(targetTimeZone))

    String.valueOf(targetformat.format(simpleformat.parse(inputdate)))
  }


  //This function is to convert the timezone for a particular client
 /**
    * @author : Mayank M
    * @version : Initial Draft 1.1 18/02/2019
    * @note : This function is to give the converted the timezone for a particular client, few additional checks been added to handle junk values for
    *       OIDdate
    *
    */
  def getTZConvertedDate = udf((OIDDate: String, TZValue: String) => {

    var returnDate = ""

    if(OIDDate.matches("\\d+") && ((OIDDate.length() == 14) || (OIDDate.length() == 17))) {
      var inputTimeZone = TZValue
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }

      val simpleformat = new SimpleDateFormat(DATEFORMATEPOCH)
      simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

      val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
      targetformat.setTimeZone(TimeZone.getTimeZone(inputTimeZone))

      returnDate = java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(OIDDate))).toString
      //    val returnDate = ConvertTimeZone(OIDDate, inputTimeZone)
    }

    returnDate

  })

  def getTZSubConvertedDate = udf((OIDDate: String, TZValue: String) => {

    var returnDate = ""

    if(OIDDate.matches("\\d+") && ((OIDDate.length() == 14) || (OIDDate.length() == 17))) {
      var inputTimeZone = TZValue
      if (inputTimeZone == null || inputTimeZone.isEmpty) {
        inputTimeZone = "America/New_York"
      }

      val simpleformat = new SimpleDateFormat(DATEFORMATEPOCH)
      simpleformat.setTimeZone(TimeZone.getTimeZone(SERVER_TIMEZONE))

      val targetformat = new SimpleDateFormat(TARGDATEFORMAT)
      targetformat.setTimeZone(TimeZone.getTimeZone(inputTimeZone))

      returnDate = java.sql.Timestamp.valueOf(targetformat.format(simpleformat.parse(OIDDate))).toString
      //    val returnDate = ConvertTimeZone(OIDDate, inputTimeZone)
    }

    returnDate

  })

  /* This function is used to convert timezone from est to utc time zone */
  def convertedtzForOidDate = udf((OIDDate: String) => {

    var returnDate = ""

    if(OIDDate.matches("\\d+")) {
      val ldt = LocalDateTime.parse(OIDDate, DateTimeFormatter.ofPattern(INGESTIONDATEFORMATYYYYMMDDHHMMSS))
      val estZoneId = ZoneId.of("America/New_York")
      val estZonedDateTime = ldt.atZone(estZoneId)
      val utcZoneId = ZoneId.of("UTC")
      val nyDateTime = estZonedDateTime.withZoneSameInstant(utcZoneId)
      val format = DateTimeFormatter.ofPattern(DATEFORMATYYYY_MM_DD_HHMMSS)
      returnDate = format.format(nyDateTime)
    }
    returnDate
  })

  /**
    * @author : Mayank M
    * @version : Initial Draft 1.0 01/02/2019
    * @note : This function is to give a current_timestamp value to each and every row
    *
    */

  def current_time: UserDefinedFunction = udf(() => {
    val date: LocalDateTime =  java.time.LocalDateTime.now()
    DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").format(date).toString
  })

  def current_time_utc  = udf(() => {
    val dates = DateTime.now(DateTimeZone.UTC)
    val dateOut = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss.SSS")
    dateOut.print(dates)
  })

  /**
    * @author : Mayank M
    * @version : Initial Draft 1.0 01/02/2019
    * @note : This function is to give the SDSfraudAnswerr to each and every row for the transaction to be marked with realFraud Y or N
    *
    */

  def returnFlag: UserDefinedFunction = udf((a: Seq[String], b: Seq[String]) => {
    val SDS = "SDS"
    val DENY = "DENY"
    val CHALLENGE = "CHALLENGE"
    var status = ""

    if(a.nonEmpty && b.nonEmpty) {
      val firstArray = a.toArray
      val secondArray = b.toArray


      val isSDSPresent = firstArray.contains(SDS)
      val isDENYPresent = secondArray.contains(DENY)
      val isCHALLENGEPresent = secondArray.contains(CHALLENGE)

      if (isSDSPresent && (isDENYPresent || isCHALLENGEPresent)) {
        var indexOfFirst = firstArray.indexOf(SDS)

        breakable {
          //        while (indexOfFirst != -1) {
          if (!status.contains("D") && secondArray(indexOfFirst).equals(DENY)) {
            status += "D"
          }
          else if (!status.contains("C") && secondArray(indexOfFirst).equals(CHALLENGE)) {
            status += "C"
          }
          if (status.contains("C") && status.contains("D")) {
            break
          }
          //          indexOfFirst = firstArray.indexOf(SDS, indexOfFirst + 1)
          //        }
        }
      }
    }

    status

  })

  def returnFlagForupdateRecReasonWithNine: UserDefinedFunction = udf((a: Seq[String]) => {
    val RULEIDSTARTINGWITHB = "B.*"
    val RULEIDSTARTINGWITH = "9.*"

    var status = ""

    if (a.nonEmpty) {
      val firstArray: Array[String] = a.toArray.filter(it => it != null)


      val isRuleIdWithBPresent = firstArray.count(_.matches(RULEIDSTARTINGWITHB))
      val isRuleIdWith9Present = firstArray.count(_.matches(RULEIDSTARTINGWITH))


      if (isRuleIdWithBPresent > 0 && isRuleIdWith9Present > 0) {
        status = "9B"
      } else if (isRuleIdWithBPresent > 0 && isRuleIdWith9Present == 0) {
        status = "B"
      } else if (isRuleIdWithBPresent == 0 && isRuleIdWith9Present > 0) {
        status = "9"
      }
    }

    status

  })


  def transformBinData = udf((a: Seq[String]) => {

    val REGEXFIRST = ".*GIFT.*CARD.*"
    val REGEXSECOND = "(.*VIRT.*GIFT.*CARD.*)|(.*EGIFT.*CARD.*)|(.*ELECTRONIC.*GIFT.*CARD.*)|(.*ONLINE.*GIFT.*CARD.*)"

    var flag20 = ""

    if (a.nonEmpty) {
      val firstArray: Array[String] = a.toArray.filter(it => it != null)


      val isREGEXFIRSTPresent = firstArray.count(_.matches(REGEXFIRST))
      val isREGEXSECONDPresent = firstArray.count(_.matches(REGEXSECOND))


      if (isREGEXFIRSTPresent > 0) {
        flag20 = "G"
      } else if (isREGEXSECONDPresent > 0) {
        flag20 = "V"
      }
    }

    flag20


  })


  def updateRecReasonwithTSW: UserDefinedFunction = udf((a: Seq[String]) => {
    val RULEIDWITHTSW = "TSW"
    val RULEIDWITHDVE = "DVE"

    var status = ""

    if (a.nonEmpty) {
      val firstArray: Array[String] = a.toArray.filter(it => it != null)


      val isRuleIdWithTSWPresent = firstArray.contains(RULEIDWITHTSW)
      val isRuleIdWithDVEPresent = firstArray.contains(RULEIDWITHDVE)


      if (isRuleIdWithTSWPresent) {
        status = "TSW"
      } else if (isRuleIdWithDVEPresent) {
        status = "DVE"
      }
    }

    status

  })

  def CountrymatchingPhase2: UserDefinedFunction = udf((a: Seq[String], b: Seq[String], c: Seq[String]) => {
    var RecipientState = ""
    var RecipientCity = ""
    var RecipientZipCd = ""

    if (a.nonEmpty) {
      val firstArray: Array[String] = a.toArray.filter(it => it != null)
      if (firstArray.length > 0) {
        RecipientState = firstArray.max
      }

    }

    if (b.nonEmpty) {
      val secondArray: Array[String] = b.toArray.filter(it => it != null)
      if (secondArray.length > 0) {
        RecipientCity = secondArray.max
      }

    }

    if (c.nonEmpty) {
      val thirdArray: Array[String] = c.toArray.filter(it => it != null)
      if (thirdArray.length > 0) {
        RecipientZipCd = thirdArray.max
      }

    }

    Result(RecipientState, RecipientCity, RecipientZipCd)

  })

  /**
    * @author : Mayank M
    * @version : Initial Draft 1.0 01/02/2019
    * @note : This function is to give the current time stamp in EPOCH as Long data type
    *
    */

  def current_time_unix_timestamp : UserDefinedFunction = udf(() => {
    val unixTimestamp : Long = System.currentTimeMillis
    unixTimestamp
  })

  /**
    * @author : Mayank M
    * @version : Draft 1.0 18/02/2019
    * @note : This function is to give the YYYYMMDD from oiddate to be used as a partitioning for the tables
    *
    */

  def oIdDateWithoutTimePart = udf((oidDate: String) => {
    var date = ""
    if(oidDate != null  && oidDate.matches("\\d+")) {
      val inputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDDHHMMSSSSS)
      val outputFormat = new SimpleDateFormat(DATEFORMATYYYYMMDD)
      date = outputFormat.format(inputFormat.parse(oidDate))
    }
    date
  })

  def ruleNameCheck(ruleIDList: Array[String],index:Int): Boolean ={
    val ruleNameCard = "CARDNO"
    val ruleNameCMail = "CUSTEMAIL"
    val ruleNameVirt = "VIRTIOVDEVICEID"
    val ruleNameCHome = "CUSTHOMEPHONE"
    val ruleNameCWork = "CUSTWORKPHONE"
    val ruleNameCId = "CUSTID"

    if (ruleIDList(index).equals(ruleNameCard) || ruleIDList(index).equals(ruleNameCMail)|| ruleIDList(index).equals(ruleNameVirt) ||ruleIDList(index).equals(ruleNameCHome)
      ||ruleIDList(index).equals(ruleNameCWork)||ruleIDList(index).equals(ruleNameCId)){
      true
    }else{
      false
    }

  }

  /**
    * @author : Kaustav M
    * @return : Retuns realfraud value(Y/N)
    * @note : This fuction returns realfraud value based on ruleid,recommend,rulename etc.
    */

  def updateRealFraudYN:UserDefinedFunction = udf ((a: Seq[String], b: Seq[String], c:Seq[String],afflt:String,clientID:String,recommd:String) => {

    val ruleSourceDve = "DVE"
    val ruleSourceTSW = "TSW"
    var realFraudYN= "Y"
    // var count="A"

    if (a.nonEmpty && b.nonEmpty && c.nonEmpty){
      val ruleSources = a.toArray
      val ruleIds = b.toArray
      val ruleNames = c.toArray

      if( recommd == "DENY"){
        // count = count + "B"
        breakable{
          for (ruleid <- ruleIds){
            if (ruleid.startsWith("B") || ruleid.startsWith("9")){
              var indexOfFirst = ruleIds.indexOf(ruleid)
              if(ruleSources(indexOfFirst) == "DVE" || ruleSources(indexOfFirst) == "TSW"){
                if ((afflt == "US" && clientID != "000031")|| ruleNameCheck(ruleNames,indexOfFirst)){
                  break
                }else{
                  realFraudYN = "N"
                }
              }else {
                realFraudYN = "N"
              }
            }else{
              realFraudYN = "N"
            }
          }
        }
      }else{
        realFraudYN = "N"
      }
    }else {
      realFraudYN = "N"
    }
    realFraudYN
  })
}