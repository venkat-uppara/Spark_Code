package com.aciworldwide.ra.redi.common.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.DatabaseServices
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.DataFrame
import com.aciworldwide.ra.redi.common.dao.CurrencyRatesHistoricalDataDao
import com.aciworldwide.ra.redi.common.actions.CurrencyRatesHistoricalDataProcess.{CURRENCY_RATES_HIST_DATA_PROCESS_INFO, getClass}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.apache.spark.sql.functions._

class CurrencyRatesHistoricalDataController  extends BaseController with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with ReDiTableSchemas{

  @transient lazy val currencyRatesDataControllerlogger = LogManager.getLogger(getClass.getName)

  val currencyRatesHistoricalData = new CurrencyRatesHistoricalDataDao(createSparkSession(CURRENCYCONVRATEAPP))

  val sparkSession = createSparkSession(CURRENCYCONVRATEAPP)

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()

  hiveSession.setDatabase(REDI_DATABASE)

  import sparkSession.implicits._

  def createCurrencyRatesHistoricalDataSet(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to Fetch Currency Rates Historical Dataset into processing layer " + schemaname +"."+ tablename)
    currencyRatesHistoricalData.fetchCurrencyHistRates(tablename, connectiontype, schemaname,numpartitions)
  }
  /*
   Store the currency data to Hive once in a day
  */

  def storeCurrencyDataHive(currencyData: DataFrame): Unit ={

    val startTimeCCService = getCurrentdateTimeStamp

    currencyRatesDataControllerlogger.debug(CURRENCY_RATES_HIST_DATA_PROCESS_INFO+" latest currency rates from API to Storing into hive table  ")

    controlTableDataProcess(currencyData,"RSLastUpdated",REDI_CURR_HIST_DATA_CONTROL_KEY,PROCESS_CONTROL_INPROGRESS,startTimeCCService.toString,"","Fetched records from Currency Rates Historical Dataset and storing into Hive Table  ",CURRENCY_RATES_HIST_DATA_PROCESS)

    currencyRatesHistoricalData.storeDataIntoHive(CURR_CONV_TABLE,APPEND_MODE,currencyData,"currencydateyyyy")

    controlTableDataProcess(currencyData,"RSLastUpdated",REDI_CURR_HIST_DATA_CONTROL_KEY,PROCESS_CONTROL_COMPLETED,startTimeCCService.toString,getCurrentdateTimeStamp.toString,"Fetched records from Currency Rates Historical Dataset  and Stored  into Hive Table ",CURRENCY_RATES_HIST_DATA_PROCESS)
  }

  /*
  Transformation will be applied on the reason codes
   */
  def processCurrencyRatesHistoricalDataCodes(CurrencyRatesHistoricalDatadf: DataFrame): DataFrame = {
    logRegularMessage("Starting to add new columns to result data frame.")
    val CurrencyRatesHistoricalDataDf=CurrencyRatesHistoricalDatadf.select($"BEGIN_RATE_TIME".alias("CurrencyDate"),$"CURRCD".alias("DestCurrencyCode"),$"RATE".alias("ConversionRate"),$"LAST_UPDATE_TIME".alias("RSLastUpdated"))
    reorderSourceTableSchema(CURRENCY_CONVRATES_COL_ORDER,addAuditColumns(CurrencyRatesHistoricalDataDf))
  }

  def CurrencyRatesHistoricalDataPipeLine(): Unit ={
    val result = createCurrencyRatesHistoricalDataSet(SDB_EXCHANGE_RATES, ORACLE_CONN_TYPE, CLIENT_DATA_DATABASE,CB_REASON_CODE_PARTS.toInt)
    logRegularMessage("Ending to Fetch Currency Rates Historical Data into processing layer " + CLIENT_DATA_DATABASE +"."+ SDB_EXCHANGE_RATES)
    result.cache()
    val resultCount = result.count()
    storeCurrencyDataHive(processCurrencyRatesHistoricalDataCodes(result))
   logRegularMessage("Finished storing the data into Hive")
   logRegularMessage("Total of " + resultCount + " records got processed by currencyRatesHistoricalDataProcess from source "+   CLIENT_DATA_DATABASE + "." + SDB_EXCHANGE_RATES + "to destination" + CURR_CONV_TABLE)
  }
    def CurrencyRatesHistoricalDataFromCSVPipeLine(): Unit ={
    logRegularMessage("Fetch Currency Rates Historical Data from csv file ")
    val currencyFile = ConfigFactory.load().getString("local.common.currency.historicalCurrencyFile")
    val CurrencyDf = sparkSession
    .read.format("csv")
      .option("inferSchema", "true").option("header", true)
      .option("escape", ",")
      .csv(currencyFile)
  val updatedCurrencyDf= CurrencyDf.select(to_date($"lastUpdateTime","dd-MM-yyyy").alias("CurrencyDate"),$"currencycode".alias("DestCurrencyCode"),
        $"rate".alias("ConversionRate")).withColumn("RSLastUpdated",lit(current_timestamp()))
 val finalCurrencyDf= reorderSourceTableSchema(CURRENCY_CONVRATES_COL_ORDER,addAuditColumns(updatedCurrencyDf))
   val resultCount = finalCurrencyDf.count()
    storeCurrencyDataHive(finalCurrencyDf)
    logRegularMessage("Finished storing the data from csv file into Hive Currency Table")
    logRegularMessage("Total of " + resultCount + " records got processed by currencyRatesHistoricalDataProcess from CSV file into destination" + CURR_CONV_TABLE)
  }
}
