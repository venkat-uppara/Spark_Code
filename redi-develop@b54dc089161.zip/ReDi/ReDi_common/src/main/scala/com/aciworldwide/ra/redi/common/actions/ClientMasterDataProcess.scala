
package com.aciworldwide.ra.redi.common.actions

import com.aciworldwide.ra.redi.common.controllers.{APSFUserDataController, ClientMasterDataController}
import com.aciworldwide.ra.redi.common.services.EstablishConnections
import org.apache.logging.log4j.LogManager

object ClientMasterDataProcess extends ClientMasterDataController with EstablishConnections with Serializable {

  @transient lazy val clientMasterlogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    val apsf=new APSFUserDataController()
    clientMasterlogger.info(CLIENTMASTERDATAPROCESS_INFO +" : Start of ClientMasterData load process")
    try{
      clientMasterDataPipeLine()
      apsf.apsfDataPipeLine()
    } catch{
      case exce: Exception => clientMasterlogger.error(CLIENTMASTERDATAPROCESS_ERROR + " : We have an error in the ClientMasterData processing " +  exce)
        System.exit(1)
    } finally {
      clientMasterlogger.info(CLIENTMASTERDATAPROCESS_INFO +" : End of ClientMasterData load process")
    }


  }


}
