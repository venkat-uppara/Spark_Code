package com.aciworldwide.ra.redi.common.schemas

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.types._

trait ReDiTableSchemas extends Serializable{

  /*
  Method to reorder the columns based on the input
   */
  def reorderSourceTableSchema(columnString: String, inputdateFrame: DataFrame): DataFrame ={
    val columns: Array[String] = columnString.split(",")
    val outputDataFrame = inputdateFrame.select(columns.head, columns.tail:_*)

    outputDataFrame
  }

 /* def clientMasterSchemaStruct(): StructType = {
    val ClientMasterSchema = StructType(
      Array(
        StructField("ClientID", StringType),
        StructField("SubClientID", StringType),
        StructField("ClientName", StringType),
        StructField("SubClientName", StringType),
        StructField("Client12", StringType),
        StructField("ClientGroup", StringType),
        StructField("SubClientGroup", StringType),
        StructField("RSActive", StringType),
        StructField("ClientCurr", StringType),
        StructField("SubClientCurr", StringType),
        StructField("CMActive", StringType),
        StructField("CSIActive", StringType),
        StructField("BEDActive", StringType),
        StructField("ChallActive", StringType),
        StructField("CBActive", StringType),
        StructField("ClientSet", ArrayType(StringType))
      ))

    ClientMasterSchema
  } */
}
