package com.aciworldwide.ra.redi.common.controllers

import java.text.SimpleDateFormat
import java.util.Calendar

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.dao.ClientMasterDataDao
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.DatabaseServices
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._


class ClientMasterDataController extends DateUtils with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with ReDiTableSchemas {

  @transient lazy val clientMasterDatalogger = LogManager.getLogger(getClass.getName)

  val baseController = new BaseController()

  val sparkSession =baseController.createSparkSession(CLIENTMASTERDATAPROCESSAPP)

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()

  hiveSession.setDatabase(REDI_DATABASE)

  val clientMasterDao = new ClientMasterDataDao(sparkSession)
  var clientMasterData: DataFrame = _
  var clientMasterDF: DataFrame = _
  var clientMasterService : DataFrame = _
  var isClientMasterMerge = false
  import sparkSession.implicits._
  /**
    * @param tableName
    * @param connectionType
    * @param schemaName
    * @return DataFrame
    *
    */
  def fetchClientMasterData(tableName: String, connectionType: String, schemaName: String): DataFrame = {
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Starting to Fetch Client Master data into processing layer " + schemaName + "." + tableName)
    val clientMasterDF = clientMasterDao.fetchClientMasterData(tableName, connectionType, schemaName,CLIENT_MASTER_CODE_PARTS)
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Fetched Client Master data  from  " + schemaName + "." + tableName)
    clientMasterDF
  }

  /**
    * @param clientMasterDataDF
    * @retun null
    */
  def saveClientMasterDatatoHDFS(clientMasterDataDF: DataFrame): Unit = {
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Starting to load the data into HDFS location")
    clientMasterDao.saveDataintoHDFS(clientMasterDataDF, JDBC_TO_AVRO_FORMAT,
      ConfigFactory.load().getString("local.common.hdfs.CLIENT_MASTER_DATA_HDFS"), HDFS_STORAGE_DATE_EXT)
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Finished to load the data into HDFS location")
  }

  /**
    *  @param clientMasterServiceDatadf
    *  Store the Client Master Data to HDFS
    */
  def saveClientMasterServiceDatatoHDFS(clientMasterServiceDataDF: DataFrame): Unit = {
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Starting to load the data into HDFS location")
    clientMasterDao.saveDataintoHDFS(clientMasterServiceDataDF, JDBC_TO_AVRO_FORMAT,
      ConfigFactory.load().getString("local.common.hdfs.CLIENT_MASTER_SERVICE_DATA_HDFS"), HDFS_STORAGE_DATE_EXT)
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Finished to load the data into HDFS location")
  }

  /**
    * @param ClientMasterdata
    * @return DataFrame
    * Getting the properties from RBI_REF_CLIENT TABLE
    */
  def getRBIREFMainTable(ClientMasterdata : DataFrame):DataFrame={
    ClientMasterdata.select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"Affiliate".alias("RED_Affiliate"),$"RSActive",$"sector",$"SectorGroup",$"Client12",$"FlagSAE",$"FlagTRE",$"FlagDVE",$"FlagTSW",$"RSLastUpdated",$"RSLastUpdatedBy").withColumn("filterValue",lit("0"))
  }

  /**
    * @param rawClientMasterdata
    * @return DataFrame
    * Starting to transfer the client master data coming from oracles
    */
  def transformRawClientMasterData(rawClientMasterData : DataFrame ) : DataFrame ={
    rawClientMasterData.select($"EBIT_CLIENT_ID".alias("ClientID"),$"EBIT_SUB_CLIENT_ID".alias("SubClientID"),$"CLIENT_NAME".alias("ClientName"),$"SUBCLIENT_NAME".alias("SubClientName")
      ,$"RED_AFFILIATE".alias("Affiliate")
      ,$"RED_AFFILIATE".alias("RED_Affiliate"),
      when($"ACTIVE_STATUS" === "Active" ,lit("Y")).otherwise("N").alias("RSActive"),
      when($"sector" ==="OTHER","Other").when($"sector".like("Retail%Athletics/Foot%"),"Retail - Athletics/FootW/Sports").
        when($"sector".like("Retail%Elec%"),"Retail - Electrical/Electronics").
        when($"sector".like("Retail%Fashion%"),"Retail - Fashion").
        when($"sector".like("Retail%General%"),"Retail - General").
        when($"sector".like("Retail%Others%"),"Retail - Others").
        when($"sector".like("Telco%IVR/Web/C%"),"Telco - IVR/Web/Call Top Up").
        when($"sector".like("Telco%Retail S%"),"Telco - Retail Sales").
        when($"sector".like("Travel%Air%"),"Travel - Airline").
        when($"sector".like("Travel%Hotel%"),"Travel - Hotels").
        when($"sector".like("Travel%Travel Ag%"),"Travel - Travel Agency").
        when($"sector".like("Travel%Other%"),"Travel - Others").
        when($"sector".like("Travel%Railway%"),"Travel - Railway").otherwise($"sector").alias("Sector"),
      when($"sector".isin("Banking","Finance"),"Finance").when($"sector".like("Digital D%"),"Entertainment").
        when($"sector".isin("Gaming","Gambling","Media","Ticketing"),"Entertainment").
        when($"sector".isin("Gift Cards","Prepaid Cards"),"Retail").when($"sector".like("Retail%"),"Retail").when($"sector".like("Telco%"),"Telco").
        when($"sector".like("Travel%"),"Travel").otherwise("Other").alias("SectorGroup"),
      concat($"EBIT_CLIENT_ID", $"EBIT_SUB_CLIENT_ID").alias("Client12"),
      $"FlagSAE",$"FlagTRE",$"FlagDVE",$"FlagTSW",
      $"LAST_UPDATED".alias("RSLastUpdated"),
      $"LAST_UPDATEDBY".alias("RSLastUpdatedBy")
    ).withColumn("filterValue",lit("1"))
  }

  /**
    *
    * @param rawClientMasterdata
    * @param RBIRefClientDate
    * @return DataFrame
    * Merging the raw Client master table and RBIRefClient  Main table
    */
  def mergeTwoDataFrames(rawClientMasterData: DataFrame,RBIRefClientDate: DataFrame):DataFrame={
    rawClientMasterData.union(RBIRefClientDate)
  }


  /**
    *
    * @param rawRBIRefClientDf
    * @param RefClientDf
    * @return DataFrame
    *   Getting the ClientGroup and PSP Group properties from RBIRefClient  Main table
    */
  def updateClientPSPGroups(rawRBIRefClientDf: DataFrame,RefClientdf: DataFrame):DataFrame  ={

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":updateClientPSPGroups RefClientdf")

    val RefClientDf=  RefClientdf.select($"clientid", $"subclientid", $"clientgroup".as("Refclientgroup"), $"psp_group".as("Refpsp_group"),$"clientset".as("Refclientset") )

    val RefClientDF= rawRBIRefClientDf.join(RefClientDf,Seq("ClientID","SubClientID"),"full_outer")
      .select($"ClientID",
        $"SubClientID",
        $"ClientName",
        $"SubClientName",
        $"Affiliate",
        $"RED_Affiliate",
        $"Sector",
        $"SectorGroup",
        $"Client12",
        $"FlagSAE",
        $"FlagTRE",
        $"FlagDVE",
        $"FlagTSW",
        $"RSLastUpdated",
        $"RSLastUpdatedBy",
        $"RSActive",
        $"RefClientGroup".as("ClientGroup1") ,
        $"RefPSP_GROUP".as("PSP_GROUP1"),
        $"Refclientset".as("ClientSet"),
        $"filterValue").groupBy($"ClientID",
      $"SubClientID",
      $"ClientName",
      $"SubClientName",
      $"Affiliate",
      $"RED_Affiliate",
      $"Sector",
      $"SectorGroup",
      $"Client12",
      $"FlagSAE",
      $"FlagTRE",
      $"FlagDVE",
      $"FlagTSW",
      $"RSLastUpdated",
      $"RSLastUpdatedBy",
      $"RSActive",
      $"ClientSet",
      $"filterValue").agg(max($"ClientGroup1").as("ClientGroup") ,
      max($"PSP_GROUP1").as("PSP_GROUP")
    )
    RefClientDF

  }

  /**
    * @param transmaster
    * @return DataFrame
    * Caluculating ClientCurrency and  SubClient Currency
    */
  def fetchClientSubClientCurrency(transMaster: DataFrame):DataFrame={
    transMaster.createOrReplaceTempView("transMaster")
    hiveSession.session().sql("SELECT ClientID,SubClientId,CURRCD,count(distinct  ClientID ) As sum_client,count(distinct concat(ClientID,SubClientId)) as Sum_SubClient," +
      "Rank() over( PARTITION by ClientID  order by count(distinct  ClientID ) desc ) as Rank_client," +
      "Rank() over( PARTITION by ClientID,SubClientId  order by count(distinct concat(ClientID,SubClientId)) desc ) as Rank_Subclient from transMaster where CurrCd IS not null  group by ClientID,SubClientId,CURRCD")
  }


  def getTransMasterTable():DataFrame={
    val dateFormat = "YYYYMMdd"
    val calendar = Calendar.getInstance()
    calendar.roll(Calendar.DAY_OF_YEAR, TRANSACTION_DAYS )
    val currentDate = calendar.getTime()
    val format = new SimpleDateFormat(dateFormat)
    val inputDate = format.format(currentDate)
    hiveSession.executeQuery("select clientId, SubClientId, currcd, max(OIDDateYYYYMMDD) AS  OIDDateYYYYMMDD from " +
      s"redi.bi_trans_master_core where OIDDateYYYYMMDD >=$inputDate  group by  clientId, SubClientId, currcd")
    /* hiveSession.execute("select clientId, SubClientId, currcd, max(OIDDateYYYYMMDD) AS  OIDDateYYYYMMDD from " +
       s"redi.trans_master_core where OIDDateYYYYMMDD >='20190206'  group by  clientId, SubClientId, currcd")*/


  }
  /**
    * @clientMasterdata
    * @return DataFrame
    *  Getting the properties from RBI_REF_CLIENT TABLE
    */

  def getRBIREFMainTableCol(clientMasterData : DataFrame):DataFrame={
    clientMasterData.select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"Affiliate".alias("RED_Affiliate"),$"ClientGroup",$"PSP_GROUP",$"ClientSet",$"RSActive",$"sector",$"SectorGroup",$"Client12",$"FlagSAE",$"FlagTRE",$"FlagDVE",$"FlagTSW",$"RSLastUpdated",$"RSLastUpdatedBy")
  }

  /**
    * @param clientMasterData
    * @return DataFrame
    * Order the Client master table cloumns and adding the Audit Columns
    */
  def ProcessClientMaster(clientMasterData: DataFrame): DataFrame = {
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":Starting to add new columns to result data frame.")
    reorderSourceTableSchema(CLIENT_MASTER_COL_ORDER,
      addAuditColumns(clientMasterData))
  }

  /*
   * @param transmaster
   * @return DataFrame
   * Fetching the Client Currency
   */
  def fetchClientCurrency(transMaster: DataFrame):DataFrame={
    transMaster.filter($"Rank_client" === 1).select($"ClientID",$"SubClientId",$"CurrCd".alias("ClientCurr"))
  }
  /**
    *
    * @param transmaster
    * @return DataFrame
    *  Fetching the SubClient Currency
    */
  def fetchSubClientCurrency(transMaster: DataFrame):DataFrame={
    transMaster.filter($"Rank_Subclient" === 1).select($"ClientID",$"SubClientId",$"CurrCd".alias("SubClientCurr"))
  }

  /**
    * @param clientCurrency
    * @param subClientCurrency
    * @return DataFrame
    * Joining the Client Currency and SubClient Currency
    */
  def joinClientSubClientCurrency(clientCurrency: DataFrame,subClientCurrency: DataFrame):DataFrame  ={
    clientCurrency.createOrReplaceTempView("ClientCurrency")
    subClientCurrency.createOrReplaceTempView("SubClientCurrency")
    sparkSession.sql("SELECT a.ClientID,a.SubClientId as SubClientID ,a.ClientCurr,b.SubClientCurr FROM ClientCurrency as a full outer join SubClientCurrency as b on a.ClientID=b.ClientID and a.SubClientId=b.SubClientId")
  }

  /**
    * @param ClientMasterData
    * @param clientCurrency
    * @return DataFrame
    * Joining the ClientMaster and Client and SubClient Curreny
    */
  def newClientMasterData(ClientMasterData: DataFrame,clientCurrency: DataFrame):DataFrame  = {
    ClientMasterData.join(clientCurrency,Seq("ClientID","SubClientID"),"left_outer")
  }

  /**
    * @param ClientMasterData
    * @param clientCurrency
    * @return DataFrame
    * Joining the ClientMaster and Client and SubClient Curreny
    */
  def clientMasterData(ClientMasterData: DataFrame,clientCurrency: DataFrame):DataFrame  = {
    ClientMasterData.join(clientCurrency,Seq("ClientID","SubClientID"),"left_outer")
  }
  /**
    * @param clientMasterData
    * @return DataFrame
    * update the old Client Master Data
    */
  def finalDataFrameRecords(clientMasterData: DataFrame):DataFrame ={

    clientMasterData.createOrReplaceTempView("ClientMasterdata")

    val clientMasterDF = sparkSession.sql("SELECT ClientID,SubClientID,ClientName,SubClientName,Affiliate,RED_Affiliate,Sector,SectorGroup,ClientSet,Client12,FlagSAE,FlagTRE,FlagDVE,FlagTSW,RSLastUpdated,'RS' AS RSLastUpdatedBy,ClientCurr,SubClientCurr,RSActive ," +
      " ClientGroup,PSP_GROUP,ClientSet,Rank() over( PARTITION by ClientID,SubClientID,RSLastUpdated  order by  RSLastUpdated desc, filterValue desc) as Rank_client from  ClientMasterdata ")

    clientMasterDF.select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"RED_Affiliate".alias("Redi_Affiliate"),$"Sector",$"SectorGroup",$"Client12",
      when($"FlagSAE".isNull,value = "F").otherwise($"FlagSAE").as("FlagSAE"),
      when($"FlagTRE".isNull,value = "F").otherwise($"FlagTRE").as("FlagTRE"),
      when($"FlagDVE".isNull,value = "F").otherwise($"FlagDVE").as("FlagDVE"),
      when($"FlagTSW".isNull,value = "F").otherwise($"FlagTSW").as("FlagTSW"),
      $"RSLastUpdatedBy",$"ClientCurr",when($"SubClientCurr" === null,$"ClientCurr").otherwise($"SubClientCurr").alias("SubClientCurr"),
      $"RSActive", $"ClientGroup",$"PSP_GROUP",$"ClientSet")
      .withColumn("SubClientGroup",lit("")).withColumn("CMActive",lit("")).withColumn("CSIActive",lit("")).withColumn("CBActive",lit("")).withColumn("BEDActive",lit("")).withColumn("ChallActive",lit(""))
      .withColumn("RiskManager",lit("")).withColumn("AccManager",lit("")).withColumn("xMerchantIds",lit("")).withColumn("ClubRFX",lit("")).withColumn("CM2Active",lit("")).withColumn("LocalKPIs",lit(""))
      .withColumn("SilentRules",lit("")).withColumn("Alerts",lit("")).withColumn("TZClient",lit("")).withColumn("TZSubClient",lit("")).withColumn("Region",lit(""))
      .withColumn("Client12Set",lit("")).withColumn("DummyBucketCol",lit("")).withColumn("RSLastUpdated", current_timestamp())
  }
  /**
    * @param clientMasterData
    * @return DataFrame
    *  update the New Client Master Data
    */
  def finalNewClientMasterDataFrameRecords(clientMasterData: DataFrame):DataFrame ={

    clientMasterData.createOrReplaceTempView("ClientMasterdata")

    val clientMasterDF = sparkSession.sql("SELECT ClientID,SubClientID,ClientName,SubClientName,Affiliate,RED_Affiliate,Sector,SectorGroup,ClientSet,Client12,FlagSAE,FlagTRE,FlagDVE,FlagTSW,RSLastUpdated,'RS' AS RSLastUpdatedBy,ClientCurr,SubClientCurr,RSActive ," +
      " ClientGroup,PSP_GROUP,ClientSet,Rank() over( PARTITION by ClientID,SubClientID,RSLastUpdated  order by  RSLastUpdated desc, filterValue desc) as Rank_client from  ClientMasterdata ")

    val clientMasterFinal = clientMasterDF.filter($"Rank_client" === 1).select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"RED_Affiliate".alias("Redi_Affiliate"),$"Sector",$"SectorGroup",$"Client12",
      when($"FlagSAE".isNull,value = "F").otherwise($"FlagSAE").as("FlagSAE"),
      when($"FlagTRE".isNull,value = "F").otherwise($"FlagTRE").as("FlagTRE"),
      when($"FlagDVE".isNull,value = "F").otherwise($"FlagDVE").as("FlagDVE"),
      when($"FlagTSW".isNull,value = "F").otherwise($"FlagTSW").as("FlagTSW"),
      $"RSLastUpdated",
      $"RSLastUpdatedBy",$"ClientCurr",when($"SubClientCurr" === null,$"ClientCurr").otherwise($"SubClientCurr").alias("SubClientCurr"),
      $"RSActive",$"ClientGroup",$"PSP_GROUP",$"ClientSet")

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG +":clientMasterFinal")
    val clientMaster = clientMasterFinal.select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"Redi_Affiliate",$"Sector",$"SectorGroup",$"Client12",$"FlagSAE",$"FlagTRE",$"FlagDVE",$"FlagTSW",$"RSLastUpdated",
      $"RSLastUpdatedBy",$"ClientCurr",$"SubClientCurr",$"RSActive",$"ClientGroup",$"PSP_GROUP",when(col("Affiliate")==="UK" ,split_string_array(clientMasterFinal("ClientSet"),lit("FDSDSDENY "))).otherwise(clientMasterFinal("ClientSet")).alias("ClientSet"))

    clientMaster.select($"ClientID",$"SubClientID",$"ClientName",$"SubClientName",$"Affiliate",$"Redi_Affiliate",$"Sector",$"SectorGroup",$"Client12",$"FlagSAE",$"FlagTRE",$"FlagDVE",$"FlagTSW",$"RSLastUpdated",
      $"RSLastUpdatedBy",$"ClientCurr",$"SubClientCurr",$"RSActive",$"ClientGroup",$"PSP_GROUP",$"ClientSet").withColumn("SubClientGroup",lit("")).withColumn("CMActive",lit("")).withColumn("CSIActive",lit("")).withColumn("CBActive",lit("")).withColumn("BEDActive",lit("")).withColumn("ChallActive",lit(""))
      .withColumn("RiskManager",lit("")).withColumn("AccManager",lit("")).withColumn("xMerchantIds",lit("")).withColumn("ClubRFX",lit("")).withColumn("CM2Active",lit("")).withColumn("LocalKPIs",lit(""))
      .withColumn("SilentRules",lit("")).withColumn("Alerts",lit("")).withColumn("TZClient",lit("")).withColumn("TZSubClient",lit("")).withColumn("Region",lit(""))
      .withColumn("Client12Set",lit("")).withColumn("DummyBucketCol",lit(""))
  }


  def getInventoryTableData():Boolean ={
    val isJobStatus:Boolean =hiveSession.executeQuery("select ISJOBSTATUS from REDI.REDI_INVENTORY WHERE JOBNAME ='CMDP'").head().getBoolean(0)
    isJobStatus
  }

  def getCopMasterData():DataFrame = {

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+": Enter getCopMasterData function")

    val max_High_Water_Mark =  hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL +" WHERE PROCESSNAME = " + "'" + CLIENT_DATA_HWM + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED  + "'" ).head().getString(0)

    clientMasterDatalogger.info("The maximum High Water Mark for CopMasterData process is : "+max_High_Water_Mark)

    val HWM_ClientMaster = convertToOracleDateFormat(max_High_Water_Mark)

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+": Converted oracle date format for maximum High Water Mark for CopMasterData process is :"+HWM_ClientMaster)

    if(HWM_ClientMaster == null) {

      clientMasterDatalogger.error(CLIENTMASTERDATAPROCESS_ERROR+": Oracle DateFormat for CopMasterData process is null. Please investigate")
    }else {
      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Retrieve the incremental  data from Oracle only ( only new data which has come after High water mark date) ")

      val clientMasterQuery = "(SELECT * from " + RS_CLIENT_MASTER_DATA + " WHERE LAST_UPDATED >= " + "'" + HWM_ClientMaster + "'" + ")  Client_Master"

     // val clientMasterQuery = "(SELECT * from " + RS_CLIENT_MASTER_DATA + " WHERE EBIT_CLIENT_ID = " + "'000006'" + ")  Client_Master"

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Query for get the incremental Data from Oracle  "+ clientMasterQuery)

      clientMasterDF = fetchClientMasterData(clientMasterQuery, ORACLE_CONN_TYPE, CLIENT_DATA_DATABASE)
    }
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Completed getCopMasterData function")

    clientMasterDF
  }

  def  getCopMasterServiceData() :DataFrame = {

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Enter getCopMasterServiceData function")

    val startTimeCMService = getCurrentdateTimeStamp

    clientMasterDatalogger.info("HighWater mark from REDI_PROCESS_CONTROL table for client master data"+ startTimeCMService)

    val max_High_Water_Mark =  hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL +" WHERE PROCESSNAME = " + "'" + CLIENT_DATA_SERVICE_HWM + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED  + "'" ).head().getString(0)

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":The maximum High Water Mark for CopMasterService Data process is : "+max_High_Water_Mark)

    val HWM_ClientMasterService = convertToOracleDateFormat(max_High_Water_Mark)

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Converted oracle date format for maximum High Water Mark for CopMasterServiceData process is :"+HWM_ClientMasterService)

    if(HWM_ClientMasterService == null) {

      clientMasterDatalogger.warn(" Oracle DateFormat for CopMasterService Data process is null ")

    }else {

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Retrieve the incremental  data from Oracle only ( only new data which has come after High water mark date) ")

       val clientMasterServicesQuery = "(SELECT * from " + RS_CLIENT_MASTER_SERVICE_DATA + " WHERE LAST_UPDATE_DATE >= " + "'" + HWM_ClientMasterService + "'" + ")  Client_Master"

      //val clientMasterServicesQuery = "(SELECT * from " + RS_CLIENT_MASTER_SERVICE_DATA + " WHERE CLIENT_ID = " + "'000006'" + ")  Client_Master"

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Query for get the incremental Data from Oracle  "+ clientMasterServicesQuery)

      val fetchClientMasterServiceDF = fetchClientMasterData(clientMasterServicesQuery, ORACLE_CONN_TYPE, CLIENT_DATA_DATABASE)

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Ending to Fetch Client Master Data into processing layer " + CLIENT_DATA_DATABASE + "." + RS_CLIENT_MASTER_DATA)

      val clientMasterServiceDF = fetchClientMasterServiceDF.select($"CLIENT_ID".alias("EBIT_CLIENT_ID"), $"SUBCLIENT_ID".alias("EBIT_SUB_CLIENT_ID"), $"SERVICE_ID",$"LAST_UPDATE_DATE")
        .groupBy($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"SERVICE_ID").agg(max($"LAST_UPDATE_DATE").as("LAST_UPDATE_DATE"))

      if(clientMasterServiceDF != null ){
        val clientMasterServicePivotDF = clientMasterServiceDF.select($"EBIT_CLIENT_ID", $"EBIT_SUB_CLIENT_ID", $"SERVICE_ID",$"LAST_UPDATE_DATE")
          .groupBy($"EBIT_CLIENT_ID", $"EBIT_SUB_CLIENT_ID",$"LAST_UPDATE_DATE")
          .agg(first(when($"SERVICE_ID" === "SAE", "SAE"), ignoreNulls = true).alias("SAE"),
            first(when($"SERVICE_ID" === "TRE", "TRE"), ignoreNulls = true).alias("TRE"),
            first(when($"SERVICE_ID" === "DVE", "DVE"), ignoreNulls = true).alias("DVE"),
            first(when($"SERVICE_ID" === "TSW", "TSW"), ignoreNulls = true).alias("TSW"))
          .select($"EBIT_CLIENT_ID", $"EBIT_SUB_CLIENT_ID" ,$"LAST_UPDATE_DATE",$"SAE", $"TRE", $"DVE", $"TSW")
        clientMasterService = clientMasterServicePivotDF.select($"EBIT_CLIENT_ID", $"EBIT_SUB_CLIENT_ID",$"LAST_UPDATE_DATE", when($"SAE" === "SAE", "T").otherwise("F").alias("FlagSAE"),
          when($"TRE" === "TRE", "T").otherwise("F").alias("FlagTRE"), when($"DVE" === "DVE", "T").otherwise("F").alias("FlagDVE"),
          when($"TSW" === "TSW", "T").otherwise("F").alias("FlagTSW"))

      }
    }

    clientMasterService.createOrReplaceTempView("clientMasterService")
    val clientMasterServiceFlagTRE= hiveSession.session().sql("select EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,max(LAST_UPDATE_DATE),FlagSAE,FlagTRE,FlagDVE,FlagTSW from clientMasterService" +
      " group by EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,FlagSAE,FlagTRE,FlagDVE,FlagTSW HAVING  FlagTRE ='T' ")

    val clientMasterServiceFlagTSW= hiveSession.session().sql("select EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,max(LAST_UPDATE_DATE),FlagSAE,FlagTRE,FlagDVE,FlagTSW from clientMasterService" +
      " group by EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,FlagSAE,FlagTRE,FlagDVE,FlagTSW HAVING  FlagTSW ='T' ")

    val clientMasterServiceFlagSAE= hiveSession.session().sql("select EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,max(LAST_UPDATE_DATE),FlagSAE,FlagTRE,FlagDVE,FlagTSW from clientMasterService" +
      " group by EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,FlagSAE,FlagTRE,FlagDVE,FlagTSW HAVING  FlagSAE ='T' ")

    val clientMasterServiceFlagDVE= hiveSession.session().sql("select EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,max(LAST_UPDATE_DATE),FlagSAE,FlagTRE,FlagDVE,FlagTSW from clientMasterService" +
      " group by EBIT_CLIENT_ID,EBIT_SUB_CLIENT_ID,FlagSAE,FlagTRE,FlagDVE,FlagTSW HAVING  FlagDVE ='T' ")

    val falgTRE=clientMasterServiceFlagTRE.select($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"max(LAST_UPDATE_DATE)".as("LAST_UPDATE_DATETRE"),$"FlagTRE")
    val falgTSW=clientMasterServiceFlagTSW.select($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"max(LAST_UPDATE_DATE)".as("LAST_UPDATE_DATETSW"),$"FlagTSW")
    val falgSAE=clientMasterServiceFlagSAE.select($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"max(LAST_UPDATE_DATE)".as("LAST_UPDATE_DATESAE"),$"FlagSAE")
    val falgDVE=clientMasterServiceFlagDVE.select($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"max(LAST_UPDATE_DATE)".as("LAST_UPDATE_DATEDVE"),$"FlagDVE")

    val joinFinal = falgTRE.join(falgTSW,Seq("EBIT_CLIENT_ID","EBIT_SUB_CLIENT_ID"),"FULL_OUTER").join(falgSAE,Seq("EBIT_CLIENT_ID","EBIT_SUB_CLIENT_ID"),"FULL_OUTER").join(falgDVE,Seq("EBIT_CLIENT_ID","EBIT_SUB_CLIENT_ID"),"FULL_OUTER")
      .select($"EBIT_CLIENT_ID",$"EBIT_SUB_CLIENT_ID",$"LAST_UPDATE_DATETRE".as("LAST_UPDATE_DATE"),
        when($"FlagTRE"==="T" ,"T").otherwise("F").alias("FlagTRE"),
        when($"FlagTSW"==="T","T").otherwise("F").alias("FlagTSW"),
        when($"FlagSAE"==="T","T").otherwise("F").alias("FlagSAE")
        ,when($"FlagDVE"==="T","T").otherwise("F").alias("FlagDVE"))

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Completed getCopMasterServiceData function: clientServiceJoin" )
    joinFinal
  }

  def clientMasterDataPipeLine(): Unit = {

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO +":Enter into the clientMasterDataPipeLine function")

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":get the highWater mark from REDI_PROCESS_CONTROL table for client master data")

    val startTimeClientMaster = getCurrentdateTimeStamp

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":HighWater mark from REDI_PROCESS_CONTROL table for client master data"+ startTimeClientMaster)

    val copMasterDf = getCopMasterData()

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Ending to Fetch Client Master Data into processing layer " + CLIENT_DATA_DATABASE + "." + RS_CLIENT_MASTER_DATA)

    copMasterDf.cache()

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Insert data into  REDI_PROCESS_CONTROL table for client master data process job"+ CLIENT_DATA_HWM + " Status Is :" + PROCESS_CONTROL_STARTED)

    startControlTableDataProcess(copMasterDf, "LAST_UPDATED", CLIENT_DATA_HWM, PROCESS_CONTROL_STARTED, startTimeClientMaster.toString, "", "Fetched records from ODS Cop Master table",CLIENT_MASTER_DATA_PROCESS)

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Successfully Inserted data into  REDI_PROCESS_CONTROL table for client master data process job"+ CLIENT_DATA_HWM + " Status Is :" + PROCESS_CONTROL_STARTED)

    val storeClientMasterDF = copMasterDf

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":get the highWater mark from REDI_PROCESS_CONTROL table for client master service process ")

    val startTimeClientMasterService = getCurrentdateTimeStamp

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":HighWater mark from REDI_PROCESS_CONTROL table for client master service data"+ startTimeClientMasterService)

    val copMasterServiceDf = getCopMasterServiceData()

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Ending to Fetch Client Master service  Data into processing layer " + CLIENT_DATA_DATABASE + "." + RS_CLIENT_MASTER_SERVICE_DATA)

    copMasterServiceDf.cache()

    startControlTableDataProcess(copMasterServiceDf,"LAST_UPDATE_DATE",CLIENT_DATA_SERVICE_HWM,PROCESS_CONTROL_STARTED,startTimeClientMaster.toString,"","Fetched records from ODS Cop Master service table",CLIENT_MASTER_DATA_PROCESS)

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":stored records from  Control tables")

    startControlTableDataProcess(copMasterServiceDf,"LAST_UPDATE_DATE",CLIENT_DATA_HWM,PROCESS_CONTROL_INPROGRESS,startTimeClientMaster.toString,"","processing to store fetched records  from ODS Cop Master  table into HDFS localtion",CLIENT_MASTER_DATA_PROCESS)

    startControlTableDataProcess(copMasterServiceDf,"LAST_UPDATE_DATE",CLIENT_DATA_SERVICE_HWM,PROCESS_CONTROL_INPROGRESS,startTimeClientMaster.toString,"","processing to store fetched records  from ODS Cop Master service table into HDFS localtion",CLIENT_MASTER_DATA_PROCESS)

    val finalCopMasterDataDf = copMasterDf.join(copMasterServiceDf, Seq("EBIT_CLIENT_ID", "EBIT_SUB_CLIENT_ID"), "left_outer")

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":fetching the number of  records from RBIRefClient table "+ finalCopMasterDataDf  )

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":fetching the existing records from RBIRefClient table ")

    val rbiRefClient = hiveSession.executeQuery("select * from redi.RBI_REF_CLIENT")

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Fetching the existing records from TransMasterCore table ")

    val transMasterTable = getTransMasterTable()

    if (finalCopMasterDataDf != null) {

      val newClientMasterDF = getRBIREFMainTable(rbiRefClient);

      val rbiRefClient1 = hiveSession.executeQuery("select clientid,subclientid,clientgroup,psp_group,clientset from redi.RBI_REF_CLIENT")

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Transforming the Raw client master details,ClientGroup and  PSP Group details  ")

      val updateClientGroup = updateClientPSPGroups(mergeTwoDataFrames(transformRawClientMasterData(finalCopMasterDataDf), newClientMasterDF), rbiRefClient1)

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Transforming the Client and Sub Client Currency Details ")

      val updateClientSubClientCurr = fetchClientSubClientCurrency(transMasterTable)

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Joining the Transformed the Client and Sub Client Currency Details into Client master table ")

      val CurrencyUpdate = joinClientSubClientCurrency(fetchClientCurrency(updateClientSubClientCurr), fetchSubClientCurrency(updateClientSubClientCurr))

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Joining the Transformed the Client and Sub Client Currency Details into Client master table ")

      val finalClientMasterData = finalNewClientMasterDataFrameRecords(newClientMasterData(updateClientGroup, CurrencyUpdate))

      clientMasterData = ProcessClientMaster(finalClientMasterData)

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+": Storing into  final transformed existing client master data into RBI_REF_CLIENT_ON_WRITE table ")

    } else {

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":updated client data and there is No new client data ")

      val oldClientMasterDF = getRBIREFMainTableCol(rbiRefClient)

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Transforming the Client and Sub Client Currency Details for new client")

      val updateClientSubClientCurr = fetchClientSubClientCurrency(transMasterTable)

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Joining the Transformed the Client and Sub Client Currency Details into Client master table for new client")

      val CurrencyUpdate = joinClientSubClientCurrency(fetchClientCurrency(updateClientSubClientCurr), fetchSubClientCurrency(updateClientSubClientCurr))

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Joining the Transformed the Client and Sub Client Currency Details into Client master table for new client")

      val finalClientMasterData = finalDataFrameRecords(clientMasterData(oldClientMasterDF, CurrencyUpdate))

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Store final transformed data into RBI_REF_CLIENT_ON_WRITE table for new client" )

      clientMasterData = ProcessClientMaster(finalClientMasterData);
    }
    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_INFO +":Storing Client Master Data Into RBI_REF_CLIENT_ON_WRITE Table" )

    val  clientLatest = Window.partitionBy("clientid","SubClientID").orderBy(desc("RSLastUpdated"))

    clientMasterData= clientMasterData.withColumn("client_row_number",row_number() over clientLatest)

    val finalClientMasterDataDF=clientMasterData.filter($"client_row_number"===1)

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_INFO +":Storing Client Master Data Into RBI_REF_CLIENT_ON_WRITE Table After remove Duplicates")

    val isClientMasterStored = storeDataIntoHive(REDI_RBI_REF_CLIENT_ON_WRITE, APPEND_MODE,finalClientMasterDataDF)

    clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_INFO +":isClientMasterStored" + isClientMasterStored)

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO +":Stored Client Master Data Into RBI_REF_CLIENT_ON_WRITE Table")

    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO +":Staring to execute MERGE Script  Client Master Data Into RBI_REF_CLIENT Table")

    if(isClientMasterStored){
      isClientMasterMerge = hiveSession.executeUpdate("MERGE INTO redi.RBI_REF_CLIENT AS D USING (Select * from redi.RBI_REF_CLIENT_ON_WRITE )" +
        " AS S ON (D.CLIENTID=S.CLIENTID and D.subclientid = S.subclientid) " +
        "WHEN MATCHED THEN UPDATE SET clientname=S.clientname,subclientname=S.subclientname,client12=S.client12," +
        "clientgroup =S.ClientGroup,subclientgroup=S.SubClientGroup,rsactive=S.RSActive,clientcurr=S.ClientCurr,subclientcurr=S.SubClientCurr," +
        "affiliate=S.affiliate,sectorgroup=S.sectorgroup,sector=S.sector,psp_group=S.psp_group,rslastupdatedby=S.rslastupdatedby,rslastupdated=S.rslastupdated,ClientSet=S.ClientSet, Client12Set=S.Client12Set," +
        "FlagSAE=S.FlagSAE,FlagTRE=S.FlagSAE,FlagDVE=S.FlagDVE,FlagTSW=S.FlagDVE,whenUpdated =S.WhenUpdated ,WhoUpdated=S.WhoUpdated WHEN NOT MATCHED THEN " +
        "INSERT VALUES(S.ClientID,S.SubClientID,S.ClientName,S.SubClientName,S.Client12,S.ClientGroup,S.SubClientGroup,S.RSActive,S.ClientCurr,S.SubClientCurr,S.CMActive,S.CSIActive,"+
        "S.BEDActive,S.ChallActive,S.CBActive,S.Redi_Affiliate,S.Affiliate,S.SectorGroup,S.Sector,S.RiskManager,S.AccManager,S.xMerchantIds,S.ClubRFX,S.CM2Active,"+
        "S.LocalKPIs,S.SilentRules,S.Alerts,S.TZClient,S.TZSubClient,S.PSP_GROUP,S.Region,S.RSLastUpdatedBy,S.RSLastUpdated,S.DummyBucketCol,S.ClientSet,S.Client12Set," +
        "S.FlagSAE, S.FlagTRE, S.FlagDVE , S.FlagTSW , S.WhenLoaded, S.WhoLoaded, S.WhenUpdated, S.WhoUpdated )")

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_INFO +":isClientMasterStored" + isClientMasterMerge)

      if(isClientMasterMerge){
        hiveSession.executeUpdate("truncate table redi.RBI_REF_CLIENT_ON_WRITE ")
        clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO +"RBI_REF_CLIENT_ON_WRITE deleted  data ")
      }
      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO +":Stored Client Master Data Into RBI_REF_CLIENT Table")

    }

    if (copMasterServiceDf != null && isClientMasterMerge) {

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Enter into Store CopMasterService table data into HDFS  ")

      saveClientMasterServiceDatatoHDFS(copMasterServiceDf)

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Completed to Store CopMasterService table data into HDFS  ")

      val endTimeClientMaster1 = getCurrentdateTimeStamp

      controlTableDataProcess(copMasterServiceDf,"LAST_UPDATE_DATE",CLIENT_DATA_SERVICE_HWM,PROCESS_CONTROL_COMPLETED,startTimeClientMaster.toString,endTimeClientMaster1.toString,"Fetched records from ODS Cop Master table & stored successfully in  HDFS",CLIENT_MASTER_DATA_PROCESS)
    }
    if (storeClientMasterDF != null && isClientMasterMerge) {

      clientMasterDatalogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Enter into Store CopMaster table data into HDFS  ")

      saveClientMasterDatatoHDFS(storeClientMasterDF)

      clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Completed to Store CopMaster table data into HDFS  ")

      val endTimeClientMaster = getCurrentdateTimeStamp

      controlTableDataProcess(storeClientMasterDF, "LAST_UPDATED", CLIENT_DATA_HWM, PROCESS_CONTROL_COMPLETED, startTimeClientMaster.toString, endTimeClientMaster.toString, "Fetched records from ODS Cop Master table & stored successfully in  HDFS",CLIENT_MASTER_DATA_PROCESS)
    }
    // clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":Check if the job is terminated forcefully ")

    /*val isJobStatus = getInventoryTableData()
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":CMDP job terminated Status is: "+isJobStatus)
    if(isJobStatus){
     clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_DEBUG+":CMDP job is  started to terminated forcefully ")
     System.exit(1)
    }*/
    clientMasterDatalogger.info(CLIENTMASTERDATAPROCESS_INFO+":Completed into the clientMasterDataPipeLine function")
  }
}
