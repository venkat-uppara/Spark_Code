package com.aciworldwide.ra.redi.commontest.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.ClientMasterDataController
import com.aciworldwide.ra.redi.common.dao.ClientMasterDataDao
import com.aciworldwide.ra.redi.common.schemas.{ClientMasterTestsSchema, CopMasterSchema}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.commontest.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}


class ClientMasterTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants {

  private val ClientMasterList = Array(
/*

    CopMasterSchema("701110", "101099", "NOS", "NOS ONLY PrePaid Recharge", "US", "Active", "OTHER", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("701134", "100099", "Qwest", "Qwest Comm", "UK", "Active", "Retail%Elec%", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700259", "200334", "BBG Communications, Inc.", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700244", "200844", "ATT International Outbound", "Custom TeleConnect Batch 2", "UK", "Active", "Travel%Hotel%", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700269", "200808", "NCIC", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%",  new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("701285", "100099", "Legacy Communications", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700414", "200814", "BBG Euroconnex Ireland3", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700416", "200416", "BBG Euroconnex UK3", "Custom TeleConnect Batch 2", "UK", "Active", "Gift Cards", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("703361", "100301", "Talk Free RT", "Custom TeleConnect Batch 2", "Active", "UK", "Retail%Elec%",new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("707243", "100099", "AT&T WorldConnect", "Custom TeleConnect Batch 2", "Active", "UK", "Retail%Elec%",new java.sql.Timestamp(System.currentTimeMillis()), "RS")
*/


    CopMasterSchema("701110", "101099", "NOS", "NOS ONLY PrePaid Recharge", "US", "Active", "OTHER","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("701134", "100099", "Qwest", "Qwest Comm", "UK", "Active", "Retail%Elec%","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700259", "200334", "BBG Communications, Inc.", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700244", "200844", "ATT International Outbound", "Custom TeleConnect Batch 2", "UK", "Active", "Travel%Hotel%","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700269", "200808", "NCIC", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%", "T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("701285", "100099", "Legacy Communications", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700414", "200814", "BBG Euroconnex Ireland3", "Custom TeleConnect Batch 2", "UK", "Active", "Retail%Elec%", "T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("700416", "200416", "BBG Euroconnex UK3", "Custom TeleConnect Batch 2", "UK", "Active", "Gift Cards","T","F","T","T", new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("703361", "100301", "Talk Free RT", "Custom TeleConnect Batch 2", "Active", "UK", "Retail%Elec%", "T","F","T","T",new java.sql.Timestamp(System.currentTimeMillis()), "RS"),
    CopMasterSchema("707243", "100099", "AT&T WorldConnect", "Custom TeleConnect Batch 2", "Active", "UK", "Retail%Elec%", "T","F","T","T",new java.sql.Timestamp(System.currentTimeMillis()), "RS")
)

  private val RBIREFCLIENT = Array(
    ClientMasterTestsSchema("701110", "101099", "NOS", "NOS ONLY PrePaid Recharge", "US", "Y", "Retail - Others", "Retail", "701110101099", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("701134", "100099", "Qwest", "Qwest Comm", "UK", "Y", "Retail - Others", "Retail", "701134100099", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("700259", "200334", "BBG Communications, Inc.", "Custom TeleConnect Batch 2", "UK", "Y", "Retail - Others", "Retail", "700259200334", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("700244", "200844", "ATT International Outbound", "Custom TeleConnect Batch 2", "UK", "Y", "Retail - Others", "Retail", "700244200844", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("700269", "200808", "NCIC", "Custom TeleConnect Batch 2", "US", "Y", "Retail - Others", "Retail", "700269200808", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("701285", "100099", "Legacy Communications", "Custom TeleConnect Batch 2", "UK", "Y", "Retail - Others", "Retail", "701285100099", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("700414", "200814", "BBG Euroconnex Ireland3", "Custom TeleConnect Batch 2", "US", "Y", "Retail - Others", "Retail", "700414200814", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T"),
    ClientMasterTestsSchema("700416", "200416", "BBG Euroconnex UK3", "Custom TeleConnect Batch 2", "US", "Y", "Retail - Others", "Retail", "700416200416", "RS", new java.sql.Timestamp(System.currentTimeMillis()), Array("SDSDNY", "FDSDNY"), "Walmart", "Walmart US", "Walmart US","T","F","T","T")

  )


  private var clientmasterdataDao: ClientMasterDataDao = _

  private var clientmasterController: ClientMasterDataController = _

  private var copmasterdf: DataFrame = _
  private var rbirefclientdf: DataFrame = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc

    import _sqlc.implicits._

    copmasterdf = _sqlc.sparkContext.parallelize(ClientMasterList).toDF()
    rbirefclientdf = _sqlc.sparkContext.parallelize(RBIREFCLIENT).toDF()

    clientmasterdataDao = new ClientMasterDataDao(_sqlc)
    clientmasterController = new ClientMasterDataController()

  }

   "This test will test if we are able to get the rows from COP Master. This " should "display the schema of the dataframe " in {
     val clientmastertestsize = clientmasterdataDao.fetchClientMasterData("SDB.COP_MASTER", "oracle", "SDB",10).take(10)
       clientmastertestsize should have size 10

    }

  "This test will test the transformation on Sector coulumn in  RawClientMaster. this" should "Display the transformed sector value " in {
    val rawclientmasterSector = clientmasterController.transformRawClientMasterData(copmasterdf)
    val sector = rawclientmasterSector.select("sector").where(rawclientmasterSector("ClientID") === "701110")
    val sectorvale = sector.collect().map(col => col.getString(0)).mkString(" ")
    sectorvale should be === "Other"
  }
  "This test will test the transformation on if Sector coulumn is Retail%Elec%  in  RawClientMaster. this" should "Display the transformed sector value " in {
    val rawclientmasterSector = clientmasterController.transformRawClientMasterData(copmasterdf)
    val sector = rawclientmasterSector.select("sector").where(rawclientmasterSector("ClientID") === "701134")
    val sectorvale = sector.collect().map(col => col.getString(0)).mkString(" ")
    sectorvale should be === "Retail - Electrical/Electronics"
  }

   "This test will test the transformation on if Sector coulumn is Travel%Hotel% in  RawClientMaster. this" should "Display the transformed sector value " in {
     val rawclientmasterSector = clientmasterController.transformRawClientMasterData(copmasterdf)
     val sector = rawclientmasterSector.select("sector").where(rawclientmasterSector("ClientID") === "700244")
     val sectorvale = sector.collect().map(col => col.getString(0)).mkString(" ")
     sectorvale should be === "Travel - Hotels"
   }

   "This test will test the transformation on if Client12 Column in  RawClientMaster. this" should "Display the transformed Client12 value " in {
     val rawclientmasterSector = clientmasterController.transformRawClientMasterData(copmasterdf)
     val client12 = rawclientmasterSector.select("Client12").where(rawclientmasterSector("ClientID") === "701110")
     val client12vale = client12.collect().map(col => col.getString(0)).mkString(" ")
     client12vale should be === "701110101099"
   }

  "This test will test the fetching the list of records from RBIREFCLIENT table from hive. this" should "Display the transformed sector value " in {
     val clientmaster = clientmasterController.getRBIREFMainTable(rbirefclientdf)
     val client12 = clientmaster.select("Client12").where(clientmaster("ClientID") === "701110")
     val client12vale = client12.collect().map(col => col.getString(0)).mkString(" ")
     client12vale should be === "701110101099"
   }

   "This test will test the merging  the RawClientMasterdata table and   RBIREFCLIENT table from hive. this" should "Display the merging of two table " in {
     val rawclientmasterSector = clientmasterController.transformRawClientMasterData(copmasterdf)
     val clientmaster = clientmasterController.getRBIREFMainTable(rbirefclientdf)
     val mergingtable = clientmasterController.mergeTwoDataFrames(rawclientmasterSector, clientmaster)
     val client12 = mergingtable.select("Client12").where(mergingtable("ClientID") === "700416" and mergingtable("filterValue") === "1")
     val client12vale = client12.collect().map(col => col.getString(0)).mkString(" ")
     client12vale should be === "700416200416"
   }
}

