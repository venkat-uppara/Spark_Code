package com.aciworldwide.ra.redi.commontest.services

import com.aciworldwide.ra.redi.common.services.EstablishConnections
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.SparkSession
import org.scalatest.{BeforeAndAfterAll, Suite}

trait ReDiTestSpec extends BeforeAndAfterAll with EstablishConnections {

  this: Suite =>
  private var _sc: SparkSession = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    lazy val spark: SparkSession = {
      getSparkSession
    }
    sparkConfig.foreach { case (k, v) => spark.sparkContext.getConf.setIfMissing(k, v) }

    _sc = getSparkSession
  }

  def sparkConfig: Map[String, String] = Map.empty

  def getSparkSession: SparkSession = {

    val sparkSession = sparkSessionBuilder(ConfigFactory.load().getString("local.common.spark.master"), ConfigFactory.load().getString("local.common.spark.app.name"))

    sparkSession
  }

  override def afterAll(): Unit = {
    if (_sc != null) {
      _sc.stop()
      _sc = null
    }
    super.afterAll()
  }

  def sc: SparkSession = _sc
}
