package com.aciworldwide.ra.redi.commontest.test


import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.commontest.services.ReDiTestSpec
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
import org.scalatest.concurrent.Eventually
import com.aciworldwide.ra.redi.common.controllers.BedDataController
import org.apache.spark.sql.functions._

import com.aciworldwide.ra.redi.common.schemas.BEDDataSchemas

class BEDDataTests extends FlatSpec  with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants  {

  private val inputData = Array(BEDDataSchemas("000031000002BHW20190218211800101","2018-12-12 18:00:00.0","Reject Fraud","TEST_CODE","TEST_DESC","2018-12-12 18:00:00.0",
    "000031","O","NoScore","","","","Y","20181212","N","2018-12-12 18:00:00.0","BEDOVROV",new java.sql.Timestamp(System.currentTimeMillis()),"2019-03-13 09:28:48.478","2019-03-13 09:28:48.478"),
    BEDDataSchemas("000031000002BHH20190218211800101","2018-12-12 18:00:00.0","Accept","TEST_CODE","TEST_DESC","2018-12-12 18:00:00.0",
      "000031","O","Challenge","","","","N","20181212","N","2018-12-12 18:00:00.0","BEDOVROV",new java.sql.Timestamp(System.currentTimeMillis()),"2019-03-13 09:28:48.478","2019-03-13 09:28:48.478"))

  var dfBed :DataFrame =_
  var res :BedDataController =_


  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    dfBed = _sqlc.sparkContext.parallelize(inputData).toDF()
    res = new BedDataController()
  }

  "This test case will test transform ChallSource. this" should "Display the transformed value ChallSource " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("ChallSource").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "BEDS"
  }

  /*"This test case will test transform realfraudtype. this" should "Display the transformed value realfraudtype " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("realfraudtype").where((bed("OID") === "000031000002BHH20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "BEDOVROV"
  }*/

  "This test case will test transform realfraudtype. this" should "Display the transformed value realfraudtype 1 " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("realfraudtype").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be ===  "BEDOVROV"
  }

  "This test case will test transform currentstatus. this" should "Display the transformed value currentstatus " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("currentstatus").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "NoScore->RejFraud"
  }
  "This test case will test transform currentstatus 1. this" should "Display the transformed value currentstatus 1 " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("currentstatus").where((bed("OID") === "000031000002BHH20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "Challenge->Accept"
  }

  "This test case will test transform decision. this" should "Display the transformed value decision " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("decision").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "R"
  }

  "This test case will test transform challstatus. this" should "Display the transformed value challstatus " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("challstatus").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === ""
  }

  "This test case will test transform decision 1. this" should "Display the transformed value decision " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("decision").where((bed("OID") === "000031000002BHH20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "A"
  }

  "This test case will test transform challstatus 1. this" should "Display the transformed value challstatus " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("challstatus").where((bed("OID") === "000031000002BHH20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "Approve"
  }

  "This test case will test transform Override. this" should "Display the transformed value Override " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("Override").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "Reject Fraud"
  }

  "This test case will test transform OverrideType. this" should "Display the transformed value OverrideType " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("OverrideType").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "O"
  }

  "This test case will test transform OverrideFraudYN. this" should "Display the transformed value OverrideFraudYN " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("OverrideFraudYN").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "Y"
  }


  "This test case will test transform overrideyyyymmdd. this" should "Display the transformed value overrideyyyymmdd " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("overrideyyyymmdd").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    dd should be === "20181212"
  }

  "This test case will test transform OverrideUpdatedYYYYMMDD. this" should "Display the transformed value OverrideUpdatedYYYYMMDD " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("OverrideUpdatedYYYYMMDD")//.where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x=>x.getString(0)).mkString("")
    val dd1 = bed.select(date_format(current_date(), "yyyyMMdd"))
    val dd2 = dd1.collect().map(x=>x.getString(0)).mkString("")
    dd should be === dd2
  }

  "This test case will test transform REALFRAUDYN. this" should "Display the transformed value REALFRAUDYN " in {
    val bed = res.finalBedtransformations(dfBed)
    val coll = bed.select("REALFRAUDYN").where((bed("OID") === "000031000002BHW20190218211800101"))
    val dd = coll.collect().map(x => x.getString(0)).mkString("")
    dd should be === "Y"
  }




}
