package com.aciworldwide.ra.redi.common

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.DataAccess
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.{BeforeAndAfterEach, FunSuite}

class CommonTestExample extends FunSuite with BeforeAndAfterEach with ReDiConstants with Serializable {
  test("objectCreation") {
    object TestObject extends DataAccess {
      override def readHiveData(spark: SparkSession, table: String): DataFrame = {
        import spark.implicits._
        Seq("A").toDF("A")
      }

      override def writeHiveData(table: String, format: String, dataframe: DataFrame): Unit = {}

      override def readKafkaData(spark: SparkSession, topic: String): DataFrame = {
        import spark.implicits._
        Seq("A").toDF("A")
      }

      override def writeKafkaData(dataframe: DataFrame): Unit = {}

      override def createSession(master: String, name: String): SparkSession = {
        SparkSession.builder()
          .config("spark.sql.caseSensitive", "false")
          .config("spark.default.parallelism", "1")
          .config("spark.sql.shuffle.partitions", "1")
          .appName(name)
          .master(master)
          .getOrCreate()
      }
    }
    lazy val session = TestObject.createSession("local[*]", "test")

    import session.implicits._
    val ds = TestObject.readHiveData(session, "example")
    assert(ds.select($"A").head().mkString == "A", "Validating that test works.")

  }
}
