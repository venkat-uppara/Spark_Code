package com.aciworldwide.ra.redi.commontest.test

import com.aciworldwide.ra.redi.common.controllers.CurrencyRatesDataController
import com.aciworldwide.ra.redi.common.dao.CurrencyDataDao
import com.aciworldwide.ra.redi.common.schemas.CurrencyResponseSchema
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.commontest.services.ReDiTestSpec
import org.apache.spark.sql.Dataset
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}


class CurrencyRateProcessTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec {

  private val currencyrateresponse = Array(
    CurrencyResponseSchema("1.000000000000", "1-01-01 00:00:00", "9999-12-31 23:59:59", "BMD", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1.000000000000", "1-01-01 00:00:00", "9999-12-31 23:59:59", "CUC", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1.000000000000", "1-01-01 00:00:00", "9999-12-31 23:59:59", "USD", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("3.673181000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "AED", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("72.249990000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "AFN", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1.789003000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "AWG", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1785.500000000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "BIF", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1.352300000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "BND", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("1616.000000000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "CDF", "2018-07-15 15:19:26.743"),
    CurrencyResponseSchema("178.000000000000", "2018-07-13 14:08:45", "9999-12-31 23:59:59", "DJF", "2018-07-15 15:19:26.743")


  )

  private var currencyController: CurrencyRatesDataController = _
  private var currencyDataDao: CurrencyDataDao = _
  private var currrates: Dataset[CurrencyResponseSchema] = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc
    import _sqlc.implicits._

    currencyController = new CurrencyRatesDataController()
    currencyDataDao = new CurrencyDataDao(_sqlc)

    currrates = _sqlc.sparkContext.parallelize(currencyrateresponse).toDF().as[CurrencyResponseSchema]
    currrates.collect().foreach(println)


  }

  "This test will test the size of the currency code response " should " be " in {
    // var conversionAmount: Double = 0.0
    //conversionAmount = convertCurrency(rsTransflowControl.getCurrencyRates(),"GBP","NAD",10)
    //conversionAmount shouldBe  180.79999999999998
    val currencyrates = currencyController.getLatestCurrencyRates(currrates).collect()
    currencyrates should have size 10
  }


  "This test is used to test the processed data... " should "be" in {
    val processedData = currencyController.processCurrencyData(currencyController.getLatestCurrencyRates(currrates)).collect()
    processedData should have size 10
  }


  "This test is used to test the audit columns additions.. " should "be" in {
    currencyController.processCurrencyData(currencyController.getLatestCurrencyRates(currrates))
      .createOrReplaceTempView("processeddata")
    val Wholoaded = sc.sql("select distinct Wholoaded from processeddata").head().getString(0)
    Wholoaded equals ("REDISYSTEM")
  }

}
