package com.aciworldwide.ra.redi.commontest.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.CBReasonCodesController
import com.aciworldwide.ra.redi.common.dao.CBReasonCodesDao
import com.aciworldwide.ra.redi.common.schemas.CBReasonCodeSchema
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.commontest.services.ReDiTestSpec
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{current_timestamp, lit}
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

/*
class CBReasonCodesTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiTestSpec with ReDiConstants {

  private val CBReasonCodesList = Array(
    CBReasonCodeSchema("00", "M", "null", "Lost Card", "Y", "BMS"),
    CBReasonCodeSchema("00", "V", "null", "Lost Card", "Y", "BMS"),
    CBReasonCodeSchema("00", "M", "Y", "Lost Card", "Y", "UKCB"),
    CBReasonCodeSchema("00", "M", "Y", "Lost Card", "Y", "ETHOCA"),
    CBReasonCodeSchema("001", "M", "N", "Requested Transaction Information Not Received", "N", "CPS"),
    CBReasonCodeSchema("002", "M", "N", "Requested/Required Item Illegible or Missing", "N", "CPS"),
    CBReasonCodeSchema("003", "M", "N", "Documentation received was invalid/incomplete.", "N", "CPS"),
    CBReasonCodeSchema("007", "M", "Y", "Warning Bulletin", "Y", "CPS"),
    CBReasonCodeSchema("008", "M", "N", "Requested/Required Authorization Not Obtained", "N", "CPS"),
    CBReasonCodeSchema("0083", "V", "Y", "Fraud - Card-Absent Environment", "Y", "TSYS")
  )

  private val CBReasonCodesArray = Array(
    ("00", "M", "null", "Lost Card", "Y", "BMS"),
    ("00", "V", "null", "Lost Card", "Y", "BMS"),
    ("00", "M", "Y", "Lost Card", "Y", "UKCB"),
    ("00", "M", "Y", "Lost Card", "Y", "ETHOCA"),
    ("001", "M", "N", "Requested Transaction Information Not Received", "N", "CPS"),
    ("002", "M", "N", "Requested/Required Item Illegible or Missing", "N", "CPS"),
    ("003", "M", "N", "Documentation received was invalid/incomplete.", "N", "CPS"),
    ("007", "M", "Y", "Warning Bulletin", "Y", "CPS"),
    ("008", "M", "N", "Requested/Required Authorization Not Obtained", "N", "CPS"),
    ("0083", "V", "Y", "Fraud - Card-Absent Environment", "Y", "TSYS")
  )

  private var cbReasonCodesDao: CBReasonCodesDao = _
  private var cbReasonCodesController: CBReasonCodesController = _
  private var cbreasoncodesdf: DataFrame = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc

    import _sqlc.implicits._

    cbreasoncodesdf = _sqlc.sparkContext.parallelize(CBReasonCodesList).toDF()

    cbReasonCodesDao = new CBReasonCodesDao(_sqlc)
    cbReasonCodesController = new CBReasonCodesController()

  }

  "This test will test if we are able to get the rows from CBReason codes. This " should "display the schema of the dataframe " in {
    val cbreasontestsize = cbReasonCodesDao.fetchCBReasonCodes("CB_DATA.CB_RSN_CD", "oracle", "CB_DATA", 10).take(10)
    cbreasontestsize should have size 10

  }

  "The processed chargeback reason fetched " should "be selected" in {
    val testresultsize = cbReasonCodesController.reorderSourceTableSchema(CB_REASON_CODE_COL_ORDER,
      addAuditColumns(cbreasoncodesdf).withColumn(STATUS_COL, lit(STATUS_ACTIVE_INDICATOR))
        .withColumn(RS_UPDATED, current_timestamp())).collect()
    testresultsize should have size 10
  }



}*/
