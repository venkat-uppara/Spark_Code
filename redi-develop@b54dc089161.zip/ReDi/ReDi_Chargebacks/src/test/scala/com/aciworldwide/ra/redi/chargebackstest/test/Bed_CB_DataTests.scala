package com.aciworldwide.ra.redi.chargebackstest.test

import com.aciworldwide.ra.redi.chargebacks.controllers.BedCBDataController
import com.aciworldwide.ra.redi.chargebacks.dao.BedDataDao
import com.aciworldwide.ra.redi.chargebacks.schemas.BED2_CB_DATA_FILES_DATA
import com.aciworldwide.ra.redi.chargebackstest.services.ReDiAutomatedCBTestSpec
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import org.apache.spark.sql.DataFrame
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}

class Bed_CB_DataTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiAutomatedCBTestSpec with ReDiConstants {

  private val BED2CBDATAFILESDATA = Array(
    BED2_CB_DATA_FILES_DATA("2222", "100005000001TAA20181116050025679", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116050034966", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116050038067", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116051142349", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116060850265", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116062618965", "3364001", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "7", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "10001", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"),
    BED2_CB_DATA_FILES_DATA("111", "100005000001TAA20181116070328332", "000022", new java.sql.Timestamp(System.currentTimeMillis()), new java.sql.Timestamp(System.currentTimeMillis()), BigDecimal(99.72), "07", "TEST_CLINT", "TEST_CLINT", BigDecimal(339), "8-Jun-15", "INITIAL_LOAD", "22", "000022", "TEST_CLINT", "TEST_CLINT", BigDecimal(111), BigDecimal(111), "TEST_CLINT"))

  private var bedcbdataDao: BedDataDao = _
  private var bedcbdataController: BedCBDataController = _
  private var bedcbdatadf: DataFrame = _


  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc

    import _sqlc.implicits._

    bedcbdatadf = _sqlc.sparkContext.parallelize(BED2CBDATAFILESDATA).toDF()
    bedcbdataDao = new BedDataDao(_sqlc)
    bedcbdataController = new BedCBDataController()
  }

  "This test will test if we are able to get the rows from bed CBData. This " should "display the schema of the dataframe " in {
    val bedcbtestsize = bedcbdataDao.fetchBedData("BEDATA.BED2_CB_DATA_FILES_DATA", "oracle", "BEDATA", 1).take(2)
    bedcbtestsize should have size 2
  }
  "This test will test the bed CB data. this" should "Display the transformed bed Data " in {
    val rawbeddata = bedcbdataController.getRawBedCBData(bedcbdatadf).collect()
    rawbeddata should have size 7
  }

  "This test will test the final transformed bed CB data. this" should "Display the transformed bed Data " in {
    val rawbeddata = bedcbdataController.getRawBedCBData(bedcbdatadf)
    val transformedbed = bedcbdataController.transformRawBedCBData(rawbeddata)
    val transform = transformedbed.filter(transformedbed("bedreferenceid") === "2222").collect().map(col => col.getDecimal(15)).head.stripTrailingZeros().toPlainString()
        transform should be === "111"
  }
  "This test will test the final transformed bed CB data fraud yes or No . this" should "Display the transformed bed Data " in {
    val rawbeddata = bedcbdataController.getRawBedCBData(bedcbdatadf)
    val transformedbed = bedcbdataController.transformRawBedCBData(rawbeddata)
    val transform = transformedbed.filter(transformedbed("bedtransactionid") === "000022").collect().map(col => col.getString(23)).mkString("")
    transform should be === "Y"
  }

  "This test will test the final transformed bed CB data fraudNo . this" should "Display the transformed bed Data " in {
    val rawbeddata = bedcbdataController.getRawBedCBData(bedcbdatadf)
    val transformedbed = bedcbdataController.transformRawBedCBData(rawbeddata)
    val transform = transformedbed.filter(transformedbed("bedtransactionid") =!= "000022").collect().map(col => col.getString(23)).mkString("")
    transform should be === "N"
  }




}


