/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */


package com.aciworldwide.ra.redi.chargebackstest.test

import com.aciworldwide.ra.redi.chargebacks.controllers.{AutomatedCBDataController, MainCBController}
import com.aciworldwide.ra.redi.chargebacks.dao.AutomatedCBDataDao
import com.aciworldwide.ra.redi.chargebackstest.services.ReDiAutomatedCBTestSpec
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import org.apache.spark.sql.DataFrame
import org.scalatest.concurrent.Eventually
import org.scalatest.{BeforeAndAfter, FlatSpec, Matchers}
/*
class AutomatedCBTests extends FlatSpec with CommonUtils with Matchers with Eventually
  with BeforeAndAfter with ReDiAutomatedCBTestSpec with ReDiConstants {

  private var automatedCBDataDao: AutomatedCBDataDao = _
  private var automatedCBDataController: AutomatedCBDataController = _
  private var automatedcbdatadf: DataFrame = _
  private var mainCBController: MainCBController = _

  override def beforeAll(): Unit = {
    super.beforeAll()
    val _sqlc = sc

    automatedCBDataDao = new AutomatedCBDataDao(_sqlc)
    //automatedCBDataController = new AutomatedCBDataController()
    mainCBController = new MainCBController()
  }

  "This test will test if we are able to get the rows from Automated CBData. This " should "display the schema of the dataframe " in {
    val cbreasontestsize = automatedCBDataDao.fetchAutomatedCBData("CB_DATA.CB_MASTER_DATA", "oracle", "CB_DATA", 1).take(2)
    cbreasontestsize should have size 2
  }

}*/


