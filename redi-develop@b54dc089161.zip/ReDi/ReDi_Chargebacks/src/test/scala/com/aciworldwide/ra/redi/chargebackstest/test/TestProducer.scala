package com.aciworldwide.ra.redi.chargebackstest.test

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.{BaseController, RollbackController}
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory;

object TestProducer extends BaseController with ReDiConstants {

  /*
  -Djavax.net.ssl.trustStore=C:/Work/idea/Lessons/keystore.jks
  -Djava.security.krb5.conf=C:/Work/downloads/krb5.conf
  -Djava.security.auth.login.config=C:/Work/downloads/jaas.conf
  */
  def main(args: Array[String]): Unit = {
    val session = createSparkSession(ConfigFactory.load().getString("local.common.spark.app.name"))

    import session.sqlContext.implicits._
    val df = /*Seq(
      ("("("809123123456UAA20180803110223000"),"),"),
      ("("("819123123456UAA20180803110223000"),"),"),
      ("("("889123123456UAA20180803110223000"),"),"))*/
    /*("("802323123456UAA20180803110223000"),"),
      ("("802323123456UAA20180803110223000"),"),
      ("("802323123456UAA20180803110223000"),"),
      ("("802323123456UAA20180803110223001"),"),
      ("("802323123456UAA20180803110223002"),"),
      ("("802323123456UAA20180803110223003"),"),
      ("("802323123456UAA20180803110223004"),"),
      ("("802323123456UAA20180803110223000"),"),
      ("("802323123456UAA20180803110223000"),")*/
    /*,
            ("("("802323123456UAA20180803110223000"),"),"),
            ("("("889123123456UAA20180803110223000"),"),"),
            ("("("819123123456UAA20180803110223005"),"),")*/
      Seq(
        ("802323123456UAA20180803110223000"),
        ("802323123456UAA20180803110223000"),
        ("802323123456UAA20180803110223018"),
        ("802323123456UAA20180803110223028"),
        ("802323123456UAA20180803110223007"),
        ("802323123456UAA20180803110223019"),
        ("802323123456UAA20180803110223029"),
        ("802323123456UAA20180803110223008"),
        ("802323123456UAA20180803110223020"),
        ("802323123456UAA20180803110223030"),
        ("802323123456UAA20180803110223009"),
        ("802323123456UAA20180803110223010"),
        ("802323123456UAA20180803110223011"),
        ("802323123456UAA20180803110223012"),
        ("802323123456UAA20180803110223013"),
        ("802323123456UAA20180803110223001"),
        ("802323123456UAA20180803110223022"),
        ("802323123456UAA20180803110223002"),
        ("802323123456UAA20180803110223023"),
        ("802323123456UAA20180803110223024"),
        ("802323123456UAA20180803110223003"),
        ("802323123456UAA20180803110223025"),
        ("802323123456UAA20180803110223004"),
        ("802323123456UAA20180803110223026"),
        ("802323123456UAA20180803110223005"),
        ("802323123456UAA20180803110223027"),
        ("802323123456UAA20180803110223006"),
        ("802323123456UAA20180803110223014"),
        ("802323123456UAA20180803110223015"),
        ("802323123456UAA20180803110223016"),
        ("802323123456UAA20180803110223021"),
        ("802323123456UAA20180803110223000"),
        ("802323123456UAA20180803110223017")
      )
        .toDF("OID")
    val hiveSession= HiveWarehouseSession.session(session).build()
    val rollbackProcessor = new RollbackController(hiveSession)
    rollbackProcessor.rollbackTransactions(df)
  }
}
