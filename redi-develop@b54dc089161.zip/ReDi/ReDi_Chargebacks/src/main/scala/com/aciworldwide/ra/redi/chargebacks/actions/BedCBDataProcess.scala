package com.aciworldwide.ra.redi.chargebacks.actions

import com.aciworldwide.ra.redi.chargebacks.controllers.BedCBDataController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections, Loggers}
import org.apache.logging.log4j.LogManager

object BedCBDataProcess extends BedCBDataController with EstablishConnections with Serializable  {

  @transient lazy val bedCBDatalogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {

    try {
      bedCBDatalogger.info(BED_CB_DATA_PROCESS_INFO+": Start of BED CB Data process")
      bedCBDataPipeline()
      bedCBDatalogger.info(BED_CB_DATA_PROCESS_INFO+":End of BED CB Data  process")
    } catch {
      case exce: Exception => bedCBDatalogger.error(BED_CB_DATA_PROCESS_ERROR+"We have an error in the BED processing " + exce.printStackTrace())
        System.exit(1)
    } finally {
      bedCBDatalogger.info(BED_CB_DATA_PROCESS_INFO+ "End of BED CB Update process")
    }
  }
}