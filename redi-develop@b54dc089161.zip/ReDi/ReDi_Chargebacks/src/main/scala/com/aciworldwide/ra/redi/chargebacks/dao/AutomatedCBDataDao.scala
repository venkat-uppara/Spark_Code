/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */


package com.aciworldwide.ra.redi.chargebacks.dao

import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.spark.sql.{DataFrame, SparkSession}

class AutomatedCBDataDao(hiveSession: HiveWarehouseSession) extends DateUtils with Loggers with DatabaseServices {

  /**
    * setupConnections is used to instantiate the SetupConnections
    * This will be used across the methods for creating connections with the databases, so declaring this globally */
  val setupConnections = new SetupConnections
  val sc= hiveSession.session()

  /**
    *  This method is used read the connection parameters and connect to the Postgres Database and
    *  Read the HWM: High Water Mark data for Automated Chargeback Data process from the Control table. */
  def fetchAutomatedCBHWMData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to fetch HWM data for Automated CB Data process from Postgres Data. " + schemaname + "." + tablename)
    val automatedCBHWMDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Fetched HWM data for Automated CB Data process from Postgres Data. " + schemaname + "." + tablename)
    automatedCBHWMDF
  }

  /**
    * This method is used read the connection parameters and connect to the Oracle Database and
    * Read the data for Automated Chargeback Data Process. */
  def fetchAutomatedCBData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): DataFrame = {
    logRegularMessage("Starting to fetch new/updated data for Automated Chargeback process from Oracle. " + schemaname + "." + tablename)
    val automatedCBDataDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Fetched new/updated data for Automated Chargeback  Data. " + schemaname + "." + tablename)
    automatedCBDataDF
  }

  /**
    * This method is used read the connection parameters and connect to the Oracle Database and
    * Read the maximum of the last_updated column in client. */

  def fetchLastUpdatedFromOracle(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int): String = {
    logRegularMessage("Starting to fetch the Maximum value of the Last Updated data from Oracle. " + schemaname + "." + tablename)
    val automatedCBLastUpdatedDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Fetched Last Updated data from Oracle. " + schemaname + "." + tablename)
    automatedCBLastUpdatedDF.collectAsList().get(0).toString()
  }

  /**
    * This method is used read the connection parameters and connect to the Postgres Database and
    * Update the HWM (High Water Mark) with the latest max GROUP_ID in the Control table. */

  def updateAutomatedCBHWMData(NewAutomatedCBHWMGID:String): Unit = {
    val setupConnection = setupConnections.createScalaConnection(REDI_CONTROL_DATABASE, POSTGRES_CONN_TYPE)
    try {
      val sqlUpdateStatement = setupConnection.createStatement()
      logRegularMessage("Starting to Update the Postgres table with the latest HWM for Automated CB Data Process. ")
      val updateAutomatedCBHWM = "UPDATE " + REDI_CONTROL_TABLE + " SET processhighwatermark = " + "'" + NewAutomatedCBHWMGID + "'" + " WHERE " + REDI_CONTROL_TABLE + ".processname = '" + REDI_AUTOMATED_CB_CONTROL_KEY + "'"
      sqlUpdateStatement.executeUpdate(updateAutomatedCBHWM)
    } catch {
      case e: Exception => logRegularMessage("Exception occurred in updating the HWM for Automated CB Data Process." + e)
    }
    finally {
      setupConnection.close()
    }
  }

}
