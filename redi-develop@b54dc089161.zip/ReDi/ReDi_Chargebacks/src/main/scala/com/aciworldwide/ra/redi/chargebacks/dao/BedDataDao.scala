package com.aciworldwide.ra.redi.chargebacks.dao

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{DateUtils, SetupConnections}
import org.apache.spark.sql.{DataFrame, SparkSession}

class BedDataDao(sc: SparkSession) extends DateUtils with Loggers with DatabaseServices with ReDiConstants with Serializable {
  /**
    * setupConnections is used to instantiate the SetupConnections
    * This will be used across the methods for creating connections with the databases, so declaring this globally */
  val setupConnections = new SetupConnections

  def fetchBedData(tablename: String, connectiontype: String, schemaname: String, numpartitions: Int):DataFrame={
    logRegularMessage("Starting to fetch new/updated data for BED  process from Oracle. " + schemaname + "." + tablename)
    val bedDF = setupConnections.readDataIntoDataframe(sc, tablename, connectiontype, schemaname, numpartitions)
    logRegularMessage("Fetched new/updated data for BED   Data. " + schemaname + "." + tablename)
    bedDF
  }
}
