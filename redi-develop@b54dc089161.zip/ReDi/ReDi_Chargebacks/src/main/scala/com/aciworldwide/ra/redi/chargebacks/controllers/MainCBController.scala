package com.aciworldwide.ra.redi.chargebacks.controllers

import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.BaseController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections}
import com.hortonworks.hwc.HiveWarehouseSession
import org.apache.logging.log4j.LogManager

class MainCBController extends BaseController with EstablishConnections with ReDiConstants {

  @transient lazy val AutomatedCBDataMainCBControllerlogger = LogManager.getLogger(getClass.getName)

  def CBDataPipeline (): Unit = {
    AutomatedCBDataMainCBControllerlogger.info(ACBPDataIngestionProcess_INFO +" :Inside CBDataPipeline Method")
    val sparkSession = createSparkSession(AUTOMATEDCBDATAPROCESSAPP)
    val hiveSession= HiveWarehouseSession.session(sparkSession).build()
    var automatedCBController = new AutomatedCBDataController(hiveSession)
    automatedCBController.AutomatedCBDataPipeline()
  }
}
