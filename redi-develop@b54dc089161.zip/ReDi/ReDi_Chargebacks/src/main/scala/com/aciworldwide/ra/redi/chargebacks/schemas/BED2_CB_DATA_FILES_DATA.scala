package com.aciworldwide.ra.redi.chargebacks.schemas

import java.sql.Timestamp

case class BED2_CB_DATA_FILES_DATA(CB_REF_ID: String, CB_OID: String, CB_TRANSID: String, CB_PROCESS_DATE: Timestamp, CB_RECEIPT_DATE: Timestamp, CB_AMOUNT: BigDecimal
                                   , CB_BANK_REASON_CODE: String, CB_CLIENT_REASON_CODE: String, CB_CLIENT_DESC: String, LINE_NUM: BigDecimal, DATA_PROC_DATE: String, DATA_FILE_NAME: String, CLIENT_ID: String,
                                   SUB_CLIENT_ID: String, OTHER_INFO1: String, OTHER_INFO2: String, OTHER_COUNT1: BigDecimal, OTHER_COUNT2: BigDecimal, REMARKS: String)

