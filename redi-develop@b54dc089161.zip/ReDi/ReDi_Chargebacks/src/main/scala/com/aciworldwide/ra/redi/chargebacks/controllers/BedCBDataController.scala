package com.aciworldwide.ra.redi.chargebacks.controllers

import java.util.UUID.randomUUID

import com.aciworldwide.ra.redi.chargebacks.actions.BedCBDataProcess.BED_CB_DATA_PROCESS_INFO
import com.aciworldwide.ra.redi.chargebacks.dao.BedDataDao
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.controllers.{BaseController, RollbackController}
import com.aciworldwide.ra.redi.common.schemas.ReDiTableSchemas
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.{CommonUtils, DateUtils}
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.logging.log4j.LogManager
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType

class BedCBDataController extends DateUtils with Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with ReDiTableSchemas  {

  @transient lazy val bedCBDataControllerlogger = LogManager.getLogger(getClass.getName)

  val baseController = new BaseController()

  val sparkSession =baseController.createSparkSession(BEDDATAPROCESSAPP)

  val bedDataDao = new BedDataDao(sparkSession)

  val hiveSession= HiveWarehouseSession.session(sparkSession).build()

  hiveSession.setDatabase(REDI_DATABASE)

  val rollback = new RollbackController(hiveSession)

  var lastcbId: String = _

  import sparkSession.implicits._

  lastcbId = gettheDataFromHive(sparkSession, REDI_CB_ID_SEQ).select(col("LastcbId")).head().getString(0).mkString("")

  def getDatabaseSchema(): String = {
    BEDATA_DATABASE
  }
  def getRawDataFrameHWMColumn(): String = {
    REDI_ODS_BED_CB_DATA_TABLE_HWM_COLUMN
  }

  def getODSWhereCondition(value: String): String = {
    " WHERE " +  getRawDataFrameHWMColumn + ">=" + "'" + value +"'"
  }

  def getHWMId(controlKey:String): String = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+":Starting to fetch HWM Value")
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Process Control Table Name:- " + REDI_PROCESS_CONTROL )
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Process Control Key  Name:- " + controlKey )
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Process Status  :- " + PROCESS_CONTROL_COMPLETED )
    var hwmDate =  hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL +" WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'"
      + PROCESS_CONTROL_COMPLETED  + "'" ).head().getString(0)
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"before converting into Oracle " + hwmDate )
    val HWMBED = convertToOracleDateFormat(hwmDate)
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"After converting into Oracle " + hwmDate )
    HWMBED
  }
  def fetchRawDataFrmBeds(BEDHWM:String,tableName:String): DataFrame ={
    val tmpTable = tableName.substring(5,10)
    val challQuery = "( SELECT * FROM" +
      " " + getDatabaseSchema + "." + tableName + getODSWhereCondition(BEDHWM) + ") BED_"+ tmpTable +"_DATA"
    bedDataDao.fetchBedData(challQuery,ORACLE_CONN_TYPE,getDatabaseSchema,BED_DATA_CODE_PARTS)
  }
  def storeDataToHDFS(df: DataFrame,tablename:String): Unit = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Starting to load data into HDFS location")
    if (tablename == REDI_ODS_BED_CB_DATA){
      saveDataintoHDFS(df, JDBC_TO_AVRO_FORMAT, ConfigFactory.load().getString("local.common.hdfs.BED_CB_DATA_FILES_DATA"), HDFS_STORAGE_DATE_EXT)
    }
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Finished loading the data into HDFS location")
  }

  def updateControlTables(bedDf: DataFrame, maxcolumn: String, processName: String,startTime:String): Unit = {
    val endTimeBEDDataLoad = getCurrentdateTimeStamp
    controlTableDataProcess(bedDf, maxcolumn, processName, PROCESS_CONTROL_COMPLETED, startTime, endTimeBEDDataLoad.toString, "Completed the  BED CB data Process",BED_CB_DATA_PROCESS)
  }

  def addChagebackUniqueId: UserDefinedFunction = udf(() => {
    randomUUID().toString()
  })
  /**
    * The Method to fetch trans detail data.
    */

  def getTransMasterCoreData(): DataFrame = {
    bedDataDao.gettheDataFromHive(sparkSession, BI_TRANS_MASTER_CORE)
  }

  /*Store Trans Detail to Hive*/
  def storeTransDetailtoHive(inputDataFrame: DataFrame): Unit = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Starting to push the data into Hive table " + REDI_TRAN_DETAIL_ON_WRITE_TABLE)
    StorethedataintoHive(REDI_TRAN_DETAIL_ON_WRITE_TABLE, APPEND_MODE, inputDataFrame)
  }

  def ProcessBedCBTransData(finalCBDataUpdate: DataFrame): DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Starting to add new columns to result data frame.")
    reorderSourceTableSchema(BED_CB_AUDIT_DATA_ON_WRITE_COL_ORDER,addAuditColumns(finalCBDataUpdate))
  }

  def bedCBDataPipeline(): Unit = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Start the ingestion Process  ")
    /*Get Latest date from Control table to fetch incremental data*/
    val bedCBdataHWM = getHWMId(REDI_ODS_BED_CB_DATA_KEY)
    val startTimeBedCB = getCurrentdateTimeStamp
    var rawBedCBData: DataFrame = null

    if (bedCBdataHWM == null) {
      bedCBDataControllerlogger.error(BED_CB_DATA_PROCESS_ERROR+"There is a error in the " + REDI_ODS_BED_CB_DATA_KEY + " value stored in Hive" + bedCBdataHWM)
    }
    else {
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"BEDCBDATAHWM :  " + bedCBdataHWM)

      rawBedCBData = fetchRawDataFrmBeds(bedCBdataHWM, REDI_ODS_BED_CB_DATA)

      bedCBDataControllerlogger.debug(CLIENTMASTERDATAPROCESS_DEBUG+":Insert data into  REDI_PROCESS_CONTROL table for BED CB  data process job"+ REDI_ODS_BED_CB_DATA_KEY + " Status Is :" + PROCESS_CONTROL_STARTED)
      startControlTableDataProcess(rawBedCBData, getRawDataFrameHWMColumn, REDI_ODS_BED_CB_DATA_KEY, PROCESS_CONTROL_STARTED, startTimeBedCB.toString, "", "Fetched records from ODS BED2_CB_DATA_FILES_DATA  table",BED_CB_DATA_PROCESS)
      storeDataToHDFS(rawBedCBData, REDI_ODS_BED_CB_DATA)
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Ending the ingestion Process  ")
    }

    if(rawBedCBData != null){
      startControlTableDataProcess(rawBedCBData,getRawDataFrameHWMColumn,REDI_ODS_BED_CB_DATA_KEY,PROCESS_CONTROL_INPROGRESS,startTimeBedCB.toString,"","processing to store fetched records  from ODS BED2_CB_DATA_FILES_DATA into Hive ",CLIENT_MASTER_DATA_PROCESS)

      /* ingestion is complted */
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Transformation started for Bed ChargeBack Data process "+rawBedCBData.count())

      val transBedCBData = transformRawBedCBData(getRawBedCBData(rawBedCBData))

      val transDetailsTxn = joinBedCbTransDetail(transBedCBData, getTransdetaildata())
      val chargeBackTxn = getChargeBackTransaction(transDetailsTxn)
      val chargeBackNMatch = joinNotMatchedBedCbTransDetail(transBedCBData, transDetailsTxn)
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+" matchedChargebacktxn " + chargeBackTxn.count())
      val BedCBData = ProcessBedCBData(getBedCBDataTable(chargeBackTxn))
      storeInputBEDCbDatatoHive(REDI_BED_CB_DATA, BedCBData)
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"stored Bed ChargeBack Data into BED_CB_AUDIT_DATA Table ")
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+" not Matched Charge Back Txn ")
      val BedCBNMData = ProcessBedCBData(getBedCBDatanotMatchTable(chargeBackNMatch))
      storeInputBEDCbDatatoHive(REDI_BED_CB_DATA, BedCBNMData)
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"stored Bed ChargeBack Data into BED_CB_AUDIT_DATA Table ")
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Matching logic for  Bed ChargeBack Data ")

      val matchedChargeBackTxn = matchBedChargeBackData(chargeBackTxn).dropDuplicates()

      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+" matchedChargebacktxn ")

      storeInputBEDCbDatatoHive(BED_CB_AUDIT_DATA_ON_WRITE, ProcessBedCBTransData(matchedChargeBackTxn))

      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Hive Merge query started : ")

      val updateTransCorewNoFraud = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING " +
        "(select *  from (select *,row_number() over(partition by oid  order by (BEDCBPROCESSDATE) desc) as num  from REDI.BED_CB_AUDIT_DATA_ON_WRITE) latest  where num=1 and clientid ='000022' and  bedcbbankreason in (\"07\", \"30\", \"31\", \"34\", \"42\", \"50\", \"53\", \"55\", \"60\", \"74\", \"82\", \"85\", \"86\", \"D1\", \"DP\", \"AP\", \"CP\", \"M01\",\"M35\", \"M36\", \"P17\", \"R04\", \"R13\", \"R2\", \"RG\", \"RM\", \"RN\", \"RV\", \"S01\", \"A3\", \"AS\", \"PTI98\")) AS S ON (D.oid=S.oid) WHEN MATCHED " +
        "THEN UPDATE SET BEDCBPROCESSDATE=S.BEDCBPROCESSDATE,BEDCBRECEIPTDATE =S.BEDCBRECEIPTDATE," +
        "BEDCBAMOUNT =S.BEDCBAMOUNT,BEDCBBANKREASON =S.BEDCBBANKREASON," +
        "BEDCBCLIENTREASON =S.BEDCBCLIENTREASON,BEDCBCLIENTDESC =S.BEDCBCLIENTDESC,BEDCBPROCESSYYYYMMDD=S.BEDCBRECEIPTYYYYMMDD,BEDCBDATAPROCYYYYMMDD=S.BEDCBDATAPROCYYYYMMDD," +
        "BEDCBWHENLOADED =S.BEDCBWHENLOADED,BEDCBWHOLOADED =S.BEDCBWHOLOADED," +
        "BEDCBWHENUPDATED =S.BEDCBWHENUPDATED,BEDCBWHOUPDATED =S.BEDCBWHOUPDATED," +
        "BEDCBFRAUDYN =S.BEDCBFRAUDYN,BEDTRANSACTIONID =S.BEDTRANSACTIONID," +
        "BEDCLIENTID =S.BEDCLIENTID,BEDSUBCLIENTID =S.BEDSUBCLIENTID," +
        "BEDDATAPROCDATE =S.BEDDATAPROCDATE,BEDDATAFILENAME =S.BEDDATAFILENAME," +
        "BEDLINENUMBER =S.BEDLINENUMBER,BEDOTHERINFO1 =S.BEDOTHERINFO1," +
        "BEDOTHERINFO2 =S.BEDOTHERINFO2,BEDOTHERCOUNT1 =S.BEDOTHERCOUNT1," +
        "BEDOTHERCOUNT2 =S.BEDOTHERCOUNT2,BEDREMARKS =S.BEDREMARKS," +
        "BEDREFERENCEID =S.BEDREFERENCEID,CHARGEBACKID =S.CHARGEBACKID," +
        "CHARGEBACKYN =S.CHARGEBACKYN,CHARGEBACKDATE =S.CHARGEBACKDATE," +
        "CHARGEBACKYYYYMMDD =S.CHARGEBACKYYYYMMDD,CHARGEBACKREASON =S.CHARGEBACKREASON," +
        "CHARGEBACKFRAUDYN =S.CHARGEBACKFRAUDYN,CHARGEBACKITEMS =S.CHARGEBACKITEMS," +
        "CHARGEBACKPROCYYYYMMDD =S.CHARGEBACKPROCYYYYMMDD,CURRENTSTATUS =S.CURRENTSTATUS," +
        "CLIENTID =S.CLIENTID,SUBCLIENTID =S.SUBCLIENTID," +
        "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

      bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG+"Hive Merge query Completed with no real fraud update : "+updateTransCorewNoFraud)

      val updateTransCore = hiveSession.executeUpdate("MERGE INTO REDI.BI_TRANS_MASTER_CORE AS D USING " +
        "(select *  from (select *,row_number() over(partition by oid  order by (BEDCBPROCESSDATE) desc) as num  from REDI.BED_CB_AUDIT_DATA_ON_WRITE) latest  where num=1 and clientid !='000022' and  bedcbbankreason not in (\"07\", \"30\", \"31\", \"34\", \"42\", \"50\", \"53\", \"55\", \"60\", \"74\", \"82\", \"85\", \"86\", \"D1\", \"DP\", \"AP\", \"CP\", \"M01\",\"M35\", \"M36\", \"P17\", \"R04\", \"R13\", \"R2\", \"RG\", \"RM\", \"RN\", \"RV\", \"S01\", \"A3\", \"AS\", \"PTI98\")) AS S ON (D.oid=S.oid) WHEN MATCHED " +
        "THEN UPDATE SET BEDCBPROCESSDATE=S.BEDCBPROCESSDATE,BEDCBRECEIPTDATE =S.BEDCBRECEIPTDATE," +
        "BEDCBAMOUNT =S.BEDCBAMOUNT,BEDCBBANKREASON =S.BEDCBBANKREASON," +
        "BEDCBCLIENTREASON =S.BEDCBCLIENTREASON,BEDCBCLIENTDESC =S.BEDCBCLIENTDESC,BEDCBPROCESSYYYYMMDD=S.BEDCBRECEIPTYYYYMMDD,BEDCBDATAPROCYYYYMMDD=S.BEDCBDATAPROCYYYYMMDD," +
        "BEDCBWHENLOADED =S.BEDCBWHENLOADED,BEDCBWHOLOADED =S.BEDCBWHOLOADED," +
        "BEDCBWHENUPDATED =S.BEDCBWHENUPDATED,BEDCBWHOUPDATED =S.BEDCBWHOUPDATED," +
        "BEDCBFRAUDYN =S.BEDCBFRAUDYN,BEDTRANSACTIONID =S.BEDTRANSACTIONID," +
        "BEDCLIENTID =S.BEDCLIENTID,BEDSUBCLIENTID =S.BEDSUBCLIENTID," +
        "BEDDATAPROCDATE =S.BEDDATAPROCDATE,BEDDATAFILENAME =S.BEDDATAFILENAME," +
        "BEDLINENUMBER =S.BEDLINENUMBER,BEDOTHERINFO1 =S.BEDOTHERINFO1," +
        "BEDOTHERINFO2 =S.BEDOTHERINFO2,BEDOTHERCOUNT1 =S.BEDOTHERCOUNT1," +
        "BEDOTHERCOUNT2 =S.BEDOTHERCOUNT2,BEDREMARKS =S.BEDREMARKS," +
        "BEDREFERENCEID =S.BEDREFERENCEID,CHARGEBACKID =S.CHARGEBACKID," +
        "CHARGEBACKYN =TRUE,CHARGEBACKDATE =S.CHARGEBACKDATE," +
        "CHARGEBACKYYYYMMDD =S.CHARGEBACKYYYYMMDD,CHARGEBACKREASON =S.CHARGEBACKREASON," +
        "CHARGEBACKFRAUDYN =S.CHARGEBACKFRAUDYN,CHARGEBACKITEMS =S.CHARGEBACKITEMS," +
        "CHARGEBACKPROCYYYYMMDD =S.CHARGEBACKPROCYYYYMMDD,CURRENTSTATUS =S.CURRENTSTATUS," +
        "REALFRAUDYN =S.REALFRAUDYN,REALFRAUDYYYYMMDD =S.REALFRAUDYYYYMMDD," +
        "REALFRAUDTYPE =S.REALFRAUDTYPE,REALFRAUDDATE =S.REALFRAUDDATE,RELFRAUDYYYYMMDD =S.RELFRAUDYYYYMMDD," +
        "RELFRAUDTYPE =S.RELFRAUDTYPE,REALFRAUDDATEBAE =current_timestamp,CLIENTID =S.CLIENTID,SUBCLIENTID =S.SUBCLIENTID," +
        "WHENLOADED=S.WHENLOADED,WHOLOADED=S.WHOLOADED,WHENUPDATED=S.WHENUPDATED,WHOUPDATED=S.WHOUPDATED")

      bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG+"Hive Merge query Completed  : "+updateTransCore)

      /* Update all the transactions as Fraud for the given fradulent card numbers in Hive Ingestion table */
      bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG + " Started labelling Fradulent transactions into Hive Ingestion table " + TRANS_MASTER_CORE_BASE)
      val updateFraudTrans_2 = hiveSession.executeUpdate(" Merge INTO redi.TRANS_MASTER_CORE AS ingtransdata " +
        " USING (select distinct OID from (select *,row_number() over(partition by oid  order by (BEDCBPROCESSDATE) desc) as num  from REDI.BED_CB_AUDIT_DATA_ON_WRITE) latest  where num=1 and clientid !='000022' and  bedcbbankreason not in (\"07\", \"30\", \"31\", \"34\", \"42\", \"50\", \"53\", \"55\", \"60\", \"74\", \"82\", \"85\", \"86\", \"D1\", \"DP\", \"AP\", \"CP\", \"M01\",\"M35\", \"M36\", \"P17\", \"R04\", \"R13\", \"R2\", \"RG\", \"RM\", \"RN\", \"RV\", \"S01\", \"A3\", \"AS\", \"PTI98\")) AS frauddata " +
        " on (frauddata.oid = ingtransdata.oid  and ingtransdata.realfraudyn = 'N' ) " +
        " When matched Then Update " +
        " SET RealFraudYN = 'Y'," +
        " realfraudtype = 'FRAUDCBF'," +
        " RealFraudDate = current_timestamp," +
        " realfrauddatebae = current_timestamp "
      )

      bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG + " Updated Fradulent transactions to redi.TRANS_MASTER_CORE" + updateFraudTrans_2)

      if(updateTransCore && updateFraudTrans_2 ){
        val fraudRollBack= hiveSession.execute("select distinct OID from (select *,row_number() over(partition by oid  order by (BEDCBPROCESSDATE) desc) as num  from REDI.BED_CB_AUDIT_DATA_ON_WRITE) latest  where num=1 and clientid !='000022' and  bedcbbankreason not in (\"07\", \"30\", \"31\", \"34\", \"42\", \"50\", \"53\", \"55\", \"60\", \"74\", \"82\", \"85\", \"86\", \"D1\", \"DP\", \"AP\", \"CP\", \"M01\",\"M35\", \"M36\", \"P17\", \"R04\", \"R13\", \"R2\", \"RG\", \"RM\", \"RN\", \"RV\", \"S01\", \"A3\", \"AS\", \"PTI98\")")

        bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG+" fraudulent transaction for rollback ")
        /** Rollback Controller for fradulent transaction to the producer */
        bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_DEBUG+"Rollback Transaction Step Started @ " + current_timestamp())

        rollback.rollbackTransactions(fraudRollBack)

      }

      hiveSession.executeUpdate("truncate table redi.BED_CB_AUDIT_DATA_ON_WRITE ")

      updateControlTables(rawBedCBData, getRawDataFrameHWMColumn, REDI_ODS_BED_CB_DATA_KEY,startTimeBedCB.toString)
    }else{
      bedCBDataControllerlogger.info(BED_CB_DATA_PROCESS_INFO+" There is BED CB data to Update into  Hive Table  " )
    }
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Rollback Transaction Step Completed @ " + current_timestamp())
  }

  /**
    * @param inputDataFrame
    * @return DataFrame
    * Store the BED CB Data to Hive
    */
  def storeInputBEDCbDatatoHive (tableName:String ,inputDataFrame: DataFrame):Unit ={
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Starting to push the data into Hive tables " + tableName)
    try {
      storeDataIntoHive(tableName, APPEND_MODE, inputDataFrame)
    } catch {
      case exce: Exception =>  bedCBDataControllerlogger.error(BED_CB_DATA_PROCESS_ERROR+"We have an error on storing data into Hive" +  exce.printStackTrace())
    } finally {
      bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"End of Storing CB_DATA data into Hive")
    }
  }

  def getRawBedCBData(rawBedCbData: DataFrame): DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"start Raw Bed Charge Back data")
    val CBProcessYYMMDD = rawBedCbData.select($"CB_REF_ID", $"CB_OID", $"CB_TRANSID", $"CB_PROCESS_DATE", $"CB_RECEIPT_DATE",
      $"CB_AMOUNT", $"CB_BANK_REASON_CODE", $"CB_CLIENT_REASON_CODE", $"CB_CLIENT_DESC", $"LINE_NUM", $"DATA_PROC_DATE",
      $"DATA_FILE_NAME", $"CLIENT_ID", $"SUB_CLIENT_ID", $"OTHER_INFO1", $"OTHER_INFO2", $"OTHER_COUNT1", $"OTHER_COUNT2", $"REMARKS")

    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total txn count  for Raw Bed Charge Back data ")
    CBProcessYYMMDD
  }

  def transformRawBedCBData(transBedCbData: DataFrame):DataFrame ={
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Transform Raw Bed CB data ")
    val transformBedCbData=  transBedCbData.select($"CB_OID",$"CB_TRANSID".alias("bedtransactionid"),
      unix_timestamp(to_date(col("CB_PROCESS_DATE"), "dd-MMM-yy")).cast(TimestampType).as("bedcbprocessdate"),
      unix_timestamp(to_date(col("CB_RECEIPT_DATE"), "dd-MMM-yy")).cast(TimestampType).as("bedcbreceiptdate"),
      $"CB_BANK_REASON_CODE".alias("bedcbbankreason"),$"CLIENT_ID".alias("bedclientid"), $"CB_AMOUNT".alias("bedcbamount"),
      $"CB_CLIENT_REASON_CODE".alias("bedcbclientreason"), $"CB_CLIENT_DESC".alias("bedcbclientdesc"),
      unix_timestamp(to_date(col("DATA_PROC_DATE"), "dd-MMM-yy")).cast(TimestampType).as("beddataprocdate"),
      $"SUB_CLIENT_ID".alias("bedsubclientid"),$"DATA_FILE_NAME".alias("beddatafilename"), $"LINE_NUM".alias("bedlinenumber"),
      $"OTHER_INFO1".alias("bedotherinfo1"),$"OTHER_INFO2".alias("bedotherinfo2"),$"OTHER_COUNT1".alias("bedothercount1"),
      $"OTHER_COUNT2".alias("bedothercount2"),$"REMARKS".alias("bedremarks"),$"CB_REF_ID".alias("bedreferenceid"))
      .withColumn("bedcbprocessyyyymmdd",date_format(to_date(col("bedcbprocessdate"), "dd-MMM-yy"), "yyyyMMdd"))
      .withColumn("bedcbreceiptyyyymmdd",date_format(to_date(col("bedcbreceiptdate"), "dd-MMM-yy"), "yyyyMMdd"))
      .withColumn("bedcbdataprocyyyymmdd",date_format(to_date(col("beddataprocdate"), "dd-MMM-yy"), "yyyyMMdd"))
      .withColumn("ChargebackIDGen", concat(lit("cbk"), monotonically_increasing_id() + (lastcbId.toInt) + 1))
      .withColumn("bedcbfraudyn", when($"bedclientid" === "000022" &&
        ($"bedcbbankreason".isin("07", "30", "31", "34", "42", "50", "53", "55", "60", "74", "82", "85", "86", "D1", "DP", "AP", "CP", "M01",
          "M35", "M36", "P17", "R04", "R13", "R2", "RG", "RM", "RN", "RV", "S01", "A3", "AS", "PTI98")), lit("N")).otherwise("Y"))
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total txn count  for Transform Raw Bed CB data ")
    transformBedCbData
  }

  def getTransdetaildata(): DataFrame = {
    val trans_Core = getTransMasterCoreData()
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Started Transform TransMasterCore ")

    val Transmastercore = trans_Core.select($"oid",$"oiddate",$"clientid",$"subclientid",$"client12",$"transactionid",$"currentstatus",$"REALFRAUDYN".alias("realfraudold"), $"realfraudyyyymmdd".alias("realfraudyyyymmddold"), $"realfraudtype".alias("realfraudtypeold"),
      $"realfrauddate".alias("realfrauddateold"),$"RELFRAUDYN".alias("relfraudold"),$"relfraudyyyymmdd".alias("relfraudyyyymmddold"),$"relfraudtype".alias("relfraudtypeold"),$"ChargebackYN",$"RECOMMENDATION",
      $"oiddateyyyymmdd")
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total txn count  for Transmastercore ")
    Transmastercore
  }

  def joinBedCbTransDetail(rawBedCbData: DataFrame, transDetail: DataFrame): DataFrame = {
    val rawchargebackdata = rawBedCbData.join(transDetail, ((rawBedCbData.col("bedclientid") === transDetail.col("clientid")) && ((rawBedCbData.col("CB_OID") === transDetail.col("oid"))
      || (rawBedCbData.col("bedtransactionid") === transDetail.col("transactionid")))), joinType = "inner").dropDuplicates()
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total charge back data after matching logic ")
    rawchargebackdata
  }

  def getChargeBackTransaction(transactionData :DataFrame):DataFrame= {
    val transaction = transactionData.where(($"ChargebackYN" === "" || $"ChargebackYN".isNull || $"ChargebackYN" === " " || $"ChargebackYN" === "false") && $"RECOMMENDATION" =!= "AuthDec")
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total ChargeBack Transactions  ")
    transactionData.drop("ChargebackYN")
  }

  def ProcessBedCBData(finalBeddata: DataFrame): DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Starting to add new columns to result data frame.")
    reorderSourceTableSchema(BED_CB_DATA_TABLE_COL_ORDER, addAuditColumns(finalBeddata))
  }

  def joinNotMatchedBedCbTransDetail(rawBedCbData: DataFrame, transDetailtxn: DataFrame): DataFrame = {
    val rawbedCBbackdata = rawBedCbData.join(transDetailtxn, ((rawBedCbData.col("CB_OID") =!= transDetailtxn.col("oid"))
      || (rawBedCbData.col("bedtransactionid") =!= transDetailtxn.col("transactionid"))), "left_anti")
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+" charge back data not Matched after matching logic ")
    rawbedCBbackdata
  }

  def getBedCBDatanotMatchTable(bedCbData: DataFrame): DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total not matched txn count  for bedCbData ")
    bedCbData.select($"CB_OID".alias("oid"), $"bedtransactionid".alias("transactionid"), $"bedcbprocessdate".alias("CBProcessDate"),
      $"bedcbreceiptdate".alias("CBReceiptDate"), $"bedcbamount".alias("CBAmount"), $"bedcbbankreason".alias("CBBankReason"),
      $"bedcbclientreason".alias("CBClientReason"), $"bedcbclientdesc".alias("CBClientDesc"), $"beddataprocdate".alias("DataProcDate"),
      $"bedclientid".alias("ClientId"), $"bedsubclientid".alias("SubClientId"), $"bedcbprocessyyyymmdd".alias("CBProcessYYYYMMDD"),
      $"bedcbreceiptyyyymmdd".alias("CBReceiptYYYYMMDD"), $"ChargebackIDGen".alias("ChargebackID"), $"bedcbfraudyn".alias("FraudYN")
      , $"bedcbdataprocyyyymmdd".alias("DataProcYYYYMMDD")).withColumn("CBremarks", lit("NotMatch")).withColumn("oiddate", lit(""))
      .withColumn("client12", lit("")).withColumn("oiddateyyyymmdd", lit(""))
  }

  def getBedCBDataTable(bedCbData: DataFrame): DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total txn count  for bedCbData ")
    bedCbData.select($"oid", $"oiddate", $"bedtransactionid".alias("transactionid"), $"bedcbprocessdate".alias("CBProcessDate"),
      $"bedcbreceiptdate".alias("CBReceiptDate"), $"bedcbamount".alias("CBAmount"), $"bedcbbankreason".alias("CBBankReason"),
      $"bedcbclientreason".alias("CBClientReason"), $"bedcbclientdesc".alias("CBClientDesc"), $"beddataprocdate".alias("DataProcDate"),
      $"bedclientid".alias("ClientId"), $"bedsubclientid".alias("SubClientId"), $"bedcbprocessyyyymmdd".alias("CBProcessYYYYMMDD"),
      $"bedcbreceiptyyyymmdd".alias("CBReceiptYYYYMMDD"), $"ChargebackIDGen".alias("ChargebackID"), $"bedcbfraudyn".alias("FraudYN"),
      $"client12",$"OIDDateYYYYMMDD", $"bedcbdataprocyyyymmdd".alias("DataProcYYYYMMDD")).withColumn("CBremarks", lit("Match"))
  }

  def matchBedChargeBackData(bedCbData: DataFrame ):DataFrame = {
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Started  matchBedChargeBackData ")
    val CBDataUpdate= bedCbData.select($"oid",$"oiddate",$"clientid",$"subclientid",$"client12",$"transactionid"
      , $"CurrentStatus".alias("CurrentStatusold"), $"oiddateyyyymmdd", $"ChargebackIDGen", $"bedcbbankreason", $"bedcbfraudyn",
      $"bedcbreceiptdate",$"bedcbprocessdate", $"bedcbreceiptyyyymmdd",$"bedcbdataprocyyyymmdd",$"bedcbprocessyyyymmdd",$"bedtransactionid",$"bedclientid",$"bedcbamount",$"bedcbclientreason",$"bedcbclientdesc",
      $"beddataprocdate",$"bedsubclientid",$"beddatafilename",$"bedlinenumber",$"bedotherinfo1",$"bedotherinfo2",$"bedothercount1",$"bedothercount2",$"bedremarks",$"bedreferenceid")
      .withColumn("ChargebackYN", lit("Y")).withColumn("ChargebackID", lit($"ChargebackIDGen")).withColumn("chargebackreason", lit($"bedcbbankreason")).withColumn("ChargebackFraudYN", lit($"bedcbfraudyn"))
      .withColumn("ChargebackItems",lit(1)).withColumn("ChargebackYYYYMMDD",date_format(to_date(col("bedcbreceiptdate"), "dd-MMM-yy"), "yyyyMMdd")).withColumn("ChargebackDate",lit($"bedcbreceiptdate"))
      .withColumn("ChargebackProcYYYYMMDD", lit($"bedcbprocessyyyymmdd"))
      .withColumn("CurrentStatus", lit(when($"CurrentStatusold".like("%CBK%"), lit($"CurrentStatusold")).otherwise(concat(lit($"CurrentStatusold"), lit(" -> CBK")))))
      .withColumn("bedcbwhenloaded", current_timestamp())
      .withColumn("bedcbwholoaded", lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn("bedcbwhenupdated", current_timestamp())
      .withColumn("bedcbwhoupdated", lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn("realfraudYN", when(col("ChargebackFraudYN") === lit("Y"), lit("Y")).otherwise(lit("")))
      .withColumn("realfraudyyyymmdd", when(col("ChargebackFraudYN") === lit("Y"), lit(date_format(current_date(), "yyyyMMdd"))).otherwise(lit("")))
      .withColumn("realfraudtype", when(col("ChargebackFraudYN") === lit("Y"), lit("FRAUDCBF")).otherwise(lit("")))
      .withColumn("realfrauddate", when(col("ChargebackFraudYN") === lit("Y"), lit(current_date())).otherwise(lit("")))
      .withColumn("realfrauddatebae", when(col("ChargebackFraudYN") === lit("Y"), lit(current_timestamp())).otherwise(lit("")))
      .withColumn("relfraudYN", when(col("ChargebackFraudYN") === lit("Y"), lit("Y")).otherwise(lit("")))
      .withColumn("relfraudyyyymmdd", when(col("ChargebackFraudYN") === lit("Y"), lit(date_format(current_date(), "yyyyMMdd"))).otherwise(lit("")))
      .withColumn("relfraudtype", when(col("ChargebackFraudYN") === lit("Y"), lit("FRAUDCBF")).otherwise(lit("")))
    //.withColumn("currentstatus", when(!col("currentstatus").like("%>CB%"), concat(col("currentstatus"), lit("->CBK"))).otherwise(col("currentstatus")))
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"completed  matchBedChargeBackData ")
    bedCBDataControllerlogger.debug(BED_CB_DATA_PROCESS_DEBUG+"Total txn count  for charge back data after matching logic  completed")
    CBDataUpdate.drop("CurrentStatusold","ChargebackIDGen")
  }
}