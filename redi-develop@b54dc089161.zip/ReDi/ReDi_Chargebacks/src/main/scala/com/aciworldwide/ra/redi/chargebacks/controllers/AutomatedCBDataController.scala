
/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */

package com.aciworldwide.ra.redi.chargebacks.controllers

import com.aciworldwide.ra.redi.chargebacks.dao.AutomatedCBDataDao
import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import com.aciworldwide.ra.redi.common.controllers.RollbackController
import com.hortonworks.hwc.HiveWarehouseSession
import com.typesafe.config.ConfigFactory
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions._
import org.apache.logging.log4j.LogManager



class AutomatedCBDataController(hiveSession : HiveWarehouseSession) extends Serializable with ReDiConstants with CommonUtils with DatabaseServices {

  //val sparkSession: SparkSession = createSparkSession(AUTOMATEDCBDATAPROCESSAPP)

  @transient lazy val AutomatedCBDataControllerlogger = LogManager.getLogger(getClass.getName)

  /** automatedCBDataDao is used to instantiate the AutomatedCBDataDao with the session builder parameter
    * This will be used across the methods for accessing the database access , so declaring this globally */
  val automatedCBDataDao = new AutomatedCBDataDao(hiveSession)
  val sparkSession = hiveSession.session()

  import sparkSession.implicits._


  //val listReasonCode: Seq[String] = List("4837","4863","75","81","83","P01","UA","F06","F16")
  //val listProcessor: Seq[String] = List( "UKCB","BMS","ETHOCA" )
  //val listFDCPNCProcessorReasonCode: Seq[String] = List( "37","63","75","83")
  //val listReasonCodeMatchType: Seq[String] = List("M2008","M2011","M2700","M6305","M6321","M6323","M6341","M6342","V28","V32","V33","V34")

  val refclient  = hiveSession.executeQuery("Select ClientId,SubClientId,client12,clientcurr,subclientcurr,ClientName,SubClientName,ClientGroup,flagtre From " + REDI_RBI_REF_CLIENT)
  val refdates =  hiveSession.executeQuery("Select dateyymmdd,datetextshort,weektextshort2,weektextmed,monthtextmed,WeekYYMMDD,monthyyyymm From " + REDI_RBI_REF_DATES_TABLE)
  val currencyrates  = hiveSession.executeQuery("Select * From " + CURR_CONV_TABLE)
 val cbReasonCodes = hiveSession.executeQuery("Select * From " + REDI_DATABASE +"."+ REDI_CB_REASONCODES)

  var lastcbId: String = _
  var fraudRollback: DataFrame = _

  var cblabelling = new CBLabellingController(hiveSession)
  val rollback = new RollbackController(hiveSession)

  /*TODO : Check if writing to file will improve perf*/
  lastcbId = hiveSession.executeQuery("Select LastcbId From " + REDI_CB_ID_SEQ).head().getString(0).mkString("")
  val destmap=currencyrates.select($"DestCurrencyCode",$"ConversionRate").collect().map(row=>(row.getString(0),row.getDouble(1))).toMap


  /** This method is used to connect to Oracle database
    * Retrieve Chargebacks data from CB_MASTER_DATA table. */
  def fetchAutomatedCBData(tablename: String, connectiontype: String, schemaname: String): DataFrame = {
    logRegularMessage("Starting to Fetch Chargebacks data into the processing layer " + schemaname + "." + tablename)
    automatedCBDataDao.fetchAutomatedCBData(tablename, connectiontype, schemaname,AUTOMATED_CB_DATA_CODE_PARTS)
  }

  /**
    * This method is used to store the data from source into HDFS. */
  def saveAutomatedCBDatatoHDFS(inputDataFrame: DataFrame):Unit = {
    logRegularMessage("Starting to load data into HDFS location")
    automatedCBDataDao.saveDataintoHDFS(inputDataFrame, JDBC_TO_AVRO_FORMAT, ConfigFactory.load().getString("local.common.hdfs.AUTOMATED_CB_DATA_HDFS"), HDFS_STORAGE_DATE_EXT)
    logRegularMessage("Finished loading the data into HDFS location")
  }
  def transformMatchType : UserDefinedFunction = udf((clientId: String, reasoncode: String, processor: String) => {

    var matchType = "N"
    val listReasonCodeMatchType: Seq[String] = List("M2008","M2011","M2700","M6305","M6321","M6323","M6341","M6342","V28","V32","V33","V34")

    if (List("000197","000198","777779", "000227","000228").contains(clientId) || processor.equals("ETHOCA")) {
      matchType = "-"
    }
    if (listReasonCodeMatchType.contains(reasoncode) && (clientId.equals("000137") || clientId.equals("000159"))) {
      matchType = "W"
    }
    matchType
  })



  //  set ReasonCode = substring(ReasonCode,2,2)
  //  where Processor = 'FDC'
  //  and len(ReasonCode) = 3
  //  and left(ReasonCode,1) = '0';
  def transformReasonCode: UserDefinedFunction = udf((reasoncode: String, processor: String ) => {
    var xReasonCode:  String = reasoncode
    if (reasoncode  != null &&  reasoncode.length() == 3
      && reasoncode.charAt(0) == '0'
      && !processor.isEmpty &&  processor.equals("FDC") ) {
      xReasonCode = reasoncode.substring(1,3)
    }
    xReasonCode
  })

  def transformFraudYN : UserDefinedFunction = udf((fraudYNtemp: String, clientId: String, reasoncode: String, processor: String, sdsyn: String) => {

    var fraudYN = "N"
    val listReasonCode: Seq[String] = List("4837","4863","75","81","83","P01","UA","F06","F16")
    val listProcessor: Seq[String] = List( "UKCB","BMS","ETHOCA" )
    val listFDCPNCProcessorReasonCode: Seq[String] = List( "37","63","75","83")

    if (fraudYNtemp  != null) {
      fraudYN = fraudYNtemp
    }

    /** For Client Specific Validations**/

    if (clientId.equals("000105") && listReasonCode.contains(reasoncode)) {
      fraudYN ="Y"
    }

    if (reasoncode != null && reasoncode.equals("XXX") && listProcessor.contains(processor)) {
      fraudYN ="Y"
    }

    if (processor != null && processor.equals("IDTGV")) {
      fraudYN ="Y"
    }

    if (processor != null && processor.equals("GC") && sdsyn =="Y") {
      fraudYN ="Y"
    }

    if (processor != null && processor.equals("GC") && reasoncode != null && reasoncode.equals("75") && clientId.equals("000031")) {
      fraudYN ="Y"
    }

    if (processor != null && processor.equals("FDC_PNC") && listFDCPNCProcessorReasonCode.contains(reasoncode)) {
      fraudYN ="Y"
    }


    fraudYN
  })

  def transformSDSYN : UserDefinedFunction = udf((SDSYNtemp: String, clientId: String, reasoncode: String, processor: String) => {

    var SDSYN = "N"
    val listReasonCode: Seq[String] = List("4837","4863","75","81","83","P01","UA","F06","F16")
    val listProcessor: Seq[String] = List( "UKCB","BMS","ETHOCA" )
    val listFDCPNCProcessorReasonCode: Seq[String] = List( "37","63","75","83")

    if (SDSYNtemp  != null) {
      SDSYN = SDSYNtemp
    }
    /** For Client Specific Validations**/

    if (clientId.equals("000105") && listReasonCode.contains(reasoncode)) {
      SDSYN = "Y"
    }
    if (reasoncode != null && reasoncode.equals("XXX") && listProcessor.contains(processor)) {
      SDSYN ="Y"
    }

    if (processor != null && processor.equals("IDTGV")) {
      SDSYN ="Y"
    }

    if (processor != null && processor.equals("FDC_PNC") && listFDCPNCProcessorReasonCode.contains(reasoncode)) {
      SDSYN ="Y"
    }
    SDSYN
  })

  //val ReasonText: Nothing = 'Reason Code ' || trim(ReasonCode) || ' - type ' || trim(Processor) || '/' || CardType
  def transformReasonText: UserDefinedFunction = udf((description: String, reasoncode: String, processor: String, cardtype: String) => {
    var xReasonText =  description
    if (description == null || (description != null && description.length ==0) ) {
      xReasonText = "Reason Code "
      if (reasoncode != null) {
        xReasonText = xReasonText.concat(reasoncode)
      }
      xReasonText = xReasonText.concat(" - type ")
      if (processor != null) {
        xReasonText = xReasonText.concat(processor)
      }
      xReasonText = xReasonText.concat("/")
      if (cardtype != null) {
        xReasonText = xReasonText.concat(cardtype)
      }

    }
    xReasonText
  })

  def currencyConversionAndValueBands(df: DataFrame): DataFrame = {
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside currencyConversion Method")
    val allCurrencyTotal = df
      .withColumn("CBValueGBP", when(col("currCd") === lit("GBP"), col("chargebackvalue"))
        .otherwise(when(col("currCd") =!= lit("GBP"), convertedCurrency(col("currCd"), lit("GBP"), col("chargebackvalue")))))
      .withColumn("CBValueUSD", when(col("currCd") === lit("USD"), col("chargebackvalue"))
        .otherwise(when(col("currCd") =!= lit("USD"), convertedCurrency(col("currCd"), lit("USD"), col("chargebackvalue")))))
      .withColumn("CBValueEUR", when(col("currCd") === lit("EUR"), col("chargebackvalue"))
        .otherwise(when(col("currCd") =!= lit("EUR"), convertedCurrency(col("currCd"), lit("EUR"), col("chargebackvalue")))))
      .withColumn("CBValueClient", when(col("currCd") === col("clientcurr"),
        col("chargebackvalue"))
        .otherwise(convertedCurrency(col("currCd"), col("clientcurr"), col("chargebackvalue"))))
      .withColumn("CBValueSubClient", when(col("currCd") === col("subclientcurr"),
        col("chargebackvalue"))
        .when(col("subclientcurr").isNull, convertedCurrency(col("currCd"), col("clientcurr"), col("chargebackvalue")))
        .otherwise(when(col("currCd") =!= col("subclientcurr"),
          convertedCurrency(col("currCd"), col("subclientcurr"), col("chargebackvalue")))))
    /*.withColumn("CBValueGBP", lit(""))
    .withColumn("CBValueUSD", lit(""))
    .withColumn("CBValueEUR", lit(""))
    .withColumn("CBValueClient", lit(""))
    .withColumn("CBValueSubClient", lit(""))*/
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : End Of currencyConversion Method")
    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : End Of currencyConversion Method")
    allCurrencyTotal
  }
  def convertedCurrency : UserDefinedFunction = udf((sourceCurrency: String, destcurrency: String, noOfUnits: String) => {
    //logRegularMessage("Inside convertedCurrency")
    var convertedCurrency: Double = 0.0
    var sourceconvrate: Double = 0.0
    var destconvrate: Double = 0.0

    /* if(destmap.isDefinedAt(sourceCurrency))
      {
        var currrate= destmap.get(sourceCurrency)
        sourceconvrate=currrate.get
      }*/
    /*if(destmap.contains(destcurrency))
    {
      var currrate= destmap.get(destcurrency)
      destconvrate=currrate.get
    }*/
    if(sourceconvrate>0) {
      //logRegularMessage("Inside if sourceconvrate conditon")
      convertedCurrency = ((1 / sourceconvrate) * destconvrate) * noOfUnits.toDouble
      convertedCurrency = BigDecimal(convertedCurrency).setScale(2, BigDecimal.RoundingMode.HALF_UP).toDouble
    }

    //logRegularMessage("Completed convertedCurrency UDF")
    convertedCurrency
  })

  def funcMaskCardNo1: UserDefinedFunction = udf((cardNo: String) => {
    var finalcc =""
    if (cardNo != null) {
      var trimlen = cardNo.trim.length
      //var maskchar = '*'.toString().*((if (trimlen > 20) 20 else trimlen) - 10)
      var maskchar = '*'.toString().*(trimlen - 10)
      finalcc = cardNo.trim.substring(0, 6) + maskchar + cardNo.trim.takeRight(4)
    }
    finalcc
  })

  /** Hash Card No Function **/
  def funcHashCardNo1: UserDefinedFunction = udf((inputString: String) => {
    var finalcc = " "
    //val saltcc1: String = ConfigFactory.load().getString("local.common.saltcc.value")
    val saltcc = "152XTOKGGBXXs-fb"
    if(inputString != null) {
      val inputStrTrim = inputString.trim.concat(saltcc)
      //println("inputStrTrim :" + inputStrTrim )

      val md = java.security.MessageDigest.getInstance("SHA-1")
      finalcc =  md.digest(inputStrTrim.getBytes("UTF-8")).map("%02x".format(_)).mkString
    }
    finalcc
  }
  )
  def funcAddTransformedColumn: UserDefinedFunction = udf((inputValue: String, inputColumn: String) => {

    if (inputValue != null && !inputValue.isEmpty) {
      inputColumn match {
        case "CardType" => inputValue match {
          case "A" => "Amex"
          case "C" => "Card Blanche"
          case "D" => "Discover"
          case "E" => "Diners"
          case "J" => "JCB"
          case "M" => "Mastercard"
          case "V" => "Visa"
          case "P" => "Private Label"
          case "U" => "Alternative"
          case _ => "Unknown CardType " + inputValue
        }
      }
    } else {
      inputValue
    }
  })

  /** Transforming the following columns
    1. TXNDateYYYYMMDD, 2. CBDateYYYYMMDD, 3. CardTypeDesc
    */
  def AutomatedCBDateTransformation(inputDataFrame: DataFrame): DataFrame ={
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside AutomatedCBDateTransformation Method")
    val cbReasonCodesDF = cbReasonCodes
      .select($"ReasonCode",
        $"CARDTYPE".alias("CARD_TYPE_RC"),
        $"FRAUDFLAG".alias("fraudflagtmp"),
        $"DESCRIPTION",
        $"SDSFLAG".alias("sdsflagtmp"),
        $"CBPROCESSOR")
    //.show(2000,false)

    val joinedDF = inputDataFrame.join(cbReasonCodesDF,
      cbReasonCodesDF("CBPROCESSOR") === inputDataFrame("CB_PROCESSOR") &&
        cbReasonCodesDF("ReasonCode") === inputDataFrame("CB_REASON_CODE") &&
        cbReasonCodesDF("CARD_TYPE_RC") === inputDataFrame("CARD_TYPE")
      , "left_outer")

    /*(cbReasonCodesDF("CARD_TYPE_RC").isNull === inputDataFrame("CARD_TYPE").isNull
      || cbReasonCodesDF("CARD_TYPE_RC") === inputDataFrame("CARD_TYPE")
      ) , "")*/
    //joinedDF.show(false)

    val intermediateDataFrame = joinedDF
      .select($"CLIENT_ID".alias("clientid"),
        $"SUB_CLIENT_ID".alias("subclientid"),
        $"TRANS_ID".alias("transactionid"),
        $"TOTAL".alias("chargebackvalue"),
        $"CURRENCY_CODE".alias("currcd"),
        $"CB_PROCESSOR".alias("processor"),
        transformReasonCode(col("CB_REASON_CODE"),  col("CB_PROCESSOR") ).alias("reasoncode"),
        $"DATA_PROC_DATE".alias("procdatetime"),
        $"DATA_FILE_DATE".alias("rawdatafiledate"),
        $"CARD_TYPE".alias("cardtype"),
        $"SOURCE_FILE".alias("sourcefile"),
        $"TRANS_DATE".alias("sourcerawtxndate"),
        $"CB_DATE".alias("sourcerawcbdate"),
        $"DESCRIPTION".alias("description"),
        $"fraudflagtmp".alias("fraudflagtemp"),
        $"sdsflagtmp".alias("sdsflagtemp"),

        funcMaskCardNo1(col("CREDIT_CARD_NUM")).alias("cardnomask"),
        funcHashCardNo1(col("CREDIT_CARD_NUM")).alias("hashcardno")
      )
      //intermediateDataFrame
      .withColumn("sourcerawtxndate",when(substring(col("sourcerawtxndate"),2,1) === lit("/") && col("clientid").isin("000227","000228"),
      concat(lit("0"),col("sourcerawtxndate")))
      .when(substring(col("sourcerawtxndate"),5,1) === lit("/") && col("clientid").isin("000227","000228")
        ,concat(concat(substring(col("sourcerawtxndate"),1,3),lit("0")),substring(col("sourcerawtxndate"),4,6)))
      .otherwise(col("sourcerawtxndate")))

      .withColumn("sourcerawcbdate",when(substring(col("sourcerawcbdate"),2,1) === lit("/") && col("clientid").isin("000227","000228"),
        concat(lit("0"),col("sourcerawcbdate")))
        .when(substring(col("sourcerawcbdate"),5,1) === lit("/") && col("clientid").isin("000227","000228")
          ,concat(concat(substring(col("sourcerawcbdate"),1,3),lit("0")),substring(col("sourcerawcbdate"),4,6)))
        .otherwise(col("sourcerawcbdate")))

      .withColumn("processor",when(col("processor") === lit("UKCB") && col("clientid").isin("000227","000228"),lit("UKCB2"))
        .otherwise(col("processor")))

      .withColumn("rawtxndate",col("sourcerawtxndate"))
      .withColumn("rawcbdate",col("sourcerawcbdate"))

      .withColumn("rawtxndate",when(col("processor").isin("PRIVALIA","ETHOCA","UKCB")
        ,concat(concat(concat(concat(substring(col("rawtxndate"),7,4),lit("-")),substring(col("rawtxndate"),4,2)),lit("-")),substring(col("rawtxndate"),1,2))
      ).otherwise(col("rawtxndate")))

      .withColumn("rawtxndate",when(!col("processor").isin("PRIVALIA","ETHOCA","UKCB")
        ,concat(concat(concat(concat(substring(col("rawtxndate"),7,4),lit("-")),substring(col("rawtxndate"),1,2)),lit("-")),substring(col("rawtxndate"),4,2))
      ).otherwise(col("rawtxndate")))

      .withColumn("rawcbdate",when(col("processor").isin("PRIVALIA","ETHOCA","UKCB")
        ,concat(concat(concat(concat(substring(col("rawcbdate"),7,4),lit("-")),substring(col("rawcbdate"),4,2)),lit("-")),substring(col("rawcbdate"),1,2))
      ).otherwise(col("rawcbdate")))

      .withColumn("rawcbdate",when(!col("processor").isin("PRIVALIA","ETHOCA","UKCB")
        ,concat(concat(concat(concat(substring(col("rawcbdate"),7,4),lit("-")),substring(col("rawcbdate"),1,2)),lit("-")),substring(col("rawcbdate"),4,2))
      ).otherwise(col("rawcbdate")))

      .withColumn("rawtxndate",when(col("processor").isin("MeS")
        ,concat(lit("20"),col("rawtxndate"))).otherwise(col("rawtxndate")))

      .withColumn("rawcbdate",when(col("processor").isin("MeS")
        ,concat(lit("20"),col("rawcbdate"))).otherwise(col("rawcbdate")))

      .withColumn("txndateyyyymmdd",when(length(col("rawtxndate")).equalTo(lit("10"))
        && substring(col("rawtxndate"),5,1).equalTo(lit("-"))
        && substring(col("rawtxndate"),8,1).equalTo(lit("-"))
        ,concat(concat(substring(col("rawtxndate"),1,4),substring(col("rawtxndate"),6,2)),substring(col("rawtxndate"),9,2)))
        .otherwise(lit(""))
      )
      .withColumn("cbdateyyyymmdd",when(length(col("rawcbdate")).equalTo(lit("10"))
        && substring(col("rawcbdate"),5,1).equalTo(lit("-"))
        && substring(col("rawcbdate"),8,1).equalTo(lit("-"))
        ,concat(concat(substring(col("rawcbdate"),1,4),substring(col("rawcbdate"),6,2)),substring(col("rawcbdate"),9,2)))
        .otherwise(lit(""))
      )
      .withColumn("txndateactual",when(length(col("rawtxndate")).equalTo(lit("10")),to_timestamp(col("rawtxndate")))
        .otherwise(lit("")))

      .withColumn("cbdateactual",when(length(col("rawcbdate")).equalTo(lit("10")),to_timestamp(col("rawcbdate")))
        .otherwise(lit("")))

      .withColumn("cardtypedesc", funcAddTransformedColumn(col("cardtype"), lit("CardType")))
      .withColumn("reasontext", transformReasonText(col("description"), col ("reasoncode"), col("processor") , col("CardType")))
      // use this once we have client specific
      .withColumn("sdsyn", transformSDSYN(col("sdsflagtemp"), col("clientid"), col("reasoncode"), col("processor")  ))
      // use this once we have client specific
      .withColumn("fraudyn", transformFraudYN(col("fraudflagtemp"), col("clientid"), col("reasoncode"), col("processor") ,col("SDSYN" )))
      .withColumn("matchtype", transformMatchType(col("clientid"), col("reasoncode"), col("processor") ))
      .withColumn("maskedcardno", lit(col("cardnomask")))
      .withColumn("origrecommsort", lit("null"))
      .withColumn("origrecomm", lit("null"))
      .withColumn("matchedoid", lit("null"))
      .withColumn("oiddate", lit("null"))
      .withColumn("cbvaluesubclient", lit("null"))
      .withColumn("cbvalueusd",lit(""))
      .withColumn("cbvaluegbp", lit("null"))
      .withColumn("cbvalueeur", lit("null"))
      .withColumn("cbvalueclient", lit("null"))
      .withColumn("oiddateyyyymmdd",lit("null"))
    //intermediateDataFrame
    val rbiRefClient=refclient.select(
      $"ClientId".alias("client_id"),$"SubClientId".alias("subclient_id"),$"client12",$"clientcurr",$"subclientcurr",$"ClientName",$"SubClientName",$"ClientGroup")
    val subclientDF = intermediateDataFrame.join(
      rbiRefClient,
      intermediateDataFrame.col("clientid") === rbiRefClient.col("client_id") &&
        intermediateDataFrame.col("subclientid") === rbiRefClient.col("subclient_id"),
      "left_outer")
      .withColumn("client12", col("client12"))
      .withColumn("clientcurr", col("clientcurr"))
      .withColumn("subclientcurr", col("subclientcurr"))
      .withColumn("clientname", col("ClientName"))
      .withColumn("subclientname", when(col("subclientname").isNull,lit("Not-Provided")).otherwise (col("subclientname")))
      .withColumn("clientgroup",col("ClientGroup"))
      .withColumn("txndateyyyymmdd1",date_format(to_date($"txndateyyyymmdd","yyyyMMdd"),"yyMMdd"))
      .withColumn("cbdateyyyymmdd1",date_format(to_date($"cbdateyyyymmdd","yyyyMMdd"),"yyMMdd"))

    val refdates1=refdates
    val cbDates1DF=subclientDF
    var finalCBDF=cbDates1DF.join(refdates1,cbDates1DF("cbdateyyyymmdd1")===refdates1("dateyymmdd"),"left_outer")
      .withColumn("datetext",col("datetextshort"))
      .withColumn("weektext",col("weektextshort2"))
      .withColumn("weekstart",expr("substring(weektextmed,1,8)"))
      .withColumn("monthtext",col("monthtextmed"))
      .withColumn("weekyyyymmdd",col("weekyymmdd"))
      .withColumn("monthyyyymm",col("monthyyyymm"))
    val refdates2=refdates1
      //.select("dateyymmdd","datetextshort")
      .withColumnRenamed("dateyymmdd","ref_dateyymmdd")
      .withColumnRenamed("datetextshort","ref_datetextshort")
      .withColumnRenamed("weektextshort2","ref_weektextshort2")
      .withColumnRenamed("weektextmed","ref_weektextmed")
      .withColumnRenamed("monthtextmed","ref_monthtextmed")
      .withColumnRenamed("WeekYYMMDD","ref_WeekYYMMDD")
      .withColumnRenamed("monthyyyymm","ref_monthyyyymm")

    var finalCBDFtmp = finalCBDF.join(refdates2,finalCBDF("txndateyyyymmdd1")===refdates2("ref_dateyymmdd"),"left_outer")
      .withColumn("txndatetext",refdates2("ref_datetextshort"))
    finalCBDF = finalCBDFtmp
      .dropDuplicates()
      .withColumn("chargebackid",concat(lit("cbk"),monotonically_increasing_id() + (lastcbId.toInt) + 1))
      .withColumn("tchargebackid", col("chargebackid"))
    finalCBDF = finalCBDF.drop("client_id")
    finalCBDF = finalCBDF.drop("subclient_id")
    finalCBDF = finalCBDF.drop("description")
    finalCBDF = finalCBDF.drop("fraudflagtemp")
    finalCBDF = finalCBDF.drop("sdsflagtemp")
    finalCBDF = finalCBDF.drop("txndateyyyymmdd1")
    finalCBDF = finalCBDF.drop("cbdateyyyymmdd1")
    finalCBDF = finalCBDF.drop("dateyymmdd")
    finalCBDF = finalCBDF.drop("datetextshort")
    finalCBDF = finalCBDF.drop("weektextshort2")
    finalCBDF = finalCBDF.drop("weektextmed")
    finalCBDF = finalCBDF.drop("weekyyyymmdd")
    finalCBDF = finalCBDF.drop("monthtextmed")
    finalCBDF = finalCBDF.drop("ref_dateyymmdd")
    finalCBDF = finalCBDF.drop("ref_datetextshort")
    finalCBDF = finalCBDF.drop("ref_weektextshort2")
    finalCBDF = finalCBDF.drop("ref_weektextmed")
    finalCBDF = finalCBDF.drop("ref_monthtextmed")
    finalCBDF = finalCBDF.drop("ref_WeekYYMMDD")
    finalCBDF = finalCBDF.drop("ref_monthyyyymm")

    val finalrawCBDataDF = finalCBDF /*.distinct() */
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : End Of AutomatedCBDateTransformation Method")
    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Count for AutomatedCBDateTransformation Method : " + finalrawCBDataDF.count())
    logRegularMessage("End Of AutomatedCBDateTransformation Method")
    finalrawCBDataDF
  }


  /** Janaki: Method to pick ref clients having TRE service enabled.
    * Only TRE enabled services are used for CB Transformation */

  def transformCBDataforTREflg(rawDataFrame:DataFrame): DataFrame = {
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside transformCBDataforTREflg Method")
    val dfTREClientSubClientIDs = refclient.select($"clientid", $"subclientid").where($"flagtre"==="T")
    rawDataFrame.join(dfTREClientSubClientIDs,
      rawDataFrame.col("CLIENT_ID") === dfTREClientSubClientIDs.col("clientid")
        && rawDataFrame.col("SUB_CLIENT_ID") === dfTREClientSubClientIDs.col("subclientid"),"inner")
    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Count for transformCBDataforTREflg Method is : " + rawDataFrame.count())
    rawDataFrame
  }
  /*
     Added by Prabhu MERF - 9642 :
     Match all the transactions from transaction detail table using card no received from chargeback file.
     This can be matched using Hash Card / Card Mask
     Mark all non matched card no with matchtype='Q' (This shows no transactions for card no).
    */
  def PrepareTxnDataDF(inputDataFrame: DataFrame): DataFrame ={
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside PrepareTxnDataDF Method")
    val TransCore = hiveSession.executeQuery("Select oid,clientid,subclientid,transactionid,cardnomask,hashcardno,decision,recommendation,oiddateyyyymmdd,oiddate,total,authamt,chargebackyn from " + BI_TRANS_MASTER_CORE)
      .createOrReplaceTempView("TransCoreView")
    //sparkSession.sql("CACHE LAZY TABLE TransCoreView")
    inputDataFrame.createOrReplaceTempView("rawcbdataview")
    //sparkSession.sql("CACHE LAZY TABLE rawcbdataview")

    /* return all possible matches from trans_core where HashCardNo matches */

    val TransCoreDF1 = sparkSession.sql("select tmc.oid,tmc.clientid,tmc.subclientid,tmc.transactionid,tmc.cardnomask,tmc.hashcardno,tmc.decision, "+
      " tmc.recommendation,tmc.oiddateyyyymmdd,tmc.oiddate,tmc.total,tmc.authamt,tmc.chargebackyn,rcb.chargebackid " +
      " from TransCoreView tmc join rawcbdataview rcb on tmc.hashcardno = rcb.hashcardno and tmc.clientid = rcb.clientid " +
      " where tmc.chargebackyn = 'N' and tmc.recommendation <> 'AuthDec' " +
      "")

    //TransCoreDF1.show(false)

    /* return all possible matches from trans_core where CardNoMask matches */
    /* Predicate on date and amount values too as matching on CardNoMask alone will return lots of false positives */
    /* -- Value +/- 20%, date +/- 7 days, any SubClientId */

    val TransCoreDF2 = sparkSession.sql("select tmc.oid,tmc.clientid,tmc.subclientid,tmc.transactionid,tmc.cardnomask,tmc.hashcardno,tmc.decision, "+
      " tmc.recommendation,tmc.oiddateyyyymmdd,tmc.oiddate,tmc.total,tmc.authamt,tmc.chargebackyn,rcb.chargebackid " +
      " from TransCoreView tmc join rawcbdataview rcb on tmc.cardnomask = rcb.cardnomask and tmc.clientid = rcb.clientid " +
      " where tmc.chargebackyn = 'N' and tmc.recommendation <> 'AuthDec' " +
      " and ABS(datediff(tmc.oiddate, rcb.txndateactual)) <= 7 " +
      " and ABS(ABS(tmc.authamt)-rcb.chargebackvalue)/rcb.chargebackvalue <= 0.020 " +
      " and tmc.AuthAmt <> 0 " +
      " and rcb.chargebackvalue <> 0 " +
      "")

    //TransCoreDF2.show()

    /* return all possible matches from trans_core where CardNoMask matches for Nordstrom (000120) specific data pull */
    /* Predicate on date and amount values too as matching on CardNoMask alone will return lots of false positives */
    /* Value +/- 25%, date +/- 15 days, any SubClientId*/

    val TransCoreDF3 = sparkSession.sql("select tmc.oid,tmc.clientid,tmc.subclientid,tmc.transactionid,tmc.cardnomask,tmc.hashcardno,tmc.decision, "+
      " tmc.recommendation,tmc.oiddateyyyymmdd,tmc.oiddate,tmc.total,tmc.authamt,tmc.chargebackyn,rcb.chargebackid " +
      " from TransCoreView tmc join rawcbdataview rcb on tmc.cardnomask = rcb.cardnomask and tmc.clientid = rcb.clientid " +
      " where tmc.chargebackyn = 'N' and tmc.recommendation <> 'AuthDec' " +
      " and tmc.clientid='000120' and rcb.clientid='000120' " +
      " and ABS(datediff(tmc.oiddate, rcb.txndateactual)) <= 15 " +
      " and ABS(ABS(tmc.AuthAmt)-rcb.chargebackvalue)/rcb.chargebackvalue <= 0.025 " +
      " and tmc.AuthAmt <> 0 " +
      " and rcb.chargebackvalue <> 0 " +
      "")

    //TransCoreDF3.show(false)

    /* return all possible matches from trans_core where left cardno mask 4 and right cardno mask 4 matches for Follett (000350) specific data pull */
    /* Predicate on date and amount values too as matching on CardNoMask alone will return lots of false positives */
    /* Value +/- 25%, date +/- 15 days, any SubClientId*/

    val TransCoreDF4 = sparkSession.sql("select tmc.oid,tmc.clientid,tmc.subclientid,tmc.transactionid,tmc.cardnomask,tmc.hashcardno,tmc.decision, "+
      " tmc.recommendation,tmc.oiddateyyyymmdd,tmc.oiddate,tmc.total,tmc.authamt,tmc.chargebackyn,rcb.chargebackid " +
      " from TransCoreView tmc join rawcbdataview rcb on substr(tmc.CardNoMask,1,4) = substr(rcb.CardNoMask,1,4) and substr(tmc.CardNoMask,-4) = substr(rcb.CardNoMask,-4) and tmc.clientid = rcb.clientid " +
      " where tmc.ChargebackYN = 'N' and tmc.Recommendation <> 'AuthDec' " +
      " and tmc.clientid='000350' and rcb.clientid='000350' " +
      " and tmc.Total = rcb.chargebackvalue " +
      "")

    //TransCoreDF4.show(false)

    /* Create final CB Trans Core data frame from Trans Core data frames */

    val finalCBTransCoreDF = mergeDataFrames(TransCoreDF1,TransCoreDF2,TransCoreDF3,TransCoreDF4)//.cache()
    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + "Count of Matched Card No. : " + finalCBTransCoreDF.count())

    //finalCBTransCoreDF.show(false)

    /* Identify chargeback id for which we have NO transaction match for the card no - matchtype Q */

    val nocardmatch = inputDataFrame.join(finalCBTransCoreDF,Seq("chargebackid"),"left_outer").where(col("oid") isNull )
      .select(col("chargebackid").alias("qchargebackid"),lit("Q").alias("qmatchtype"))//.cache()

    //nocardmatch

    /* Update rawcbdatadf with matchtype='Q' for no card no match */

    val updateRawCBDataDF = inputDataFrame.join(nocardmatch,
      inputDataFrame.col("chargebackid") === nocardmatch.col("qchargebackid"),"left_outer")
      .withColumn("matchtype",when(inputDataFrame.col("chargebackid") === nocardmatch.col("qchargebackid"),nocardmatch.col("qmatchtype"))
        .otherwise(inputDataFrame.col("matchtype"))).drop(col("qmatchtype")).drop(col("qchargebackid"))//.cache()

    //updateRawCBDataDF

    /*  Chargeback Matching Process starts here
        First Match 1 : Using Transaction Id
    */
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : End of  PrepareTxnDataDF Method")
    match1TxnId (updateRawCBDataDF,finalCBTransCoreDF)
  }
  /*
  Added by Prabhu MERF - 9642 :
  Method 1: To match CB using Transaction Id
   */

  def match1TxnId(rawcbdatadf: DataFrame,cbtransdetaildf: DataFrame): DataFrame ={
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside Match1TxnId Method")

    val wrkcbmatchtxn2 = rawcbdatadf.where(col("matchtype") === lit("N") || col("matchtype") ===  lit("Q"))
      /* -- Remove Walmart FDC items */
      .filter(col("clientid") =!= lit("000022") || col("processor").like("FDC%"))
      /* Slight massaging of transaction ids by client for match to Transaction data */
      .withColumn("transactionid"
      ,when(col("clientid") === lit("000022"),substring(col("transactionid"),1,9))
        .when(col("clientid") === lit("000117"),regexp_replace(col("transactionid"),lit("U"),lit("US")))
        .when(col("clientid") === lit("000178"),concat(lit("NP"),col("transactionid")))
        .when(col("clientid") === lit("000195"),concat(lit("N"),col("transactionid")))
        .when(col("clientid") === lit("000160") && col("processor") === lit("DISCOVER"),substring(col("transactionid"),1,7))
        .when(col("clientid") === lit("000051") && col("processor") === lit("AMEX"),substring(col("transactionid"),2,7))
        .when(col("clientid") === lit("000051") && col("processor") === lit("DISCOVER"),substring(col("transactionid"),3,7))
        .otherwise(col("transactionid")))//.cache()

    /* -- First get potential matches using HashCardNo */

    val txnmatch1 = wrkcbmatchtxn2.join(cbtransdetaildf,
      wrkcbmatchtxn2.col("clientid") === cbtransdetaildf.col("clientid") && wrkcbmatchtxn2.col("hashcardno") === cbtransdetaildf.col("hashcardno") && wrkcbmatchtxn2.col("transactionid") === cbtransdetaildf.col("transactionid"),"inner")
      .select(lit("T").alias("tmatchtype"),wrkcbmatchtxn2.col("chargebackid").alias("xchargebackid"),cbtransdetaildf.col("oid"),cbtransdetaildf.col("total"),cbtransdetaildf.col("oiddate").alias("xoiddate"),cbtransdetaildf.col("oiddateyyyymmdd").alias("xoiddateyyyymmdd")
        ,cbtransdetaildf.col("recommendation")
      )

    //txnmatch1.show(false)

    /* -- Second get potential matches using CardNoMask */

    val txnmatch2 = wrkcbmatchtxn2.join(cbtransdetaildf,
      wrkcbmatchtxn2.col("clientid") === cbtransdetaildf.col("clientid") && wrkcbmatchtxn2.col("cardnomask") === cbtransdetaildf.col("cardnomask") && wrkcbmatchtxn2.col("transactionid") === cbtransdetaildf.col("transactionid"),"inner")
      .select(lit("T").alias("tmatchtype"),wrkcbmatchtxn2.col("chargebackid").alias("xchargebackid"),cbtransdetaildf.col("oid"),cbtransdetaildf.col("total"),cbtransdetaildf.col("oiddate").alias("xoiddate"),cbtransdetaildf.col("oiddateyyyymmdd").alias("xoiddateyyyymmdd")
        ,cbtransdetaildf.col("recommendation")
      )

    //txnmatch2

    /* -- Third get potential matches using transaction id without card matching */

    val txnmatch3 = wrkcbmatchtxn2.where(col("matchtype") === lit("Q")).join(cbtransdetaildf,
      wrkcbmatchtxn2.col("clientid") === cbtransdetaildf.col("clientid") && wrkcbmatchtxn2.col("transactionid") === cbtransdetaildf.col("transactionid"),"inner")
      .select(lit("T").alias("tmatchtype"),wrkcbmatchtxn2.col("chargebackid").alias("xchargebackid"),cbtransdetaildf.col("oid"),cbtransdetaildf.col("total"),cbtransdetaildf.col("oiddate").alias("xoiddate"),cbtransdetaildf.col("oiddateyyyymmdd").alias("xoiddateyyyymmdd")
        ,cbtransdetaildf.col("recommendation")
      )

    //txnmatch3

    /* Merge all the transaction id match steps to a single data frame */

    val finaltxnmatch = txnmatch1.union(txnmatch2).union(txnmatch3).distinct()

    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + "Count of Matched Transactions : " + finaltxnmatch.count())

    //finaltxnmatch

    /* Update rawcbdata with matchtype='T' for transaction Id match */
    val updateRawCBDataDF = rawcbdatadf.join(finaltxnmatch,
      rawcbdatadf.col("chargebackid") === finaltxnmatch.col("xchargebackid"),"left_outer")
      .withColumn("matchtype",when(finaltxnmatch.col("oid").isNotNull ,finaltxnmatch.col("tmatchtype")).otherwise(rawcbdatadf.col("matchtype")))
      .withColumn("matchedoid",when(finaltxnmatch.col("oid").isNotNull ,finaltxnmatch.col("oid")).otherwise(lit("null")))
      .withColumn("oiddateyyyymmdd",when(finaltxnmatch.col("oid").isNotNull ,finaltxnmatch.col("xoiddateyyyymmdd")).otherwise(lit("null")))
      .withColumn("oiddate",when(finaltxnmatch.col("oid").isNotNull ,finaltxnmatch.col("xoiddate")).otherwise(lit("null")))
      .withColumn("chargebackyn",when(finaltxnmatch.col("oid").isNotNull,lit("Y")).otherwise(lit("N")))
      .withColumn("chargebackitems",when(finaltxnmatch.col("oid").isNotNull,lit("1")).otherwise(lit("")))
      .withColumn("chargebackprocyyyymmdd",when(finaltxnmatch.col("oid").isNotNull,lit(date_format(current_date(),"yyyyMMdd"))).otherwise(lit("")))
      .withColumn("chargebackdate",when(finaltxnmatch.col("oid").isNotNull ,rawcbdatadf.col("cbdateactual")).otherwise(lit("")))
      .withColumn("chargebackyyyymmdd",when(finaltxnmatch.col("oid").isNotNull ,rawcbdatadf.col("cbdateyyyymmdd")).otherwise(lit("")))
      .withColumn("chargebackreason",when(finaltxnmatch.col("oid").isNotNull ,rawcbdatadf.col("reasoncode")).otherwise(lit("")))
      .withColumn("chargebackfraudyn",when(finaltxnmatch.col("oid").isNotNull && rawcbdatadf.col("fraudyn") === lit("Y"),lit("Y")).otherwise(lit("")))
      .withColumn("origrecomm",when(finaltxnmatch.col("oid").isNotNull ,finaltxnmatch.col("recommendation")).otherwise(lit("")))
      .withColumn("origrecommsort",when(finaltxnmatch.col("oid").isNotNull && finaltxnmatch.col("recommendation") === lit("Accept") , lit("1"))
        .when(finaltxnmatch.col("oid").isNotNull && finaltxnmatch.col("recommendation") === lit("Challenge") , lit("2"))
        .when(finaltxnmatch.col("oid").isNotNull && finaltxnmatch.col("recommendation") === lit("Deny") , lit("3"))
        .when(finaltxnmatch.col("oid").isNotNull && finaltxnmatch.col("recommendation") === lit("NoScore") , lit("4"))
        .otherwise(lit("20")))
      .withColumn("origrecomm",when(col("matchtype") === lit("X"), lit("Pre May 2012"))
        .when(col("matchtype") === lit("N"), lit("Not Matched"))
        .when(col("matchtype") === lit("W"), lit("Excluded"))
        .otherwise(col("origrecomm")))
      .withColumn("origrecommsort",when(col("matchtype").isin("X", "N", "W"),
        when(col("matchtype") === lit("X"), lit("18"))
          when(col("matchtype") === lit("N"), lit("19"))
          when(col("matchtype") === lit("W"), lit("20"))))
      .withColumn("origrecommsort",when(col("origrecomm").isin("Accept", "Challenge", "Deny", "NoScore"),
        when(col("origrecomm") === lit("Accept"), lit("1"))
          when(col("origrecomm") === lit("Challenge"), lit("2"))
          when(col("origrecomm") === lit("Deny"), lit("3"))
          when(col("origrecomm") === lit("NoScore"), lit("4"))))
      .withColumn("realfraud",when(col("chargebackfraudyn") === lit("Y"),lit("Y")).otherwise(lit("")))
      .withColumn("realfraudyyyymmdd",when(col("chargebackfraudyn") === lit("Y"),lit(date_format(current_date(),"yyyyMMdd"))).otherwise(lit("")))
      .withColumn("realfraudtype",when(col("chargebackfraudyn") === lit("Y"),lit("FRAUDCBF")).otherwise(lit("")))
      .withColumn("realfrauddate",when(col("chargebackfraudyn") === lit("Y"),lit(current_date())).otherwise(lit("")))
      //.withColumn("realfrauddatebae",when(col("chargebackfraudyn") === lit("Y"),lit(current_timestamp())).otherwise(lit("")))
      .withColumn("relfraud",when(col("chargebackfraudyn") === lit("Y"),lit("Y")).otherwise(lit("")))
      .withColumn("relfraudyyyymmdd",when(col("chargebackfraudyn") === lit("Y"),lit(date_format(current_date(),"yyyyMMdd"))).otherwise(lit("")))
      .withColumn("relfraudtype",when(col("chargebackfraudyn") === lit("Y"),lit("FRAUDCBF")).otherwise(lit("")))

      .drop(col("tmatchtype"))
      .drop(col("xchargebackid"))
      .drop(col("xoiddateyyyymmdd"))
      .drop(col("xoiddate"))

    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : End Of Match1TxnId Method")
    updateRawCBDataDF//.cache()
  }
  /**
    *
    * @param TransCoreDF1
    * @param TransCoreDF2
    * @param TransCoreDF3
    * @param TransCoreDF4
    * @return DataFrame
    * Merging two data frames
    *
    */
  def mergeDataFrames(TransCoreDF1: DataFrame,TransCoreDF2: DataFrame,TransCoreDF3: DataFrame,TransCoreDF4: DataFrame):DataFrame={
    //TransCoreDF1.union(TransCoreDF2).union(TransCoreDF3).union(TransCoreDF4)
    TransCoreDF1.dropDuplicates()
    //.union(TransCoreDF3).union(TransCoreDF4).dropDuplicates()
  }
  /*
  Getting CB High Water Mark
   */
  def getCBHWMId(controlKey: String): String = {
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Starting to fetch HWM Value")
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Process Control Table Name:- " + REDI_PROCESS_CONTROL)
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Process Control Key  Name:- " + controlKey)
    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Process Status  :- " + PROCESS_CONTROL_COMPLETED)
    AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Getting High Water Mark from " + REDI_PROCESS_CONTROL + " table for CB Process")
    val AutomatedCBHWMGID = hiveSession.executeQuery("SELECT max(HIGHWATERMARK) FROM " + REDI_PROCESS_CONTROL + " WHERE PROCESSNAME = " + "'" + controlKey + "'" + " AND PROCESSCURRENTSTATUS = " + "'" + PROCESS_CONTROL_COMPLETED + "'").head().getString(0)
    AutomatedCBHWMGID
  }
  /** ****************************************************************************************************************************************************
    * This is the method which is invoked by the action
    * This will be used to ingest and process the Automated Chargeback Data from Source into Destination
    * ***************************************************************************************************************************************************/
  def AutomatedCBDataPipeline(): Unit = {

    AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Inside AutomatedCBDataPipeline Method")

    /** Ingestion Process Step: 01
      * Get the High Water Mark (Maximum of GROUPID) for Automated CB Data from Hive control table
      * The value returned will be stored in the AutomatedCBHWMGID variable. */
    val AutomatedCBHWMGID = getCBHWMId(REDI_AUTOMATED_CB_CONTROL_KEY)
    //print("AutomatedCBHWMGID" + AutomatedCBHWMGID)

    /** Ingestion Process Step: 02
      * 1. Check whether the HWM for Automated CB process (GROUP_ID) is null.
      * If null then throw an error that on the oracle date converted and exit.
      * 2. If the HWM for Automated CB process (GROUP_ID) is not null then read incremental data from Oracle (only new data which has come after High water mark date)
      */
    if (AutomatedCBHWMGID == null) {
      AutomatedCBDataControllerlogger.error(ACBPDataIngestionProcess_ERROR + " : There is an error in the " + REDI_AUTOMATED_CB_CONTROL_KEY + " value stored in Hive : " + AutomatedCBHWMGID)
    }
    else {
      /** Ingestion Process Step: 02(A)
        * Creating the Query that will be executed in Oracle to get data for CB_MASTER_DATA. */

      val AUTOMATED_CB_MASTER_QUERY = "(SELECT * FROM " + CBDATA_DATABASE + "." + RS_AUTOMATED_CB_DATA + " WHERE GROUP_ID >" + AutomatedCBHWMGID + ") Automated_CBData"

      val RawAutomatedCBDataDF = fetchAutomatedCBData(AUTOMATED_CB_MASTER_QUERY, ORACLE_CONN_TYPE, CBDATA_DATABASE)

      AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Fetched Chargeback Data into processing layer "+ CBDATA_DATABASE +"."+ RS_AUTOMATED_CB_DATA)

      /**Caching the Dataframe, so that the data presists in memory and can be easy to push into HDFS*/

      RawAutomatedCBDataDF.cache()

      /** Reading the Dataframe for getting the total count of records that was Ingested from Oracle
        * This value is pushed into the variable AutomatedCBDataCount. */
      val AutomatedCBDataCount = RawAutomatedCBDataDF.count()
      AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Source Raw Data count : " + AutomatedCBDataCount)
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Fetched " + AutomatedCBDataCount + " records from Source")

      /** Ingestion Process Step: 03
        * Updating the Process Status in the into Hive Control table */

      // Setting the Start time of the Automated CBData
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + ":Insert data into " + REDI_PROCESS_CONTROL + " table for CB data process job "+ REDI_AUTOMATED_CB_CONTROL_KEY + " with Status as :" + PROCESS_CONTROL_STARTED)
      val startTimeAutomatedCBDataLoad= getCurrentdateTimeStamp.toString
      controlTableDataProcess(RawAutomatedCBDataDF,"GROUP_ID",REDI_AUTOMATED_CB_CONTROL_KEY,PROCESS_CONTROL_STARTED,startTimeAutomatedCBDataLoad,"","Starting to Fetch the AutoamtedCBData from ODS into HDFS",Automated_CB_Data_Process)
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + ":Successfully Inserted data into " + REDI_PROCESS_CONTROL + " table for CB data process job "+ REDI_AUTOMATED_CB_CONTROL_KEY + " with Status as :" + PROCESS_CONTROL_STARTED)

      /* If Source Returns Any Data then Proceed for Transformation */
      if (AutomatedCBDataCount != 0) {

        /** Transformation Process Step:01 */
        val cbtransformation1 = transformCBDataforTREflg(RawAutomatedCBDataDF)
        val cbtransformation2 = AutomatedCBDateTransformation(cbtransformation1)
        val cbtransformation3 = currencyConversionAndValueBands(cbtransformation2)
        //.show(false)

        /** CB Matching Process Step:02 */
        /* Prabhu for MERF-9642 : Chargeback Labelling
       This inludes Matching and Labelling cb process. This will return the list of orders identified as fraud in cb pocessing.
       * */
        val cbmatching = PrepareTxnDataDF(cbtransformation3)
        //.show(false)

        /** CB Labelling Process Step:03 */
        val fraudRollback = cblabelling.labellingCBdataDF(cbmatching)
        //.show(false)
        //.persist()

        /** Rollback Process Step:04 */
        /** Rollback Controller for fradulent transaction to the producer */
        AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Rollback Transaction Step Started by CB Processor at : " + getCurrentdateTimeStamp)
        rollback.rollbackTransactions(fraudRollback)
        AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Rollback Transaction Step Completed for CB Processor : " + getCurrentdateTimeStamp)

        /** Ingestion Process Step: 05
          * Pushing the Data from Dataframe into HDFS */
        saveAutomatedCBDatatoHDFS(RawAutomatedCBDataDF)

        /** Ingestion Process Step: 06
          * Reading the Dataframe for getting the MAXIMUM of GROUP_ID from the data Ingested from Oracle
          * This value is pushed into Hive Control Table.
          * Updating the Maximum GROUP_ID into Hive Control table and Marking the end of process */
      }
      // Setting the End time of the Automated CBData
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + ":Insert data into " + REDI_PROCESS_CONTROL + " table for CB data process job "+ REDI_AUTOMATED_CB_CONTROL_KEY + " with Status as :" + PROCESS_CONTROL_COMPLETED)
      val endTimeAutomatedCBDataLoad= getCurrentdateTimeStamp.toString
      controlTableDataProcess(RawAutomatedCBDataDF,"GROUP_ID",REDI_AUTOMATED_CB_CONTROL_KEY,PROCESS_CONTROL_COMPLETED,startTimeAutomatedCBDataLoad,endTimeAutomatedCBDataLoad,"Completed the AutoamtedCBData Fetch from ODS into HDFS",Automated_CB_Data_Process)
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + ":Successfully Inserted data into " + REDI_PROCESS_CONTROL + " table for CB data process job "+ REDI_AUTOMATED_CB_CONTROL_KEY + " with Status as :" + PROCESS_CONTROL_COMPLETED)
      /**
        * Final message of how many records were ingested and stored in HDFS as part of Automated CB Process
        */
      AutomatedCBDataControllerlogger.info(ACBPDataIngestionProcess_INFO + " : Total records : " + AutomatedCBDataCount + " ingested to ReDi File storage "+ RS_AUTOMATED_CB_DATA)
      AutomatedCBDataControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Total records of : " + AutomatedCBDataCount + " ingested to ReDi File storage "+ RS_AUTOMATED_CB_DATA)

    }

  }
}
