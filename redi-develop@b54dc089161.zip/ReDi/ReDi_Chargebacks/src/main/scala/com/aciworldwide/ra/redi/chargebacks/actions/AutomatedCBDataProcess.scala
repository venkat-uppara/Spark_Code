/**
  * @author : Janakiraman Sivasailam
  * @version : 1.0 Initial Draft
  * @usecase : MERF-8361 / MERF-10007
  * @note :
  */

package com.aciworldwide.ra.redi.chargebacks.actions

import com.aciworldwide.ra.redi.chargebacks.controllers.MainCBController
import com.aciworldwide.ra.redi.common.services.{EstablishConnections}
import org.apache.logging.log4j.LogManager

object AutomatedCBDataProcess extends MainCBController with EstablishConnections with Serializable {
  /**
    * This invokes the process that addresses the Automated Chargeback Data
    */
  @transient lazy val AutomatedCBDataActionlogger = LogManager.getLogger(getClass.getName)

  def main(args: Array[String]): Unit = {
    AutomatedCBDataActionlogger.debug(ACBPDataIngestionProcess_DEBUG + " : Start of Incremental Load for Automated Chargeback Data from ODS")
    try{
      CBDataPipeline()
    }
    catch {
      case e: Exception => AutomatedCBDataActionlogger.error(ACBPDataIngestionProcess_ERROR + " : We have an error in the Incremental Load for Automated Chargeback Data Flow ")
        e.printStackTrace()
        System.exit(1)
    }
    finally {
      AutomatedCBDataActionlogger.debug(ACBPDataIngestionProcess_DEBUG + " : End of Incremental Load for Automated Chargeback Data from ODS")
    }
  }
}