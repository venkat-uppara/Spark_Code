package com.aciworldwide.ra.redi.chargebacks.controllers


import com.aciworldwide.ra.redi.common.constants.ReDiConstants
import com.aciworldwide.ra.redi.common.services.{DatabaseServices, Loggers}
import com.aciworldwide.ra.redi.common.utils.CommonUtils
import org.apache.spark.sql.functions.{col, _}
import org.apache.spark.sql.{DataFrame, SparkSession}
import com.hortonworks.hwc.HiveWarehouseSession
import com.hortonworks.hwc.HiveWarehouseSession._
import org.apache.logging.log4j.LogManager
//import com.hortonworks.hwc.HiveWarehouseSession.HIVE_WAREHOUSE_CONNECTOR

class CBLabellingController(hiveSession : HiveWarehouseSession) extends Serializable with ReDiConstants with CommonUtils with DatabaseServices
  with Loggers {

  @transient lazy val AutomatedCBLabellingControllerlogger = LogManager.getLogger(getClass.getName)

  //var transDetailTable: DataFrame = hiveSession.executeQuery("Select oid,clientid,hashcardno,oiddateyyyymmdd,realfraudyn from " + BI_TRANS_MASTER_CORE)

  val sparkSession = hiveSession.session()

  import sparkSession.implicits._

  def labellingCBdataDF(inputDataFrame: DataFrame): DataFrame = {

    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Inside labellingCBdataDF Method")

    val sourceDataFrame = inputDataFrame
      .withColumnRenamed("OID", "REFERENCE_OID")
      .withColumnRenamed("oiddate", "cb_oiddate")
      .withColumnRenamed("clientid", "cb_clientid")
      .withColumnRenamed("subclientid", "cb_subclientid")
      .withColumnRenamed("client12", "cb_client12")
      .withColumnRenamed("transactionid", "cb_transactionid")
      .withColumnRenamed("subclientname", "cb_subclientname")
      .withColumnRenamed("clientname", "cb_clientname")
      .withColumnRenamed("recommendation", "cb_recommend")
      .withColumnRenamed("hashcardno", "cb_hashcardno")
      .withColumnRenamed("cardnomask", "cb_cardnomask")
      .withColumnRenamed("oiddateyyyymmdd", "cb_oiddateyyyymmdd")
      .withColumn(WHENLOADED, current_timestamp())
      .withColumn(WHOLOADED, lit(WHO_LOADED_UPDATED_INSERT))
      .withColumn(WHENUPDATED, current_timestamp())
      .withColumn(WHOUPDATED, lit(WHO_LOADED_UPDATED_INSERT))
      .dropDuplicates()
      .cache()
    //sourceDataFrame.show(false)

    /* Insert into CB Audit Table */
    val insertCBAuditData = sourceDataFrame
      .select(
        col("chargebackid"),
        col("cb_clientid").as("clientid"),
        col("cb_subclientid").as("subclientid"),
        col("cb_client12").as("client12"),
        col("cb_transactionid").as("transactionid"),
        col("cb_hashcardno").as("hashcardno"),
        col("chargebackvalue"),
        col("currcd"),
        col("reasoncode"),
        col("processor"),
        col("procdatetime"),
        col("rawdatafiledate"),
        col("cardtype"),
        col("sourcefile"),
        col("sourcerawtxndate"),
        col("sourcerawcbdate"),
        col("cb_cardnomask").as("cardnomask"),
        col("weekyymmdd"),
        col("weektext"),
        col("weekstart"),
        col("txndateyyyymmdd"),
        col("txndatetext"),
        col("txndateactual"),
        col("tchargebackid"),
        col("cb_subclientname").as("subclientname"),
        col("subclientcurr"),
        col("sdsyn"),
        col("reasontext"),
        col("rawtxndate"),
        col("rawcbdate"),
        col("origrecommsort"),
        col("origrecomm"),
        col("monthyyyymm"),
        col("monthtext"),
        col("matchtype"),
        col("matchedoid"),
        col("cb_oiddate").as("oiddate"),
        col("maskedcardno"),
        col("fraudyn"),
        col("datetext"),
        col("cb_clientname").as("clientname"),
        col("clientgroup"),
        col("clientcurr"),
        col("cbvalueusd"),
        col("cbvaluesubclient"),
        col("cbvaluegbp"),
        col("cbvalueeur"),
        col("cbvalueclient"),
        col("cbdateyyyymmdd"),
        col("cbdateactual"),
        col("cardtypedesc"),
        col("cb_oiddateyyyymmdd").as("oiddateyyyymmdd"),
        col("WHENLOADED"),
        col("WHOLOADED"),
        col("WHENUPDATED"),
        col("WHOUPDATED")
      )
      .cache()

    //insertCBAuditData.show(false)

    // Store to Hive Table REDI_CB_AUDIT_DATA
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started pushing the data into Hive tables " + REDI_CB_AUDIT_DATA)
    val isCBAuditStored = storeInputCBMastertoHive(reorderSourceTableSchema(CB_AUDIT_DATA_COL_ORDER, insertCBAuditData))
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Number of rows inserted in " + REDI_CB_AUDIT_DATA + " table is : " + insertCBAuditData.count())
    AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Number of rows inserted in " + REDI_CB_AUDIT_DATA + " table is : " + insertCBAuditData.count() + " with DB Insert Status as : " + isCBAuditStored)

    /* Insert into Fraud Trans Table for cb data identified as fraud*/
    val insertCBFraudTrans = insertCBAuditData
      .select(
        col("matchedoid").alias("oid"),
        col("oiddateyyyymmdd"),
        col("WHENLOADED")
      )
      .where(col("fraudyn") === lit("Y") && (col("matchedoid") =!= lit("null")))
      .cache()

    //insertCBFraudTrans.show(false)

    // Store to Hive Table REDI_LABEL_FRAUD_TRANS
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started pushing CB Fraudulent Transaction data into Hive tables " + REDI_LABEL_FRAUD_TRANS)
    val isFraudTransStored = storeFraudTranstoHive(insertCBFraudTrans,OVERWRITE_MODE)
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Number of rows inserted in " + REDI_LABEL_FRAUD_TRANS + " table is : " + insertCBFraudTrans.count())
    AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Number of rows inserted in " + REDI_LABEL_FRAUD_TRANS + " table is : " + insertCBFraudTrans.count())

    /* Update cb details in BI Trans Core Table*/
    if (isCBAuditStored) {
      AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started updating the data into Hive table " + BI_TRANS_MASTER_CORE)
      val updateTransCore = hiveSession.executeUpdate(" Merge INTO " + BI_TRANS_MASTER_CORE + " AS transdata " +
        " USING " + REDI_CB_AUDIT_DATA + " AS sourceData " +
        " on (transdata.chargebackyn ='N' and sourceData.matchedoid  is not null and sourceData.matchedoid = transdata.oid  and sourceData.oiddateyyyymmdd = transdata.oiddateyyyymmdd ) " +
        " When matched Then Update " +
        " SET CHARGEBACKVALUE =  sourceData.chargebackvalue," +
        " CBPROCESSOR =  sourceData.processor," +
        " PROCDATETIME =  sourceData.procdatetime," +
        " RAWDATAFILEDATE =  sourceData.rawdatafiledate," +
        " SOURCEFILE =  sourceData.sourcefile," +
        " SOURCERAWTXNDATE =  sourceData.sourcerawtxndate," +
        " SOURCERAWCBDATE =  sourceData.sourcerawcbdate," +
        " CBWEEKYYYYMMDD =  sourceData.weekyymmdd," +
        " CBWEEKTEXT =  sourceData.weektext," +
        " CBWEEKSTART = sourceData.weekstart," +
        " CBTXNDATEYYYYMMDD =  sourceData.txndateyyyymmdd," +
        " CBTXNDATETEXT =  sourceData.txndatetext," +
        " CBTXNDATEACTUAL =  sourceData.txndateactual," +
        " TCHARGEBACKID =  sourceData.tchargebackid," +
        " CBSDSYN =  sourceData.sdsyn," +
        " CBREASONTEXT =  sourceData.reasontext," +
        " RAWTXNDATE =  sourceData.rawtxndate," +
        " RAWCBDATE =  sourceData.rawcbdate," +
        " ORIGRECOMMSORT =  sourceData.origrecommsort," +
        " ORIGRECOMM =  sourceData.origrecomm," +
        " CBMONTHYYYYMM =  sourceData.monthyyyymm," +
        " CBMONTHTEXT =  sourceData.monthtext," +
        " MATCHTYPE = sourceData.matchtype," +
        " MATCHEDOID = sourceData.matchedoid," +
        " CBFRAUDYN =  sourceData.fraudyn," +
        " CBDATETEXT =  sourceData.datetext," +
        " CBVALUEUSD =  sourceData.cbvalueusd," +
        " CBVALUESUBCLIENT =  sourceData.cbvaluesubclient," +
        " CBVALUEGBP =  sourceData.cbvaluegbp," +
        " CBVALUEEUR =  sourceData.cbvalueeur," +
        " CBVALUECLIENT = sourceData.cbvalueclient," +
        " CBDATEYYYYMMDD = sourceData.cbdateyyyymmdd," +
        " CBDATEACTUAL = sourceData.cbdateactual," +
        " CHARGEBACKID =  sourceData.chargebackid," +
        " CHARGEBACKYN = 'Y'," +
        " CHARGEBACKDATE = sourceData.cbdateactual," +
        " CHARGEBACKYYYYMMDD = sourceData.cbdateyyyymmdd," +
        " CHARGEBACKREASON =  sourceData.reasoncode," +
        " CHARGEBACKFRAUDYN = (CASE sourceData.fraudyn when 'Y' then 'Y' else null end)," +
        " CHARGEBACKITEMS = '1'," +
        " CHARGEBACKPROCYYYYMMDD = date_format(current_date,'yyyyMMdd')," +
        " RealFraudYN = (CASE sourceData.fraudyn when 'Y' then 'Y' else 'N' end)," +
        " RealFraudDate = (CASE sourceData.fraudyn when 'Y' then current_timestamp else 'N' end)," +
        " RealFraudYYYYMMDD = (CASE sourceData.fraudyn when 'Y' then date_format(current_date,'yyyyMMdd') else null end)," +
        " RealFraudType = (CASE sourceData.fraudyn when 'Y' then 'FRAUDCBF' else null end)," +
        /* " RelFraudYN = (CASE sourceData.fraudyn when 'Y' then 'Y' else 'N' end)," +
         " RelFraudYYYYMMDD = (CASE sourceData.fraudyn when 'Y' then date_format(current_date,'yyyyMMdd') else null end)," +
         " RelFraudType = (CASE sourceData.fraudyn when 'Y' then 'FRAUDCBF' else null end)," +*/
        " CurrentStatus = (Case when transdata.CurrentStatus not like '%>CB%' then transdata.CurrentStatus || '->CBK'  else transdata.CurrentStatus end)," +
        " realfrauddatebae = (CASE sourceData.fraudyn when 'Y' then current_timestamp else null end)," +
        " CBWHENLOADED = sourceData.WHENLOADED," +
        " CBWHOLOADED = sourceData.WHOLOADED," +
        " CBWHENUPDATED = sourceData.WHENUPDATED," +
        " CBWHOUPDATED = sourceData.WHOUPDATED," +
        " WHENUPDATED = current_timestamp," +
        " WHOUPDATED = sourceData.WHOUPDATED"
      )
      AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Update completed for " + BI_TRANS_MASTER_CORE + " With DB Update Status as :" + updateTransCore)
      AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Update completed for " + BI_TRANS_MASTER_CORE + " With DB Update Status as :" + updateTransCore)
    }

    /* mark all the transactions belonging to the fradulent card numbers as Fraud.*/

    if (isFraudTransStored) {
      AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started loading all the matched transactions for Fradulent Card No. in the table " + REDI_LABEL_FRAUD_TRANS)
      val insertFraudCardTrans = hiveSession.executeUpdate(" Merge INTO " + REDI_LABEL_FRAUD_TRANS + " AS frauddatatarget " +
        " USING (select A.OID,A.OIDDateYYYYMMDD From " + BI_TRANS_MASTER_CORE +
        " A Join (Select OID,HashCardNo ,ClientId From " + BI_TRANS_MASTER_CORE +
        " Where coalesce(RealFraudYN,'N')='Y') AS B " +
        " ON A.ClientId=B.ClientId " +
        " AND A.HashCardNo=B.HashCardNo " +
        " AND coalesce(A.RealFraudYN,'N')='N' ) AS frauddatasource " +
        " on (frauddatasource.oid = frauddatatarget.oid ) " +
        " When not matched then insert values (frauddatasource.OID,frauddatasource.OIDDateYYYYMMDD,current_timestamp) "
      )
      AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Inserted Fraud Trans into " + REDI_LABEL_FRAUD_TRANS + " With DB Insert Status as :" + insertFraudCardTrans)
      AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Inserted Fraud Trans into " + REDI_LABEL_FRAUD_TRANS + " With DB Insert Status as :" + insertFraudCardTrans)
    }

    /* Update all the transactions as Fraud for the given fradulent card numbers */
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started labelling Fradulent transactions into Hive table " + BI_TRANS_MASTER_CORE)
    val updateFraudTrans = hiveSession.executeUpdate(" Merge INTO " + BI_TRANS_MASTER_CORE + " AS transdata " +
      " USING (select distinct oid from " + REDI_LABEL_FRAUD_TRANS + ") AS frauddata " +
      " on (frauddata.oid = transdata.oid  and transdata.realfraudyn = 'N' ) " +
      " When matched Then Update " +
      " SET RealFraudYN = 'Y'," +
      " RealFraudDate = current_timestamp," +
      " RealFraudYYYYMMDD = date_format(current_date,'yyyyMMdd')," +
      /*" RelFraudYN = 'Y'," +
      " RelFraudYYYYMMDD = date_format(current_date,'yyyyMMdd')," +*/
      " realfrauddatebae = current_timestamp "
    )
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Updated Fraudulent Transaction into " + BI_TRANS_MASTER_CORE + " with DB Update status as : " + updateFraudTrans)
    AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Updated Fraudulent Transaction into " + BI_TRANS_MASTER_CORE + " with DB Update status as : " + updateFraudTrans)

    /* Update all the transactions as Fraud for the given fradulent card numbers in Hive Ingestion table for BAE Consumption*/
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Started labelling Fradulent transactions into Hive Ingestion table " + TRANS_MASTER_CORE_BASE)
    val updateFraudTrans_2 = hiveSession.executeUpdate(" Merge INTO " + TRANS_MASTER_CORE_BASE + " AS ingtransdata " +
      " USING (select distinct oid from " + REDI_LABEL_FRAUD_TRANS + ") AS frauddata " +
      " on (frauddata.oid = ingtransdata.oid  and ingtransdata.realfraudyn = 'N' ) " +
      " When matched Then Update " +
      " SET RealFraudYN = 'Y'," +
      " realfraudtype = 'FRAUDCBF'," +
      " RealFraudDate = current_timestamp," +
      " realfrauddatebae = current_timestamp "
    )
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Updated Fraudulent Transaction into " + TRANS_MASTER_CORE_BASE + " with DB Update status as : " + updateFraudTrans_2)
    AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Updated Fraudulent Transaction into " + TRANS_MASTER_CORE_BASE + " with DB Update status as : " + updateFraudTrans_2)

    // insertCBAuditData

    /* Fetch all Fradulent transactions for Rollback Process */

    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Fetching all Fradulent transactions From Hive table " + REDI_LABEL_FRAUD_TRANS + " for Rollback")
    val fraudRollback = hiveSession.executeQuery("Select OID From " +  REDI_LABEL_FRAUD_TRANS)
    //.cache()
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Total Fradulent transactions identified " + fraudRollback.count())
    AutomatedCBLabellingControllerlogger.debug(ACBPDataIngestionProcess_DEBUG + " Total Fradulent transactions identified " + fraudRollback.count())
    fraudRollback
  }

  /*Store CB Audit data to Hive */
  def storeInputCBMastertoHive(inputDataFrame: DataFrame): Boolean = {
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Starting to push the data into Hive table " + REDI_CB_AUDIT_DATA)
    val dbstatus = StorethedataintoHive1(REDI_CB_AUDIT_DATA, APPEND_MODE, inputDataFrame)
    dbstatus
  }

  /*Store Fradulent transactions to Hive temp table*/
  def storeFraudTranstoHive(inputDataFrame: DataFrame,mode:String): Boolean = {
    AutomatedCBLabellingControllerlogger.info(ACBPDataIngestionProcess_INFO + " Starting to push the data into Hive table " + REDI_LABEL_FRAUD_TRANS)
    val dbstatus =  StorethedataintoHive1(REDI_LABEL_FRAUD_TRANS, mode, inputDataFrame)
    dbstatus
  }

  /*Store Data in Hive */

  def StorethedataintoHive1(tablename: String, format: String, inputdataset: DataFrame): Boolean = {
    var isHiveStore :Boolean = false;
    inputdataset.write.format(HIVE_WAREHOUSE_CONNECTOR)
      .option("database","redi")
      .mode(format)
      .option("table", tablename)
      .save()
    isHiveStore = true
    isHiveStore
  }
}
