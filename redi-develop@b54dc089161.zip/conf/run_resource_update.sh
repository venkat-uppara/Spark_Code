#!/bin/sh

cd /apps/ReDi/conf
#jar vfu $1 *.*
jar vfu $1 application.conf
jar vfu $1 log4j2.xml
jar vfu $1 log4j.properties

