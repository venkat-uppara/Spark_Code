#!/bin/sh
HDFS_REDI=/user/srvredi/redi/
HDFS_CBREASONCODES=/user/srvredi/redi/cbrsncodes/
HDFS_CLIENT_MASTERDATA=/user/srvredi/redi/clientmasterdata/
HDFS_TRANSFORM_METADATA=/user/srvredi/redi/trans_metadata
HDFS_BAND_TRANS_METADATA=/user/srvredi/redi/band_tras_metadata
HDFS_CHECK_POINT=/user/srvredi/checkpoint/
CSI_HDFS=/user/srvredi/redi/csi
AUTOMATED_HDFS=/user/srvredi/redi/automatedcbdata
TRANSACTIONORCFILEPATH=/user/srvredi/redi/exectransactions
TRANSACTIONTOPICCHECKPOINTLOCATION=/user/srvredi/checkpoint/Exec
HDFS_AUTOMATED_CB_DATA=/user/srvredi/redi/automatedcbdata/AutomatedCBData 
CLIENT_MASTER_SERVICE_DATA_HDFS=/user/srvredi/redi/clientmasterdata/ClientmasterServiceData
CSI_SUBCLIENT_PROFILES_HDFS=/user/srvredi/redi/csi/subclient_profiles_data
CSI_CANCEL_CODES_HDFS=/user/srvredi/redi/csi/cancel_codes_data
CSI_USERS_HDFS=/user/srvredi/redi/csi/users_data
CSI_CASES_HDFS=/user/srvredi/redi/csi/cases_data
CSI_ACCESS_HDFS=/user/srvredi/redi/csi/access_data
CSI_TXN_NOTES_HDFS=/user/srvredi/redi/csi/transactionnotes_data
CSI_ORDER_DISPOSITION_HDFS=/user/srvredi/redi/csi/order_disposition_data
SCHEDULERTOPICCHECKPOINTLOCATION=/user/srvredi/checkpoint/Scheduler_ReDi
SCHEDULERPARQUETFILE=/user/srvredi/redi/schedulerdata
HDFS_BIN_DATA=/user/srvredi/redi/RBI_REF_BIN_DATA
TRE_RULE_DETAIL_DATA_HDFS=/user/srvredi/redi/treruledetails/
TRE_RULE_DETAILS_CHECK_POINT=/user/srvredi/treruledetailscheckpoint
TRERULEHITSTOPICCHECKPOINTLOCATION=/user/srvredi/checkpoint/ruleHits
TRERULEHITSORCFILEPATH=/user/srvredi/redi/ruleHitstransactions
CSI_QUEUES_HDFS=/user/srvredi/redi/csi/queues_data
CSI_ITEM_ACCESS_HDFS=/user/srvredi/redi/csi/item_access_data
BED_CB_DATA_FILES_DATA=/user/srvredi/redi/bedcbdata
DVE_TSW_RULE_DETAIL_DATA_HDFS=/user/srvredi/redi/dvetswruledetails
VELOCITY_LIMIT_MASTER_HDFS=/user/srvredi/redi/velocitylimitmaster
BED_DATA_FILES_DATA =/user/srvredi/redi/beddata

# create ReDI directory

if hdfs dfs -test  -e $HDFS_REDI; then
    echo "[$HDFS_REDI] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_REDI
  echo " Created on HDFS Location [$HDFS_REDI]"
  
fi

# create directory for storing cb reason codes into hdfs

if hdfs dfs -test  -e $HDFS_CBREASONCODES; then
    echo "[$HDFS_CBREASONCODES] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_CBREASONCODES
  echo " Created on HDFS Location [$HDFS_CBREASONCODES]"
  
fi

# create directory for storing Client Master data into hdfs

if hdfs dfs -test  -e $HDFS_CLIENT_MASTERDATA; then
    echo "[$HDFS_CLIENT_MASTERDATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_CLIENT_MASTERDATA
  echo " Created on HDFS Location [$HDFS_CLIENT_MASTERDATA]"
  
fi

# create directory for storing Transform Meta data into hdfs

if hdfs dfs -test  -e $HDFS_TRANSFORM_METADATA; then
    echo "[$HDFS_TRANSFORM_METADATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_TRANSFORM_METADATA
  echo " Created on HDFS Location [$HDFS_TRANSFORM_METADATA]"
  
fi

# create directory for storing Band Meta data into hdfs

if hdfs dfs -test  -e $HDFS_BAND_TRANS_METADATA; then
    echo "[$HDFS_BAND_TRANS_METADATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_BAND_TRANS_METADATA
  echo " Created on HDFS Location [$HDFS_BAND_TRANS_METADATA]"
fi


# create directory for storing Chaeck Point data into hdfs

if hdfs dfs -test  -e $CSI_HDFS; then
    echo "[$CSI_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_HDFS
  echo " Created on HDFS Location [$CSI_HDFS]"
fi

# create directory for storing Chaeck Point data into hdfs

if hdfs dfs -test  -e $AUTOMATED_HDFS; then
    echo "[$AUTOMATED_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $AUTOMATED_HDFS
  echo " Created on HDFS Location [$AUTOMATED_HDFS]"
fi

# create directory for storing Chaeck Point data into hdfs

if hdfs dfs -test  -e $HDFS_CHECK_POINT; then
    echo "[$HDFS_CHECK_POINT] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_CHECK_POINT
  echo " Created on HDFS Location [$HDFS_CHECK_POINT]"
fi

# create directory for storing Transaction ORC file into hdfs

if hdfs dfs -test  -e $TRANSACTIONORCFILEPATH; then
    echo "[$TRANSACTIONORCFILEPATH] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRANSACTIONORCFILEPATH
  echo " Created on HDFS Location [$TRANSACTIONORCFILEPATH]"
fi

# create directory for storing TRE RULE DETAIL ORC file into hdfs

if hdfs dfs -test  -e $TRE_RULE_DETAIL_DATA_HDFS; then
    echo "[$TRE_RULE_DETAIL_DATA_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRE_RULE_DETAIL_DATA_HDFS
  echo " Created on HDFS Location [$TRE_RULE_DETAIL_DATA_HDFS]"
fi

# create directory for storing TRE RULE DETAIL Check point location in hdfs

if hdfs dfs -test  -e $TRE_RULE_DETAILS_CHECK_POINT; then
    echo "[$TRE_RULE_DETAILS_CHECK_POINT] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRE_RULE_DETAILS_CHECK_POINT
  echo " Created on HDFS Location [$TRE_RULE_DETAILS_CHECK_POINT]"
fi

# create directory for storing TRE RULE HITS Check point location in hdfs

if hdfs dfs -test  -e $TRERULEHITSTOPICCHECKPOINTLOCATION; then
    echo "[$TRERULEHITSTOPICCHECKPOINTLOCATION] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRERULEHITSTOPICCHECKPOINTLOCATION
  echo " Created on HDFS Location [$TRERULEHITSTOPICCHECKPOINTLOCATION]"
fi

# create directory for storing MAIN TRANSACTION Check point location in hdfs

if hdfs dfs -test  -e $TRANSACTIONTOPICCHECKPOINTLOCATION; then
    echo "[$TRANSACTIONTOPICCHECKPOINTLOCATION] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRANSACTIONTOPICCHECKPOINTLOCATION
  echo " Created on HDFS Location [$TRANSACTIONTOPICCHECKPOINTLOCATION]"
fi

# create directory for storing TRE RULE HITS ORC File location in hdfs

if hdfs dfs -test  -e $TRERULEHITSORCFILEPATH; then
    echo "[$TRERULEHITSORCFILEPATH] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRERULEHITSORCFILEPATH
  echo " Created on HDFS Location [$TRERULEHITSORCFILEPATH]"
fi

# create directory for storing CB DATA  File location in hdfs

if hdfs dfs -test  -e $HDFS_AUTOMATED_CB_DATA; then
    echo "[$HDFS_AUTOMATED_CB_DATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_AUTOMATED_CB_DATA
  echo " Created on HDFS Location [$HDFS_AUTOMATED_CB_DATA]"
fi

# create directory for storing CB MASTER SERVICE File location in hdfs

if hdfs dfs -test  -e $CLIENT_MASTER_SERVICE_DATA_HDFS; then
    echo "[$CLIENT_MASTER_SERVICE_DATA_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CLIENT_MASTER_SERVICE_DATA_HDFS
  echo " Created on HDFS Location [$CLIENT_MASTER_SERVICE_DATA_HDFS]"
fi

# create directory for storing CSI SUBCLIENT File location in hdfs

if hdfs dfs -test  -e $CSI_SUBCLIENT_PROFILES_HDFS; then
    echo "[$CSI_SUBCLIENT_PROFILES_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_SUBCLIENT_PROFILES_HDFS
  echo " Created on HDFS Location [$CSI_SUBCLIENT_PROFILES_HDFS]"
fi

# create directory for storing CSI CANCEL File location in hdfs

if hdfs dfs -test  -e $CSI_CANCEL_CODES_HDFS; then
    echo "[$CSI_CANCEL_CODES_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_CANCEL_CODES_HDFS
  echo " Created on HDFS Location [$CSI_CANCEL_CODES_HDFS]"
fi

# create directory for storing CSI CANCEL File location in hdfs
if hdfs dfs -test  -e $CSI_CASES_HDFS; then
    echo "[$CSI_CASES_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_CASES_HDFS
  echo " Created on HDFS Location [$CSI_CASES_HDFS]"
fi

# create directory for storing CSI USER File location in hdfs
if hdfs dfs -test  -e $CSI_USERS_HDFS; then
    echo "[$CSI_USERS_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_USERS_HDFS
  echo " Created on HDFS Location [$CSI_USERS_HDFS]"
fi

# create directory for storing CSI ACCESS File location in hdfs
if hdfs dfs -test  -e $CSI_ACCESS_HDFS; then
    echo "[$CSI_ACCESS_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_ACCESS_HDFS
  echo " Created on HDFS Location [$CSI_ACCESS_HDFS]"
fi

# create directory for storing CSI ACCESS File location in hdfs
if hdfs dfs -test  -e $CSI_TXN_NOTES_HDFS; then
    echo "[$CSI_TXN_NOTES_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_TXN_NOTES_HDFS
  echo " Created on HDFS Location [$CSI_TXN_NOTES_HDFS]"
fi

# create directory for storing CSI ORDER DISPOSITION  File location in hdfs
if hdfs dfs -test  -e $CSI_ORDER_DISPOSITION_HDFS; then
    echo "[$CSI_ORDER_DISPOSITION_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_ORDER_DISPOSITION_HDFS
  echo " Created on HDFS Location [$CSI_ORDER_DISPOSITION_HDFS]"
fi

# create directory for storing SCHEDULER TOPIC CHECKPOINT LOCATION  in hdfs
if hdfs dfs -test  -e $SCHEDULERTOPICCHECKPOINTLOCATION; then
    echo "[$SCHEDULERTOPICCHECKPOINTLOCATION] exists on HDFS"
  else 
  hdfs dfs -mkdir $SCHEDULERTOPICCHECKPOINTLOCATION
  echo " Created on HDFS Location [$SCHEDULERTOPICCHECKPOINTLOCATION]"
fi

# create directory for storing SCHEDULER PARQUET FILE LOCATION  in hdfs
if hdfs dfs -test  -e $SCHEDULERPARQUETFILE; then
    echo "[$SCHEDULERPARQUETFILE] exists on HDFS"
  else 
  hdfs dfs -mkdir $SCHEDULERPARQUETFILE
  echo " Created on HDFS Location [$SCHEDULERPARQUETFILE]"
fi

# create directory for storing BIN_DATA  FILE LOCATION  in hdfs
if hdfs dfs -test  -e $HDFS_BIN_DATA; then
    echo "[$HDFS_BIN_DATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $HDFS_BIN_DATA
  echo " Created on HDFS Location [$HDFS_BIN_DATA]"
fi
# create directory for storing TRE RULE DETAIL ORC file into hdfs

if hdfs dfs -test  -e $TRE_RULE_DETAIL_DATA_HDFS; then
    echo "[$TRE_RULE_DETAIL_DATA_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRE_RULE_DETAIL_DATA_HDFS
  echo " Created on HDFS Location [$TRE_RULE_DETAIL_DATA_HDFS]"
fi

# create directory for storing TRE RULE DETAIL Check point location in hdfs

if hdfs dfs -test  -e $TRE_RULE_DETAILS_CHECK_POINT; then
    echo "[$TRE_RULE_DETAILS_CHECK_POINT] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRE_RULE_DETAILS_CHECK_POINT
  echo " Created on HDFS Location [$TRE_RULE_DETAILS_CHECK_POINT]"
fi

# create directory for storing TRE RULE HITS Check point location in hdfs

if hdfs dfs -test  -e $TRERULEHITSTOPICCHECKPOINTLOCATION; then
    echo "[$TRERULEHITSTOPICCHECKPOINTLOCATION] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRERULEHITSTOPICCHECKPOINTLOCATION
  echo " Created on HDFS Location [$TRERULEHITSTOPICCHECKPOINTLOCATION]"
fi

# create directory for storing TRE RULE HITS ORC File location in hdfs

if hdfs dfs -test  -e $TRERULEHITSORCFILEPATH; then
    echo "[$TRERULEHITSORCFILEPATH] exists on HDFS"
  else 
  hdfs dfs -mkdir $TRERULEHITSORCFILEPATH
  echo " Created on HDFS Location [$TRERULEHITSORCFILEPATH]"
fi
# create CSI Queue directory

if hdfs dfs -test  -e $CSI_QUEUES_HDFS; then
    echo "[$CSI_QUEUES_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_QUEUES_HDFS
  echo " Created on HDFS Location [$CSI_QUEUES_HDFS]"
  
fi  

# create CSI Items directory

if hdfs dfs -test  -e $CSI_ITEM_ACCESS_HDFS; then
    echo "[$CSI_ITEM_ACCESS_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $CSI_ITEM_ACCESS_HDFS
  echo " Created on HDFS Location [$CSI_ITEM_ACCESS_HDFS]"
  
fi

# create BED CB Data directory

if hdfs dfs -test  -e $BED_CB_DATA_FILES_DATA; then
    echo "[$BED_CB_DATA_FILES_DATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $BED_CB_DATA_FILES_DATA
  echo " Created on HDFS Location [$BED_CB_DATA_FILES_DATA]"
  
fi

# create DVE TSW RULE Details directory

if hdfs dfs -test  -e $DVE_TSW_RULE_DETAIL_DATA_HDFS; then
    echo "[$DVE_TSW_RULE_DETAIL_DATA_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $DVE_TSW_RULE_DETAIL_DATA_HDFS
  echo " Created on HDFS Location [$DVE_TSW_RULE_DETAIL_DATA_HDFS]"
  
fi

# create VELOCITY LIMIT MASTER directory

if hdfs dfs -test  -e $VELOCITY_LIMIT_MASTER_HDFS; then
    echo "[$VELOCITY_LIMIT_MASTER_HDFS] exists on HDFS"
  else 
  hdfs dfs -mkdir $VELOCITY_LIMIT_MASTER_HDFS
  echo " Created on HDFS Location [$VELOCITY_LIMIT_MASTER_HDFS]"
  
fi

# create BED DATA directory

if hdfs dfs -test  -e $BED_DATA_FILES_DATA; then
    echo "[$BED_DATA_FILES_DATA] exists on HDFS"
  else 
  hdfs dfs -mkdir $BED_DATA_FILES_DATA
  echo " Created on HDFS Location [$BED_DATA_FILES_DATA]"
  
fi