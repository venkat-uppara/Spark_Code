#!/bin/bash
########################################################################################################
# Created / Version : 26-July-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	KCS
# Description : SQOOP Script to Ingest RBI_REF_CLIENT data from Sybase IQ database to Hadoop Hive 
########################################################################################################

################################################
# Variable Declarations
################################################

DIR_NAME="RBI_REF_CLIENT"
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

#########################################################################
# SQOOP Import RBI_REF_CLIENT table data and region details From Sybase IQ to HDFS
#########################################################################

echo "###############################################################################"
echo "Executing SQOOP Script for Importing RBI_REF_CLIENT data from Sybase IQ"
echo "###############################################################################"
echo "Enter the userid which is to be used for Sqoop import."
#read SYBASE_USER
#echo entreduseridis:${SYBASE_USER}
#echo "Enter the password for Sybase user"
#read SYBASE_PWD
#echo entredpasswordis:${SYBASE_PWD}

sqoop import \
--connect  ${SYBASEIQ_DRIVER} \
--username $2  \
--password $3 \
--query "SELECT T1.* FROM (SELECT A.ClientId,A.SubClientId,A.ClientName,A.SubClientName,A.Client12,A.ClientGroup,A.RSActive,A.ClientCurr,SubClientCurr,A.CMActive,A.CSIActive,A.BEDActive,A.ChallActive,A.CBActive,A.Affiliate,A.SectorGroup,A.Sector,A.RiskManager,A.AccManager,A.xMerchantIds,A.ClubRFX,A.CM2Active,A.LocalKPIs,A.SilentRules,A.Alerts,A.TZClient,A.TZSubClient,A.PSP_GROUP,B.GCRegion FROM $2.RBI_REF_CLIENT A LEFT OUTER JOIN $2.RBI_REF_GCREGIONS B ON A.Client12 = B.ClientId12) T1 WHERE \$CONDITIONS" \
--optionally-enclosed-by '\"' \
--fields-terminated-by '~' \
--null-string '' \
--delete-target-dir \
--target-dir ${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_CLIENT.csv \
--driver ${SYBASE_DRIVER} \
-m 1 2>&1| tee -a ${SQOOP_LOG_FILE}

echo "####################################################"
echo "SQOOP Import Completed!" 
echo "####################################################"

##############################################
#Writing Sqoop Validation for data Import
##############################################
echo "########################################################################### " > ${JOB_VALIDATION_FILE}
echo "SQOOP Import Validation for ${SQOOP_LOG_FILE} " >> ${JOB_VALIDATION_FILE}
echo "########################################################################### ">> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "The url to track the job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Submitting tokens for job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map input records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map output records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Retrieved" >> ${JOB_VALIDATION_FILE}

echo "##################################################"
echo "Importing Data from HDFS to Hive Started"
echo "##################################################"

########################################################################################
# Creating Hive External Table EXT_RBI_REF_CLIENT for the CLIENT data file
# imported using the SQOOP Script.
# Loading data from the External table to Hive Managed ORC table Destination_RBI_REF_CLIENT
########################################################################################
if [ -f EXT_RBI_REF_CLIENT.hql ]; then
    rm EXT_RBI_REF_CLIENT.hql
fi	
	
echo "##################################################" > EXT_RBI_REF_CLIENT.hql
echo "# Creating External table in Hive referencing the"  >> EXT_RBI_REF_CLIENT.hql
echo "# location of the .csv file"					 >> EXT_RBI_REF_CLIENT.hql
echo "##################################################" >> EXT_RBI_REF_CLIENT.hql
echo "use redi;" >> EXT_RBI_REF_CLIENT.hql
echo "CREATE EXTERNAL TABLE IF NOT EXISTS EXT_RBI_REF_CLIENT(" >> EXT_RBI_REF_CLIENT.hql
echo "ClientId 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",SubClientId 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",ClientName 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",SubClientName 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",Client12 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",ClientGroup 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",RSActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",ClientCurr 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",SubClientCurr 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",CMActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",CSIActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",BEDActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",ChallActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",CBActive 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",Affiliate 	CHAR(2)" >> EXT_RBI_REF_CLIENT.hql
echo ",SectorGroup 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",Sector 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",RiskManager 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",AccManager 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",xMerchantIds 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",ClubRFX 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",CM2Active 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",LocalKPIs 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",SilentRules 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",Alerts 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",TZClient 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",TZSubClient 	string" >> EXT_RBI_REF_CLIENT.hql
echo ",PSP_GROUP	string" >> EXT_RBI_REF_CLIENT.hql
echo ",GCRegion 	string" >> EXT_RBI_REF_CLIENT.hql
echo ")" >> EXT_RBI_REF_CLIENT.hql
echo "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'" >> EXT_RBI_REF_CLIENT.hql
echo "WITH SERDEPROPERTIES (" >> EXT_RBI_REF_CLIENT.hql 
echo '   "separatorChar" = "~",' >> EXT_RBI_REF_CLIENT.hql
echo '   "quoteChar"     = "\""' >> EXT_RBI_REF_CLIENT.hql
echo ")"  >> EXT_RBI_REF_CLIENT.hql
echo "STORED AS TEXTFILE" >> EXT_RBI_REF_CLIENT.hql
echo "location '${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_CLIENT.csv';" >> EXT_RBI_REF_CLIENT.hql
echo "SELECT COUNT(ClientId) FROM EXT_RBI_REF_CLIENT;" >> EXT_RBI_REF_CLIENT.hql

if [ ! -f EXT_RBI_REF_CLIENT.hql ]; then
#-{
    echo "File: `pwd`/EXT_RBI_REF_CLIENT.hql not found!"
	else
	####################################################################################################
	# Initiate the Hive shell using beeline to move data from the HDFS file location to Hive TABLE
	#hive -f EXT_RBI_REF_CLIENT.hql
	####################################################################################################
	beeline -u ${HIVE_BEELINE_PATH} -f EXT_RBI_REF_CLIENT.hql 2>&1| tee -a ${HIVE_LOG_FILE}
	echo "##########################################################"
	echo "Importing Data from HDFS to Hive Completed"
	echo "SQOOP Log path : `pwd`/${SQOOP_LOG_FILE}"
	echo "HIVE Log path : `pwd`/${HIVE_LOG_FILE}"
	echo "Job Validation Path : `pwd`/${JOB_VALIDATION_FILE}"
	echo "##########################################################"
#-}	
fi
