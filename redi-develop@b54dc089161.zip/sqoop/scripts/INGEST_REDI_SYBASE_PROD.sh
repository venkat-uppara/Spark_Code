#!/bin/bash
########################################################################################################
# Created / Version : 23-MAR-2019 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	Venkat
# Description : SQOOP Script to Ingest RBI_CLIENT_PROD data from Sybase IQ database to Hadoop Hive 
########################################################################################################

################################################
# Variable Declarations
################################################
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

#########################################################################
# SQOOP Import RBI_CLIENT_PROD table data From Sybase IQ to HDFS
#########################################################################

echo "###############################################################################"
echo "Executing SQOOP Script for Importing REDI data from Sybase IQ"
echo "###############################################################################"

sh INGEST_RBI_CLIENT_PROD.sh $1 $2 $3
sh INGEST_RBI_REF_BIN_DATA_Hist.sh $1 $2 $3
sh INGEST_RBI_REF_CLIENT.sh $1 $2 $3
sh INGEST_RBI_REF_CLIENT12_SETS.sh $1 $2 $3
sh INGEST_RBI_REF_COUNTRY sh $1 $2 $3
sh INGEST_RBI_REF_CSI1_CANCEL_CODES.sh $1 $2 $3
sh INGEST_RBI_REF_CURRENCY.sh $1 $2 $3
sh INGEST_RBI_REF_DATES_DATA.sh $1 $2 $3
sh INGEST_RBI_REF_SUBCLIENT_GROUP_NAME.sh $1 $2 $3

echo "####################################################"
echo "SQOOP Import Completed!" 
echo "####################################################"

echo "###############################################################################"
echo "Start to Removing the  SQOOP Log files"
echo "###############################################################################"

rm  SQOOP*
rm  VALIDATION*
rm  HIVE*
rm  EXT_*

echo "###############################################################################"
echo "Executing Removing the  SQOOP Log files completed"
echo "###############################################################################"