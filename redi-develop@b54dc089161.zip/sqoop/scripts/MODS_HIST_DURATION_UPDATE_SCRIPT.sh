#!/bin/bash
#####################################################################################################################################
# Description : To import duration fields data from Oracle to HDFS and updating redi.BI_TRANS_MASTER_CORE table with duration fields
# Created by  : Babu N U
# Created date: 16/07/2019
#####################################################################################################################################


if [ "$#" -ne 6 ]; then
        echo "Please refer the below usage example...
        Ex: sh $0 path clientid oiddate hist_period_in_months username password
        Usage: sh $0 /apps/ReDi/conf 000373 201907 10 username password"
        exit 1
fi

source $1/rediEnvSetup.sh
SRC_DIR="$1/../sqoop"

if [ -d ${SRC_DIR}/logs ]; then
        echo "Log dir exists..."
else
        mkdir -p ${SRC_DIR}/logs
fi

LOG_FILE="${SRC_DIR}/logs/duration_update_`date +%Y-%m-%dT%H:%M:%S`.log"

CLIENTID=$2
OIDDATE=$3
HIST_PERIOD_IN_MONTHS=$4
HDFS_DIR="${HDFS_LOCATION}/mods_hist_duration_update/clientid=${CLIENTID}"
HIVE_BI_TABLE="redi.BI_TRANS_MASTER_CORE"
ORACLE_MODS_TABLE="MODS.TRANS_MASTER"
ORACLE_USER=$5
ORACLE_PWD=$6
UPDATE_SCRIPT=$(cat ${SRC_DIR}/../hive/dml/MODS_HIST_DURATION_UPDATE.hql |sed "s/client_id/$CLIENTID/g"|sed "s/to_oid_date/$OIDDATE/g"|sed "s/from_oid_date/`expr $OIDDATE - $HIST_PERIOD_IN_MONTHS`/g")
echo `date` + "Hive Update script is : " + $UPDATE_SCRIPT >> $LOG_FILE

echo `date` + ": Importing data by using CLIENTID='$CLIENTID' and OIDDATE range $HIST_PERIOD_IN_MONTHS months before $OIDDATE ..." >> $LOG_FILE
sqoop import --connect $ORACLE_URL --username $ORACLE_USER --password $ORACLE_PWD --table $ORACLE_MODS_TABLE --where "CLIENT_ID='$CLIENTID' AND TO_NUMBER(TO_CHAR(OID_DATE,'YYYYMM'))>=`expr $OIDDATE - $HIST_PERIOD_IN_MONTHS` AND TO_NUMBER(TO_CHAR(OID_DATE,'YYYYMM'))<='$OIDDATE'" --columns "OID,DURATION, DURATION_BTI, DURATION_COP, DURATION_CX, DURATION_DVE, DURATION_EWB, DURATION_GATHER, DURATION_IOV, DURATION_IPID, DURATION_PPI, DURATION_PRISM, DURATION_PWS ,DURATION_RECOMMEND, DURATION_RPS, DURATION_SDS, DURATION_TMX, DURATION_TMX_SVC ,DURATION_TSW,DURATION_VALID,CLIENT_ID" --target-dir $HDFS_DIR --append --fields-terminated-by "~" -m 24 --split-by "TO_NUMBER(TO_CHAR(OID_DATE,'YYYYMM'))" --as-textfile 2>&1 >> $LOG_FILE
ERR=$?

if [ "$ERR" -eq 0 ]; then
        echo `date` + ":Sqoop import is successful and updating the $HIVE_BI_TABLE in hive..."  >> $LOG_FILE
        beeline -u $HIVE_BEELINE_PATH -e "${UPDATE_SCRIPT}" 2>&1 >> $LOG_FILE
        HIVE_ERR=$?
        if [ "$HIVE_ERR" -eq 0 ]; then
                echo `date` + ": Successfully updated the $HIVE_BI_TABLE in hive..." >> $LOG_FILE
                exit 0
        else
                echo `date` + ": Failed to update $HIVE_BI_TABLE due to some issues..." >> $LOG_FILE
                exit 1
        fi
else
        echo `date` + ": Sqoop import has been failed due to some issues..." >> $LOG_FILE
        exit 1
fi
cat $LOG_FILE
exit 0