#!/bin/bash
########################################################################################################
# Created / Version : 26-July-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	KCS
# Description : SQOOP Script to Ingest RBI_REF_CLIENT12_SETS data from Sybase IQ database to Hadoop Hive Table
########################################################################################################

################################################
# Variable Declarations
################################################

DIR_NAME="RBI_REF_CLIENT12set"
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

#########################################################################
# SQOOP Import RBI_REF_CLIENT12_SETS table data From Sybase IQ to HDFS
#########################################################################

echo "###############################################################################"
echo "Executing SQOOP Script for Importing RBI_REF_CLIENT12_SETS data from Sybase IQ"
echo "###############################################################################"

#echo "Enter the userid which is to be used for Sqoop import."
#read SYBASE_USER
#echo entreduseridis:${SYBASE_USER}
#echo "Enter the password for Sybase user"
#read SYBASE_PWD
#echo entredpasswordis:${SYBASE_PWD}

sqoop import \
--connect  ${SYBASEIQ_DRIVER} \
--username $2  \
--password $3 \
--query "select Client12Set,Client12 from MODS.RBI_REF_CLIENT12_SETS WHERE \$CONDITIONS" \
--optionally-enclosed-by '\"' \
--fields-terminated-by '~' \
--null-string '' \
--delete-target-dir \
--target-dir ${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_CLIENT12_SETS.csv \
--driver ${SYBASE_DRIVER} \
-m 1 2>&1| tee -a ${SQOOP_LOG_FILE}

echo "####################################################"
echo "SQOOP Import Completed!" 
echo "####################################################"

##############################################
#Writing Sqoop Validation for data Import
##############################################
echo "########################################################################### " > ${JOB_VALIDATION_FILE}
echo "SQOOP Import Validation for ${SQOOP_LOG_FILE} " >> ${JOB_VALIDATION_FILE}
echo "########################################################################### ">> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "The url to track the job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Submitting tokens for job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map input records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map output records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Retrieved" >> ${JOB_VALIDATION_FILE}

echo "##################################################"
echo "Importing Data from HDFS to Hive Started"
echo "##################################################"

########################################################################################
# Creating Hive External Table EXT_RBI_REF_CLIENT12_SETS for the CLIENT data file
# Creating Hive External Table EXT_RBI_REF_CLIENT12_SETS for the CLIENT data file
# imported using the SQOOP Script.
# Loading data from the External table to Hive Managed ORC table Destination_RBI_REF_CLIENT12_SETS
########################################################################################
if [ -f EXT_RBI_REF_CLIENT12_SETS.hql ]; then
    rm EXT_RBI_REF_CLIENT12_SETS.hql
fi	
	
echo "##################################################" > EXT_RBI_REF_CLIENT12_SETS.hql
echo "# Creating External table in Hive referencing the"  >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "# location of the .csv file"					 >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "##################################################" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "use redi;" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "CREATE EXTERNAL TABLE IF NOT EXISTS EXT_RBI_REF_CLIENT12_SETS(" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "Client12Set	string" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo ",Client12	string" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo ")" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "WITH SERDEPROPERTIES (" >> EXT_RBI_REF_CLIENT12_SETS.hql 
echo '   "separatorChar" = "~",' >> EXT_RBI_REF_CLIENT12_SETS.hql
echo '   "quoteChar"     = "\""' >> EXT_RBI_REF_CLIENT12_SETS.hql
echo ")"  >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "STORED AS TEXTFILE" >> EXT_RBI_REF_CLIENT12_SETS.hql
echo "location '${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_CLIENT12_SETS.csv';" >> EXT_RBI_REF_CLIENT12_SETS.hql

echo "SELECT COUNT(Client12) FROM EXT_RBI_REF_CLIENT12_SETS;" >> EXT_RBI_REF_CLIENT12_SETS.hql

if [ ! -f EXT_RBI_REF_CLIENT12_SETS.hql ]; then
#-{
    echo "File: `pwd`/EXT_RBI_REF_CLIENT12_SETS.hql not found!"
	else
	####################################################################################################
	# Initiate the Hive shell using beeline to move data from the HDFS file location to Hive TABLE
	#hive -f EXT_RBI_REF_CLIENT12_SETS.hql
	####################################################################################################
	beeline -u ${HIVE_BEELINE_PATH} -f EXT_RBI_REF_CLIENT12_SETS.hql 2>&1| tee -a ${HIVE_LOG_FILE}
	echo "##########################################################"
	echo "Importing Data from HDFS to Hive Completed"
	echo "SQOOP Log path : `pwd`/${SQOOP_LOG_FILE}"
	echo "HIVE Log path : `pwd`/${HIVE_LOG_FILE}"
	echo "Job Validation Path : `pwd`/${JOB_VALIDATION_FILE}"
	echo "##########################################################"
#-}	
fi
