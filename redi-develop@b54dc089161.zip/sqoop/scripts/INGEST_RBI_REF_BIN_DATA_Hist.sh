#!/bin/bash
########################################################################################################
# Created / Version : 06-July-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	PBB
# Description : Sqoop Script to Ingest historical bin data from Sybase IQ database to Hadoop Hive 
########################################################################################################

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

################################################
# Variable Declarations
################################################
#HDFS_LOCATION="/user/srvredi/redi"
DIR_NAME="RBI_REF_BIN_DATA"
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#########################################################################
# SQOOP Import RBI_REF_BIN_DATA table data From Sybase IQ to HDFS
#########################################################################
echo "###############################################################################"
echo "Executing Scoop Script for Importing Historical Bin data from Sybase IQ"
echo "###############################################################################"
#echo "Enter the userid which is to be used for Sqoop import."
#read SYBASE_USERNAME
#echo entreduseridis:${SYBASE_USERNAME}
#echo "Enter the password for Sybase user"
#read SYBASE_PASSWORD
#echo entredpasswordis:${SYBASE_PASSWORD}


sqoop import \
--connect  ${SYBASEIQ_DRIVER} \
--username $2  \
--password $3 \
--query "SELECT T1.* FROM (SELECT A.BIN,A.BINType,A.BINOwner,A.BINCrDr,A.BINDesc2,A.BINCountry,A.BINCountryCode2,A.BINCountryCode3,A.BINCountryNum,A.BINWebsite,A.BINPhone,B.BINGroup,'Y' AS BINRFX FROM $2.RBI_REF_BIN_DATA A LEFT OUTER JOIN $2.RBI_REF_BIN_GROUPS B ON A.BIN = B.CardBIN) T1 WHERE \$CONDITIONS" \
--optionally-enclosed-by '\"' \
--fields-terminated-by '~' \
--null-string '' \
--delete-target-dir \
--target-dir ${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_BIN_DATA.csv \
--driver ${SYBASE_DRIVER} \
-m 1 2>&1| tee -a ${SQOOP_LOG_FILE}

echo "####################################################"
echo "Scoop Import Completed !" 
echo "####################################################"

##############################################
#Writing Sqoop Validation for data Import
##############################################
echo "########################################################################### " > ${JOB_VALIDATION_FILE}
echo "SQOOP Import Validation for ${SQOOP_LOG_FILE} " >> ${JOB_VALIDATION_FILE}
echo "########################################################################### ">> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "The url to track the job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Submitting tokens for job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map input records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map output records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Retrieved" >> ${JOB_VALIDATION_FILE}

echo "##################################################"
echo "Importing Data from HDFS to Hive Started"
echo "##################################################"

########################################################################################
# Creating Hive External Table EXT_RBI_REF_BIN_DATA for the bin data file
# imported using the Scoop Script.
# Loading data from the External table to Hive Managed ORC table RBI_REF_BIN_DATA
########################################################################################
if [ -f EXT_RBI_REF_BIN_DATA.hql ]; then
    rm EXT_RBI_REF_BIN_DATA.hql
fi	
	
echo "##################################################" > EXT_RBI_REF_BIN_DATA.hql
echo "# Create External table in Hive referencing the"  >> EXT_RBI_REF_BIN_DATA.hql
echo "# location of the .csv file"					 >> EXT_RBI_REF_BIN_DATA.hql
echo "##################################################" >> EXT_RBI_REF_BIN_DATA.hql
echo "use redi;" >> EXT_RBI_REF_BIN_DATA.hql
echo "CREATE EXTERNAL TABLE IF NOT EXISTS EXT_RBI_REF_BIN_DATA(" >> EXT_RBI_REF_BIN_DATA.hql
echo "BIN			string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINType	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINOwner	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCrDr	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINDesc2	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountry	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryCode2	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryCode3	string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryNum		string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINWebsite		string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINPhone		string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINGroup		string" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINRFX			char(1)" >> EXT_RBI_REF_BIN_DATA.hql
echo ")" >> EXT_RBI_REF_BIN_DATA.hql
echo "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'" >> EXT_RBI_REF_BIN_DATA.hql
echo "WITH SERDEPROPERTIES (" >> EXT_RBI_REF_BIN_DATA.hql 
echo '   "separatorChar" = "~",' >> EXT_RBI_REF_BIN_DATA.hql
echo '   "quoteChar"     = "\""' >> EXT_RBI_REF_BIN_DATA.hql
echo ")"  >> EXT_RBI_REF_BIN_DATA.hql


echo "STORED AS TEXTFILE" >> EXT_RBI_REF_BIN_DATA.hql
echo "location '${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_BIN_DATA.csv';" >> EXT_RBI_REF_BIN_DATA.hql

echo "##################################################" >> EXT_RBI_REF_BIN_DATA.hql
echo "# Insert the data from the External table to the " >> EXT_RBI_REF_BIN_DATA.hql
echo "# Hive ORC table" >> EXT_RBI_REF_BIN_DATA.hql
echo "##################################################" >> EXT_RBI_REF_BIN_DATA.hql

echo "use redi;" >> EXT_RBI_REF_BIN_DATA.hql

echo "INSERT OVERWRITE TABLE RBI_REF_BIN_DATA" >> EXT_RBI_REF_BIN_DATA.hql
echo "SELECT BIN" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINType" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINOwner" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCrDr" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINDesc2" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountry" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryCode2" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryCode3" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINCountryNum" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINWebsite" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINPhone" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINGroup" >> EXT_RBI_REF_BIN_DATA.hql
echo ",BINRFX" >> EXT_RBI_REF_BIN_DATA.hql
echo ",current_timestamp()" >> EXT_RBI_REF_BIN_DATA.hql
echo ",current_user()" >> EXT_RBI_REF_BIN_DATA.hql
echo ",current_timestamp()" >> EXT_RBI_REF_BIN_DATA.hql
echo ",current_user()" >> EXT_RBI_REF_BIN_DATA.hql
echo "FROM EXT_RBI_REF_BIN_DATA;" >> EXT_RBI_REF_BIN_DATA.hql

echo "SELECT COUNT(BIN) FROM RBI_REF_BIN_DATA;" >> EXT_RBI_REF_BIN_DATA.hql

if [ ! -f EXT_RBI_REF_BIN_DATA.hql ]; then
#-{
    echo "File: `pwd`/EXT_RBI_REF_BIN_DATA.hql not found!"
	else
	####################################################################################################
	# Initiate the Hive shell using beeline to move data from the HDFS file location to Hive TABLE
	#hive -f EXT_RBI_REF_BIN_DATA.hql
	####################################################################################################
	beeline -u ${HIVE_BEELINE_PATH} -f EXT_RBI_REF_BIN_DATA.hql 2>&1| tee -a ${HIVE_LOG_FILE}
	echo "##########################################################"
	echo "Importing Data from HDFS to Hive Completed"
	echo "SQOOP Log path : `pwd`/${SQOOP_LOG_FILE}"
	echo "HIVE Log path : `pwd`/${HIVE_LOG_FILE}"
	echo "Job Validation Path : `pwd`/${JOB_VALIDATION_FILE}"
	echo "##########################################################"
#-}	
fi
