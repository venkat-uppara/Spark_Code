#!/bin/bash
########################################################################################################
# Created / Version : 20-July-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	JS
# Description : SQOOP Script to Ingest RBI_REF_COUNTRY data from Sybase IQ database to Hadoop Hive 
########################################################################################################

################################################
# Variable Declarations
################################################

DIR_NAME="RBI_REF_COUNTRY"
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

#########################################################################
# SQOOP Import RBI_REF_COUNTRY table data From Sybase IQ to HDFS
#########################################################################

echo "###############################################################################"
echo "Executing SQOOP Script for Importing RBI_REF_COUNTRY data from Sybase IQ"
echo "###############################################################################"
echo "Enter the userid which is to be used for Sqoop import."
#read SYBASE_USERNAME
#echo entreduseridis:${SYBASE_USERNAME}
#echo "Enter the password for Sybase user"
#read SYBASE_PASSWORD
#echo entredpasswordis:${SYBASE_PASSWORD}

sqoop import \
--connect  ${SYBASEIQ_DRIVER} \
--username $2  \
--password $3 \
--query "SELECT CountryCode, CountryDesc, CountryCode2, CountryCode3  FROM MODS.RBI_REF_COUNTRY WHERE \$CONDITIONS" \
--optionally-enclosed-by '\"' \
--fields-terminated-by '~' \
--null-string '' \
--delete-target-dir \
--target-dir ${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_COUNTRY.csv \
--driver ${SYBASE_DRIVER} \
-m 1 2>&1| tee -a ${SQOOP_LOG_FILE}

echo "####################################################"
echo "SQOOP Import Completed!" 
echo "####################################################"

##############################################
#Writing Sqoop Validation for data Import
##############################################
echo "########################################################################### " > ${JOB_VALIDATION_FILE}
echo "SQOOP Import Validation for ${SQOOP_LOG_FILE} " >> ${JOB_VALIDATION_FILE}
echo "########################################################################### ">> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "The url to track the job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Submitting tokens for job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map input records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map output records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Retrieved" >> ${JOB_VALIDATION_FILE}

echo "##################################################"
echo "Importing Data from HDFS to Hive Started"
echo "##################################################"

########################################################################################
# Creating Hive External Table EXT_RBI_REF_COUNTRY for the Currency data file
# Creating Hive External Table EXT_RBI_REF_COUNTRY for the Currency data file
# imported using the SQOOP Script.
# Loading data from the External table to Hive Managed ORC table RBI_REF_COUNTRY
########################################################################################
if [ -f EXT_RBI_REF_COUNTRY.hql ]; then
    rm EXT_RBI_REF_COUNTRY.hql
fi	
	
echo "##################################################" > EXT_RBI_REF_COUNTRY.hql
echo "# Creating External table in Hive referencing the"  >> EXT_RBI_REF_COUNTRY.hql
echo "# location of the .csv file"					 >> EXT_RBI_REF_COUNTRY.hql
echo "##################################################" >> EXT_RBI_REF_COUNTRY.hql
echo "use redi;" >> EXT_RBI_REF_COUNTRY.hql
echo "CREATE EXTERNAL TABLE IF NOT EXISTS EXT_RBI_REF_COUNTRY(" >> EXT_RBI_REF_COUNTRY.hql
echo "CountryCode 	string" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryDesc	string" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryCode2	string" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryCode3	string" >> EXT_RBI_REF_COUNTRY.hql
echo ")" >> EXT_RBI_REF_COUNTRY.hql
echo "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'" >> EXT_RBI_REF_COUNTRY.hql
echo "WITH SERDEPROPERTIES (" >> EXT_RBI_REF_COUNTRY.hql 
echo '   "separatorChar" = "~",' >> EXT_RBI_REF_COUNTRY.hql
echo '   "quoteChar"     = "\""' >> EXT_RBI_REF_COUNTRY.hql
echo ")"  >> EXT_RBI_REF_COUNTRY.hql
echo "STORED AS TEXTFILE" >> EXT_RBI_REF_COUNTRY.hql
echo "location '${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_REF_COUNTRY.csv';" >> EXT_RBI_REF_COUNTRY.hql

echo "##################################################" >> EXT_RBI_REF_COUNTRY.hql
echo "# Insert the data from the External table to the " >> EXT_RBI_REF_COUNTRY.hql
echo "# Hive ORC table" >> EXT_RBI_REF_COUNTRY.hql
echo "##################################################" >> EXT_RBI_REF_COUNTRY.hql

echo "use redi;" >> EXT_RBI_REF_COUNTRY.hql
echo "INSERT OVERWRITE TABLE RBI_REF_COUNTRY" >> EXT_RBI_REF_COUNTRY.hql
echo "SELECT CountryCode" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryDesc" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryCode2" >> EXT_RBI_REF_COUNTRY.hql
echo ",CountryCode3" >> EXT_RBI_REF_COUNTRY.hql
echo ",current_timestamp()" >> EXT_RBI_REF_COUNTRY.hql
echo ",current_user()" >> EXT_RBI_REF_COUNTRY.hql
echo ",current_timestamp()" >> EXT_RBI_REF_COUNTRY.hql
echo ",current_user()" >> EXT_RBI_REF_COUNTRY.hql
echo "FROM EXT_RBI_REF_COUNTRY;" >> EXT_RBI_REF_COUNTRY.hql

echo "SELECT COUNT(CountryCode) FROM RBI_REF_COUNTRY;" >> EXT_RBI_REF_COUNTRY.hql

if [ ! -f EXT_RBI_REF_COUNTRY.hql ]; then
#-{
    echo "File: `pwd`/EXT_RBI_REF_COUNTRY.hql not found!"
	else
	####################################################################################################
	# Initiate the Hive shell using beeline to move data from the HDFS file location to Hive TABLE
	#hive -f EXT_RBI_REF_COUNTRY.hql
	####################################################################################################
	beeline -u ${HIVE_BEELINE_PATH} -f EXT_RBI_REF_COUNTRY.hql 2>&1| tee -a ${HIVE_LOG_FILE}
	echo "##########################################################"
	echo "Importing Data from HDFS to Hive Completed"
	echo "SQOOP Log path : `pwd`/${SQOOP_LOG_FILE}"
	echo "HIVE Log path : `pwd`/${HIVE_LOG_FILE}"
	echo "Job Validation Path : `pwd`/${JOB_VALIDATION_FILE}"
	echo "##########################################################"
#-}	
fi
