#!/bin/bash
########################################################################################################
# Created / Version : 26-July-2018 / Initial Draft
# Modified / Version / Modified By
# (Future Modification Comments)
# Created By		 : 	KCS
# Description : SQOOP Script to Ingest RBI_CLIENT_PROD data from Sybase IQ database to Hadoop Hive 
########################################################################################################

################################################
# Variable Declarations
################################################
DIR_NAME="RBI_CLIENT_PROD"
SQOOP_LOG_FILE="SQOOP_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
HIVE_LOG_FILE="HIVE_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"
JOB_VALIDATION_FILE="VALIDATION_`date '+%Y-%m-%d:%H:%M:%S'`_LOG"

#################################################
# Sourcing Environment Variables
#################################################

source $1/rediEnvSetup.sh

#########################################################################
# SQOOP Import RBI_CLIENT_PROD table data From Sybase IQ to HDFS
#########################################################################

echo "###############################################################################"
echo "Executing SQOOP Script for Importing RBI_CLIENT_PROD data from Sybase IQ"
echo "###############################################################################"

#echo "Enter the userid which is to be used for Sqoop import."
#read SYBASE_USERNAME
#echo entreduseridis:${SYBASE_USERNAME}
#echo "Enter the password for Sybase user"
#read SYBASE_PASSWORD
#echo entredpasswordis:${SYBASE_PASSWORD}

sqoop import \
--connect  ${SYBASEIQ_DRIVER} \
--username $2  \
--password $3 \
--query "select ClientSet,ClientId from MODS.RBI_CLIENT_PROD WHERE \$CONDITIONS" \
--optionally-enclosed-by '\"' \
--fields-terminated-by '~' \
--null-string '' \
--delete-target-dir \
--target-dir ${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_CLIENT_PROD.csv \
--driver ${SYBASE_DRIVER} \
-m 1 2>&1| tee -a ${SQOOP_LOG_FILE}

echo "####################################################"
echo "SQOOP Import Completed!" 
echo "####################################################"

##############################################
#Writing Sqoop Validation for data Import
##############################################
echo "########################################################################### " > ${JOB_VALIDATION_FILE}
echo "SQOOP Import Validation for ${SQOOP_LOG_FILE} " >> ${JOB_VALIDATION_FILE}
echo "########################################################################### ">> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "The url to track the job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Submitting tokens for job" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map input records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Map output records" >> ${JOB_VALIDATION_FILE}
cat ${SQOOP_LOG_FILE} | grep -i "Retrieved" >> ${JOB_VALIDATION_FILE}

echo "##################################################"
echo "Importing Data from HDFS to Hive Started"
echo "##################################################"

########################################################################################
# Creating Hive External Table EXT_RBI_CLIENT_PROD for the CLIENT data file
# imported using the SQOOP Script.
# Loading data from the External table to Hive Managed ORC table Destination_RBI_REF_CLIENT
########################################################################################
if [ -f EXT_RBI_CLIENT_PROD.hql ]; then
    rm EXT_RBI_CLIENT_PROD.hql
fi	
	
echo "##################################################" > EXT_RBI_CLIENT_PROD.hql
echo "# Creating External table in Hive referencing the"  >> EXT_RBI_CLIENT_PROD.hql
echo "# location of the .csv file"					 >> EXT_RBI_CLIENT_PROD.hql
echo "##################################################" >> EXT_RBI_CLIENT_PROD.hql
echo "use redi;" >> EXT_RBI_CLIENT_PROD.hql
echo "CREATE EXTERNAL TABLE IF NOT EXISTS EXT_RBI_CLIENT_PROD(" >> EXT_RBI_CLIENT_PROD.hql
echo "ClientSet	string" >> EXT_RBI_CLIENT_PROD.hql
echo ",ClientId	string" >> EXT_RBI_CLIENT_PROD.hql
echo ")" >> EXT_RBI_CLIENT_PROD.hql
echo "ROW FORMAT SERDE 'org.apache.hadoop.hive.serde2.OpenCSVSerde'" >> EXT_RBI_CLIENT_PROD.hql
echo "WITH SERDEPROPERTIES (" >> EXT_RBI_CLIENT_PROD.hql 
echo '   "separatorChar" = "~",' >> EXT_RBI_CLIENT_PROD.hql
echo '   "quoteChar"     = "\""' >> EXT_RBI_CLIENT_PROD.hql
echo ")"  >> EXT_RBI_CLIENT_PROD.hql
echo "STORED AS TEXTFILE" >> EXT_RBI_CLIENT_PROD.hql
echo "location '${HDFS_LOCATION}/${DIR_NAME}/IQ_RBI_CLIENT_PROD.csv';" >> EXT_RBI_CLIENT_PROD.hql

echo "SELECT COUNT(ClientId) FROM EXT_RBI_ClIENT_PROD;" >> EXT_RBI_CLIENT_PROD.hql

if [ ! -f EXT_RBI_CLIENT_PROD.hql ]; then
#-{
    echo "File: `pwd`/EXT_RBI_CLIENT_PROD.hql not found!"
	else
	####################################################################################################
	# Initiate the Hive shell using beeline to move data from the HDFS file location to Hive TABLE
	#hive -f EXT_RBI_CLIENT_PROD.hql
	####################################################################################################
	beeline -u ${HIVE_BEELINE_PATH} -f EXT_RBI_CLIENT_PROD.hql 2>&1| tee -a ${HIVE_LOG_FILE}
	echo "##########################################################"
	echo "Importing Data from HDFS to Hive Completed"
	echo "SQOOP Log path : `pwd`/${SQOOP_LOG_FILE}"
	echo "HIVE Log path : `pwd`/${HIVE_LOG_FILE}"
	echo "Job Validation Path : `pwd`/${JOB_VALIDATION_FILE}"
	echo "##########################################################"
#-}	
fi
